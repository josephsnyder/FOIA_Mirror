#List the files in a zip
#usage: Get-Zip c:\demo\myzip.zip
param([string]$zipFileName)
if (test-path($zipFileName)) {
	$shellApplication = new-object -com shell.application
	$zipPackage = $shellApplication.NameSpace($zipFileName)
	$zipPackage.Items() | Select Path
}
