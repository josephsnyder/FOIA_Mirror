#
# Stop a VistaWeb instance
#
param([string]$instanceName,[switch]$webOnly)

.(Resolve-Path ./core.ps1)
.(Resolve-Path ./names.ps1)

if ($webOnly) {
	Write-Host "===stop webs only==="
}

if ($instanceName -and -not($webOnly)) {
	foreach ($webName in $webList) {
		$appName = $webName + "_" + $instanceName
		if ($manager.ApplicationPools[$appName]) {
			$isStopped = (.\stopAppPoolAndWait -appPool $manager.ApplicationPools[$appName])
			Write-Host "stopped $appName = $isStopped"
		}
	}
}
else {
	foreach ($site in $manager.Sites) {
		if ($site.Name.StartsWith("vw","CurrentCultureIgnoreCase")) {
			Write-Host "stopping web " $site.Name
			$stoppedState = $site.Stop()
		}
	}
	if (-not($webOnly)) {
		foreach ($appPool in $manager.ApplicationPools) {
			if ($appPool.Name.StartsWith("vw","CurrentCultureIgnoreCase")) {
				$isStopped = (.\stopAppPoolAndWait -appPool $appPool)
				Write-Host "stopped " $appPool.Name " = $isStopped"
			}
		}
	}
}

$manager.CommitChanges()
