#
# Restart a VistaWeb instance
#
param([string]$instanceName,[switch]$webOnly)

if ($instanceName) {
	if ($webOnly) {
		.\StopVw -instanceName $instanceName -webOnly
		.\StartVw -instanceName $instanceName -webOnly
	}
	else {
		.\StopVw -instanceName $instanceName
		.\StartVw -instanceName $instanceName
	}
}
else {
	if ($webOnly) {
		.\StopVw -webOnly
		.\StartVw -webOnly
	}
	else {
		.\StopVw
		.\StartVw
	}
}
