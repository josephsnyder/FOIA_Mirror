#
#
param([string]$SourceFilePath=$(throw "-SourceFilePath <file path> must be specified"), [string]$DestRelPath=$(throw "-DestRelPath <relative file path> must be specified"), [string]$AppName=$(throw "-AppName <web instance name> must be specified"), [string]$InstanceName)

.(Resolve-Path ./core.ps1)
.(Resolve-Path ./names.ps1)

if (-not(Test-Path $SourceFilePath)) {
	throw "the -SourceFilePath parameter, $SourceFilePath , could not be found"
}

if (-not($DestRelPath.StartsWith("\") -or $DestRelPath.StartsWith("/"))) {
	$DestRelPath = "\" + $DestRelPath
}

$webSiteName = $AppName
if ($webs[$AppName]) {
	$webSiteName = $webs[$AppName]
}

if ($manager.Sites[$webSiteName]) {
	if ($webSiteName -eq $AppName) {
		if ($InstanceName) {
			$app = $manager.Sites[$webSiteName].Applications[("/"+$InstanceName)]
		}
		else {
			$app = $manager.Sites[$webSiteName].Applications[0]
		}
	}
	else {
		if ($InstanceName) {
			$app = $manager.Sites[$webSiteName].Applications[("/" + $InstanceName + "/" + $AppName)]
		}
		else {
			$app = $manager.Sites[$webSiteName].Applications[("/"+$AppName)]
		}
	}
}
else {
	write-host "web site $webSiteName is not found - no action taken"
	Exit
}

if (-not($app)) {
	Write-Host "no application found - no action taken"
	Exit
}

$destFullPath = $app.VirtualDirectories[0].PhysicalPath + $DestRelPath
if (-not(Test-Path $destFullPath)) {
	write-host "Warning: destination path not found -> $destFullPath ; writing file anyway"
}
Write-Host "copying file $SourceFilePath to $destFullPath ... " -NoNewLine
Copy-Item $SourceFilePath $destFullPath
Write-Host "done"
if ($app.ApplicationPoolName -and $manager.ApplicationPools[$app.ApplicationPoolName]) {
	write-host "recycling webs app pool " $app.ApplicationPoolName "..." -NoNewLine
	$manager.ApplicationPools[$app.ApplicationPoolName].Recycle()
	write-host "done"
}
