#
#
param([string]$InstanceName, [string]$SitesFile=$(throw "no -SitesFile specified"))

if (-not(Test-Path $SitesFile)) {
	throw "sites file $SitesFile not found"
}

.\Replace-File -SourceFilePath $SitesFile -DestRelPath "resources\xml\VhaSites.xml" -AppName "vw" -InstanceName $InstanceName
