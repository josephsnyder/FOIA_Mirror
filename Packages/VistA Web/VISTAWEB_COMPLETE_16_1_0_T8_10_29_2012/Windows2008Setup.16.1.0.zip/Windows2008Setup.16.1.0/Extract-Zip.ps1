#
#usage: Extract-Zip <path to zip> <path to destination>
#
#example: Extract-Zip c:\demo\myzip.zip c:\demo\destination
#
param([string]$zipfilename, [string] $destination)

if(test-path($zipfilename))
{	
	$shellApplication = new-object -com shell.application
	$zipPackage = $shellApplication.NameSpace($zipfilename)
	$destinationFolder = $shellApplication.NameSpace($destination)
	$destinationFolder.CopyHere($zipPackage.Items())
}