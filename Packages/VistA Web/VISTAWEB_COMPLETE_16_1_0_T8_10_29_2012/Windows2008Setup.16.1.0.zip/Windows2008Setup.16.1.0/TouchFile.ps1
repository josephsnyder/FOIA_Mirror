# Touch-File procedure for VistaWeb
#
param([string]$DestRelPath=$(throw "-DestRelPath <relative file path> must be specified"), [string]$AppName=$(throw "-AppName <web instance name> must be specified"), [string]$InstanceName)

.(Resolve-Path ./core.ps1)
.(Resolve-Path ./names.ps1)

if (-not($DestRelPath.StartsWith("\") -or $DestRelPath.StartsWith("/"))) {
	$DestRelPath = "\" + $DestRelPath
}

$webSiteName = $AppName
if ($webs[$AppName]) {
	$webSiteName = $webs[$AppName]
}

if ($manager.Sites[$webSiteName]) {
	if ($webSiteName -eq $AppName) {
		if ($InstanceName) {
			$app = $manager.Sites[$webSiteName].Applications[("/"+$InstanceName)]
		}
		else {
			$app = $manager.Sites[$webSiteName].Applications[0]
		}
	}
	else {
		if ($InstanceName) {
			$app = $manager.Sites[$webSiteName].Applications[("/" + $InstanceName + "/" + $AppName)]
		}
		else {
			$app = $manager.Sites[$webSiteName].Applications[("/"+$AppName)]
		}
	}
}
else {
	write-host "web site $webSiteName is not found - no action taken"
	Exit
}

if (-not($app)) {
	Write-Host "no application found - no action taken"
	Exit
}

$destFullPath = $app.VirtualDirectories[0].PhysicalPath + $DestRelPath
if (Test-Path $destFullPath) {
	Write-Host "touching file $destFullPath ... " -NoNewLine
	(Get-Item $destFullPath).LastWriteTime = (Get-Date)
	Write-Host "done"
}
else {
	write-host "Warning: destination path not found -> $destFullPath ; touch not done"
}
