#
#
param([string]$InstanceName, [string]$zipFile=$(Resolve-Path .\vistaweb_COMPLETE*.zip), [string]$installTargetRoot=$(Resolve-Path .), [string]$sitesFile, [string]$testInstance, [string]$db_server, [string]$db_name, [string]$db_userId, [string]$db_userPw, [string]$ipAll="*", [string]$showVersion, [string]$vistaSecPhrase, [string]$awivSecPhrase, [string]$db_server_logging, [string]$db_name_logging, [string]$db_userId_logging, [string]$db_userPw_logging)
.(Resolve-Path ./core.ps1)
.(Resolve-Path ./names.ps1)

####################################################################
## Functions
####################################################################

function GetSecureString {
	param([System.Security.SecureString]$ss)
	return [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss))
}

function SetRequireSsl {
	param([string]$webName)
	$manager.GetApplicationHostConfiguration().GetSection("system.webServer/security/access", $webName)["sslFlags"] = "Ssl"
}

function MaybeCreateDir {
	param([string]$name)
	if (-not(Test-Path $name)) {
		$newDir = (New-Item $name -type directory)
	}
}

function MaybeCreate-AppPool {
	param([string]$name, [string]$subname)
	$poolName = $name
	if ($subname) {
		$poolName += "_" + $subname
	}
	write-host "creating app pool $poolName"
	if ($manager.ApplicationPools[$poolName]) {
		write-host "app pool '$poolName' not created because it was already found"
		return
	}
	$newPool = $manager.ApplicationPools.Add($poolName)
	write-debug ".created '$poolName'"
	$newPool.ProcessModel.IdentityType = [Microsoft.Web.Administration.ProcessModelIdentityType]::ApplicationPoolIdentity
	write-debug ".identity type set"
	$newPool.ProcessModel.LoadUserProfile = $true
	write-debug ".user profile set"
	if ($appsObjects[$name]) {
		write-debug ".running app pool setup for $name"
		&$appsObjects[$name] -appPool $newPool
	}
}

function MaybeCreate-Web {
	param([string]$appName)
	$webName = $appName
	if ($webs[$appName]) {
		$webName = $webs[$appName]
	}
	if ($manager.Sites[$webName]) {
		return
	}
	if ($websObjects[$webName] -and $websObjects[$webName]["port"]) {
		$port = $websObjects[$webName]["port"]
	}
	else {
		$port = Read-Host "What port should be used for $webName ?"
		if ($port -eq $null -or $port -eq "") {
			throw "invalid port entered for $webName"
		}
	}
	$newSite = $manager.Sites.Add($webName, $emptyDirectory, $port)
	$ip = Read-Host "What IP address should be used for $webName ? [Enter nothing for '$ipAll']"
	$siteName = Read-Host "What site name should be used as the host header for this site? [Normally is blank]"
	if ($ip -eq "") {$ip=$ipAll}
	if ($websObjects[$webName] -and $websObjects[$webName]["ssl"]) {
		$protocol="https"
	}
	else {
		$protocol="http"
	}
	write-debug "creating new binding for $webName"
	$newSite.Bindings.Clear()
	$bindInfo = ($ip+":"+$port+":"+$siteName)
	if ($protocol -eq "https") {
		write-debug "trying to bind to a cert"
		$certObject = (Get-ChildItem -path cert:\LocalMachine\My -Recurse)
		if ($certObject -eq $null) {
			throw "no certs found for binding to $webName"
		}
		if ($certObject.GetType().Name -eq "X509Certificate2") {
			write-debug "found single certificate in MY collection"
			$cert = $certObject
		}
		else {
			Write-Host " "
			Write-Host "select a certificate number to use for $webName (1 - " $certObject.Count "):"
			for ($i=0;$i -lt $certObject.count;$i++) {
				Write-Host ($i+1) " " $certObject[$i].Subject
			}
			$certIndex = Read-Host "Enter a certificate number"
			$cert = $certObject[($certIndex-1)]
		}
		$newBinding = $newSite.Bindings.Add($bindInfo,$cert.GetCertHash(), "MY")
		SetRequireSsl -webName $webName
	}
	else {
		$newBinding = $newSite.Bindings.Add($bindInfo,$protocol)
	}
	write-debug $newSite.Bindings[0]
	$newSite.Applications[0].ApplicationPoolName = $defaultAppPoolName
}

function CreateWebApp {
	param([string]$appName)
	$webName = $appName
	if ($webs[$appName]) {
		$webName = $webs[$appName]
	}
	write-debug "creating app $appName in web $webName ..."
	if ($webName -eq $appName) {
		$path = ""
	}
	else {
		$path = $appName
	}
	$dirPath = $installTargetRoot + "\" + $appName
	$poolName = $appName
	if ($isNamedInstance) {
		if ($path.Length -gt 0) {
			$path = $InstanceName + "/" + $path
		}
		else {
			$path = $InstanceName
		}
		$dirPath += "\" + $InstanceName
		$poolName += "_" + $InstanceName
		$extraVirtual = "/" + $InstanceName
		if (-not($webName -eq $appName) -and -not($manager.Sites[$webName].Applications["/"].VirtualDirectories[$extraVirtual])) {
			$newVirtual = $manager.Sites[$webName].Applications["/"].VirtualDirectories.Add($extraVirtual, $emptyDirectory)
		}
	}
	$path = "/" + $path
	write-debug "APP path = $path"
	write-debug "APP dirPath = $dirPath"
	if ($manager.Sites[$webName].Applications[$path]) {
		write-debug "removing old APP"
		$manager.Sites[$webName].Applications.Remove($manager.Sites[$webName].Applications[$path])
	}
	MaybeCreateDir -name $dirPath
	write-debug "creating APP"
	$appl = $manager.Sites[$webName].Applications.Add($path, $dirPath)
	$appl.ApplicationPoolName = $poolName
}

function ChangeWebConfigFor2008 {
	param([string]$appDir)
	if (-not(Test-Path $appDir)) {
		return
	}
	$configFileName = $appDir + "\web.config"
	$config2008FileName = $appDir + "\web.2008.config"
	if (Test-Path $config2008FileName) {
		write-debug "updating web.config in $appDir"
		Copy-Item $config2008FileName $configFileName
	}
	Get-ChildItem $appDir | ?{$_.Attributes -band [IO.FileAttributes]::Directory} | ?{ChangeWebConfigFor2008 -appDir $_.FullName}
}

function InstallAppFiles {
	param([string]$appName)
	write-host "installing files for $appName..." -NoNewline
	$installPath = $installTargetRoot + "\" + $appName
	if ($isNamedInstance) {
		$installPath += "\" + $InstanceName
	}
	.\Extract-Zip (Get-ChildItem -Path ($allUnzipDir + "\vistaweb" + $websObjects[$appName]["zipAlias"] + "*.zip")).FullName $installPath
	write-host "done"
	write-host "updating common configuration in $appName..." -NoNewLine
	ChangeWebConfigFor2008 -appDir $installPath
	write-host "common configuration done"
	if (Test-Path ($installPath + "\bin\AWIVEncryption.ocx")) {
		regsvr32 /s ($installPath + "\bin\AWIVEncryption.ocx")
		write-host "registered AWIV ActiveX"
	}
}

function RunAppConfig([string]$appName) {
	if ($appConfigs[$appName]) {
		$installPath = $installTargetRoot + "\" + $appName
		if ($isNamedInstance) {
			$installPath += "\" + $InstanceName
		}
		&$appConfigs[$appName] -InstallDir $installPath
	}
}

####################################################################
## MAIN PROGRAM
####################################################################

$isNamedInstance = $true
if ($InstanceName -eq $null -or $InstanceName -eq "") {
	$isNamedInstance = $false
	$response = Read-Host "Create a single installation of VistaWeb? (Enter 'Y' to continue)"
	if (-not($response -eq "y" -or $response -eq "Y")) {
		Exit
	}
}

if ("y" -eq $testInstance.toLower() -or "n" -eq $testInstance.toLower()) {
	$isTestInstance = ($testInstance.toLower() -eq "y")
}
else {
	$isTestInstance = (Read-Host "Is this a test instance? (Enter 'Y' or 'N')").toLower() -eq "y"
}
if ($db_server -eq "") {
	$db_server = Read-Host "Enter the VistaWeb application database server name or IP"
}
if ($db_name -eq "") {
	$db_name = Read-Host "Enter the VistaWeb application database name"
}
if ($db_userId -eq "") {
	$db_userId = Read-Host "Enter the VistaWeb application database user ID"
}
if ($db_userPw -eq "") {
	$db_userPw =  GetSecureString(Read-Host "Enter the VistaWeb application database user password" -AsSecureString)
}

if ($db_server_logging -eq "") {
	$db_server_logging = Read-Host "Enter the VistaWeb logging database server name or IP, or press <enter> to use all of the application database settings"
	if ($db_server_logging -eq "") {
		$db_server_logging = $db_server
		$db_name_logging = $db_name
		$db_userId_logging = $db_userId
		$db_userPw_logging = $db_userPw
		write-debug "logging server : $db_server_logging"
		write-debug "logging db name: $db_name_logging"
		write-debug "logging userId :  $db_userId_logging"
		write-debug "logging userPw : ********"
	}
}
if ($db_name_logging -eq "") {
	$db_name_logging = Read-Host "Enter the VistaWeb logging database name"
}
if ($db_userId_logging -eq "") {
	$db_userId_logging = Read-Host "Enter the VistaWeb logging database user ID"
}
if ($db_userPw_logging -eq "") {
	$db_userPw_logging =  GetSecureString(Read-Host "Enter the VistaWeb logging database user password" -AsSecureString)
}

$emptyDirectory = $installTargetRoot + "\" + $emptyName
MaybeCreate-AppPool -name $defaultAppPoolName
MaybeCreateDir -name $emptyDirectory
$allUnzipDir = $installTargetRoot + "\" + $tempName
MaybeCreateDir -name $allUnzipDir
write-host "Deleting old files..."
Get-ChildItem $allUnzipDir | ?{!($_.Attributes -band [IO.FileAttributes]::Directory)} | Remove-Item
write-host "Unzipping VistaWeb installs..."
.\Extract-Zip $zipFile $allUnzipDir
write-host "Done unzipping main file - installing webs"

foreach ($appName in $webList) {
	MaybeCreate-AppPool -name $appName -subname $InstanceName
	MaybeCreate-Web -appName $appName
	CreateWebApp -appName $appName
	InstallAppFiles -appName $appName
}
foreach ($appName in $webList) {
	RunAppConfig -appName $appName
}
$manager.CommitChanges()
Remove-Item $allUnzipDir -Recurse
