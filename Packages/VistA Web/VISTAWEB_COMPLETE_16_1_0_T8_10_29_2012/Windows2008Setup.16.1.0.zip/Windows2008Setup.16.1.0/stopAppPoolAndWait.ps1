#
# Call Stop() on an application pool and wait up to 90 seconds for the state to change to "stopped"
#
param([Microsoft.Web.Administration.ApplicationPool]$appPool)
if (-not($appPool)) {
	return $true
}
if (($appPool.State -ne [Microsoft.Web.Administration.ObjectState]::Stopped) -and
	($appPool.State -ne [Microsoft.Web.Administration.ObjectState]::Stopping)) {
	$stopState = $appPool.Stop()
}
$appPoolWaitCount = 0
while (($appPool.State -ne [Microsoft.Web.Administration.ObjectState]::Stopped) -and
		($appPoolWaitCount -lt 90)) {
	Write-Host "." -NoNewLine
	$appPoolWaitCount++
	[System.Threading.Thread]::Sleep(1000)
}

return ($appPool.State -eq [Microsoft.Web.Administration.ObjectState]::Stopped)
