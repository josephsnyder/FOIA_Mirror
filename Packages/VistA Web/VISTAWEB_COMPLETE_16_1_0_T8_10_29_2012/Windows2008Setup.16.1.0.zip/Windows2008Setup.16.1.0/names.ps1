$vw_web = @{
	"ssl"=$true;
	"port"=443;
	"zipAlias"="emr";
}

$vwContext_web = @{
	"ssl"=$false;
	"zipAlias"="context";
}

$vwEncrypt_web = @{
	"ssl"=$false;
	"zipAlias"="vwEncrypt";
}

$vw_app = {
	param([Microsoft.Web.Administration.ApplicationPool]$appPool)
	$appPool.Failure.RapidFailProtection=$false
	$appPool.Recycling.PeriodicRestart.Schedule.Clear()
	$appPool.Recycling.PeriodicRestart.Time = new-object TimeSpan(0,0,0)
	$resetTime = new-object TimeSpan(22,0,0)
	$newSchedule = $appPool.Recycling.PeriodicRestart.Schedule.Add($resetTime)
}

$vwContext_app = {
	param([Microsoft.Web.Administration.ApplicationPool]$appPool)
	$appPool.ProcessModel.MaxProcesses=2
	$appPool.Recycling.PeriodicRestart.Schedule.Clear()
	$appPool.Recycling.PeriodicRestart.Time = new-object TimeSpan(0,0,0)
	$resetTime = new-object TimeSpan(22,0,0)
	$newSchedule = $appPool.Recycling.PeriodicRestart.Schedule.Add($resetTime)
}

$vwEncrypt_app = {
	param([Microsoft.Web.Administration.ApplicationPool]$appPool)
	$appPool["enable32BitAppOnWin64"]=$true;
	$appPool.ProcessModel.MaxProcesses=2
	$appPool.Recycling.PeriodicRestart.Schedule.Clear()
	$appPool.Recycling.PeriodicRestart.Time = new-object TimeSpan(0,0,0)
	$resetTime = new-object TimeSpan(22,0,0)
	$newSchedule = $appPool.Recycling.PeriodicRestart.Schedule.Add($resetTime)
}

$webs=@{"vw"=$null;"vwContext"=$null;"vwEncrypt"="vwMeans";}
$webList=("vw","vwContext","vwEncrypt")

$websObjects=@{
	"vw"=$vw_web;
	"vwContext"=$vwContext_web;
	"vwEncrypt"=$vwEncrypt_web;
}

$appsObjects=@{
	"vw"=$vw_app;
	"vwContext"=$vwContext_app;
	"vwEncrypt"=$vwEncrypt_app;
}

$defaultAppPoolName = "vw_default"
$emptyName = "empty"
$tempName = "temp"

function UpdateLog4Net {
	param([string]$logXmlName)
	if (-not(Test-Path $logXmlName)) {
		return
	}
	$logXml = New-Object XML
	$logXml.Load($logXmlName)
	$logXml.SelectNodes("/log4net/appender[@type='log4net.Appender.AdoNetAppender']/connectionString") | % {$_.SetAttribute("value","Server=$db_server_logging;Database=$db_name_logging;integrated security=false;persist security info=True;User ID=$db_userId_logging;Password=$db_userPw_logging")}
	$logXml.SelectNodes("/log4net/root/appender-ref[ref='fileAppender']") | % {$_.SetAttribute("ref", "adoNetAppender")}
	$logXml.Save($logXmlName)
}

$vw_config = {
	param([string]$InstallDir)
	$configFileName = $InstallDir + "\web.config"
	$configXml = New-Object XML
	$configXml.Load($configFileName)
	if ("y" -eq $showVersion.toLower() -or "n" -eq $showVersion.toLower()) {
		$isFullVersionShown = ("y" -eq $showVersion.toLower())
	}
	else {
		$isFullVersionShown = (Read-Host "Show full version number?").toLower() -eq "y"
	}
	if ($vistaSecPhrase) {
		$bse_vwSp = $vistaSecPhrase
	}
	else {
		$bse_vwSp = Read-Host "Enter the VistaWeb security phrase"
	}
	if ($awivSecPhrase) {
		$bse_awivSp = $awivSecPhrase
	}
	else {
		$bse_awivSp = Read-Host "Enter the AWIV security phrase:"
	}
	$configXml.SelectNodes("/configuration/appSettings/add[@key='allowViewLog']") | % {$_.SetAttribute("value","false")}
	$configXml.SelectNodes("/configuration/daoConfig/add[@key='protocol_CDS.chemHemExcluded']") | % {$_.SetAttribute("value","true")}
	$configXml.SelectNodes("/configuration/userActivity/add[@key='userActivity.logStats']") | % {$_.SetAttribute("value","true")}
	$configXml.SelectNodes("/configuration/page/add[@key='page.useFullVersion']") | % {$_.SetAttribute("value",($isFullVersionShown.toString().toLower()))}
	$configXml.SelectNodes("/configuration/page/add[@key='vistaConnection.securityPhrase' or @key='fhieConnection.securityPhrase']") | % {$_.SetAttribute("value",$bse_vwSp)}
	$configXml.SelectNodes("/configuration/page/add[@key='awiv.securityPhrase']") | % {$_.SetAttribute("value",$bse_awivSp)}
	$configXml.SelectNodes("/configuration/userActivity/add[@key='userActivity.connectionString']") | % {$_.SetAttribute("value","Server=$db_server;Database=$db_name;User ID=$db_userId;Password=$db_userPw;persist security info=True;packet size=4096;Connect Timeout=2;Min Pool Size=5;Max Pool Size=500")}
	$configXml.SelectNodes("/configuration/userActivity/add[@key='userActivity.altConnectionString']") | % {$_.SetAttribute("value","Server=$db_server;Database=$db_name;User ID=$db_userId;Password=$db_userPw;persist security info=True;packet size=4096;Connect Timeout=30;Pooling=false")}
	if ($isTestInstance) {
		$caipConfig = "/resources/xml/caipConfig_sqa.xml"
	}
	else {
		$caipConfig = "/resources/xml/caipConfig_production.xml"
	}
	$configXml.SelectNodes("/configuration/appSettings/add[@key='caipConfigFile']") | % {$_.SetAttribute("value",$caipConfig)}

	if ($manager.Sites["vwMeans"].Bindings[0].Host) {
		$serverName = $manager.Sites["vwMeans"].Bindings[0].Host
	}
	else {
		if ($manager.sites["vwMeans"].bindings[0].endpoint.address.address -eq 0) {
			$serverName = "LocalHost"
		}
		else {
			$serverName = $manager.sites["vwMeans"].bindings[0].endpoint.address.ToString()
		}
	}

	$encryptUrl = $manager.sites["vwMeans"].bindings[0].protocol + "://" + $serverName + ":" + $manager.sites["vwMeans"].bindings[0].endpoint.port
	if ($isNamedInstance) {
		$encryptUrl += "/" + $InstanceName
	}
	$encryptUrl += "/vwEncrypt/awivEncryptionSvc.asmx"
	$configXml.SelectNodes("/configuration/page/add[@key='awiv.cryptoServiceUri']") | % {$_.SetAttribute("value",$encryptUrl)}

	$configXml.Save($configFileName)
	
	if (Test-Path $sitesFile) {
		Copy-Item $sitesFile ($InstallDir + "\resources\xml\VhaSites.xml")
	}
	
	UpdateLog4Net -logXmlName ($InstallDir + "\resources\xml\log4net.xml")
}

$vwContext_config = {
	param([string]$InstallDir)
	$configFileName = $InstallDir + "\web.config"
	$configXml = New-Object XML
	$configXml.Load($configFileName)
	$configXml.SelectNodes("//*[@name='connectionString']") | % {$_.SetAttribute("value","Server=$db_server;Database=$db_name;User ID=$db_userId;Password=$db_userPw;Min Pool Size=5;Max Pool Size=500;Pooling=true;Connect Timeout=2;persist security info=True;")}
	$configXml.SelectNodes("//*[@name='altConnectionString']") | % {$_.SetAttribute("value","Server=$db_server;Database=$db_name;User ID=$db_userId;Password=$db_userPw;Pooling=false;Connect Timeout=30;persist security info=True;")}
	$configXml.Save($configFileName)
	UpdateLog4Net -logXmlName ($InstallDir + "\resources\xml\log4net.xml")
}

$vwEncrypt_config = {
	param([string]$InstallDir)
	UpdateLog4Net -logXmlName ($InstallDir + "\resources\xml\log4net.xml")
}

$appConfigs=@{
	"vw"=$vw_config;
	"vwContext"=$vwContext_config;
	"vwEncrypt"=$vwEncrypt_config;
}
