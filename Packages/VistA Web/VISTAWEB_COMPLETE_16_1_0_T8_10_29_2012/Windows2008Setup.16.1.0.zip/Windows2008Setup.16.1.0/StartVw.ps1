#
# Start a VistaWeb instance
#
param([string]$instanceName,[switch]$webOnly)

.(Resolve-Path ./core.ps1)
.(Resolve-Path ./names.ps1)

if ($webOnly) {
	Write-Host "===start webs only==="
}

if (-not($webOnly) -and
	$manager.ApplicationPools[$defaultAppPoolName] -and 
	$manager.ApplicationPools[$defaultAppPoolName].State -ne [Microsoft.Web.Administration.ObjectState]::Started -and
	$manager.ApplicationPools[$defaultAppPoolName].State -ne [Microsoft.Web.Administration.ObjectState]::Starting) {
	Write-Host "starting $defaultAppPoolName "
	$startState = $manager.ApplicationPools[$defaultAppPoolName].Start()
}

if ($instanceName -and -not($webOnly)) {
	foreach ($webName in $webList) {
		$appName = $webName + "_" + $instanceName
		if ($manager.ApplicationPools[$appName]) {
			if ($manager.ApplicationPools[$appName].State -ne [Microsoft.Web.Administration.ObjectState]::Started -and
				$manager.ApplicationPools[$appName].State -ne [Microsoft.Web.Administration.ObjectState]::Starting) {
				Write-Host "starting " $manager.ApplicationPools[$appName].Name
				$startState = $manager.ApplicationPools[$appName].Start()
			}
		}
	}
}
else {
	if (-not($webOnly)) {
		foreach ($appPool in $manager.ApplicationPools) {
			if ($appPool.Name.StartsWith("vw","CurrentCultureIgnoreCase")) {
				if ($appPool.State -ne [Microsoft.Web.Administration.ObjectState]::Started -and
					$appPool.State -ne [Microsoft.Web.Administration.ObjectState]::Starting) {
					Write-Host "starting " $appPool.Name
					$startState = $appPool.Start()
				}
			}
		}
	}
	foreach ($site in $manager.Sites) {
		if ($site.Name.StartsWith("vw","CurrentCultureIgnoreCase")) {
			Write-Host "starting web " $site.Name
			$startState = $site.Start()
		}
	}
}

$manager.CommitChanges()
