#
$loadResults = [System.Reflection.Assembly]::LoadFrom( "C:\windows\system32\inetsrv\Microsoft.Web.Administration.dll" )
$manager = new-object Microsoft.Web.Administration.ServerManager
