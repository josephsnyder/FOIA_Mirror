#
param([string]$InstanceName)
.(Resolve-Path ./names.ps1)
.(Resolve-Path ./core.ps1)

####################################################################
## Functions
####################################################################

function Stop-Web {
	param([string]$name)
	Write-Host "stopping $name " -NoNewline
	if ($manager.Sites[$name]) {
		$manager.Sites[$name].Stop()
	}
	else {
		Write-Host "-not found"
	}
}

function Stop-AllVwWebs {
	Write-Host "attempting to stop " $webs.count "webs..."
	foreach ($appName in $webList) {
		$webName = $appName
		if ($webs[$appName]) {
			$webName = $webs[$appName]
		}
		Stop-Web -name $webName
		if ($manager.ApplicationPools[$appName]) {
			write-host "stopping app pool $appName ..." -NoNewLine
			$stopResult = (.\stopAppPoolAndWait -appPool $manager.ApplicationPools[$appName])
			write-host "stopped = $stopResult"
		}
	}
}

function Delete-AnyVwApps {
	$pathList=@()
	write-debug "collecting apps & folders to remove"
	foreach ($appName in $webList) {
		$appList=@()
		$webName = $appName
		$webAppName = "/" + $InstanceName
		if ($webs[$appName]) {
			$webName = $webs[$appName]
			$webAppName += "/" + $appName
		}
		write-debug "looking for app $webAppName in web $webName"
		if ($manager.Sites[$webName]) {
			foreach ($app in $manager.Sites[$webName].Applications) {
				write-debug ("$webName has app " + $app.Path)
				if ($app.Path -eq $webAppName) {
					foreach ($virtual in $app.virtualDirectories) {
						$pathList += $virtual.physicalPath
					}
					$appList += $app
				}
				if ($app.Path -eq "/" -and $app.VirtualDirectories[("/"+$InstanceName)]) {
					$app.VirtualDirectories.Remove($app.VirtualDirectories[("/"+$InstanceName)])
				}
			}
		}
		if ($appList.count -gt 0) {
			write-host "deleting " $appList.count " apps from " $webName "..."
			foreach ($app in $appList) {
				write-host " " $app.path
				$manager.Sites[$webName].Applications.Remove($app)
			}
			$manager.CommitChanges()
		}
	}
	if ($pathList.count -gt 0) {
		write-host "deleting folders under " $webName
		foreach ($dir in $pathList) {
			if (Test-Path $dir) {
				Remove-Item $dir -Recurse
			}
			$parentDirPath = $dir.substring(0,$dir.LastIndexOf("\"))
			if (-not(Resolve-Path ($parentDirPath+"\*"))) {
				Remove-Item $parentDirPath
			}
		}
	}
}

function Delete-AllVwWebs {
	$dirList = @()
	foreach ($appName in $webList) {
		$webName = $appName
		if ($webs[$appName]) {
			$webName = $webs[$appName]
		}
		if ($manager.Sites[$webName]) {
			foreach ($app in $manager.Sites[$webName].Applications) {
				foreach ($virtual in $app.VirtualDirectories) {
					$dirList += $virtual.PhysicalPath
				}
			}
			$site = $manager.Sites[$webName]
			write-host "deleting site $webName"
			$manager.Sites.Remove($site)
			$manager.CommitChanges()
		}
	}
	if ($dirList.Count -gt 0) {
		write-host "deleting " $dirList.Count " directories"
		foreach ($dirName in $dirList) {
			Unregister-AwivComponent -dir $dirName
			Remove-Item $dirName
		}
	}
}

function Delete-AllVwAppPools {
	foreach ($appName in $webList) {
		$poolName = ($appName + "_" + $InstanceName)
		if ($manager.ApplicationPools[$poolName]) {
			write-host "deleting app pool $poolName"
			$manager.ApplicationPools.Remove($manager.ApplicationPools[$poolName])
		}
	}
	$manager.CommitChanges()
}

function Delete-AllVwPools {
	foreach ($webName in $webList) {
		if ($manager.ApplicationPools[$webName]) {
			write-host "deleting app pool $webName"
			$manager.ApplicationPools.Remove($manager.ApplicationPools[$webName])
		}
	}
	if ($manager.ApplicationPools[$defaultAppPoolName]) {
		write-host "deleting app pool $defaultAppPoolName"
		$manager.ApplicationPools.Remove($manager.ApplicationPools[$defaultAppPoolName])
	}
	$manager.CommitChanges()
}

function Unregister-AwivComponent {
	param([string]$dir)
	Get-ChildItem -Path d:\data\vwInstall -Recurse -Include awiv*.ocx | % {
		write-host ("attempting to unregister ActiveX control " + $_.fullName)
		regsvr32 /u $_.fullName
	}
}

function Stop-AllVwAppPools([string]$name) {
	foreach ($appName in $webList) {
		$poolName = $appName + "_" + $name
		write-host "stopping pool $poolName..." -NoNewline
		if ($manager.ApplicationPools[$poolName]) {
			$stopMessage = (.\stopAppPoolAndWait -appPool $manager.ApplicationPools[$poolName])
			write-host "stopped $poolName = $stopMessage"
		}
		else {
			write-host "not found"
		}
	}
}

function Maybe-DeleteEmptyWebs {
	foreach ($appName in $webList) {
		$webName = $appName
		if ($webs[$appName]) {
			$webName = $webs[$appName]
		}
		if ($manager.Sites[$webName]) {
			if ($manager.Sites[$webName].Applications.Count -gt 1) {
				return
			}
		}
	}
	write-host "==removing empty webs=="
	foreach ($appName in $webList) {
		$webName = $appName
		if ($webs[$appName]) {
			$webName = $webs[$appName]
		}
		if ($manager.Sites[$webName]) {
			write-host "removing $webName ..." -NoNewline
			$stopMessage = $manager.Sites[$webName].Stop()
			write-host $stopMessage "... " -NoNewLine
			$manager.Sites.Remove($manager.Sites[$webName])
			write-host "removed"
		}
	}
	$manager.CommitChanges()
	if ($manager.ApplicationPools[$defaultAppPoolName]) {
		write-host "removing default appPool ( $defaultAppPoolName )..." -NoNewline
		$manager.ApplicationPools.Remove($manager.ApplicationPools[$defaultAppPoolName])
		$manager.CommitChanges()
		write-host "done"
	}
}

####################################################################
## MAIN PROGRAM
####################################################################
write-debug "instance name is $InstanceName"

$all = $false
if ($InstanceName.trim().length -lt 1) {
	$response = Read-Host "Are you sure you want to delete ALL VistaWeb instances (Y or N)?"
	if (-not($response.ToUpper() -eq "Y")) {
		Exit
	}
	$all=$true
}

write-debug "processing all? $all"
if ($all) {
	Stop-AllVwWebs
	Delete-AllVwWebs
	Delete-AllVwPools
}
else {
	Stop-AllVwAppPools -name $InstanceName
	Delete-AnyVwApps
	Delete-AllVwAppPools -name $InstanceName
	Maybe-DeleteEmptyWebs
}

