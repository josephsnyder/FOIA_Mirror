// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

//#if !defined(AFX_STDAFX_H__FCB46FFB_7753_434D_AAA2_407842BF7805__INCLUDED_)
//#define AFX_STDAFX_H__FCB46FFB_7753_434D_AAA2_407842BF7805__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NUM_ARGS	2
#define MAX_ABSTRACT_ROWS	189
#define MAX_ABSTRACT_COLUMNS	121

#include <stdlib.h>		/* Needed for MAX_PATH */

#if (_MSC_VER >= 1000)
#pragma warning (disable : 4214 4201 4115 4514)
#endif

#if (_MSC_VER >= 1000)
#pragma warning (default : 4214 4201 4115)
#endif

#include <windows.h>
#include <string.h>		
#include <stdio.h>		
#include <commdlg.h>
#include <iostream.h>	

#include "C:\program files\accusoft\imagegear v15\md\dll\include\gear.h"		/* Include for AccuSoft Image Gear */

#include "C:\program files\accusoft\imagegear v15\md\dll\include\i_med.h"		/* Header for Medical Extension API	*/

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

//#endif // !defined(AFX_STDAFX_H__FCB46FFB_7753_434D_AAA2_407842BF7805__INCLUDED_)
