/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */

namespace DicomImporter.ViewModels
{
    using System;
    using System.Collections.ObjectModel;

    using DicomImporter.Common.Exceptions;
    using DicomImporter.Common.Interfaces.DataSources;
    using DicomImporter.Common.Model;
    using DicomImporter.Common.View;
    using DicomImporter.Common.ViewModel;

    using ImagingClient.Infrastructure.DialogService;
    using ImagingClient.Infrastructure.Exceptions;
    using ImagingClient.Infrastructure.Views;

    using Microsoft.Practices.Prism.Commands;
    using Microsoft.Practices.Prism.Regions;

    /// <summary>
    /// The create new radiology order view model.
    /// </summary>
    public class CreateNewRadiologyOrderViewModel : ImporterReconciliationViewModel
    {
        #region Constants and Fields

        /// <summary>
        /// The cached ordering location.
        /// </summary>
        private static OrderingLocation cachedOrderingLocation;

        /// <summary>
        /// The cached ordering provider.
        /// </summary>
        private static OrderingProvider cachedOrderingProvider;


        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateNewRadiologyOrderViewModel"/> class.
        /// </summary>
        /// <param name="dialogService">
        /// The dialog service.
        /// </param>
        /// <param name="dicomImporterDataSource">
        /// The dicom importer data source.
        /// </param>
        public CreateNewRadiologyOrderViewModel(
            IDialogService dialogService, IDicomImporterDataSource dicomImporterDataSource)
        {
            this.DialogService = dialogService;
            this.DicomImporterDataSource = dicomImporterDataSource;

            this.DisplayExistingOrderControls = true;

            this.NavigateForward = new DelegateCommand<object>(
                o =>
                    {
                        if (this.CurrentReconciliation.Order == null)
                        {
                            string message = "You must select or create an order before proceeding.";
                            string caption = "No Order Selected or Created";
                            this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Error);
                        }
                        else
                        {
                            this.NavigateWorkItem(ViewNames.ReconciliationSummaryView);
                        }
                    }, 
                o => this.ValidateForm());

            this.NavigateBack =
                new DelegateCommand<object>(
                    o =>
                    this.NavigateWorkItem(
                        this.HasAdministratorKey ? ViewNames.SelectOrderTypeView : ViewNames.PatientSelectionView));

            this.CancelReconciliationCommand = new DelegateCommand<object>(
                o => this.CancelReconciliation());
        }

        #endregion

        #region Delegates

        /// <summary>
        /// The initialize procedure modifiers event handler.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        public delegate void InitializeProcedureModifiersEventHandler(object sender, EventArgs e);

        /// <summary>
        /// The refresh selected procedure modifiers event handler.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        public delegate void RefreshSelectedProcedureModifiersEventHandler(object sender, EventArgs e);

        #endregion

        #region Public Events

        /// <summary>
        /// The initialize procedure modifiers.
        /// </summary>
        public event InitializeProcedureModifiersEventHandler InitializeProcedureModifiers;

        /// <summary>
        /// The refresh selected procedure modifiers.
        /// </summary>
        public event RefreshSelectedProcedureModifiersEventHandler RefreshSelectedProcedureModifiers;

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets a value indicating whether AnyProcedureModifiersAvailable.
        /// </summary>
        public bool AnyProcedureModifiersAvailable
        {
            get
            {
                Order order = this.CurrentReconciliation.Order;
                if (order != null && order.IsToBeCreated)
                {
                    if (order.ProcedureModifiers != null && 
                        order.ProcedureModifiers.Count > 0)
                    {
                        return true;
                    }

                    if (order.Procedure != null && 
                        order.Procedure.ProcedureModifiers != null && 
                        order.Procedure.ProcedureModifiers.Count > 0)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether DisplayExistingOrderControls.
        /// </summary>
        public bool DisplayExistingOrderControls { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether DisplayOrderCreationControls.
        /// </summary>
        public bool DisplayOrderCreationControls { get; set; }

        /// <summary>
        /// Gets or sets NavigateBack.
        /// </summary>
        public DelegateCommand<object> NavigateBack { get; set; }

        /// <summary>
        /// Gets or sets NavigateForward.
        /// </summary>
        public DelegateCommand<object> NavigateForward { get; set; }

        /// <summary>
        /// Gets or sets ProcedureModifiers.
        /// </summary>
        public ObservableCollection<ProcedureModifier> ProcedureModifiers { get; set; }

        /// <summary>
        /// Gets or sets Procedures.
        /// </summary>
        public ObservableCollection<Procedure> Procedures { get; set; }

        /// <summary>
        /// Gets or sets SelectedOrderingLocation.
        /// </summary>
        public OrderingLocation SelectedOrderingLocation
        {
            get
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    return this.CurrentReconciliation.Order.OrderingLocation;
                }

                return null;
            }

            set
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    this.CurrentReconciliation.Order.OrderingLocation = value;
                    this.CurrentReconciliation.Order.OrderingLocationIen = value.Id;
                    this.RaisePropertyChanged("SelectedOrderingLocation");
                    this.NavigateForward.RaiseCanExecuteChanged();

                    // Save the value to app config for next time...
                    cachedOrderingLocation = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets SelectedOrderingProvider.
        /// </summary>
        public OrderingProvider SelectedOrderingProvider
        {
            get
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    return this.CurrentReconciliation.Order.OrderingProvider;
                }

                return null;
            }

            set
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    this.CurrentReconciliation.Order.OrderingProvider = value;
                    this.RaisePropertyChanged("SelectedOrderingProvider");
                    this.NavigateForward.RaiseCanExecuteChanged();

                    // Save the value to app config for next time...
                    if (value != null)
                    {
                        cachedOrderingProvider = value;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets SelectedProcedure.
        /// </summary>
        public Procedure SelectedProcedure
        {
            get
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    return this.CurrentReconciliation.Order.Procedure;
                }

                return null;
            }

            set
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    this.CurrentReconciliation.Order.Procedure = value;
                    this.SelectedProcedureModifiers = null;
                    this.InitializeProcedureModifiers(this, null);
                    this.RaisePropertyChanged("AnyProcedureModifiersAvailable");
                    this.NavigateForward.RaiseCanExecuteChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets SelectedProcedureModifiers.
        /// </summary>
        public ObservableCollection<ProcedureModifier> SelectedProcedureModifiers
        {
            get
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    return this.CurrentReconciliation.Order.ProcedureModifiers;
                }

                return null;
            }

            set
            {
                if (this.CurrentReconciliation.Order != null && this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    this.CurrentReconciliation.Order.ProcedureModifiers = value;
                    this.RaisePropertyChanged("SelectedProcedureModifier");
                    this.RaisePropertyChanged("AnyProcedureModifiersAvailable");
                }
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// The on navigated to.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                base.OnNavigatedTo(navigationContext);

                try
                {
                    // Load the lookup tables
                    this.Procedures = this.DicomImporterDataSource.GetProcedureList(true);
                }
                catch (ServerException se)
                {
                    if (se.ErrorCode.Equals(ImporterErrorCodes.OutsideLocationConfigurationErrorCode))
                    {
                        // Show the error, cancel the work Item, and navigate back to the Home view
                        this.ShowOutsideLocationErrorAndCancelWorkItem();
                        
                        // Return from OnNavigatedTo
                        return;
                    }
                    else
                    {
                        throw;
                    }
                }

                // If we are toggling here from the Existing orders screen, we need to intialize
                // with a new order. 
                if (this.CurrentReconciliation.Order == null || !this.CurrentReconciliation.Order.IsToBeCreated)
                {
                    this.CurrentReconciliation.Order = new Order { Specialty = "RAD", IsToBeCreated = true, ExamStatus = string.Empty };

                    // Try to set the ordering location and provider if we have default values for them
                    this.SetDefaultOrderingLocation();
                    this.SetDefaultOrderingProvider();

                    // Clear out the SelectedProcedure
                    this.SelectedProcedure = null;

                    // Reset to "read by VA radiologist" as the default
                    this.CurrentReconciliation.IsStudyToBeReadByVaRadiologist = true;

                    // Reinitialize Procedure Modifiers
                    this.RefreshSelectedProcedureModifiers(this, null);
                }

                this.RefreshSelectedProcedureModifiers(this, null);
            }
            catch (Exception e)
            {
                var window = new ExceptionWindow(e);
                window.ShowDialog();
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The set default ordering location.
        /// </summary>
        private void SetDefaultOrderingLocation()
        {
            if (cachedOrderingLocation != null)
            {
                this.SelectedOrderingLocation = cachedOrderingLocation;
            }
        }

        /// <summary>
        /// The set default ordering provider.
        /// </summary>
        private void SetDefaultOrderingProvider()
        {
            if (cachedOrderingProvider != null)
            {
                this.SelectedOrderingProvider = cachedOrderingProvider;
            }
        }

        /// <summary>
        /// Validates the form.
        /// </summary>
        /// <returns>
        /// Returns <c>true</c> if the form is valid, otherwise false.
        /// </returns>
        private bool ValidateForm()
        {
            // Have to have a reconciliation ...
            if (this.CurrentReconciliation == null)
            {
                return false;
            }

            Order order = this.CurrentReconciliation.Order;

            // Have to have an order...
            if (order == null)
            {
                return false;
            }

            // Have to have an Ordering Provider
            if (order.OrderingProvider == null)
            {
                return false;
            }

            // Have to have an Ordering Location
            if (order.OrderingLocation == null)
            {
                return false;
            }

            // Have to have a Procedure
            if (order.Procedure == null)
            {
                return false;
            }

            return true;
        }

        #endregion
    }
}