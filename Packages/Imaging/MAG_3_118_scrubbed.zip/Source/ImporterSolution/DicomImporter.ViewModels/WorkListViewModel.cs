/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */

using DicomImporter.Common.Services;
using ImagingClient.Infrastructure.StorageDataSource;

namespace DicomImporter.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;

    using DicomImporter.Common.Exceptions;
    using DicomImporter.Common.Interfaces.DataSources;
    using DicomImporter.Common.Model;
    using DicomImporter.Common.View;
    using DicomImporter.Common.ViewModel;

    using ImagingClient.Infrastructure.DialogService;
    using ImagingClient.Infrastructure.Exceptions;
    using ImagingClient.Infrastructure.Views;

    using log4net;

    using Microsoft.Practices.Prism.Commands;
    using Microsoft.Practices.Prism.Regions;

    /// <summary>
    /// The work list view model.
    /// </summary>
    public class WorkListViewModel : ImporterViewModel
    {
        #region Constants and Fields

        /// <summary>
        /// The logger.
        /// </summary>
        private static readonly ILog Logger = LogManager.GetLogger(typeof(WorkListViewModel));

        /// <summary>
        /// The all sources.
        /// </summary>
        private const string AllSources = "All Sources";

        /// <summary>
        /// The Logged in as CSRA message.
        /// </summary>
        private const string LoggedInAsCSRAMessage = "You are currently logged in as a Contracted Studies User. Only Fee Basis work items are available for reconciliation.";

        /// <summary>
        /// The no items available message.
        /// </summary>
        private const string NoItemsAvailableMessage = "No importer items are currently available for reconciliation.";

        /// <summary>
        /// The no items found caption.
        /// </summary>
        private const string NoItemsFoundCaption = "No Importer Items Found";

        /// <summary>
        /// The no search items found message.
        /// </summary>
        private const string NoSearchItemsFoundMessage = "No importer items were found matching your filter criteria...";

        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="WorkListViewModel"/> class.
        /// </summary>
        /// <param name="dialogService">
        /// The dialog service.
        /// </param>
        /// <param name="importerDialogService">
        /// The importer dialog service.
        /// </param>
        /// <param name="dicomImporterDataSource">
        /// The dicom importer data source.
        /// </param>
        /// <param name="storageDataSource">
        /// The storage data source.
        /// </param>
        public WorkListViewModel(IDialogService dialogService, IImporterDialogService importerDialogService, IDicomImporterDataSource dicomImporterDataSource, IStorageDataSource storageDataSource)
        {
            this.DialogService = dialogService;
            this.DicomImporterDataSource = dicomImporterDataSource;
            this.ImporterDialogService = importerDialogService;
            this.StorageDataSource = storageDataSource;

            // Navigate to the Study List view, passing in the workitem key
            this.NavigateToStudyListViewCommand = new DelegateCommand<object>(
                o => this.NavigateToStudyListView(), o => (this.SelectedWorkItem != null));

            this.DeleteImportItemCommand = new DelegateCommand<object>(
                o => this.DeleteImportItem(), o => (this.SelectedWorkItem != null));

            this.NavigateToImporterHomeViewCommand =
                new DelegateCommand<object>(o => this.NavigateMainRegionTo(ViewNames.ImporterHomeView));

            this.ApplyFilterCommand = new DelegateCommand<object>(o => this.ApplyFilter());
            this.ResetFilterCommand = new DelegateCommand<object>(o => this.ResetFilter());
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets ApplyFilterCommand.
        /// </summary>
        public DelegateCommand<object> ApplyFilterCommand { get; set; }

        /// <summary>
        /// Gets or sets DeleteImporterItem.
        /// </summary>
        public DelegateCommand<object> DeleteImportItemCommand { get; set; }

        /// <summary>
        /// Gets or sets NavigateToImporterHomeView.
        /// </summary>
        public DelegateCommand<object> NavigateToImporterHomeViewCommand { get; set; }

        /// <summary>
        /// Gets or sets NavigateToStudyListView.
        /// </summary>
        public DelegateCommand<object> NavigateToStudyListViewCommand { get; set; }

        /// <summary>
        /// Gets or sets DeleteImporterItem.
        /// </summary>
        public string UserRoleMessage { get; set; }

        /// <summary>
        /// Gets or sets PatientNameFilter.
        /// </summary>
        public string PatientNameFilter { get; set; }

        /// <summary>
        /// Gets or sets ResetFilterCommand.
        /// </summary>
        public DelegateCommand<object> ResetFilterCommand { get; set; }

        /// <summary>
        /// Gets or sets SelectedWorkItem.
        /// </summary>
        public ImporterWorkItem SelectedWorkItem
        {
            get
            {
                return this.WorkItem;
            }

            set
            {
                this.WorkItem = value;
                this.NavigateToStudyListViewCommand.RaiseCanExecuteChanged();
                this.DeleteImportItemCommand.RaiseCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether ShowActiveWorkItems.
        /// </summary>
        public bool ShowActiveWorkItems { get; set; }

        /// <summary>
        /// Gets or sets SourceFilter.
        /// </summary>
        public string SourceFilter { get; set; }

        /// <summary>
        /// Gets or sets Sources.
        /// </summary>
        public ObservableCollection<string> Sources { get; set; }

        /// <summary>
        /// Gets or sets WorkItemSubtypeFilter.
        /// </summary>
        public ImporterWorkItemSubtype WorkItemSubtypeFilter { get; set; }

        /// <summary>
        /// Gets or sets WorkItemSubtypes.
        /// </summary>
        public ObservableCollection<ImporterWorkItemSubtype> WorkItemSubtypes { get; set; }

        /// <summary>
        /// Gets or sets WorkItems.
        /// </summary>
        public ObservableCollection<ImporterWorkItem> WorkItems { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// The on navigated to.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            base.OnNavigatedTo(navigationContext);

            try
            {
                // Display an informational message if the user is logged in as a CSRA
                if (HasContractedStudiesKey && !HasAdministratorKey)
                {
                    this.UserRoleMessage = LoggedInAsCSRAMessage;
                }

                var filter = new ImporterWorkItemFilter { Status = ImporterWorkItemStatuses.New };

                this.AddFeeOriginFilterIfNecessary(filter);

                this.WorkItems = this.DicomImporterDataSource.GetWorkItemList(filter);

                this.WorkItemSubtypes = ImporterWorkItemSubtype.GetAllSubtypes();
                this.WorkItemSubtypeFilter = this.WorkItemSubtypes[0];

                // This is a hack for now. Should replace with a custom RPC call
                this.GetAndBindSources(filter);

                this.ShowActiveWorkItems = true;

                if (this.WorkItems == null || this.WorkItems.Count == 0)
                {
                    this.DialogService.ShowAlertBox(
                        this.UIDispatcher, NoItemsAvailableMessage, NoItemsFoundCaption, MessageTypes.Info);
                }
            }
            catch (Exception e)
            {
                var window = new ExceptionWindow(e);
                window.ShowDialog();
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Navigates to study list view.
        /// </summary>
        private void NavigateToStudyListView()
        {
            string originalStatus = this.SelectedWorkItem.Status;

            // Try to transition the work item if possible
            try
            {
                // Using the id, get the full workItem and transition it to InReconciliation
                this.WorkItem = this.DicomImporterDataSource.GetAndTranstionImporterWorkItem(
                    this.SelectedWorkItem, this.SelectedWorkItem.Status, ImporterWorkItemStatuses.InReconciliation);
            }
            catch (ServerException se)
            {
                // Handle the server exception and then return. Note that if it's not one of the know exceptions we handle, 
                // the exception will be rethrown, to be handled by the general exception handler
                this.HandleServerException(se);
                return;
            }

            // If we get here and neither the work item or the work item details are null, we're successful. Continue on.
            // Otherwise, warn the user that the work item couldn't be retrieved, try to restore the status of the work item,
            // and don't continue to the details.
            if (this.WorkItem != null && this.WorkItem.WorkItemDetails != null)
            {
                // The work item was found and transitioned, so continue
                this.WorkItem.OriginalStatus = originalStatus;

                // Cache the workItem
                ImporterWorkItemCache.Add(this.WorkItem);
                this.NavigateWorkItem(ViewNames.StudyListView);
            }
            else
            {
                // Attempt to restore the work item to its original status.
                try
                {
                    this.DicomImporterDataSource.UpdateWorkItem(this.WorkItem, ImporterWorkItemStatuses.InReconciliation, originalStatus);
                }
                catch (Exception e)
                {
                    Logger.Error("Error restoring work item to it's original status", e);
                }

                // Display a message to the user indicating the failed retrieval
                string message = "The selected work item was not able to be retrieved successfully. This could be due to a temporary\n"
                    + "network issue, or a corrupted work item.\n\n If the problem persists, please contact an adminstrator.";
                string caption = "Error Retrieving Work Item";

                DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Error);

                // Reload the work items
                this.ApplyFilter();

            }
        }

        /// <summary>
        /// Deletes the importer item.
        /// </summary>
        private void DeleteImportItem()
        {
            try
            {
                if (DeleteImporterWorkItem(SelectedWorkItem))
                {
                    // Refresh the list
                    this.ApplyFilter();
                }
            }
            catch (ServerException se)
            {
                this.HandleServerException(se);
            }
        }

        /// <summary>
        /// Handles the server exception.
        /// </summary>
        /// <param name="se">The se.</param>
        private void HandleServerException(ServerException se)
        {
            // Check for "expected" exceptions and handle them. Rethrow on unexpected ones...
            if (se.ErrorCode == ImporterErrorCodes.WorkItemNotFoundErrorCode)
            {
                this.DialogService.ShowAlertBox(
                    this.UIDispatcher, WorkItemNotFoundErrorMessage, WorkItemNotFoundErrorCaption, MessageTypes.Error);
            }
            else if (se.ErrorCode == ImporterErrorCodes.InvalidWorkItemStatusErrorCode)
            {
                string message = se.Message;
                this.DialogService.ShowAlertBox(
                    this.UIDispatcher, message, WorkItemInInvalidStateCaption, MessageTypes.Error);
            }
            else
            {
                // Rethrow the error up to the general exception handler
                throw se;
            }

            // Reload the work items
            this.ApplyFilter();
        }

        /// <summary>
        /// The add fee origin filter if necessary.
        /// </summary>
        /// <param name="filter">
        /// The filter.
        /// </param>
        private void AddFeeOriginFilterIfNecessary(ImporterWorkItemFilter filter)
        {
            // If they are a contracted studies user and NOT and adminstrator, only show them FEE stuff.
            if (this.HasContractedStudiesKey && !this.HasAdministratorKey)
            {
                filter.OriginIndex = "F";
            }
        }

        /// <summary>
        /// The apply filter.
        /// </summary>
        private void ApplyFilter()
        {
            var filter = new ImporterWorkItemFilter { Status = ImporterWorkItemStatuses.New };

            // Get the source if something specific is selected
            if (this.SourceFilter != null && this.SourceFilter != AllSources)
            {
                filter.Source = this.SourceFilter;
            }

            // Get the subtype if something is selected
            if (this.WorkItemSubtypeFilter != null && this.WorkItemSubtypeFilter != ImporterWorkItemSubtype.AllSubtypes)
            {
                filter.Subtype = this.WorkItemSubtypeFilter.Code;
            }

            filter.Status = this.ShowActiveWorkItems
                                ? ImporterWorkItemStatuses.New
                                : ImporterWorkItemStatuses.ImportComplete;

            // Add the fee origin filter if necessary
            this.AddFeeOriginFilterIfNecessary(filter);

            this.WorkItems = this.DicomImporterDataSource.GetWorkItemList(filter);

            if (this.WorkItems == null || this.WorkItems.Count == 0)
            {
                this.DialogService.ShowAlertBox(
                    this.UIDispatcher, NoSearchItemsFoundMessage, NoItemsFoundCaption, MessageTypes.Info);
            }

            this.PerformPatientFilter();
        }

        /// <summary>
        /// Gets and binds the sources.
        /// </summary>
        /// <param name="filter">The filter.</param>
        private void GetAndBindSources(ImporterWorkItemFilter filter)
        {
            // Populate the dropdown for source filter to only include sources in our current
            // collection of workitems
            var allEligibleWorkItems = new ObservableCollection<ImporterWorkItem>(this.WorkItems);

            // Get the completed work items
            filter.Status = ImporterWorkItemStatuses.ImportComplete;
            ObservableCollection<ImporterWorkItem> completedWorkItems =
                this.DicomImporterDataSource.GetWorkItemList(filter);

            foreach (ImporterWorkItem item in completedWorkItems)
            {
                allEligibleWorkItems.Add(item);
            }

            IEnumerable<string> sources =
                (from workItem in allEligibleWorkItems select workItem.Source).Distinct().OrderBy(x => x);

            this.Sources = new ObservableCollection<string>(sources);
            this.Sources.Insert(0, AllSources);
            this.SourceFilter = this.Sources[0];
        }

        /// <summary>
        /// The perform patient filter.
        /// </summary>
        private void PerformPatientFilter()
        {
            this.PatientNameFilter += string.Empty;

            // If the patient name filter is empty, do nothing
            if (string.IsNullOrEmpty(this.PatientNameFilter.Trim()))
            {
                return;
            }

            // Do the patient name filter
            IEnumerable<ImporterWorkItem> filteredItems = from workItem in this.WorkItems
                                                          where
                                                              workItem.PatientName.ToUpper().Contains(
                                                                  this.PatientNameFilter.ToUpper())
                                                          select workItem;

            this.WorkItems = new ObservableCollection<ImporterWorkItem>(filteredItems);
        }

        /// <summary>
        /// The reset filter.
        /// </summary>
        private void ResetFilter()
        {
            this.NavigateMainRegionTo(ViewNames.WorkListView);
        }

        #endregion
    }
}