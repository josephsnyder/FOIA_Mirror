/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace DicomImporter.ViewModels
{
    using System;
    using System.Collections.ObjectModel;
    using System.Linq;

    using DicomImporter.Common.Exceptions;
    using DicomImporter.Common.Interfaces.DataSources;
    using DicomImporter.Common.Model;
    using DicomImporter.Common.View;
    using DicomImporter.Common.ViewModel;

    using ImagingClient.Infrastructure.DialogService;
    using ImagingClient.Infrastructure.Exceptions;

    using Microsoft.Practices.Prism.Commands;
    using Microsoft.Practices.Prism.Regions;

    /// <summary>
    /// The choose existing order view model.
    /// </summary>
    public class ChooseExistingOrderViewModel : ImporterReconciliationViewModel
    {
        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ChooseExistingOrderViewModel"/> class.
        /// </summary>
        /// <param name="dialogService">
        /// The dialog service.
        /// </param>
        /// <param name="dicomImporterDataSource">
        /// The dicom importer data source.
        /// </param>
        public ChooseExistingOrderViewModel(
            IDialogService dialogService, IDicomImporterDataSource dicomImporterDataSource)
        {
            this.DialogService = dialogService;
            this.DicomImporterDataSource = dicomImporterDataSource;

            this.NavigateForward = new DelegateCommand<object>(
                o =>
                    {
                        if (this.CurrentReconciliation.Order == null)
                        {
                            string message = "You must select or create an order before proceeding.";
                            string caption = "No Order Selected or Created";
                            this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Error);
                        }
                        else
                        {
                            this.NavigateWorkItem(ViewNames.ReconciliationSummaryView);
                        }
                    }, 
                o => this.ValidateForm());

            this.NavigateBack =
                new DelegateCommand<object>(
                    o =>
                    this.NavigateWorkItem(
                        this.HasAdministratorKey ? ViewNames.SelectOrderTypeView : ViewNames.PatientSelectionView));

            this.CancelReconciliationCommand = new DelegateCommand<object>(
                o => this.CancelReconciliation());

            this.RefreshOrdersCommand = new DelegateCommand<object>(o => this.RefreshOrders());
        }

        #endregion

        #region Constants and Fields

        /// <summary>
        /// The message to display when the seleted exam is already complete.
        /// </summary>
        private const string ExamAlreadyCompleteMessage = "The exam status for the selected order is already complete and cannot be automatically reverted to examined. If the study needs to be read by a VA radiologist, you need to contact your Radiology ADPAC to manually reset the exam status.";

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets the Exam Status Message.
        /// </summary>
        public string ExamStatusMessage { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether IsStudyReadByVaRadiologistEnabled.
        /// </summary>
        public bool IsStudyReadByVaRadiologistEnabled { get; set; }

        /// <summary>
        /// Gets or sets NavigateBack.
        /// </summary>
        public DelegateCommand<object> NavigateBack { get; set; }

        /// <summary>
        /// Gets or sets NavigateForward.
        /// </summary>
        public DelegateCommand<object> NavigateForward { get; set; }

        /// <summary>
        /// Gets or sets RefreshOrdersCommand.
        /// </summary>
        public DelegateCommand<object> RefreshOrdersCommand { get; set; }

        /// <summary>
        /// Gets or sets SelectedOrder.
        /// </summary>
        public Order SelectedOrder
        {
            get
            {
                return (this.CurrentReconciliation != null) ? this.CurrentReconciliation.Order : null;
            }

            set
            {
                if (this.CurrentReconciliation != null)
                {
                    this.CurrentReconciliation.Order = value;
                }

                this.SetVaRadiologistEnabledStatus();
                this.DisplayCompletedExamMessageIfNecessary();

                this.NavigateForward.RaiseCanExecuteChanged();
                this.RaisePropertyChanged("SelectedOrder");
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// The on navigated to.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            base.OnNavigatedTo(navigationContext);

            try
            {
                // Refresh the orders for the patient.
                if (this.CurrentReconciliation.Orders == null)
                {
                    this.RefreshOrders();
                }
            }
            catch (ServerException se)
            {
                if (se.ErrorCode.Equals(ImporterErrorCodes.OutsideLocationConfigurationErrorCode))
                {
                    // Show the error, cancel the work Item, and navigate back to the Home view
                    this.ShowOutsideLocationErrorAndCancelWorkItem();

                    // Return from OnNavigatedTo
                    return;
                }
                else
                {
                    throw;
                }
            }

            this.SetVaRadiologistEnabledStatus();
            this.DisplayCompletedExamMessageIfNecessary();
        }

        #endregion

        #region Methods

        /// <summary>
        /// The refresh orders.
        /// </summary>
        private void RefreshOrders()
        {
            this.CurrentReconciliation.Order = null;

            // Get all the orders for the patient
            this.CurrentReconciliation.Orders = this.DicomImporterDataSource.GetOrdersForPatient(this.CurrentReconciliation.Patient.Dfn);

            // First, add previously reconciled order if necessary
            this.AddPreviouslyReconciledOrderIfNecessary();

            // Display a popup if no orders were found after the searching and filtering...
            if (this.CurrentReconciliation.Orders == null || this.CurrentReconciliation.Orders.Count == 0)
            {
                string message = "No orders were found for " + this.CurrentReconciliation.Patient.PatientName
                                 + "\nin a status that allows for image attachment.";
                string caption = "No Orders Found";
                this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Info);
            }

            this.RaisePropertyChanged("SelectedOrder");
            this.NavigateForward.RaiseCanExecuteChanged();
        }

        /// <summary>
        /// Adds the previously reconciled order if necessary.
        /// </summary>
        private void AddPreviouslyReconciledOrderIfNecessary()
        {
            // if the current patient does not match the previously reconciled patient, exit, since we don't
            // want to add an order for another patient to the list...
            if (this.CurrentReconciliation.Patient != this.CurrentStudy.PreviouslyReconciledPatient)
            {
                return;
            }

            // If we're still here, check to see if there is a previously reconciled order 
            // and if it's not in the list, add it
            if (this.CurrentStudy.PreviouslyReconciledOrder != null)
            {
                // Attempt to find a match
                Order previouslyReconciledOrder = this.GetMatchingOrder(
                    this.CurrentStudy.PreviouslyReconciledOrder, this.CurrentReconciliation.Orders);

                // If we didn't find a match, add it to the list and resort the list
                if (previouslyReconciledOrder == null)
                {
                    this.CurrentReconciliation.Orders.Add(this.CurrentStudy.PreviouslyReconciledOrder);
                    this.CurrentReconciliation.Orders =
                        new ObservableCollection<Order>(
                            this.CurrentReconciliation.Orders.OrderByDescending(o => o.OrderDateAsDateTime));
                }
            }
        }

        /// <summary>
        /// The set va radiologist enabled status.
        /// </summary>
        private void SetVaRadiologistEnabledStatus()
        {
            if (this.SelectedOrder != null && 
                this.SelectedOrder.Specialty.Equals("RAD") &&
                !ExamStatuses.IsCompletedStatus(this.SelectedOrder.ExamStatus))
            {
                this.IsStudyReadByVaRadiologistEnabled = true;
            }
            else
            {
                this.IsStudyReadByVaRadiologistEnabled = false;
                if (this.CurrentReconciliation != null)
                {
                    this.CurrentReconciliation.IsStudyToBeReadByVaRadiologist = true;
                }
            }
        }

        /// <summary>
        /// Displays the "completed exam" message if necessary.
        /// </summary>
        private void DisplayCompletedExamMessageIfNecessary()
        {
            if (this.SelectedOrder != null && this.SelectedOrder.Specialty.Equals("RAD") && ExamStatuses.IsCompletedStatus(this.SelectedOrder.ExamStatus))
            {
                this.ExamStatusMessage = ExamAlreadyCompleteMessage;
            }
            else
            {
                this.ExamStatusMessage = string.Empty;
            }
        }
        
        /// <summary>
        /// Validates the form.
        /// </summary>
        /// <returns>
        /// Whether or not the form is valid.
        /// </returns>
        private bool ValidateForm()
        {
            // Have to have a reconciliation ...
            if (this.CurrentReconciliation == null)
            {
                return false;
            }

            Order order = this.CurrentReconciliation.Order;

            // Have to have an order...
            if (order == null)
            {
                return false;
            }

            return true;
        }

        #endregion
    }
}