/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace DicomImporter.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.IO;
    using System.Windows.Threading;

    using DicomImporter.Common.Exceptions;
    using DicomImporter.Common.Interfaces.DataSources;
    using DicomImporter.Common.Model;
    using DicomImporter.Common.View;

    using ImagingClient.Infrastructure.DialogService;
    using ImagingClient.Infrastructure.Model;
    using ImagingClient.Infrastructure.PatientDataSource;
    using ImagingClient.Infrastructure.StorageDataSource;
    using ImagingClient.Infrastructure.Utilities;

    using log4net;

    using Microsoft.Practices.Prism.Commands;
    using Microsoft.Practices.Prism.Regions;

    /// <summary>
    /// The media staging view model.
    /// </summary>
    public class MediaStagingViewModel : MediaReadingViewModel
    {
        #region Constants and Fields

        /// <summary>
        /// The change patient.
        /// </summary>
        private const string ChangePatient = "Change Patient...";

        /// <summary>
        /// The hide advanced options text.
        /// </summary>
        private const string HideAdvancedOptionsText = "Disable Advanced Options...";

        /// <summary>
        /// The select patient.
        /// </summary>
        private const string SelectPatient = "Select Patient...";

        /// <summary>
        /// The show advanced options text.
        /// </summary>
        private const string ShowAdvancedOptionsText = "Enable Advanced Options...";

        /// <summary>
        /// The logger.
        /// </summary>
        private static readonly ILog Logger = LogManager.GetLogger(typeof(MediaStagingViewModel));

        /// <summary>
        /// The drive letter.
        /// </summary>
        private string driveLetter;

        /// <summary>
        /// The is patient known.
        /// </summary>
        private bool isPatientKnown;

        /// <summary>
        /// The patient.
        /// </summary>
        private Patient patient;

        /// <summary>
        /// The selected origin index.
        /// </summary>
        private OriginIndex selectedOriginIndex;

        #endregion

        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MediaStagingViewModel"/> class.
        /// </summary>
        /// <param name="dialogService">
        /// The dialog service.
        /// </param>
        /// <param name="dicomImporterDataSource">
        /// The dicom importer data source.
        /// </param>
        /// <param name="storageDataSource">
        /// The storage data source.
        /// </param>
        /// <param name="patientDataSource">
        /// The patient data source.
        /// </param>
        public MediaStagingViewModel(
            IDialogService dialogService, 
            IDicomImporterDataSource dicomImporterDataSource, 
            IStorageDataSource storageDataSource, 
            IPatientDataSource patientDataSource)
        {
            this.DialogService = dialogService;
            this.DicomImporterDataSource = dicomImporterDataSource;
            this.StorageDataSource = storageDataSource;
            this.PatientDataSource = patientDataSource;

            this.ProgressViewModel.IsWorkInProgress = false;

            this.AdvancedOptionsText = ShowAdvancedOptionsText;
            this.ShowAdvancedOptions = false;
            this.ToggleAdvancedOptions = new DelegateCommand<object>(
                o => this.OnToggleAdvancedOptions(), o => this.CanSelectAdvancedOptions());

            this.PerformActionCommand = new DelegateCommand<object>(
                o => this.BuildWorkItemAndCopyMediaToShare(), o => this.CanStage());

            this.ShowStudyDetailsWindow = new DelegateCommand<object>(
                o => this.ShowStudyDetails(this, null), 
                o => (this.SelectedStudies != null && this.SelectedStudies.Count == 1));

            this.NavigateToImporterHomeView =
                new DelegateCommand<object>(
                    o => this.NavigateMainRegionTo(ViewNames.ImporterHomeView), 
                    o => !this.ProgressViewModel.IsWorkInProgress);

            this.CancelActionCommand = new DelegateCommand<object>(
                o =>
                    {
                        if (this.PreppingAdvancedOptions)
                        {
                            this.CancelAdvancedOptionsAction();
                        }
                        else
                        {
                            this.CancelAction();
                        }
                    }, 
                o => this.CanCancel());
        }

        #endregion

        #region Delegates

        /// <summary>
        /// The show study details window event handler.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        public delegate void ShowStudyDetailsWindowEventHandler(object sender, EventArgs e);

        #endregion

        #region Public Events

        /// <summary>
        /// The show study details.
        /// </summary>
        public event ShowStudyDetailsWindowEventHandler ShowStudyDetails;

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets AdvancedOptionsText.
        /// </summary>
        public string AdvancedOptionsText { get; set; }

        /// <summary>
        /// Gets or sets DriveLetter.
        /// </summary>
        public string DriveLetter
        {
            get
            {
                return this.driveLetter;
            }

            set
            {
                // If the value is changing, and it's not being cleared....
                if ((this.driveLetter != value) && (value != null))
                {
                    // Clear everything in memory related to the work item
                    this.WorkItem = null;
                    this.SelectedStudies = null;
                    this.StudyListBuiltSuccessfully = false;

                    // if we're already in the advanced options view, reload studies from disk
                    if (this.ShowAdvancedOptions)
                    {
                        this.ShowAdvancedOptions = false;
                        this.InitializeAndShowAdvancedOptions();
                    }
                }

                this.driveLetter = value;
                this.PerformActionCommand.RaiseCanExecuteChanged();
                this.ToggleAdvancedOptions.RaiseCanExecuteChanged();
                this.NavigateToImporterHomeView.RaiseCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IsPatientKnown.
        /// </summary>
        public bool IsPatientKnown
        {
            get
            {
                return this.isPatientKnown;
            }

            set
            {
                this.isPatientKnown = value;
                this.PerformActionCommand.RaiseCanExecuteChanged();
                this.NavigateToImporterHomeView.RaiseCanExecuteChanged();
            }
        }

        // Commands

        /// <summary>
        /// Gets or sets NavigateToImporterHomeView.
        /// </summary>
        public DelegateCommand<object> NavigateToImporterHomeView { get; set; }

        /// <summary>
        /// Gets OriginIndexList.
        /// </summary>
        public ObservableCollection<OriginIndex> OriginIndexList
        {
            get
            {
                return this.DicomImporterDataSource.GetOriginIndexList();
            }
        }

        /// <summary>
        /// Gets or sets Patient.
        /// </summary>
        public Patient Patient
        {
            get
            {
                return this.patient;
            }

            set
            {
                this.PatientSelectionButtonText = value == null ? SelectPatient : ChangePatient;

                this.patient = value;
                this.PerformActionCommand.RaiseCanExecuteChanged();
                this.NavigateToImporterHomeView.RaiseCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets or sets PatientSelectionButtonText.
        /// </summary>
        public string PatientSelectionButtonText { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether PreppingAdvancedOptions.
        /// </summary>
        public bool PreppingAdvancedOptions { get; set; }

        /// <summary>
        /// Gets or sets SelectedOriginIndex.
        /// </summary>
        public OriginIndex SelectedOriginIndex
        {
            get
            {
                return this.selectedOriginIndex;
            }

            set
            {
                this.selectedOriginIndex = value;
                this.PerformActionCommand.RaiseCanExecuteChanged();
                this.NavigateToImporterHomeView.RaiseCanExecuteChanged();
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether ShowAdvancedOptions.
        /// </summary>
        public bool ShowAdvancedOptions { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether ShowAdvancedOptionsControls.
        /// </summary>
        public bool ShowAdvancedOptionsControls { get; set; }

        /// <summary>
        /// Gets or sets ToggleAdvancedOptions.
        /// </summary>
        public DelegateCommand<object> ToggleAdvancedOptions { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// The do initialize advanced options.
        /// </summary>
        /// <param name="o">
        /// The o.
        /// </param>
        /// <param name="args">
        /// The args.
        /// </param>
        public void DoInitializeAdvancedOptions(object o, DoWorkEventArgs args)
        {
            if (!this.StudyListBuiltSuccessfully)
            {
                this.ProgressViewModel.Text = "Reading Studies from Drive...";

                if (this.ReadDicomStudiesFromPath(this.DriveLetter, true, this.SelectedOriginIndex.Code))
                {
                    if (this.StudiesOnMedia.Count != 0)
                    {
                        // Attach the the temporary study list to the workitem details
                        this.UIDispatcher.Invoke(
                            DispatcherPriority.Normal,
                            (Action)(() => this.WorkItem.WorkItemDetails.Studies = new ObservableCollection<Study>(this.StudiesOnMedia)));

                        this.StudyListBuiltSuccessfully = true;
                        this.RaisePropertyChanged("StudiesOnMedia");
                    }
                    else
                    {
                        this.ProgressViewModel.Text = "NO DICOM media found...";
                        string message = "No DICOM media was found on the drive. There is nothing to import.";
                        string caption = "No DICOM media found";
                        this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Warning);
                    }
                }
            }
        }

        /// <summary>
        /// The initialize advanced options completed.
        /// </summary>
        /// <param name="o">
        /// The o.
        /// </param>
        /// <param name="args">
        /// The args.
        /// </param>
        public void InitializeAdvancedOptionsCompleted(object o, RunWorkerCompletedEventArgs args)
        {
            this.ProgressViewModel.IsWorkInProgress = false;
            this.PreppingAdvancedOptions = false;

            if (this.StudyListBuiltSuccessfully)
            {
                this.ShowAdvancedOptions = true;
                this.AdvancedOptionsText = HideAdvancedOptionsText;
            }
            else
            {
                this.PreppingAdvancedOptions = false;
                this.ShowAdvancedOptions = false;
                this.AdvancedOptionsText = ShowAdvancedOptionsText;
            }

            this.PerformActionCommand.RaiseCanExecuteChanged();
            this.CancelActionCommand.RaiseCanExecuteChanged();
            this.ToggleAdvancedOptions.RaiseCanExecuteChanged();
            this.NavigateToImporterHomeView.RaiseCanExecuteChanged();

            this.RaisePropertyChanged("AdvancedOptionsText");
        }

        /// <summary>
        /// The on navigated to.
        /// </summary>
        /// <param name="navigationContext">
        /// The navigation context.
        /// </param>
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            base.OnNavigatedTo(navigationContext);
            this.PopulateDriveList();
            this.SelectedOriginIndex = this.OriginIndexList[0];
            this.IsPatientKnown = true;

            this.PatientSelectionButtonText = this.Patient == null ? SelectPatient : ChangePatient;
        }

        /// <summary>
        /// The perform staging operation.
        /// </summary>
        /// <param name="o">
        /// The o.
        /// </param>
        /// <param name="args">
        /// The args.
        /// </param>
        public void PerformStagingOperation(object o, DoWorkEventArgs args)
        {
            Logger.Debug("Preparing to perform staging operation.");

            // No advanced options... Just stage the entire media
            this.ProgressViewModel.IsWorkInProgress = true;
            this.ProgressViewModel.Text = "Reading Studies from Drive...";

            this.PerformActionCommand.RaiseCanExecuteChanged();
            this.CancelActionCommand.RaiseCanExecuteChanged();
            this.ToggleAdvancedOptions.RaiseCanExecuteChanged();
            this.NavigateToImporterHomeView.RaiseCanExecuteChanged();

            if (!this.ShowAdvancedOptions)
            {
                if (this.ReadDicomStudiesFromPath(this.DriveLetter, true, this.SelectedOriginIndex.Code))
                {
                    this.SetOriginIndexDataForStudies(this.StudiesOnMedia, this.SelectedOriginIndex.Code);

                    // Attach the the temporary study list to the workitem details
                    this.UIDispatcher.Invoke(
                        DispatcherPriority.Normal, 
                        (Action)delegate { this.WorkItemDetails.Studies = new ObservableCollection<Study>(this.StudiesOnMedia); });

                    // If there were no studies able to be resolved, tell the user and halt progress
                    if (this.WorkItemDetails.Studies == null || this.WorkItemDetails.Studies.Count == 0)
                    {
                        this.ProgressViewModel.Text = "NO DICOM media found...";
                        string message = "No DICOM media was found on the drive. There is nothing to import.";
                        string caption = "No DICOM media found";
                        this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Warning);
                        return;
                    }

                    // Strip any unsupported files, and if the user doesn't want to continue, halt processing
                    if (!this.StripUnsupportedSopInstances(this.DriveLetter, this.WorkItemDetails.Studies))
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            else
            {
                // Copy the selected studies into a local list
                var studiesToStage = new ObservableCollection<Study>();
                foreach (Study study in this.SelectedStudies)
                {
                    studiesToStage.Add(study);
                }

                // Now that the selected studies have been copied to a temporary collection, strip any unsupported files, and 
                // if the user doesn't want to continue, halt processing
                if (!this.StripUnsupportedSopInstances(this.DriveLetter, studiesToStage))
                {
                    return;
                }

                // There are studies left after removing any unsupported instances, and the user wants to continue... 
                // Set the origin index
                this.SetOriginIndexDataForStudies(studiesToStage, this.SelectedOriginIndex.Code);

                // Advanced options were selected. Check to see that they haven't swapped the CD out from under us!
                // Get a "signature" for the media by hashing all the filenames
                var allFiles = new List<string>();
                PathUtilities.AddFiles(this.DriveLetter, "*", allFiles);
                string latestMediaSignature = StringUtilities.GetHashForStringArray(allFiles.ToArray());

                if (!this.WorkItemDetails.MediaBundleSignature.Equals(latestMediaSignature))
                {
                    string message = "Something is wrong with CD/DVD disk.  The disk does not appear to be the\n"
                                     + "same one that was used at the start of the Importer session.  Could the\n"
                                     + "original disk have been removed and another one inserted into the drive?";
                    string caption = "Media Has Changed";
                    this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Error);
                    this.StudyListBuiltSuccessfully = false;
                    return;
                }
                else
                {
                    // Only stage the selected studies
                    this.ProgressViewModel.IsWorkInProgress = true;

                    // Attach the selected studies list to the workitem details
                    this.UIDispatcher.Invoke(
                        DispatcherPriority.Normal, 
                        (Action)(() => { this.WorkItemDetails.Studies = new ObservableCollection<Study>(studiesToStage); }));
                }
            }

            // Cancel if requested
            if (this.Worker.CancellationPending)
            {
                args.Cancel = true;
                return;
            }

            // Copy the files to the staging area
            this.ProgressViewModel.Text = "Copying files to staging area";

            Exception fileCopyingException = null;
            try
            {
                this.CopyFilesToServer();
            }
            catch (Exception e)
            {
                fileCopyingException = e;
            }

            this.FinalizeStaging(fileCopyingException);
        }

        /// <summary>
        /// Finalizes staging.
        /// </summary>
        /// <param name="fileCopyingException">The exception thrown during processing, if any.</param>
        private void FinalizeStaging(Exception fileCopyingException)
        {
            try
            {
                if (fileCopyingException != null)
                {
                    if (fileCopyingException is InvalidNetworkLocationException)
                    {
                        InvalidNetworkLocationException e = (InvalidNetworkLocationException)fileCopyingException;
                        string caption = "Invalid Network Location Entry";
                        string message = "The current write location has an invalid \\\\server\\share value of:  \"" + e.ServerAndShare + "\".\n";
                        message += "Please contact an administrator.\n";

                        this.ProgressViewModel.IsWorkInProgress = false;
                        this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Error);
                    }
                    else if (fileCopyingException is NetworkLocationConnectionException)
                    {
                        string caption = "Invalid Network Location Credentials";
                        string message = "The current write location has an invalid username/password configured.\n";
                        message += "Please contact an administrator.\n";

                        this.ProgressViewModel.IsWorkInProgress = false;
                        this.DialogService.ShowAlertBox(this.UIDispatcher, message, caption, MessageTypes.Error);
                    }
                    else
                    {
                        // Create the WorkItem in a failed status, for later cleanup
                        this.WorkItem.Status = ImporterWorkItemStatuses.FailedStaging;
                        ProgressViewModel.Text = "Updating work item...";
                        RetryUtility.RetryAction(this.CreateImporterWorkItem, 3);
                        this.ProgressViewModel.IsWorkInProgress = false;
                        this.DialogService.ShowExceptionWindow(this.UIDispatcher, fileCopyingException);
                    }
                }
                else if (this.Worker.CancellationPending)
                {
                    // Create the WorkItem in a cancelled status, for later cleanup
                    this.WorkItem.Status = ImporterWorkItemStatuses.CancelledStaging;
                    ProgressViewModel.Text = "Updating work item...";
                    RetryUtility.RetryAction(this.CreateImporterWorkItem, 3);

                    // Display the Success notification
                    this.ProgressViewModel.IsWorkInProgress = false;
                    this.DialogService.ShowAlertBox(
                        this.UIDispatcher,
                        "The staging operation was cancelled.",
                        "Staging Cancelled",
                        MessageTypes.Info);
                }
                else
                {
                    // Save the WorkItem to the database and display the alert if the media was staged successfully
                    this.WorkItem.WorkItemDetails.VaPatientFromStaging = Patient;
                    this.WorkItem.WorkItemDetails.IsMediaBundleStaged = true;
                    ProgressViewModel.Text = "Updating work item...";
                    RetryUtility.RetryAction(this.CreateImporterWorkItem, 3);

                    // Display the Success notification
                    this.ProgressViewModel.IsWorkInProgress = false;
                    this.DialogService.ShowAlertBox(
                        this.UIDispatcher,
                        "Staging completed successfully. Please remove the media from the drive",
                        "Staging Complete",
                        MessageTypes.Info);
                }
            }
            catch (Exception e)
            {
                this.ProgressViewModel.IsWorkInProgress = false;
                this.DialogService.ShowAlertBox(
                    this.UIDispatcher, "Error during Media Staging: " + e.Message, "Staging Error", MessageTypes.Error);

                Logger.Error("Error staging media: " + e.Message, e);
            }
        }

        /// <summary>
        /// The perform staging operation completed.
        /// </summary>
        /// <param name="o">
        /// The o.
        /// </param>
        /// <param name="args">
        /// The args.
        /// </param>
        private void PerformStagingOperationCompleted(object o, RunWorkerCompletedEventArgs args)
        {
            this.ProgressViewModel.IsWorkInProgress = false;

            // Renavigate to this window to reset everything...
            this.NavigateMainRegionTo(ViewNames.MediaStagingView);
        }

        #endregion

        #region Methods

        /// <summary>
        /// The cancel action.
        /// </summary>
        protected void CancelAction()
        {
            this.Worker.CancelAsync();
            this.ProgressViewModel.Text = "Cancellation pending...";
            this.CancelActionCommand.RaiseCanExecuteChanged();
            this.NavigateToImporterHomeView.RaiseCanExecuteChanged();
        }

        /// <summary>
        /// The cancel advanced options action.
        /// </summary>
        protected void CancelAdvancedOptionsAction()
        {
            this.Worker.CancelAsync();
        }

        /// <summary>
        /// The build work item and copy media to share.
        /// </summary>
        private void BuildWorkItemAndCopyMediaToShare()
        {
            var driveInfo = new DriveInfo(this.DriveLetter);
            if (driveInfo.IsReady)
            {
                // Create and spawn a new backround worker to actually read the drive.
                // This lets us cancel if necessary, etc.
                this.Worker = new BackgroundWorker { WorkerSupportsCancellation = true };
                this.Worker.DoWork += this.PerformStagingOperation;
                this.Worker.RunWorkerCompleted += this.PerformStagingOperationCompleted;
                this.Worker.RunWorkerAsync();
            }
            else
            {
                this.ShowDriveNotReadyAlert();
            }
        }

        /// <summary>
        /// Determines whether the user can cancel the staging operation.
        /// </summary>
        /// <returns>
        ///   <c>true</c> if the user can cancel the staging operation; otherwise, <c>false</c>.
        /// </returns>
        private bool CanCancel()
        {
            // Check to see if a worker is active and cancellation is pending...
            bool cancellationPending = false;
            if (this.Worker != null && this.Worker.CancellationPending)
            {
                cancellationPending = true;
            }

            // We can only cancel if work is in progress, but cancellation has not already
            // been requested...
            return this.ProgressViewModel.IsWorkInProgress && !cancellationPending;
        }

        /// <summary>
        /// Determines whether the user can select advanced options. Used to enable and disable the
        /// button
        /// </summary>
        /// <returns>
        ///   <c>true</c> if the user can select advanced options; otherwise, <c>false</c>.
        /// </returns>
        private bool CanSelectAdvancedOptions()
        {
            bool hasRights = this.HasAdvancedStagingKey || this.HasContractedStudiesKey || this.HasAdministratorKey;
            bool driveSelected = !string.IsNullOrEmpty(this.DriveLetter);

            return hasRights && driveSelected && !this.ProgressViewModel.IsWorkInProgress;
        }

        /// <summary>
        /// Determines whether the user can stage. Used to enable or disable the button
        /// </summary>
        /// <returns>
        ///   <c>true</c> if the user can stage; otherwise, <c>false</c>.
        /// </returns>
        private bool CanStage()
        {
            // If it's a known patient, they have to provide a patient
            if (this.IsPatientKnown && this.Patient == null)
            {
                return false;
            }

            // If they haven't selected a drive or there's already work in progress, 
            // can't stage.
            if (string.IsNullOrEmpty(this.DriveLetter) || this.ProgressViewModel.IsWorkInProgress)
            {
                return false;
            }

            // If they've showed advanced options, but no studies are selected, can't stage
            if (this.ShowAdvancedOptions && (this.SelectedStudies == null || this.SelectedStudies.Count == 0))
            {
                return false;
            }

            // If we've gotten, here, we can stage
            return true;
        }

        /// <summary>
        /// The create importer work item.
        /// </summary>
        private void CreateImporterWorkItem()
        {
            this.DicomImporterDataSource.CreateImporterWorkItem(this.WorkItem, false);
        }

        /// <summary>
        /// The initialize and show advanced options.
        /// </summary>
        private void InitializeAndShowAdvancedOptions()
        {
            var driveInfo = new DriveInfo(this.DriveLetter);
            if (driveInfo.IsReady)
            {
                this.ProgressViewModel.IsWorkInProgress = true;
                this.PerformActionCommand.RaiseCanExecuteChanged();
                this.CancelActionCommand.RaiseCanExecuteChanged();
                this.ToggleAdvancedOptions.RaiseCanExecuteChanged();
                this.NavigateToImporterHomeView.RaiseCanExecuteChanged();

                // Create and spawn a new backround worker to actually read the drive.
                // This lets us cancel if necessary, etc.
                this.Worker = new BackgroundWorker { WorkerSupportsCancellation = true };
                this.Worker.DoWork += this.DoInitializeAdvancedOptions;
                this.Worker.RunWorkerCompleted += this.InitializeAdvancedOptionsCompleted;
                this.Worker.RunWorkerAsync();
            }
            else
            {
                this.ShowDriveNotReadyAlert();
            }
        }

        /// <summary>
        /// The on toggle advanced options.
        /// </summary>
        private void OnToggleAdvancedOptions()
        {
            if (this.ShowAdvancedOptions)
            {
                this.ShowAdvancedOptions = false;
                this.StudyListBuiltSuccessfully = false;
                this.ShowAdvancedOptionsControls = false;
                this.AdvancedOptionsText = ShowAdvancedOptionsText;
                this.PerformActionCommand.RaiseCanExecuteChanged();
                this.ToggleAdvancedOptions.RaiseCanExecuteChanged();
                this.NavigateToImporterHomeView.RaiseCanExecuteChanged();
            }
            else
            {
                this.PreppingAdvancedOptions = true;
                this.ShowAdvancedOptionsControls = true;
                this.InitializeAndShowAdvancedOptions();
            }

            this.RaisePropertyChanged("ShowAdvancedOptionsControls");
            this.RaisePropertyChanged("AdvancedOptionsText");
            this.RaisePropertyChanged("StudiesOnMedia");
        }

        /// <summary>
        /// The show drive not ready alert.
        /// </summary>
        private void ShowDriveNotReadyAlert()
        {
            this.DialogService.ShowAlertBox(
                this.UIDispatcher, 
                "Drive " + this.DriveLetter + " cannot be read from at this time. Staging cannot continue.", 
                "Drive not Ready", 
                MessageTypes.Error);
        }

        #endregion
    }
}