﻿/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 11/21/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace ImagingClient.Infrastructure.Help
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Windows.Threading;

    using ImagingClient.Infrastructure.DialogService;
    using ImagingClient.Infrastructure.Views;

    /// <summary>
    /// The help manager.
    /// </summary>
    public class HelpManager
    {
        #region Constants and Fields

        /// <summary>
        /// The importer user manual.
        /// </summary>
        private const string ImporterUserManual = "MAG_DICOM_Importer_II_User_Manual.pdf";

        #endregion

        #region Public Methods

        /// <summary>
        /// The show help.
        /// </summary>
        /// <param name="uiDispatcher">
        /// The ui dispatcher.
        /// </param>
        public static void ShowHelp(Dispatcher uiDispatcher)
        {
            var dialogService = new DialogService();

            if (File.Exists(ImporterUserManual))
            {
                ProcessStartInfo psi = new ProcessStartInfo
                    {
                        UseShellExecute = true, 
                        FileName = ImporterUserManual
                    };

                try
                {
                    Process.Start(psi);
                }
                catch (System.ComponentModel.Win32Exception ex)
                {
                    string errorMessage = "Adobe Acrobat is not installed. The Dicom Importer II is unable to "
                                          + "open the user manual.";

                    dialogService.ShowAlertBox(uiDispatcher, errorMessage, "Unable to Open User Manual", MessageTypes.Warning);
                }
                catch (Exception ex)
                {
                    dialogService.ShowExceptionWindow(uiDispatcher, ex);
                }
            }
            else
            {
                dialogService.ShowAlertBox(
                    uiDispatcher, 
                    "Couldn't find the user manual: " + ImporterUserManual, 
                    "User Manual Not Found", 
                    MessageTypes.Warning);
            }
        }

        #endregion
    }
}