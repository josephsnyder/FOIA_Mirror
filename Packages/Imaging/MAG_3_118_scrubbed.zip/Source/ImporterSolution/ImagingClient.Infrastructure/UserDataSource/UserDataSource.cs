/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace ImagingClient.Infrastructure.UserDataSource
{
    using System;
    using System.Collections.ObjectModel;
    using System.Configuration;

    using ImagingClient.Infrastructure.Configuration;
    using ImagingClient.Infrastructure.Rest;
    using ImagingClient.Infrastructure.User.Model;

    using VistaCommon;

    /// <summary>
    /// The user data source.
    /// </summary>
    public class UserDataSource : IUserDataSource
    {
        #region Constants and Fields

        /// <summary>
        /// The user service url.
        /// </summary>
        private string userServiceUrl = "UserWebApp";

        #endregion

        #region Public Methods

        /// <summary>
        /// Authenticates the user.
        /// </summary>
        /// <param name="accessCode">
        /// The access code.
        /// </param>
        /// <param name="verifyCode">
        /// The verify code.
        /// </param>
        public void AuthenticateUser(string accessCode, string verifyCode)
        {
            // Put an initial version of the UserCredential object in context, containing access and verify codes.
            // It will be replaced with the full version upon successful login
            UserContext.UserCredentials = new UserCredentials(accessCode, verifyCode);

            // Build the resource path
            string resourcePath = "user/authenticateUser?applicationName=Importer2";

            try
            {
                var credentials = RestUtils.DoGetObject<UserCredentials>(this.userServiceUrl, resourcePath);
                credentials.AccessCode = accessCode;
                credentials.VerifyCode = verifyCode;
                UserContext.IsLoginSuccessful = true;
                UserContext.UserCredentials = credentials;
                UserContext.LoginErrorMessage = string.Empty;
            }
            catch (Exception e)
            {
                UserContext.IsLoginSuccessful = false;
                UserContext.LoginErrorMessage = e.Message;
            }
        }

        /// <summary>
        /// Gets a collection of divisions accessible by the user.
        /// </summary>
        /// <param name="accessCode">
        /// The access code.
        /// </param>
        /// <returns>
        /// a collection of divisions accessible by the user
        /// </returns>
        public ObservableCollection<Division> GetDivisionList(string accessCode)
        {
            string resourcePath = "user/getDivisionList?accessCode=" + accessCode;
            return RestUtils.DoGetObject<ObservableCollection<Division>>(this.userServiceUrl, resourcePath);
        }

        /// <summary>
        /// Gets the welcome message.
        /// </summary>
        /// <returns>
        /// The welcome message string
        /// </returns>
        public string GetWelcomeMessage()
        {
            string welcomeMessage;

            try
            {
                string resourcePath = "public/getWelcomeMessage";
                welcomeMessage = RestUtils.DoGetString(this.userServiceUrl, resourcePath, false);
            }
            catch (Exception)
            {
                welcomeMessage = "Unable to retrieve welcome message from VistA...";
            }

            return welcomeMessage;
        }

        #endregion
    }
}