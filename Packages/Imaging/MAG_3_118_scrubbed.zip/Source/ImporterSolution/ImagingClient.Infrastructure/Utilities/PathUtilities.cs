/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace ImagingClient.Infrastructure.Utilities
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    using log4net;

    /// <summary>
    /// The path utilities.
    /// </summary>
    public class PathUtilities
    {
        #region Public Methods

        /// <summary>
        /// The add files.
        /// </summary>
        /// <param name="path">
        /// The path.
        /// </param>
        /// <param name="filter">
        /// The filter.
        /// </param>
        /// <param name="files">
        /// The files.
        /// </param>
        public static void AddFiles(string path, string filter, IList<string> files)
        {
            try
            {
                Directory.GetFiles(path, filter).ToList().ForEach(files.Add);

                Directory.GetDirectories(path).ToList().ForEach(s => AddFiles(s, filter, files));
            }
            catch (UnauthorizedAccessException)
            {
                // ok, so we are not allowed to dig into that directory. Move on.
            }
        }

        /// <summary>
        /// Combines the path.
        /// </summary>
        /// <param name="part1">Path part 1.</param>
        /// <param name="part2">Path part 2.</param>
        /// <returns>The combined path</returns>
        public static string CombinePath(string part1, string part2)
        {
            if (part1.EndsWith(":"))
            {
                part1 = part1 + "\\";
            }

            if (part2.StartsWith("\\") || part2.StartsWith("/"))
            {
                part2 = part2.Substring(1);
            }

            return Path.Combine(part1, part2);
        }

        /// <summary>
        /// Given a root path and a full path, gets the relative path off of the root.
        /// </summary>
        /// <param name="rootPath">The root path.</param>
        /// <param name="fullPath">The full path.</param>
        /// <returns>The relative path</returns>
        public static string GetRelativePath(string rootPath, string fullPath)
        {
            if (rootPath.EndsWith("\\") || rootPath.EndsWith("/"))
            {
                rootPath = rootPath.Substring(0, rootPath.Length - 1);
            }

            string relativePath = fullPath.Substring(rootPath.Length);

            return relativePath;
        }

        #endregion
    }
}