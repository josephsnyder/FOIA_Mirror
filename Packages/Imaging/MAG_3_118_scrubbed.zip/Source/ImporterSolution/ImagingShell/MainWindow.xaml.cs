/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace ImagingShell
{
    using System;
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;

    using DicomImporter.ViewModels;

    using ImagingClient.Infrastructure.Commands;
    using ImagingClient.Infrastructure.Help;
    using ImagingClient.Infrastructure.User.Model;
    using ImagingClient.Infrastructure.Views;

    using Microsoft.Practices.ServiceLocation;

    using log4net;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        /// <summary>
        /// The logger.
        /// </summary>
        private static readonly ILog Logger = LogManager.GetLogger(typeof(MainWindow));

        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow"/> class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();
            this.Name = "MainWindow";
            var viewModel = new MainWindowViewModel();
            this.DataContext = viewModel;

            // Initialize Menus
            var mnuDicom = new MenuItem { Header = "Importer" };
            this.mnuMain.Items.Insert(this.mnuMain.Items.Count - 1, mnuDicom);

            var mnuDicomImport = new MenuItem
                {
                    Header = "Importer Home", 
                    Command = ((MainWindowViewModel)this.DataContext).ShowDicomHome
                };

            mnuDicom.Items.Add(mnuDicomImport);

            // Register for the login event
            viewModel.ShowLoginWindow += this.OnShowLoginWindow;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// The on show login window.
        /// </summary>
        public void OnShowLoginWindow()
        {
            UserContext.UserCredentials = null;
            var loginWindow = ServiceLocator.Current.GetInstance<LoginWindow>();
            try
            {
                loginWindow.Owner = this;
                loginWindow.ShowDialog();
            }
            catch (Exception e)
            {
                // Shutting down... ignore
                Logger.Info("Shutting down...");
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// The exit item_ click.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        private void ExitItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// The on window closing.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        private void OnWindowClosing(object sender, CancelEventArgs e)
        {
            if (CompositeCommands.ShutdownCommand.CanExecute(e))
            {
                CompositeCommands.ShutdownCommand.Execute(e);
            }

            if (!e.Cancel)
            {
                Application.Current.Shutdown();
            }
        }

        /// <summary>
        /// The view user manual_ click.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        private void ViewUserManual_Click(object sender, RoutedEventArgs e)
        {
            HelpManager.ShowHelp(this.Dispatcher);
        }

        /// <summary>
        /// Handles the Click event of the ViewAboutWindow control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
        private void ViewAboutWindow_Click(object sender, RoutedEventArgs e)
        {
            // Future plans will be to use unity and populate with a list of modules
            AboutWindow aboutWindow = new AboutWindow("DICOM Importer II");
            aboutWindow.ShowDialog();
        }

        /// <summary>
        /// The window_ key down.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.F1:
                    {
                        HelpManager.ShowHelp(this.Dispatcher);
                        break;
                    }
            }
        }

        #endregion
    }
}
