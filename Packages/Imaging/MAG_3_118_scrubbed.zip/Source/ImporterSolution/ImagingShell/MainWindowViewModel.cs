/**
 * 
 * Package: MAG - VistA Imaging
 * WARNING: Per VHA Directive 2004-038, this routine should not be modified.
 * Date Created: 03/01/2011
 * Site Name:  Washington OI Field Office, Silver Spring, MD
 * Developer:  Jon Louthian
 * Description: 
 *
 *       ;; +--------------------------------------------------------------------+
 *       ;; Property of the US Government.
 *       ;; No permission to copy or redistribute this software is given.
 *       ;; Use of unreleased versions of this software requires the user
 *       ;;  to execute a written test agreement with the VistA Imaging
 *       ;;  Development Office of the Department of Veterans Affairs,
 *       ;;  telephone (301) 734-0100.
 *       ;;
 *       ;; The Food and Drug Administration classifies this software as
 *       ;; a Class II medical device.  As such, it may not be changed
 *       ;; in any way.  Modifications to this software may result in an
 *       ;; adulterated medical device under 21CFR820, the use of which
 *       ;; is considered to be a violation of US Federal Statutes.
 *       ;; +--------------------------------------------------------------------+
 *
 */
namespace ImagingShell
{
    using System.ComponentModel;

    using ImagingClient.Infrastructure;
    using ImagingClient.Infrastructure.Commands;
    using ImagingClient.Infrastructure.User.Model;
    using ImagingClient.Infrastructure.ViewModels;

    using Microsoft.Practices.Prism.Commands;
    using Microsoft.Practices.Prism.Regions;
    using Microsoft.Practices.ServiceLocation;

    /// <summary>
    /// The main window view model.
    /// </summary>
    internal class MainWindowViewModel : ImagingViewModel
    {
        #region Constructors and Destructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindowViewModel"/> class.
        /// </summary>
        public MainWindowViewModel()
        {
            this.OnLogOut = new DelegateCommand<object>(
                o =>
                    {
                        var e = new CancelEventArgs();
                        if (CompositeCommands.LogoutCommand.CanExecute(e))
                        {
                            CompositeCommands.LogoutCommand.Execute(e);
                        }

                        if (!e.Cancel)
                        {
                            LoginManager.IsAttemptingLogout = true;

                            // Try to navigate back to the home view. The active view will have a chance to cancel navigation
                            // and logout...
                            var manager = ServiceLocator.Current.GetInstance<IRegionManager>();
                            manager.RequestNavigate(RegionNames.MainRegion, "ImagingClientHomeView");

                            // If the user didn't cancel logout, clear the credentials and show the login window
                            if (!LoginManager.IsLogoutCancelled)
                            {
                                UserContext.UserCredentials = null;
                                UserContext.IsLoginSuccessful = false;
                                this.OnShowLoginWindow();
                            }

                            // Clean up for next time...
                            LoginManager.IsAttemptingLogout = false;
                            LoginManager.IsLogoutCancelled = false;

                            // If login is successful, navigate to Importer home
                            if (UserContext.IsLoginSuccessful)
                            {
                                manager.RequestNavigate(RegionNames.MainRegion, "ImporterHomeView");
                            }
                        }
                    });

            this.ShowDicomHome = new DelegateCommand<object>(o => this.NavigateMainRegionTo("ImporterHomeView"));
        }

        #endregion

        #region Delegates

        /// <summary>
        /// The show login window handler.
        /// </summary>
        public delegate void ShowLoginWindowHandler();

        #endregion

        #region Public Events

        /// <summary>
        /// The show login window.
        /// </summary>
        public event ShowLoginWindowHandler ShowLoginWindow;

        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets OnExit.
        /// </summary>
        public DelegateCommand<object> OnExit { get; set; }

        /// <summary>
        /// Gets or sets OnLogOut.
        /// </summary>
        public DelegateCommand<object> OnLogOut { get; set; }

        /// <summary>
        /// Gets or sets ShowDicomHome.
        /// </summary>
        public DelegateCommand<object> ShowDicomHome { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// The on show login window.
        /// </summary>
        public void OnShowLoginWindow()
        {
            if (this.ShowLoginWindow != null)
            {
                this.ShowLoginWindow();
            }
        }

        #endregion
    }
}