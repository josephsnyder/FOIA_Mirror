/*
 * 
  Package: MAG - VistA Imaging
  WARNING: Per VHA Directive 2004-038, this routine should not be modified.
  Date Created: March 11, 2008
  Site Name:  Washington OI Field Office, Silver Spring, MD
  Developer:        BUCKD
  Description: 

        ;; +--------------------------------------------------------------------+
        ;; Property of the US Government.
        ;; No permission to copy or redistribute this software is given.
        ;; Use of unreleased versions of this software requires the user
        ;;  to execute a written test agreement with the VistA Imaging
        ;;  Development Office of the Department of Veterans Affairs,
        ;;  telephone (301) 734-0100.
        ;;
        ;; The Food and Drug Administration classifies this software as
        ;; a Class II medical device.  As such, it may not be changed
        ;; in any way.  Modifications to this software may result in an
        ;; adulterated medical device under 21CFR820, the use of which
        ;; is considered to be a violation of US Federal Statutes.
        ;; +--------------------------------------------------------------------+

 */

using System;
using System.Collections.Generic;
using System.Text;

namespace Dexter
{
    /// <summary>
    /// This enumeration encodes the platter status maintained by DiskXtender.
    /// </summary>
    public enum PlatterStatusEnum {
        /// <summary>
        /// Offline - the platter is offline and may not be used to transfer files to and from the DEX drives.
        /// </summary>
        Offline = 0,
        /// <summary>
        /// Online - the platter is online and available to transfer files to and from the DEX drives.
        /// </summary>
        Online = 1,
        /// <summary>
        /// This status is a placeholder for all the other platter status codes that have not been reverse engineered.
        /// </summary>
        Unknown = 3,
        /// <summary>
        /// OfflineError - the platter is in an error condition, which also means it is offline.
        /// </summary>
        OfflineError = 4
    };

    /// <summary>
    /// The PlatterInformation class is used to hold metadata about each platter.
    /// </summary>
    public class PlatterInformation
    {
        private int platterNumber;
        private String platterName;
        private String platterSerialNumber;
        private PlatterStatusEnum platterStatus;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="platterNumber">The number which uniquely identifies a platter in the windows registry.</param>
        /// <param name="platterName">The use assigned name associated with the platter. Not unique.</param>
        /// <param name="platterSerialNumber">The unique system assigned serial number associated with the platter.</param>
        /// <param name="platterStatus">The status of the platter. Currently online or offline.</param>
        public PlatterInformation(int platterNumber, String platterName, String platterSerialNumber, int platterStatus)
        {
            this.platterNumber = platterNumber;
            this.platterName = platterName;
            this.platterSerialNumber = platterSerialNumber;
            switch (platterStatus)
            {
                case 0:
                    this.platterStatus = PlatterStatusEnum.Offline;
                    break;
                case 1:
                    this.platterStatus = PlatterStatusEnum.Online;
                    break;
                case 4:
                    this.platterStatus = PlatterStatusEnum.OfflineError;
                    break;
                default:
                    this.platterStatus = PlatterStatusEnum.Unknown;
                    break;
            }
        }

        /// <summary>
        /// Platter number exposed as a read only property.
        /// </summary>
        public int PlatterNumber
        {
            get { return platterNumber; }
        }

        /// <summary>
        /// Platter name exposed as a read only property.
        /// </summary>
        public String PlatterName
        {
            get { return platterName; }
        }

        /// <summary>
        /// Platter serial number exposed as a read only property.
        /// </summary>
        public String PlatterSerialNumber
        {
            get { return platterSerialNumber; }
        }

        /// <summary>
        /// Platter status exposed as a read only property.
        /// </summary>
        public PlatterStatusEnum PlatterStatus
        {
            get { return platterStatus; }
        }

        /// <summary>
        /// Formats the platter information as a single line appropriate for use in the platters with files report.
        /// </summary>
        /// <returns></returns>
        public String FormatForPlatterSummaryReport()
        {
            return this.platterName + "\t" + this.platterSerialNumber + "\t" + this.platterStatus.ToString("g");
        }

    }
}
