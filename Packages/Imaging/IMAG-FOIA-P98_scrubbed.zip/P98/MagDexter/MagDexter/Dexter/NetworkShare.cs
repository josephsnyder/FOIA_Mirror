/*
 * 
  Package: MAG - VistA Imaging
  WARNING: Per VHA Directive 2004-038, this routine should not be modified.
  Date Created: March 11, 2008
  Site Name:  Washington OI Field Office, Silver Spring, MD
  Developer:        BUCKD
  Description: 

        ;; +--------------------------------------------------------------------+
        ;; Property of the US Government.
        ;; No permission to copy or redistribute this software is given.
        ;; Use of unreleased versions of this software requires the user
        ;;  to execute a written test agreement with the VistA Imaging
        ;;  Development Office of the Department of Veterans Affairs,
        ;;  telephone (301) 734-0100.
        ;;
        ;; The Food and Drug Administration classifies this software as
        ;; a Class II medical device.  As such, it may not be changed
        ;; in any way.  Modifications to this software may result in an
        ;; adulterated medical device under 21CFR820, the use of which
        ;; is considered to be a violation of US Federal Statutes.
        ;; +--------------------------------------------------------------------+

 */

using System;
using System.Collections.Generic;
using System.Text;

namespace Dexter
{
    /// <summary>
    /// The NetworkShare class is used to hold metadata about a Windows network file share.
    /// </summary>
    public class NetworkShare
    {
        String shareName; // the network share name
        String sharePath; // the fully qualified path to the file share directory on the server
        bool isDuplicate = false;

        /// <summary>
        /// This propert indicates that the network share is a duplicate
        /// </summary>
        public bool IsDuplicate
        {
            get { return isDuplicate; }
            set { isDuplicate = value; }
        }

        /// <summary>
        /// The network share name.
        /// </summary>
        public String ShareName
        {
            get { return shareName; }
        }

        /// <summary>
        /// The fully qualified path to the file share directory on the server.
        /// </summary>
        public String SharePath
        {
            get { return sharePath; }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="shareName">The network share name.</param>
        /// <param name="sharePath">The fully qualified path to the file share directory on the server.</param>
        public NetworkShare(String shareName, String sharePath)
        {
            this.shareName = shareName;
            this.sharePath = sharePath;
            this.isDuplicate = false;
        }
    }
}
