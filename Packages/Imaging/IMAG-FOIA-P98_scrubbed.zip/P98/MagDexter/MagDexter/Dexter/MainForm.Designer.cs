/**
 * 
  Package: MAG - VistA Imaging
  WARNING: Per VHA Directive 2004-038, this routine should not be modified.
  Date Created:
  Site Name:  Washington OI Field Office, Silver Spring, MD
  Developer:
  Description: 

        ;; +--------------------------------------------------------------------+
        ;; Property of the US Government.
        ;; No permission to copy or redistribute this software is given.
        ;; Use of unreleased versions of this software requires the user
        ;;  to execute a written test agreement with the VistA Imaging
        ;;  Development Office of the Department of Veterans Affairs,
        ;;  telephone (301) 734-0100.
        ;;
        ;; The Food and Drug Administration classifies this software as
        ;; a Class II medical device.  As such, it may not be changed
        ;; in any way.  Modifications to this software may result in an
        ;; adulterated medical device under 21CFR820, the use of which
        ;; is considered to be a violation of US Federal Statutes.
        ;; +--------------------------------------------------------------------+

 */
namespace Dexter
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxInfo = new System.Windows.Forms.TextBox();
            this.buttonPlatterReports = new System.Windows.Forms.Button();
            this.folderBrowserDialogXrefDir = new System.Windows.Forms.FolderBrowserDialog();
            this.buttonSelectOutputFolder = new System.Windows.Forms.Button();
            this.textBoxOutputFolder = new System.Windows.Forms.TextBox();
            this.numericUpDownFileTimeDelay = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelCurrentFile = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CNetHelpProvider = new System.Windows.Forms.HelpProvider();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutDexterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBoxNetworkShare = new System.Windows.Forms.ComboBox();
            this.bindingSourceDataSetDex = new System.Windows.Forms.BindingSource(this.components);
            this.dataSetDex1 = new Dexter.DataSetDex();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFileTimeDelay)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceDataSetDex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetDex1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxInfo
            // 
            this.textBoxInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxInfo.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CNetHelpProvider.SetHelpKeyword(this.textBoxInfo, "Dexter_Form_MainForm.htm#MainForm_textBoxInfo");
            this.CNetHelpProvider.SetHelpNavigator(this.textBoxInfo, System.Windows.Forms.HelpNavigator.Topic);
            this.textBoxInfo.Location = new System.Drawing.Point(12, 89);
            this.textBoxInfo.Multiline = true;
            this.textBoxInfo.Name = "textBoxInfo";
            this.textBoxInfo.ReadOnly = true;
            this.textBoxInfo.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.CNetHelpProvider.SetShowHelp(this.textBoxInfo, true);
            this.textBoxInfo.Size = new System.Drawing.Size(522, 187);
            this.textBoxInfo.TabIndex = 0;
            // 
            // buttonPlatterReports
            // 
            this.buttonPlatterReports.AccessibleDescription = "Build platter summary and detail reports by scanning the selected network share";
            this.buttonPlatterReports.AccessibleName = "Process network share button";
            this.buttonPlatterReports.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CNetHelpProvider.SetHelpKeyword(this.buttonPlatterReports, "Dexter_Form_MainForm.htm#MainForm_buttonPlatterReports");
            this.CNetHelpProvider.SetHelpNavigator(this.buttonPlatterReports, System.Windows.Forms.HelpNavigator.Topic);
            this.buttonPlatterReports.Location = new System.Drawing.Point(409, 282);
            this.buttonPlatterReports.Name = "buttonPlatterReports";
            this.CNetHelpProvider.SetShowHelp(this.buttonPlatterReports, true);
            this.buttonPlatterReports.Size = new System.Drawing.Size(125, 23);
            this.buttonPlatterReports.TabIndex = 6;
            this.buttonPlatterReports.Text = "&Create Platter Reports";
            this.buttonPlatterReports.UseVisualStyleBackColor = true;
            this.buttonPlatterReports.Click += new System.EventHandler(this.buttonPlatterReports_Click);
            // 
            // folderBrowserDialogXrefDir
            // 
            this.folderBrowserDialogXrefDir.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // buttonSelectOutputFolder
            // 
            this.buttonSelectOutputFolder.AccessibleDescription = "Select the output folder that Dexter reports will be written to.";
            this.buttonSelectOutputFolder.AccessibleName = "Select Output Folder";
            this.buttonSelectOutputFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.CNetHelpProvider.SetHelpKeyword(this.buttonSelectOutputFolder, "Dexter_Form_MainForm.htm#MainForm_buttonSelectOutputFolder");
            this.CNetHelpProvider.SetHelpNavigator(this.buttonSelectOutputFolder, System.Windows.Forms.HelpNavigator.Topic);
            this.buttonSelectOutputFolder.Location = new System.Drawing.Point(12, 37);
            this.buttonSelectOutputFolder.Name = "buttonSelectOutputFolder";
            this.CNetHelpProvider.SetShowHelp(this.buttonSelectOutputFolder, true);
            this.buttonSelectOutputFolder.Size = new System.Drawing.Size(114, 22);
            this.buttonSelectOutputFolder.TabIndex = 2;
            this.buttonSelectOutputFolder.Text = "&Select Output Folder";
            this.buttonSelectOutputFolder.UseVisualStyleBackColor = true;
            this.buttonSelectOutputFolder.Click += new System.EventHandler(this.buttonSelectOutputFolder_Click);
            // 
            // textBoxOutputFolder
            // 
            this.textBoxOutputFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxOutputFolder.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CNetHelpProvider.SetHelpKeyword(this.textBoxOutputFolder, "Dexter_Form_MainForm.htm#MainForm_textBoxOutputFolder");
            this.CNetHelpProvider.SetHelpNavigator(this.textBoxOutputFolder, System.Windows.Forms.HelpNavigator.Topic);
            this.textBoxOutputFolder.Location = new System.Drawing.Point(134, 38);
            this.textBoxOutputFolder.Name = "textBoxOutputFolder";
            this.textBoxOutputFolder.ReadOnly = true;
            this.CNetHelpProvider.SetShowHelp(this.textBoxOutputFolder, true);
            this.textBoxOutputFolder.Size = new System.Drawing.Size(401, 20);
            this.textBoxOutputFolder.TabIndex = 0;
            this.textBoxOutputFolder.TabStop = false;
            this.textBoxOutputFolder.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxOutputFolder_Validating);
            // 
            // numericUpDownFileTimeDelay
            // 
            this.numericUpDownFileTimeDelay.AccessibleDescription = "Introduce a time delay between each file processed in a Platter Detail Report.";
            this.numericUpDownFileTimeDelay.AccessibleName = "Wait between ";
            this.numericUpDownFileTimeDelay.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CNetHelpProvider.SetHelpKeyword(this.numericUpDownFileTimeDelay, "Dexter_Form_MainForm.htm#MainForm_numericUpDownFileTimeDelay");
            this.CNetHelpProvider.SetHelpNavigator(this.numericUpDownFileTimeDelay, System.Windows.Forms.HelpNavigator.Topic);
            this.numericUpDownFileTimeDelay.Location = new System.Drawing.Point(134, 64);
            this.numericUpDownFileTimeDelay.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericUpDownFileTimeDelay.Name = "numericUpDownFileTimeDelay";
            this.numericUpDownFileTimeDelay.ReadOnly = true;
            this.CNetHelpProvider.SetShowHelp(this.numericUpDownFileTimeDelay, true);
            this.numericUpDownFileTimeDelay.Size = new System.Drawing.Size(55, 20);
            this.numericUpDownFileTimeDelay.TabIndex = 3;
            this.numericUpDownFileTimeDelay.ValueChanged += new System.EventHandler(this.numericUpDownFileTimeDelay_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.CNetHelpProvider.SetHelpKeyword(this.label3, "Dexter_Form_MainForm.htm#MainForm_label3");
            this.CNetHelpProvider.SetHelpNavigator(this.label3, System.Windows.Forms.HelpNavigator.Topic);
            this.label3.Location = new System.Drawing.Point(99, 69);
            this.label3.Name = "label3";
            this.CNetHelpProvider.SetShowHelp(this.label3, true);
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Wait";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.CNetHelpProvider.SetHelpKeyword(this.label4, "Dexter_Form_MainForm.htm#MainForm_label4");
            this.CNetHelpProvider.SetHelpNavigator(this.label4, System.Windows.Forms.HelpNavigator.Topic);
            this.label4.Location = new System.Drawing.Point(195, 69);
            this.label4.Name = "label4";
            this.CNetHelpProvider.SetShowHelp(this.label4, true);
            this.label4.Size = new System.Drawing.Size(128, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "milliseconds between files";
            // 
            // statusStrip
            // 
            this.CNetHelpProvider.SetHelpKeyword(this.statusStrip, "Dexter_Form_MainForm.htm#MainForm_statusStrip");
            this.CNetHelpProvider.SetHelpNavigator(this.statusStrip, System.Windows.Forms.HelpNavigator.Topic);
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelCurrentFile,
            this.toolStripStatusLabel1});
            this.statusStrip.Location = new System.Drawing.Point(0, 311);
            this.statusStrip.Name = "statusStrip";
            this.CNetHelpProvider.SetShowHelp(this.statusStrip, true);
            this.statusStrip.Size = new System.Drawing.Size(546, 22);
            this.statusStrip.TabIndex = 9;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabelCurrentFile
            // 
            this.toolStripStatusLabelCurrentFile.Name = "toolStripStatusLabelCurrentFile";
            this.toolStripStatusLabelCurrentFile.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // CNetHelpProvider
            // 
            this.CNetHelpProvider.HelpNamespace = "Dexter.chm";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.CNetHelpProvider.SetHelpKeyword(this.label1, "Dexter_Form_MainForm.htm#MainForm_label4");
            this.CNetHelpProvider.SetHelpNavigator(this.label1, System.Windows.Forms.HelpNavigator.Topic);
            this.label1.Location = new System.Drawing.Point(13, 288);
            this.label1.Name = "label1";
            this.CNetHelpProvider.SetShowHelp(this.label1, true);
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Select network share";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(546, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutDexterToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutDexterToolStripMenuItem
            // 
            this.aboutDexterToolStripMenuItem.Name = "aboutDexterToolStripMenuItem";
            this.aboutDexterToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.aboutDexterToolStripMenuItem.Text = "&About Dexter";
            this.aboutDexterToolStripMenuItem.Click += new System.EventHandler(this.aboutDexterToolStripMenuItem_Click);
            // 
            // comboBoxNetworkShare
            // 
            this.comboBoxNetworkShare.AccessibleDescription = "Select network share combo box";
            this.comboBoxNetworkShare.AccessibleName = "Select network share";
            this.comboBoxNetworkShare.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxNetworkShare.DataSource = this.bindingSourceDataSetDex;
            this.comboBoxNetworkShare.DisplayMember = "ShareDescription";
            this.comboBoxNetworkShare.FormattingEnabled = true;
            this.comboBoxNetworkShare.Location = new System.Drawing.Point(134, 283);
            this.comboBoxNetworkShare.Name = "comboBoxNetworkShare";
            this.comboBoxNetworkShare.Size = new System.Drawing.Size(269, 21);
            this.comboBoxNetworkShare.TabIndex = 11;
            this.comboBoxNetworkShare.ValueMember = "ShareName";
            // 
            // bindingSourceDataSetDex
            // 
            this.bindingSourceDataSetDex.AllowNew = false;
            this.bindingSourceDataSetDex.DataMember = "DexShare";
            this.bindingSourceDataSetDex.DataSource = this.dataSetDex1;
            this.bindingSourceDataSetDex.Sort = "ShareDescription";
            // 
            // dataSetDex1
            // 
            this.dataSetDex1.DataSetName = "DataSetDex";
            this.dataSetDex1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // MainForm
            // 
            this.AccessibleDescription = "Generate Platter Reports for network shares mapped to DEX drives.";
            this.AccessibleName = "Dexter - Platter Report Generation Utility";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 333);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxNetworkShare);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDownFileTimeDelay);
            this.Controls.Add(this.buttonSelectOutputFolder);
            this.Controls.Add(this.textBoxOutputFolder);
            this.Controls.Add(this.buttonPlatterReports);
            this.Controls.Add(this.textBoxInfo);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.CNetHelpProvider.SetHelpKeyword(this, "Dexter_Form_MainForm.htm");
            this.CNetHelpProvider.SetHelpNavigator(this, System.Windows.Forms.HelpNavigator.Topic);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(554, 366);
            this.Name = "MainForm";
            this.CNetHelpProvider.SetShowHelp(this, true);
            this.Text = "MagDexter - Platter Report Generation Utility";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFileTimeDelay)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceDataSetDex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSetDex1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxInfo;
        private System.Windows.Forms.Button buttonPlatterReports;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogXrefDir;
        private System.Windows.Forms.Button buttonSelectOutputFolder;
        private System.Windows.Forms.TextBox textBoxOutputFolder;
        private System.Windows.Forms.NumericUpDown numericUpDownFileTimeDelay;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCurrentFile;
        private System.Windows.Forms.HelpProvider CNetHelpProvider;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutDexterToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBoxNetworkShare;
        private System.Windows.Forms.Label label1;
        private DataSetDex dataSetDex1;
        private System.Windows.Forms.BindingSource bindingSourceDataSetDex;
    }
}

