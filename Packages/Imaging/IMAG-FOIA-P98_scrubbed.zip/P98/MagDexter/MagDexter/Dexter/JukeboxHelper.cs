/*
 * 
  Package: MAG - VistA Imaging
  WARNING: Per VHA Directive 2004-038, this routine should not be modified.
  Date Created: March 11, 2008
  Site Name:  Washington OI Field Office, Silver Spring, MD
  Developer:        BUCKD
  Description: 

        ;; +--------------------------------------------------------------------+
        ;; Property of the US Government.
        ;; No permission to copy or redistribute this software is given.
        ;; Use of unreleased versions of this software requires the user
        ;;  to execute a written test agreement with the VistA Imaging
        ;;  Development Office of the Department of Veterans Affairs,
        ;;  telephone (301) 734-0100.
        ;;
        ;; The Food and Drug Administration classifies this software as
        ;; a Class II medical device.  As such, it may not be changed
        ;; in any way.  Modifications to this software may result in an
        ;; adulterated medical device under 21CFR820, the use of which
        ;; is considered to be a violation of US Federal Statutes.
        ;; +--------------------------------------------------------------------+

 */

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using System.IO;
using System.Diagnostics;
using log4net;
using System.Management;
using System.Threading;

namespace Dexter
{
    /// <summary>
    /// A utility class used to handle jukebox related tasks.
    /// </summary>
    public class JukeboxHelper
    {
        /// <summary>
        /// The file prefix for platter detail report files.
        /// </summary>
        public const String PLATTER_DETAIL_REPORT_PREFIX = "Platter Detail Report ";
        /// <summary>
        /// The filename of the platter summary report.
        /// </summary>
        public const String PLATTER_SUMMARY_REPORT_FILENAME = "Platter Summary Report.txt"; // the platter summary report is named this

        /// <summary>
        /// 
        /// </summary>
        public const string NETWORK_SHARES_PROCESSED_TRACKING_FILENAME = "Network Shares Processed.txt";

        /// <summary>
        /// The filename of the list of network shares processed in a given output folder
        /// </summary>
        public const String NETWORK_SHARES_PROCESSED_FILENAME = "Network Shares Processed.txt";

        /// <summary>
        /// The item that indicates that all network shares should be processed.
        /// </summary>
        public const String ALL_NETWORK_SHARES = "ALL";

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="info">Delegate used to write to the main form's info text box.</param>
        /// <param name="progress">Delegate used to increment the main form's progress bar.</param>
        /// <param name="processFile">Delegate used write the current file being processed to the main form's status bar.</param>
        public JukeboxHelper(InfoDelegate info, ProcessFileDelegate processFile)
        {
            this.info = info;
            this.processFile = processFile;
        }

        #region private member variables
        private InfoDelegate info; // used to display a line of text in the main form's info text box
        private ProcessFileDelegate processFile; // used to allow windows to process system events to keep the UI responsive
        private bool canRun = false; // allows platter report processing to be canceled by the user
        private Dictionary<int, PlatterInformation> platterByNumber = null; // map of platter information by platter number
        private const int PLATTER_NUMBER_OFFSET = 39; // the offset in the $DEXDATA extended attribute where the platter number resides
        private const int PLATTER_NUMBER_KEY_LENGTH = 5; // in the registry, platter numbers are left padded with 0 to achieve this length
        private int lastPlatterNumber = -1; // used to determine what platter writer is associated with
        private StreamWriter writer = null; // the stream writer used to write a platter report
        private String outputFolder = null; // the directory that writer should write to
        private int fileTimeDelay = 0; // the amount of time to delay between processing each file in a directory
        private NetworkShare share = null; // the network share that platter reports are being generated for.
        private long networkShareFileCount = 0; // the running count of files processed on a network share

        #endregion

        #region public properties
        /// <summary>
        /// For platter detail report generation, the amount of time to wait between processing files on the DEX drive.
        /// </summary>
        public int FileTimeDelay
        {
            get { return fileTimeDelay; }
            set { fileTimeDelay = value; }
        }

        /// <summary>
        /// The folder where platter reports should be written to.
        /// </summary>
        public String OutputFolder
        {
            get { return outputFolder; }
            set { outputFolder = value; }
        }

        /// <summary>
        /// Setting this to false will cause the platter report processing to abort.
        /// </summary>
        public bool CanRun
        {
            get { return canRun; }
            set { canRun = value; }
        }
        #endregion

        #region private methods

        /// <summary>
        /// Returns a log4net logger.
        /// </summary>
        /// <returns></returns>
        private ILog Logger()
        {
            return LogManager.GetLogger(typeof(JukeboxHelper).Name);
        }

        /// <summary>
        /// Returns a map of PlatterInformation objects keyed by platter number. This information is loaded from the
        /// windows registry and only platters that contain files will be included.
        /// </summary>
        /// <returns></returns>
        private Dictionary<int, PlatterInformation> GetPlattersIndexedByPlatterNumber()
        {
            if (platterByNumber == null)
            {
                platterByNumber = new Dictionary<int, PlatterInformation>();
                using (RegistryKey media = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Legato\XMS\Media")) // read only
                {
                    foreach (String platterNumberKey in media.GetSubKeyNames())
                    {
                        using (RegistryKey platter = media.OpenSubKey(platterNumberKey))
                        {
                            String containsFiles = platter.GetValue("Contains Files").ToString();
                            int platterNumber = int.Parse(platterNumberKey);
                            if (containsFiles.ToUpper() == "YES" && this.GetPlatterFileCount(platterNumber) > 0)
                            {
                                String platterName = platter.GetValue("Name").ToString();
                                String serialNumber = platter.GetValue("Serial Number").ToString();
                                int status = (int)platter.GetValue("Status");
                                PlatterInformation platterInfo = new PlatterInformation(int.Parse(platterNumberKey),
                                platterName, serialNumber, status);
                                platterByNumber.Add(platterNumber, platterInfo);
                            }
                        }
                    }
                }
            }
            return platterByNumber; 
        }

        /// <summary>
        /// Determine the number of files contained on the platter identified by platterNumber.
        /// </summary>
        /// <param name="platterNumber">The unique platter identifier that identifies the platter in the windows registry.</param>
        /// <returns>The number of files contained on the platter.</returns>
        private int GetPlatterFileCount(int platterNumber)
        {
            int fileCount = 0;
            String platterNumberKey = platterNumber.ToString().PadLeft(PLATTER_NUMBER_KEY_LENGTH, '0');
            using (RegistryKey extendedDrives = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Legato\DiskXtender\ExtendedDrives")) // read only
            {
                foreach (String extendedDrive in extendedDrives.GetSubKeyNames())
                {
                    using (RegistryKey platter = extendedDrives.OpenSubKey(extendedDrive + @"\Media\" + platterNumberKey))
                    {
                        if (platter != null)
                        {
                            fileCount = int.Parse(platter.GetValue("FilterFileCount").ToString());
                            break;
                        }
                    }
                }
            }

            return fileCount;
        }

        /// <summary>
        /// If a platter is referred by a DEX file extended attribute to that is not in the platter list, this method will attempt
        /// to add it on the fly. This could occur if a new platter was brought online after the platter list was obtained.
        /// </summary>
        /// <param name="platterNumber">The unique platter identifier that identifies the platter in the windows registry.</param>
        /// <returns>true if the platter was successfully added</returns>
        private bool AddNewPlatter(int platterNumber)
        {
            bool platterAdded = false;
            Debug.Assert(platterByNumber != null, "platterByNumber does not exist");
            Debug.Assert(!platterByNumber.ContainsKey(platterNumber), "platterByNumber contains key " + platterNumber.ToString());
            String platterNumberKeyName = platterNumber.ToString().PadLeft(PLATTER_NUMBER_KEY_LENGTH, '0');
            using (RegistryKey platter = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Legato\XMS\Media\" + platterNumberKeyName)) // read only
            {
                if (platter != null)
                {
                    String platterName = platter.GetValue("Name").ToString();
                    String serialNumber = platter.GetValue("Serial Number").ToString();
                    int status = (int)platter.GetValue("Status");
                    if (platterName.Length > 0 && serialNumber.Length > 0)
                    {
                        PlatterInformation platterInfo = new PlatterInformation(platterNumber,
                            platterName, serialNumber, status);

                        platterByNumber.Add(platterNumber, platterInfo);
                        platterAdded = true;
                    }
                }
            }
            return platterAdded;
        }

        /// <summary>
        /// Given a platter number, this method will return a filename suitable for conaining the platter report. If the
        /// platter associated with the writer member vailable is different than platterNumber than then writer will be
        /// closed and the correct report file opened.
        /// </summary>
        /// <param name="platterNumber">The unique platter identifier that identifies the platter in the windows registry.</param>
        /// <returns>The platter report file name.</returns>
        private String GetPlatterReportFilename(int platterNumber)
        {
            PlatterInformation platterInfo = this.platterByNumber[platterNumber];
            return PLATTER_DETAIL_REPORT_PREFIX + platterInfo.PlatterName + " (" + platterInfo.PlatterSerialNumber + ").txt";
        }

        /// <summary>
        /// Writes a line to the platter report file assocated with the platter identified by platterNumber.
        /// </summary>
        /// <param name="platterNumber">The unique platter identifier that identifies the platter in the windows registry.</param>
        /// <param name="filespec">The filespec of the file that resides on the platter.</param>
        private void WritePlatterReportLine(int platterNumber, String filespec)
        {
            if (this.lastPlatterNumber != platterNumber) 
            {
                if (this.writer != null)
                {
                    this.writer.Close();
                }
                String reportFilespec = Path.Combine(this.outputFolder, this.GetPlatterReportFilename(platterNumber));
                PlatterInformation platterInfo = this.platterByNumber[platterNumber];
                this.writer = new StreamWriter(reportFilespec, true);
                this.lastPlatterNumber = platterNumber;
            }
            writer.WriteLine(this.ConvertFilespecToUnc(filespec));
        }

        /// <summary>
        /// Given a fully qualified filename, this method returns the UNC equivalent based on the share information
        /// specified in the shareName and sharePhysicalPath member variables.
        /// </summary>
        /// <param name="filespec"></param>
        /// <returns>the UNC equivalent of filespec</returns>
        private String ConvertFilespecToUnc(String filespec)
        {
            return @"\\" + System.Environment.MachineName + @"\" + this.share.ShareName + filespec.Substring(this.share.SharePath.Length);
        }

        /// <summary>
        /// This method returns a sorted list of platter information sorted by concatenating platter name and serial number.
        /// The sorted list is used to order the information written out in the platters with files report.
        /// </summary>
        /// <returns>A list of platter information sorted by platter name and serial number.</returns>
        private IList<PlatterInformation> GetPlatterNamesForReport()
        {
            Dictionary<int, PlatterInformation> platterMap = GetPlattersIndexedByPlatterNumber();
            SortedList<String, PlatterInformation> platterReportList = new SortedList<String, PlatterInformation>();
            foreach (int platterNumber in platterMap.Keys)
            {
                String key = platterMap[platterNumber].PlatterName + "_" + platterMap[platterNumber].PlatterSerialNumber;
                platterReportList.Add(key, platterMap[platterNumber]);
            }
            return platterReportList.Values;
        }

        private void WritePlatterDetailReportsForFolderAndRecurse(String parentFolder)
        {
            String[] folders = Directory.GetDirectories(parentFolder);
            long folderCount = folders.Length;

            foreach (String folder in folders)
            {
                if (this.CanRun == false)
                {
                    break;
                }
                WritePlatterDetailReportsForFolder(folder);
            }

            // maintain compatibility with the folder traversal order that was used previously when retrieving a folder
            // list using Directory.GetDirectories(share.SharePath, "*", SearchOption.AllDirectories)
            for (int i = folders.Length - 1; i >= 0; i--)
            {
                if (this.CanRun == false)
                {
                    break;
                }
                WritePlatterDetailReportsForFolderAndRecurse(folders[i]);
            }
        }

        /// <summary>
        /// Writes the share name to the NETWORK_SHARES_PROCESSED_FILENAME file in the current output folder to indicate
        /// that the output folder contains detail platter reports for the share.
        /// </summary>
        private void MarkNetworkShareProcessedInOutputFolder()
        {
            String filespec = Path.Combine(this.outputFolder, NETWORK_SHARES_PROCESSED_FILENAME);
            using (StreamWriter writer = new StreamWriter(filespec, true)) // append
            {
                writer.WriteLine(this.share.ShareName);
            }
        }
        #endregion

        #region public methods


        /// <summary>
        /// Check to see if the network share has platter reports in the current output folder.
        /// </summary>
        /// <param name="share">the network share that platter reportswill be searched for</param>
        /// <param name="folder">the folder to check for platter reports</param>
        /// <returns>true if platter reports for the network share exist in the specified output folder</returns>
        public bool IsNetworkSharePlatterReportsInFolder(NetworkShare share, String folder)
        {
            bool isNetworkSharePlatterReportsInFolder = false;
            String filespec = Path.Combine(folder, NETWORK_SHARES_PROCESSED_FILENAME);

            if (File.Exists(filespec))
            {
                using (StreamReader sr = new StreamReader(filespec))
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line == share.ShareName)
                        {
                            isNetworkSharePlatterReportsInFolder = true;
                            break;
                        }
                    }
                }
            }

            return isNetworkSharePlatterReportsInFolder;
        }

        /// <summary>
        /// Populates the passed DexShareDataTable with a list of share names and physical paths associated with the
        /// DEX drives on the local server. 
        /// </summary>
        public SortedList<String, NetworkShare> GetDexShares()
        {
            SortedList<String, NetworkShare> dexShares = new SortedList<String, NetworkShare>();
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Share");
            foreach (ManagementObject queryObj in searcher.Get())
            {
                String shareName = queryObj["Name"].ToString();
                String sharePath = queryObj["Path"].ToString();
                //String shareDescription = queryObj["Description"].ToString();
                if (sharePath.Length == 0 || Directory.GetDirectoryRoot(sharePath).ToUpper() == sharePath.ToUpper())
                {
                    continue; // ignore root directory shares and the $IPC share which does not have a path
                }
                else if (this.IsDexDrive(sharePath))
                {
                    NetworkShare dexShare = new NetworkShare(shareName, sharePath);
                    this.MarkIfDuplicate(dexShares, dexShare);
                    dexShares.Add(shareName, dexShare);
                    if (dexShare.IsDuplicate)
                    {
                        Logger().Info("Duplicate DEX share detected: " + shareName + " (" + sharePath + ")");
                        Logger().Info("Muliple shares mapped to the same directory: " + sharePath);
                    }
                    else
                    {
                        Logger().Info("DEX share detected: " + shareName + " (" + sharePath + ")");
                    }
                }
                //info(queryObj["Name"].ToString() + " " + queryObj["Path"].ToString() + " " + queryObj["Description"].ToString() +
                //    " " + queryObj["Status"].ToString());
            }

            return dexShares;
        }

        /// <summary>
        /// Compares the passed network share to the passed network shares collection. If two shares are mapped to the same share patch then both network shares
        /// will have their IsDuplicate property set.
        /// </summary>
        /// <param name="dexShares">A collection of Network locations to search.</param>
        /// <param name="dexShare">The network location whose SharePath is to be compared against the NetworkLocations in the dexShares collection. The assumption is that dexShare
        /// is NOT a part of the dexShares collection</param>
        private void MarkIfDuplicate(SortedList<String, NetworkShare> dexShares, NetworkShare dexShare)
        {
            foreach (KeyValuePair<String, NetworkShare> keyValue in dexShares)
            {
                if (keyValue.Value.SharePath.ToUpper() == dexShare.SharePath.ToUpper())
                {
                    keyValue.Value.IsDuplicate = true;
                    dexShare.IsDuplicate = true;
                }
            }
        }

        /// <summary>
        /// Determine if the absolute directory path resides on the DEX drive.
        /// </summary>
        /// <param name="path">A absolute path string. Absolute means the path string starts with a drive letter and
        /// includes all path information starting from the root directory.</param>
        /// <returns>true if the directory path resides on the DEX drive, false otherwise</returns>
        public bool IsDexDrive(String path)
        {
            bool isDexDrive = false;
            if (path.Length > 0)
            {
                String pathRoot = Directory.GetDirectoryRoot(path).ToUpper();
                using (RegistryKey extendedDrives = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Legato\DiskXtender\ExtendedDrives")) // read only
                {
                    if (extendedDrives != null)
                    {
                        foreach (String extendedDrive in extendedDrives.GetSubKeyNames())
                        {
                            using (RegistryKey driveInformation = extendedDrives.OpenSubKey(extendedDrive + @"\DriveInformation"))
                            {
                                String driveLetter = driveInformation.GetValue("DriveLetter").ToString();
                                String driveRoot = Directory.GetDirectoryRoot(driveLetter).ToUpper();
                                if (driveRoot == pathRoot)
                                {
                                    isDexDrive = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            return isDexDrive;
        }

        /// <summary>
        /// Creates the Platter Summary report which contains a list of platter that contain VistA Imaging files.
        /// </summary>
        public void PlatterSummaryReport()
        {
            String filespec = Path.Combine(this.outputFolder, PLATTER_SUMMARY_REPORT_FILENAME);
            this.info("   " + (File.Exists(filespec) ? "Refreshing" : "Building") + " Platter Summary Report");
            IList<PlatterInformation> platters = GetPlatterNamesForReport();
            using (StreamWriter writer = new StreamWriter(filespec, false)) // overwrite
            {
                writer.WriteLine("Platter Name\tPlatter Serial Number\tPlatter Status");
                foreach (PlatterInformation platter in platters)
                {
                    writer.WriteLine(platter.FormatForPlatterSummaryReport());
                }
            }
            this.info("   Done");
        }

        /// <summary>
        /// Cleans up after generating Platter Detail reports. Among other things, the StreamWriter associated with the last
        /// Platter Detail report to be written to is closed.
        /// </summary>
        public void PlatterReportCleanup()
        {
            if (writer != null)
            {
                writer.Close();
                writer = null;
            }
            this.lastPlatterNumber = -1;
        }

        /// <summary>
        /// Generate the Platter Detail reports for all the files contained on a network share.
        /// </summary>
        /// <param name="share">The NetworkShare to create detail reports for.</param>
        public void WritePlatterDetailReportsForNetworkShare(NetworkShare share)
        {
            Debug.Assert(this.IsNetworkSharePlatterReportsInFolder(share, this.outputFolder) == false);
            this.share = share;
            this.networkShareFileCount = 0;
            if (this.CanRun == true)
            {
                Logger().Info(this.info("   Building Platter Detail reports for network share " + share.ShareName));
                this.MarkNetworkShareProcessedInOutputFolder();
                this.WritePlatterDetailReportsForFolder(share.SharePath);
            }

            if (this.CanRun == true)
            {
                this.WritePlatterDetailReportsForFolderAndRecurse(share.SharePath);
            }

            if (this.CanRun == true)
            {
                Logger().Info(this.info("   Done. " + this.networkShareFileCount.ToString() + " files processed."));
            }
        }

        /// <summary>
        // For each file contained in the specified dirctory, determine the platter and write the fully qualified UNC file
        /// name to the appropriate Platter Detail report file.
        /// </summary>
        /// <param name="folder">The folder to process.</param>
        private void WritePlatterDetailReportsForFolder(String folder)
        {
            Dictionary<int, PlatterInformation> platterMap = GetPlattersIndexedByPlatterNumber();
            String[] files = Directory.GetFiles(folder);
            //Logger().Info("Processing folder: " + folder);
            this.networkShareFileCount += files.Length;

            foreach (String file in files)
            {
                processFile(file);
                if (canRun == false)
                {
                    break;
                }
                byte[] eaValue = NtDllHelper.GetFileExtendedAttributeValue(file, "$DEXDATA");
                if (eaValue != null)
                {
                    int index = PLATTER_NUMBER_OFFSET;
                    Debug.Assert(eaValue.Length >= index + 4);
                    int platterNumber = BitConverter.ToInt32(eaValue, index);
                    //info(eaValue[index].ToString() + " " + eaValue[index + 1].ToString() + " " + eaValue[index + 2].ToString() + " " + eaValue[index + 3].ToString() + " ");
                    if (platterMap.ContainsKey(platterNumber))
                    {
                        this.WritePlatterReportLine(platterNumber, file);
                    }
                    else
                    {
                        if (this.AddNewPlatter(platterNumber))
                        {
                            this.WritePlatterReportLine(platterNumber, file);
                            Logger().Info(info("New Platter Detected: " + platterMap[platterNumber].PlatterName));
                            this.PlatterSummaryReport(); // since we found a new platter the summary report must be re-run
                        }
                        else
                        {
                            // something is wrong with the way we are decoding the platter number from the
                            // $DEXDATA extended attribute OR disxtender has a reference to a platter that does not
                            // exist (encountered in Tampa).
                            Logger().Error(file + " platter " + platterNumber.ToString() + " not found");
                        }
                    }
                }
                else
                {
                    Logger().Info(file + " (created " + File.GetCreationTime(file).ToString("G") + ") cannot be associated with a platter."); // log but don't display
                }
                if (this.fileTimeDelay > 0)
                {
                    Thread.Sleep(this.fileTimeDelay);
                }
            }
        }

        /// <summary>
        /// Returns a count of platters that have files.
        /// </summary>
        /// <returns>Returns the number of platters detected that have files.</returns>
        public int GetPlatterCount()
        {
            return GetPlattersIndexedByPlatterNumber().Count;
        }

        /// <summary>
        /// Returns true if the version of DiskXtender is one that we support (ver 5 for now)
        /// </summary>
        /// <returns>true if we support the detected version of DiskXtender, false otherwise</returns>
        public bool IsDexVersionSupported()
        {
            bool isSupported = false;

            using (RegistryKey dexRegistration = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Legato\DiskXtender\Registration")) // read only
            {
                String dexVersion = dexRegistration.GetValue("Version").ToString(); //x.yy.zzz
                Debug.Assert(dexVersion != null);
                String[] parts = dexVersion.Split(new char[] {'.'});
                Debug.Assert(parts.Length > 0);
                int majorVersion = Int32.Parse(parts[0]);
                if (majorVersion == 5 || majorVersion == 4) // DKB - support version 4 - 2/18/2009
                {
                    isSupported = true;
                }
            }
            return isSupported;
        }
        #endregion
    }
}
