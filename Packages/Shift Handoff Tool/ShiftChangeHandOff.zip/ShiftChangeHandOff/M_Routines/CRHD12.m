CRHD12	; CAIRO/CLC - TIU EXTRACT - Extract section of the TIU document to be used in the CAIRO Hand-off Tool ;28-Jan-2008 15:40;CLC
	;;1.0;CRHD;****;Jan 28, 2008;
	;=================================================================
TIU(RTN,DFN,PLEV)	;
	N VAIN
	D INP^VADPT
	K RTN
	D GETDATA(.RTN,"",DFN,+$G(VAIN(7)),$$NOW^XLFDT,DUZ,"","",PLEV)  ;get TIU text
	Q
GETDATA(CRHDTN,AJRTITLE,CRHDDFN,CRHDSDT,CRHDEDT,CRHDUSER,CRHDCAP,CRHDEND,CRHDP)	;
	;AJRTITLE -progress note to use in the search for date
	;CRHDDFN -patient identifier
	;CRHDSDT -start date to retrieve data
	;CRHDEDT -end date for retrieval
	;CRHDUSER -user requesting data
	;CRHDCAP - TIU caption to extract data from note.
	;CRHDEND - end text extract
	;CRHDP - parameter level to retrieve parameters
	;======================================================
	N CRHDTXT,PNLST,N,QFLG,C,N,DOCFLG,LN,CRHDNDM,CRHDCDM,CRHDTIT,I2,STOPDT
	K CRHDTN,TCN,I,I3
	S LN=1,CRHDNDM="",CRHDCDM=""
	;get parameters from Vista parameter file
	D GETPARAM(CRHDP,.CRHDTITS,.CRHDCAP,.CRHDEND)
	Q:'CRHDTITS
	;if date not define default to todays date
	S CRHDSDT=$G(CRHDSDT,$$DT^XLFDT)
	S CRHDEDT=$G(CRHDEDT,$$NOW^XLFDT)
	S CRHDUSER=$G(CRHDUSER,DUZ)
	Q:'CRHDDFN
	Q:'CRHDUSER
	Q:CRHDCAP=""
	S DOCFLG=0
	D GETNOTES(.PNLST,CRHDDFN,.CRHDTITS)
	I $D(VAIN) S DFN=CRHDDFN D INP^VADPT
	S STOPDT=9999999.999999-+$G(VAIN(7))
	S INVDT=0
	F  S INVDT=$O(PNLST(INVDT)) Q:'INVDT!(INVDT>STOPDT)!(DOCFLG)  D
	.S N=0
	.F  S N=$O(PNLST(INVDT,N)) Q:'N!(DOCFLG)  S DOCFLG=N D
	..I $$CANDO^TIULP(DOCFLG,"VIEW",CRHDUSER) D
	...D TGET^TIUSRVR1(.CRHDTXT,DOCFLG)
	...S (N,QFLG)=0
	...F  S N=$O(@CRHDTXT@(N)) Q:'N!(QFLG)  D
	....S LINE=@CRHDTXT@(N)
	....F I=1:1:$L(CRHDCAP,"|") Q:$P(CRHDCAP,"|",I)=""  I LINE[$P(CRHDCAP,"|",I) D
	.....S TCN=$G(TCN)+1 I TCN=1 S CRHDTN(LN)="<<Note: "_$P($G(^TIU(8925.1,+$G(^TIU(8925,DOCFLG,0)),0)),"^",1)_" Signed by: "_$P($G(^VA(200,$P($G(^TIU(8925,DOCFLG,15)),"^",2),0)),"^",1)_" on "_$$FMTE^XLFDT(+$G(^TIU(8925,DOCFLG,15)),1)_">>"
	.....S C=(N-1),LN=$G(LN)+1
	.....F  S C=$O(@CRHDTXT@(C)) Q:'C!(QFLG)  D
	......F I3=1:1:$L(CRHDEND,"|") Q:$P(CRHDEND,"|",I3)=""  I @CRHDTXT@(C)[$P(CRHDEND,"|",I3) S QFLG=1
	......S:'QFLG CRHDTN(LN)=@CRHDTXT@(C),LN=LN+1
	..E  S DOCFLG=0
	Q
PARAM(W,X)	;
	Q $$GET^XPAR(W,X,1,"I")
	;
GETPARAM(CRHDPL,AJRTITLE,CRHDCAP,CRHDEND)	;
	N PAR,L
	S L=$L(CRHDPL,"^")
	I +CRHDPL S PAR=$P($P(CRHDPL,"^",L),"-",1)_".`"_+CRHDPL
	D GETLST^XPAR(.AJRTITLE,PAR,"AJRCHGOV TITLE LIST","I")
	D GETLST^XPAR(.AJRCAP,PAR,"AJRCHGOV CAPTION LIST","I")
	D GETLST^XPAR(.AJREND,PAR,"AJRCHGOV END CHAR LIST","I")
	Q
GETNOTES(LST,DFN,TITLE)	;
	N I,X
	S I=0
	F  S I=$O(TITLE(I)) Q:'I  D
	.S X=TITLE(I)
	.M LST=^TIU(8925,"APT",DFN,X,7)
	Q
