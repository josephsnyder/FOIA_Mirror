:: Department of Veterans Affairs
:: Office of Information and Technology (OI&T)
:: Office of Enterprise Development (OED)
:: Common Services Portfolio
:: Product: HealtheVet Web Services Client (HWSC)

:: Zip Contents: Production HWSC Components
:: Connectivity Scope: VistA/M to Remote Web Services

:: Version: 1.0.0.031

=======================================================
       CONTENTS
=======================================================

   I.  Introduction: XOBW Production Code
  II.  ASCII/Binary File Translation Issues (VMS Systems)
 III.  Documentation

=======================================================
   I.    Introduction: XOBW Production code
=======================================================

The HealtheVet Web Services Client (HWSC) product provides M/VistA-side 
applications access to remote web services. To support this functionality,
the M/VistA server must be a InterSystems Cache v5.2.3 adhoc 8574 or 
greater account.

This zipfile distributes the production components for the HWSC application, 
in the XOBW namespace.

The directory structure of the XOBW distribution zip file is as follows:

   /xobw-1.0.0.xxx
      - XOBW_1_0_Bxx.KID: M KIDS distribution for HWSC
      - XOBW_1_0_Bxx.XML: XML file containing Cache Object exports for HWSC
      - XOBW_1_0_Bxx.XML.MD5: integrity verification MD5 checksum for XML file

Note: A separate XOBT-namespaced distribution file is provided for the related, 
XOBT-namespaced, non-production components. These are sample applications, and as
will not be officially released. The XOBT components consist of a sample web 
application (to install on a J2EE server) and a matching web services client 
sample (to install on a Cache server). These are intended as programming examples
and are primarily of interest to developers.
        
=======================================================
  II.    ASCII/Binary File Translation Issues (VMS Systems)
=======================================================

As part of your installation process, you will need to unzip and transfer the 
following files to the file system of your M server:

�	XOBW_1_0_Bxx.KID (KIDS build) 
�	XOBW_1_0_Bxx.XML (Cache Objects export file)

For Windows and Linux M servers, transfer the two files to the M server 
as you normally would, e.g., using FTP's ASCII translation mode if already
unzipped.

For OpenVMS-based M servers, for Cach� up to and including v5.2.3 Adhoc 5059, 
however, due to a Cach� SAX Parser bug, the XOBW_1_0_Bxx.XML file must be 
transferred such that its line breaks end up following Windows conventions 
(not OpenVMS conventions). The easiest way to ensure this is to:

  1. [For installations on OpenVMS Cache servers only]
  2. Unzip the distribution zip on a Windows system
  3. Use FTP and transfer the XOBW_1_0_Bxx.XML file using BINARY ftp mode
  4. Use FTP and transfer the XOBW_1_0_Bxx.KID file using ASCII ftp mode (unlike
     the XML file, the .KID file should still be transferred via ftp in ASCII
     mode to all systems including OpenVMS.)

Although using BINARY mode to transfer an XML text file is counter-intuitive, 
doing so is necessary on OpenVMS systems due to a known bug in the SAX parser
used by Cach� on VMS systems up to and including Cach� v5.2.3 Adhoc 5059
versions. InterSystems plans to fix the issue in a future version of Cach�. 

=======================================================
 III.    Documentation
=======================================================

Refer to the HWSC documentation set for installation instructions and user manuals.
