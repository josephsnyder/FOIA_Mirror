package EXT.DOMAIN.pharmacy.ct.query;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
/**
 * @author rick.bloyer
 * 
 */
public class Query {
private Class entityReturnType = null;
private String clause = null;
private List<String> entities = null;
private List<String> columns = null;
private List<String> orderByColumns = null;
private List<Condition> conditions = null;
private Operator orderBy = null;
private boolean dummyQuery = false;
private String preBuiltHql;
private String queryAsXML = null;
/**
 * Default constructor. Construct an initialized Query object.
 */
public Query() {
clause = "SELECT ";
entities = new ArrayList();
columns = new ArrayList();
orderByColumns = new ArrayList();
conditions = new ArrayList<Condition>();
orderBy = Operator.ASC;
/**
 * This is constructor used as a dummy constructor when the hql has already
 * been defined by the query.
 * 
 * @param dummyQuery
 * @param preBuiltHql
 *            Hql that was already defined.
 */
public Query(final boolean dummyQuery, final String preBuiltHql,
final Class entityReturnType) {
this();
this.dummyQuery = dummyQuery;
this.preBuiltHql = preBuiltHql;
this.entityReturnType = entityReturnType;
/**
 * Construct an initialized Query object, assigning the entityReturnType
 * object.
 * 
 * @param entityReturnType
 *            object used to determine the table to query via the Hibernate
 *            ORM interface.
 */
public Query(final Class entityReturnType) {
this();
this.entityReturnType = entityReturnType;
/**
 * Retrieve the List of entites.
 * 
 * @return List of objects representing tables queried via the Hibernate ORM
 *         interface
 */
public List getEntities() {
return entities;
/**
 * Assign the List of entities.
 * 
 * @param entities
 */
public void setEntities(final List entities) {
this.entities = entities;
/**
 * Add an entity name to the List of entities.
 * 
 * @param entityName
 *            the table name to assign.
 */
public void setEntity(final String entityName) {
entities.add(entityName);
/**
 * Retrieve the List of query columns.
 * 
 * @return List of columns.
 */
public List getColumns() {
return columns;
/**
 * Assign List of columns to query.
 * 
 * @param columns
 *            List of column names.
 */
public void setColumns(final List columns) {
this.columns = columns;
/**
 * Add a column name to the List of columns.
 * 
 * @param column
 *            name to add.
 */
public void setColumn(final String column) {
columns.add(column);
/**
 * Retrieve List of columns sorted in natural order.
 * 
 * @return List of columns sorted in natural order.
 */
public List<String> getOrderByColumns() {
return orderByColumns;
/**
 * Assign List of ordered columns.
 * 
 * @param orderByColumns
 *            List of ordered columns.
 */
public void setOrderByColumns(final List<String> orderByColumns) {
this.orderByColumns = orderByColumns;
/**
 * Add a column to the List of ordered columns.
 * 
 * @param column
 *            name to add to the List of ordered columns.
 */
public void setOrderByColumn(final String column) {
orderByColumns.add(column);
/**
 * Assign an order by column. This will result in a SQL ORDER BY clause at
 * the end of the SQL query.
 * 
 * @param column
 *            the column to set ORDER BY
 * @param operator
 *            indicating ASC or DESC order
 */
public void setOrderByColumn(final String column, final Operator operator) {
orderByColumns.add(column);
orderBy = operator;
/**
 * Retrieve the List of conditions.
 * 
 * @param ordered
 *            flag indicating that the conditions will be sorted in assigned
 *            order.
 * @return List of conditions.
 */
public List<Condition> getConditions(final boolean ordered) {
if (ordered) {
Collections.sort(conditions);
return conditions;
/**
 * Assign the List of conditions.
 * 
 * @param conditions
 *            List to assign.
 */
public void setConditions(final List<Condition> conditions) {
this.conditions = conditions;
/**
 * Add a condition to the List of conditions.
 * 
 * @param condition
 *            the condition to add.
 */
public void addCondition(final Condition condition) {
conditions.add(condition);
/**
 * Remove a condition from the conditions collection
 * 
 * @param condition
 */
public void dropCondition(Condition condition)
if( condition != null )
if( conditions.contains(condition))
conditions.remove(condition);
/**
 * Retrieve the assigned query in HQL syntax.
 * 
 * @param ordered
 *            flag indicating whether the assigned conditions are ordered or
 *            not.
 * @return HQL query in String format.
 */
public String getHQLQuery(final boolean ordered)
if (dummyQuery)
return preBuiltHql;
if (ordered && conditions.size() > 0)
Collections.sort(conditions);
StringBuffer expression = new StringBuffer();
String t1Alias = "t1";
String entityName = entityReturnType.getSimpleName() + " as " + t1Alias;
if (columns.size() > 0)
expression.append("select ");
Iterator<String> cIter = columns.iterator();
for (int i = 0; i < columns.size(); i++)
expression.append(t1Alias);
expression.append(".");
expression.append(cIter.next());
if (i != columns.size() - 1) 
expression.append(", ");
expression.append("\n");
expression.append("from ");
expression.append(entityName);
if (conditions.size() > 0)
expression.append("\n");
expression.append("where ");
Condition cond = null;
for (int i = 0; i < conditions.size(); i++)
cond = conditions.get(i);
if( cond.isLower() )
expression.append("lower(");
expression.append(t1Alias);
expression.append(".");
expression.append(cond.getCondition());
if (i != conditions.size() - 1)
expression.append(" " + cond.getPredicate() + " ");
expression.append("\n");
if (orderByColumns.size() > 0)
Iterator<String> oIter = orderByColumns.iterator();
expression.append("order by ");
for (int j = 0; j < orderByColumns.size(); j++)
expression.append(t1Alias);
expression.append(".");
expression.append(oIter.next());
if (j != orderByColumns.size() - 1)
expression.append(", ");
expression.append(" ");
expression.append(getOrderBy());
return expression.toString();
/**
 * Retrieve the HQL query WHERE clause.
 * 
 * @return HQL query WHERE clause in String format.
 */
public String getHQLWhereClause() {
StringBuffer expression = new StringBuffer();
expression.append("where ");
Condition cond = null;
for (int i = 0; i < conditions.size(); i++) {
cond = conditions.get(i);
expression.append(cond.getCondition());
if (i != conditions.size() - 1) {
expression.append(" " + cond.getPredicate() + " ");
expression.append("\n");
if (orderByColumns.size() > 0) {
Iterator<String> oIter = orderByColumns.iterator();
expression.append("order by ");
for (int j = 0; j < orderByColumns.size(); j++) {
expression.append(oIter.next());
if (j != orderByColumns.size() - 1) {
expression.append(", ");
expression.append(" ");
expression.append(getOrderBy());
return expression.toString();
/**
 * Retrieve the entity return type.
 * 
 * @return the Class object of the assigned entity return type.
 */
public Class getEntityReturnType() {
return entityReturnType;
/**
 * Sets the entity return type
 * 
 * @param entityReturnType
 *            The Class object of the query
 */
public void setEntityReturnType(final Class entityReturnType) {
this.entityReturnType = entityReturnType;
/**
 * Retrieve the SELECT clause statement in SQL format.
 * 
 * @return the SQL SELECT clause.
 */
public String getClause() {
return clause;
/**
 * Assign the SELECT clause.
 * 
 * @param clause
 *            the SELECT clause.
 */
public void setClause(final String clause) {
this.clause = clause;
/**
 * Retrieve the order by Operator
 * 
 * @return Operator indicating order by direction.
 */
public Operator getOrderBy() {
return orderBy;
/**
 * Assign the order by direction operator.
 * 
 * @param orderBy
 *            operator.
 */
public void setOrderBy(final Operator orderBy) {
this.orderBy = orderBy;
public String getQueryAsXML()
return queryAsXML;
public void setQueryAsXML(String queryAsXML)
this.queryAsXML = queryAsXML;
