Test Build
Configured with CT_EAR/build.dev.properties file
This document describes the Custom Tables Application build process.  The intended audience for this document is the Configuration Manager role, or whomever will be building and deploying the EAR application archive to the test and production application servers.  The process features targets for building a deployable Enterprise Application Archive (EAR) file for either a testing or production environment.
*** Test Build ***
Test build ANT targets:
  build-test: Compiles the source including test code source, with compiler debug parameters to distribution directory
  dist-test: Builds and creates testing distribution archive
  all-test: Builds everything for testing deploy, including generating Javadoc documentation
The test build will compile the source code classes with the following bytecode settings:
  -include bytecode debug information, with debug level set to "source, lines, vars"
  -compiler deprecation warning set to on
  -compiler warning reports "unchecked" conversions, casts, method invocations, collection calls etc etc
The test build will copy the following test configuration files to their respective deployable locations:
  -CT_EAR/build.dev.properties to CT_EAR/build.properties build configuration
  -CT_EAR/log4j.dev.properties to APP-INF/classes/log4j.properties logging configuration
  -CT_WEB/WebContents/WEB-INF/web-test.xml as the web.xml deployment descriptor (renames it to web.xml)
The test build will include all test libraries in directory:
  -CT_EAR/APP-INF/lib/dev
The test bill will include in the compile all test source code in directories:
  -CT_WEB/test
  -CT_WEB/src/EXT/DOMAIN/pharmacy/ct/web/test
*** Production Build ***
Test build ANT targets:
  build: Compile the production source to distribution directory
  dist: Builds and creates production distribution archive
  all: Builds everything for production deploy, including generating Javadoc documentation
The production build will compile the source code classes with the following bytecode settings:
  -bytecode debug information turned off
  -compiler deprecation warning turned of 
  -no compiler warning reports
The production build will copy the following production configuration files to their respective deployable locations:
  -CT_EAR/build.prod.properties to CT_EAR/build.properties build configuration
  -CT_EAR/log4j.prod.properties to APP-INF/classes/log4j.properties logging configuration
  -CT_WEB/WebContents/WEB-INF/web-prod.xml as the web.xml deployment descriptor (renames it to web.xml)
