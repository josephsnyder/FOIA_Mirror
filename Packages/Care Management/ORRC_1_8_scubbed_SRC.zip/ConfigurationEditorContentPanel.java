package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.config.internal.Parameter;
import gov.va.med.hds.cd.spectrum.GradientPanel;
import gov.va.med.hds.cd.spectrum.jsorttable.JSortTable;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorContentPanel extends JPanel {
	private GradientPanel titlePanel;
	private JPanel tablePanel;
	private JScrollPane tableScrollPane;
	private JSortTable parameterTable;
	private JPanel propertyPanel;
	private JTabbedPane tabPane;
	private JSplitPane splitPane;
	private JPopupMenu tablePopMenu;
	private ListSelectionModel listSelModel;
	private IParameterCategory parameterCategory;
	private String title = "";
	private ConfigurationEditorCategoryPropertyPanel catPropPanel;
	private ConfigurationEditorParameterPropertyPanel paramPropPanel;
	private ConfigurationEditorParameterTableModel parameterTableModel;
	private Parameter parameter;
	private ParameterDefinitionModel parameterDefinitionModel;

	private int newParameterSuffix = 1;

	/** Creates new form UiPreferencePanel */
	public ConfigurationEditorContentPanel(ParameterDefinitionModel parameterDefinitionModel) {
		this.parameterDefinitionModel = parameterDefinitionModel;
		initGUI();
	}

	/** This method is called from within the constructor to initialize the form. */
	private void initGUI() {

		setLayout(new BorderLayout());
		setPreferredSize(new java.awt.Dimension(390, 385));
		setSize(new java.awt.Dimension(390, 385));

		// create titlePanel
		titlePanel =
			new GradientPanel(
				title,
				"",
				new Color(0, 0, 0),
				new Color(255, 255, 255),
				GradientPanel.LEFT_TO_RIGHT);
		add(titlePanel, BorderLayout.NORTH);
		titlePanel.setMinimumSize(new Dimension(10, 20));
		titlePanel.setPreferredSize(new Dimension(10, 20));
		titlePanel.setSize(new Dimension(390, 20));

		// create tablePanel
		tablePanel = new JPanel();
		tablePanel.setLayout(new BorderLayout());

		parameterTable = new JSortTable();
		parameterTableModel =
			new ConfigurationEditorParameterTableModel(parameterCategory);
		parameterTable.setModel(parameterTableModel);
		parameterTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		listSelModel = parameterTable.getSelectionModel();
		listSelModel.addListSelectionListener(new ParamSelector());

		tableScrollPane = new JScrollPane();
		tableScrollPane.setViewportView(parameterTable);
		tableScrollPane.setHorizontalScrollBarPolicy(
			JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		tableScrollPane.setVerticalScrollBarPolicy(
			JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		tablePanel.add(tableScrollPane, BorderLayout.CENTER);
		tablePanel.setPreferredSize(new java.awt.Dimension(390, 185));
		setSize(new java.awt.Dimension(390, 185));

		// create propertyPanel
		propertyPanel = new JPanel();
		propertyPanel.setLayout(new BorderLayout());

		tabPane = new JTabbedPane(JTabbedPane.BOTTOM);
		catPropPanel = new ConfigurationEditorCategoryPropertyPanel();
		tabPane.addTab("Category", catPropPanel);

		paramPropPanel = new ConfigurationEditorParameterPropertyPanel(parameterDefinitionModel);
		tabPane.addTab("Parameter", paramPropPanel);
		propertyPanel.add(tabPane, BorderLayout.CENTER);
		propertyPanel.setPreferredSize(new java.awt.Dimension(390, 200));
		propertyPanel.setSize(new java.awt.Dimension(390, 200));

		// create splitPane
		splitPane =
			new JSplitPane(
				JSplitPane.VERTICAL_SPLIT,
				tablePanel,
				propertyPanel);
		splitPane.setOneTouchExpandable(true);
		add(splitPane, BorderLayout.CENTER);

		// create context menu for parameter
		tablePopMenu = new JPopupMenu();

		//create addNode menu item
		JMenuItem addParameter = new JMenuItem("New");
		addParameter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		tablePopMenu.add(addParameter);

		//create deleteNode menu item
		JMenuItem deleteParameter = new JMenuItem("Delete");
		deleteParameter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		tablePopMenu.add(deleteParameter);
		tablePopMenu.addSeparator();
		//create refreshTable menu item
		JMenuItem refreshTable = new JMenuItem("Refresh");
		refreshTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		tablePopMenu.add(refreshTable);
		// add listener to configTree to invoke outlinePopMenu
		MouseListener popupListener = new TablePopupListener();

		parameterTable.addMouseListener(popupListener);

	}

	public void setTitle(String title) {
		titlePanel.setTitle(title);
	}
	
	public void resetContents(IParameterCategory pc) {
		parameterCategory = pc;
		title = (pc == null ? "" : pc.toString());
		titlePanel.setTitle(title);
		if ((pc != null) && (pc.getName() != "Retrieving data...")) {
			(
				(ConfigurationEditorParameterTableModel) parameterTable
					.getModel())
					.setParameterList(
				pc);
			catPropPanel.setCategory(pc);
		}
		if (parameterCategory.isLeaf()) {
			if (parameterTable.getRowCount() > 0) {
				parameterTable.changeSelection(0, 0, false, false);
			}
			
			tabPane.setSelectedComponent(paramPropPanel);
		} else {
			tabPane.setSelectedComponent(catPropPanel);
		}
		
		revalidate();
	}

	class ParamSelector implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			int selectedRow;

			if (!e.getValueIsAdjusting()) {
				selectedRow = parameterTable.getSelectedRow();
				if (selectedRow >= 0) {
					parameter =
						(
							(ConfigurationEditorParameterTableModel) parameterTable
								.getModel())
								.getParameterAt(
							selectedRow);
					paramPropPanel.setParameter(
						parameter,
						parameterCategory,
						parameterTableModel,
						selectedRow);
					tabPane.setSelectedComponent(paramPropPanel);
				}
			}
		}
	}

	class TablePopupListener extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			maybeShowPopup(e);
		}

		public void mouseReleased(MouseEvent e) {
			maybeShowPopup(e);
		}

		private void maybeShowPopup(MouseEvent e) {
			if (e.isPopupTrigger()) {
				tablePopMenu.show(e.getComponent(), e.getX(), e.getY());
			}
		}
	}

	/**
	 * Method addParameter.
	 */
	public void addParameter() {
		parameter =
			new Parameter(
				"New Parameter" + newParameterSuffix,
				parameterCategory.getConfiguration(),
				parameterCategory);
		parameter.setKey("New Parameter" + newParameterSuffix + " Key^^");
		parameter.setValue("New Parameter" + newParameterSuffix++ +" Value");
		parameterCategory.addParameter(parameter.getKey(), parameter);
		int newRow =
			parameterTableModel.addParameter(parameter, parameterCategory);
		parameterTable.setRowSelectionInterval(newRow, newRow);
	}
	
	/**
	 * Method addParameterDefinition.
	 */
	public void addParameterDefinition() {
		parameter =
			new Parameter(
				"New Parameter" + newParameterSuffix,
				parameterCategory.getConfiguration(),
				parameterCategory);
		parameter.setKey("New Parameter" + newParameterSuffix + " Key^^");
		parameter.setValue("New Parameter" + newParameterSuffix++ +" Value");
		parameterCategory.addParameter(parameter.getKey(), parameter);
		int newRow =
			parameterTableModel.addParameter(parameter, parameterCategory);
		parameterTable.setRowSelectionInterval(newRow, newRow);
	}

}
