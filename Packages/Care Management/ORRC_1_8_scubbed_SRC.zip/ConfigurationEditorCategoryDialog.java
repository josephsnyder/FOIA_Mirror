/*
 * Created on Feb 27, 2003 2:47:53 PM
 */
package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.spectrum.GradientPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorCategoryDialog extends JDialog {

	GradientPanel topPanel;
	JPanel definitionPanel;
	JPanel propertyPanel;
	JPanel bottomPanel;
	JPanel buttonPanel;
	JLabel iconLabel;
	JButton finishButton;
	JButton cancelButton;
	
	public ConfigurationEditorCategoryDialog() {
		super();
		initGUI();
	}

	private void initGUI() {

		setTitle("New");
		setModal(true);
		setResizable(false);
        iconLabel =
            new JLabel(
                new ImageIcon(
                    ConfigurationEditorCategoryDialog.class.getResource(
                        "CategoryGlyph.gif")));
		iconLabel.setOpaque(false);

		topPanel =
			new GradientPanel(
				"Category",
				"Define a new Category.",
				new Color(0, 0, 0),
				new Color(255, 255, 255),
				GradientPanel.LEFT_TO_RIGHT);
		iconLabel.setBorder(new EmptyBorder(0, 0, 0, 20));
		setComponentSize(topPanel, new Dimension(485, 66));
		topPanel.add(iconLabel, BorderLayout.EAST);
		getContentPane().add(topPanel, BorderLayout.NORTH);

		definitionPanel = new JPanel();
		definitionPanel.setLayout(
			new BoxLayout(definitionPanel, BoxLayout.Y_AXIS));
		setComponentSize(definitionPanel, new Dimension(485, 410));
		getContentPane().add(definitionPanel, BorderLayout.CENTER);

		bottomPanel = new JPanel();
		setComponentSize(bottomPanel, new Dimension(485, 50));
		bottomPanel.setLayout(new BorderLayout());
		bottomPanel.add(new JSeparator(), BorderLayout.NORTH);
		
		finishButton = new JButton("Finish");
		setComponentSize(finishButton, new Dimension(75, 27));
		finishButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doFinish();
				setVisible(false);
				dispose();
			}
		});

		cancelButton = new JButton("Cancel");
		setComponentSize(cancelButton, new Dimension(75, 27));
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doCancel();
				setVisible(false);
				dispose();
			}
		});
		
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setBorder(new EmptyBorder(5, 10, 5, 10));
		buttonPanel.add(finishButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(5, buttonPanel.getHeight())));
		buttonPanel.add(cancelButton);
		bottomPanel.add(buttonPanel, BorderLayout.EAST);		
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);

		pack();
	}

	private void doCancel() {
		// TODO
	}

	private void doFinish() {
		// TODO
	}

	private void setComponentSize(JComponent component, Dimension dimension) {
		component.setMaximumSize(dimension);
		component.setMinimumSize(dimension);
		component.setPreferredSize(dimension);
	}

	public static void main(String[] args) {
		JDialog dialog = (JDialog) new ConfigurationEditorCategoryDialog();

		dialog.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		dialog.show();
	}
}
