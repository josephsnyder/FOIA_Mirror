package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.IConfiguration;
import gov.va.med.hds.cd.config.IEntity;
import gov.va.med.hds.cd.config.IParameter;
import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.config.IParameterDefinition;
import gov.va.med.hds.cd.spectrum.LabelledItemPanel;
import gov.va.med.hds.cd.spectrum.text.StringField;
import gov.va.med.hds.util.mumps.StringUtil;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorParameterPropertyPanel
	extends JPanel
	implements ListDataListener, ActionListener {
	private LabelledItemPanel dialogPanel;
	private JLabel paramPropLabel = new JLabel("Edit Parameter");
	private JComboBox fullNameEditor;
	private IConfiguration configuration;
	private IParameterDefinition parameterDefinition;
	private ParameterDefinitionModel parameterDefinitionModel;
	private StringField nameEditor =
		new StringField(3, 80, 30);
	private JComboBox entityEditor;
	private StringField instanceEditor =
		new StringField(1, 80, 30);
	private StringField valueEditor =
		new StringField(3, 80, 30);
	private ComboBoxModel entityModel = new DefaultComboBoxModel();
	private IParameterCategory parameterCategory;
	private IParameter parameter;
	private ConfigurationEditorParameterTableModel parameterTableModel;
	private int parameterIndex;

	/** Creates new form ConfigurationEditorCategoryPropertyPanel */
	public ConfigurationEditorParameterPropertyPanel(ParameterDefinitionModel parameterDefinitionModel) {
		this.parameterDefinitionModel = parameterDefinitionModel;
		parameterDefinitionModel.addListDataListener(this);
		initGUI(parameterDefinitionModel);
	}

	private void initGUI(ParameterDefinitionModel parameterDefinitionModel) {
		dialogPanel = new LabelledItemPanel();

		fullNameEditor =
			new JComboBox(parameterDefinitionModel);
		fullNameEditor.addActionListener(this);

		entityEditor =
			new JComboBox(entityModel);

		setLayout(new BorderLayout());
		add(paramPropLabel, BorderLayout.NORTH);

		dialogPanel.setBorder(
			new CompoundBorder(
				new EtchedBorder(),
				new EmptyBorder(10, 10, 10, 10)));
		dialogPanel.setPreferredSize(new Dimension(360, 300));

		fullNameEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Full Name:", fullNameEditor);
		nameEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Display Name:", nameEditor);
		entityEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Entity:", entityEditor);
		instanceEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Instance:", instanceEditor);
		valueEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Value:", valueEditor);

		add(dialogPanel, BorderLayout.CENTER);

		setSize(getPreferredSize());
	}

	void setParameter(
		IParameter param,
		IParameterCategory pCat,
		ConfigurationEditorParameterTableModel pTableModel,
		int index) {

		IEntity selectedEntity = null;
		parameterIndex = index;
		parameter = param;
		parameterCategory = pCat;
		parameterTableModel = pTableModel;

		parameterDefinitionModel.setSelectedItem(param.getId());
		nameEditor.setValue(param.getName());
		nameEditor.grabFocus();
		nameEditor.selectAll();
		for (int i = 0; i < entityModel.getSize(); i++) {
			IEntity entity = (IEntity) entityModel.getElementAt(i);
			if (entity
				.getEntityGvn()
				.equals(";" + StringUtil.piece(param.getEntity(), ';', 2))) {
				selectedEntity = entity;
			}
		}
		if (selectedEntity != null) {
			entityEditor.setSelectedItem(selectedEntity);
		}
		instanceEditor.setValue(param.getInstance());
		valueEditor.setValue(param.getValue());
	}

	IParameter doApply() {

		//		parameter.setName(nameTextField.getText());
		//
		//		parameter.setKey(paramKeyTextField.getText());
		//
		//		parameter.setValue(paramValueTextField.getText());
		//
		return parameter;

	}

	private class ParameterChangeListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			//			if (e.getSource() == nameTextField) {
			//				String oldKey = parameter.getKey();
			//				parameter.setName(e.getActionCommand());
			//				String newKey =
			//					parameter.getName()
			//						+ '^'
			//						+ StringUtil.piece(oldKey, '^', 2)
			//						+ '^'
			//						+ StringUtil.piece(oldKey, '^', 3);
			//				parameter.setKey(newKey);
			//				parameterCategory.updateParameter(
			//					oldKey,
			//					newKey,
			//					parameter.getValue());
			//				paramKeyTextField.setText(parameter.getKey());
			//				paramKeyTextField.grabFocus();
			//			} else if (e.getSource() == paramKeyTextField) {
			//				String oldKey = parameter.getKey();
			//				String newKey = e.getActionCommand();
			//				parameter.setKey(newKey);
			//				parameter.setName(StringUtil.piece(parameter.getKey(), '^', 1));
			//				parameterCategory.updateParameter(
			//					oldKey,
			//					newKey,
			//					parameter.getValue());
			//				nameTextField.setText(parameter.getName());
			//				paramValueTextField.grabFocus();
			//				paramValueTextField.selectAll();
			//			} else if (e.getSource() == paramValueTextField) {
			//				parameter.setValue(e.getActionCommand());
			//				parameterCategory.putParameter(
			//					parameter.getKey(),
			//					parameter.getValue());
			//			}
			//			parameterTableModel.updateParameter(
			//				parameter,
			//				parameterIndex,
			//				parameterCategory);
		}
	}
	/**
	 * @see javax.swing.event.ListDataListener#intervalAdded(javax.swing.event.ListDataEvent)
	 */
	public void intervalAdded(ListDataEvent e) {
	}
	/**
	 * @see javax.swing.event.ListDataListener#intervalRemoved(javax.swing.event.ListDataEvent)
	 */
	public void intervalRemoved(ListDataEvent e) {
	}
	/**
	 * @see javax.swing.event.ListDataListener#contentsChanged(javax.swing.event.ListDataEvent)
	 */
	public void contentsChanged(ListDataEvent e) {
		if (e.getSource() instanceof ParameterDefinitionModel) {
			ParameterDefinitionModel pdm =
				(ParameterDefinitionModel) e.getSource();
			if (parameter != null) {
				parameterDefinition =
					parameterDefinitionModel.get(parameter.getId());
				if (parameterDefinition != null) {
					((DefaultComboBoxModel) entityModel).removeAllElements();
					Object[] entities =
						parameterDefinition.getEntities().toArray();
					for (int i = 0; i < entities.length; i++) {
						((DefaultComboBoxModel) entityModel).addElement(
							(IEntity) entities[i]);
					}
				}
			}
		}
	}

	/**
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		parameterDefinition =
			(IParameterDefinition) ((JComboBox) e.getSource())
				.getSelectedItem();
//		parameterDefinitionChanged();
	}

	private void parameterDefinitionChanged() {
		((DefaultComboBoxModel) entityModel).removeAllElements();
		Object[] entities = parameterDefinition.getEntities().toArray();
		for (int i = 0; i < entities.length; i++) {
			((DefaultComboBoxModel) entityModel).addElement(
				(IEntity) entities[i]);
		}
		if (parameterCategory.isLeaf()) {
			parameterCategory.setFullName(parameterDefinition.getFullName());
			parameterCategory.setName(parameterDefinition.getDisplayText());
		}
		nameEditor.setValue(parameterDefinition.getFullName());
	}

}
