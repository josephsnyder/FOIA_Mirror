package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.ConfigDAOEvent;
import gov.va.med.hds.cd.config.IConfigDAOListener;
import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.config.IParameterDefinition;
import gov.va.med.hds.cd.config.internal.ParameterCategory;
import gov.va.med.hds.cd.config.internal.ParameterDefinitionDataProvider;
import gov.va.med.hds.cd.runtime.IRuntimeContext;
import gov.va.med.hds.cd.spectrum.GradientPanel;
import gov.va.med.hds.cd.spectrum.LabelledItemPanel;
import gov.va.med.hds.cd.spectrum.longlist.BufferModel;
import gov.va.med.hds.cd.spectrum.longlist.LongListLookup;
import gov.va.med.hds.cd.spectrum.text.ILongListFieldSelectionListener;
import gov.va.med.hds.cd.spectrum.text.LongListField;
import gov.va.med.hds.cd.spectrum.text.OrderedListField;
import gov.va.med.hds.cd.spectrum.text.StringField;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Iterator;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorDefinitionDialog
	extends JDialog
	implements ILongListFieldSelectionListener, IConfigDAOListener {

	private JTabbedPane tabPane;
	private GradientPanel topPanel;
	private LabelledItemPanel definitionPanel;
	private LabelledItemPanel instancePanel;
	private LabelledItemPanel valuePanel;
	private LabelledItemPanel keyWordPanel;
	private LabelledItemPanel entityPanel;
	private JPanel propertyPanel;
	private JPanel bottomPanel;
	private JPanel buttonPanel;
	private JPanel cbPanel;
	private JLabel iconLabel;
	private JButton finishButton;
	private JButton cancelButton;
	private LongListField parameterDefinitionField;
	private LongListLookup lookupBox;
	private BufferModel bufferModel;
	private ParameterDefinitionDataProvider dataProvider;
	private Component parentComponent;
	private StringField displayTextField;
	private JCheckBox multipleValued;
	private StringField instanceTermField;
	private StringField valueTermField;
	private JCheckBox prohibitEditing;
	private StringField valueDataTypeField;
	private StringField valueDomainField;
	private StringField valueHelpField;
	private StringField valueValidationCodeField;
	private StringField valueScreenCodeField;
	private StringField instanceDataTypeField;
	private StringField instanceDomainField;
	private StringField instanceHelpField;
	private StringField instanceValidationCodeField;
	private StringField instanceScreenCodeField;
	private JTextArea description;
	private JScrollPane descriptionScrollPane;
	private OrderedListField entities;
	private OrderedListField keyWords;
	private IParameterCategory parameterCategory = null;
	private IParameterDefinition parameterDefinition = null;
	private IRuntimeContext runtime = null;

	public ConfigurationEditorDefinitionDialog(
		Component parentComponent,
		IRuntimeContext runtime) {
		super();
		this.parentComponent = parentComponent;
		this.runtime = runtime;
		initGUI();
	}

	private void initGUI() {

		setTitle("New");
		setModal(true);
		setResizable(false);
        iconLabel =
            new JLabel(
                new ImageIcon(
                    ConfigurationEditorDefinitionDialog.class.getResource(
                        "ParameterGlyph.gif")));
		iconLabel.setOpaque(false);

		topPanel =
			new GradientPanel(
				"Parameter",
				"Define a new Parameter.",
				new Color(0, 0, 0),
				new Color(255, 255, 255),
				GradientPanel.LEFT_TO_RIGHT);
		iconLabel.setBorder(new EmptyBorder(0, 0, 0, 20));
		setComponentSize(topPanel, new Dimension(485, 66));
		topPanel.add(iconLabel, BorderLayout.EAST);
		getContentPane().add(topPanel, BorderLayout.NORTH);

		propertyPanel = new JPanel();
		propertyPanel.setLayout(new BoxLayout(propertyPanel, BoxLayout.Y_AXIS));
		setComponentSize(propertyPanel, new Dimension(485, 445));

		definitionPanel = new LabelledItemPanel();
		definitionPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		setComponentSize(definitionPanel, new Dimension(485, 200));
		bufferModel = new BufferModel(300);

		try {
			dataProvider = new ParameterDefinitionDataProvider(runtime, bufferModel);
		} catch (Exception e1) {
			runtime.getLogger(getClass()).error("Unable to create instance of " + ParameterDefinitionDataProvider.class.getName(), e1);
		}
		
		dataProvider.setBufferModel(bufferModel);

		lookupBox = new LongListLookup();
		lookupBox.setModel(bufferModel);
		lookupBox.setPreferredSize(new Dimension(300, 300));

		parameterDefinitionField =
			new LongListField(
				3,
				80,
				30,
				"Select Parameter Definition",
				lookupBox,
				"");

		parameterDefinitionField.addSelectionListener(this);

		definitionPanel.addItem("Name:", parameterDefinitionField);

		displayTextField = new StringField(3, 80, 42);
		definitionPanel.addItem("Display Text:", displayTextField);

		cbPanel = new JPanel();
		cbPanel.setLayout(new BoxLayout(cbPanel, BoxLayout.X_AXIS));

		multipleValued = new JCheckBox("Multiple Valued");
		cbPanel.add(multipleValued);
		cbPanel.add(Box.createHorizontalGlue());

		prohibitEditing = new JCheckBox("Prohibit Editing");
		cbPanel.add(prohibitEditing);
		cbPanel.add(Box.createHorizontalGlue());

		definitionPanel.addItem("Modifiers:", cbPanel);

		description = new JTextArea(3, 35);
		description.setLineWrap(false);
		descriptionScrollPane = new JScrollPane(description);
		setComponentSize(descriptionScrollPane,	new Dimension(369, 70));
		definitionPanel.addItem("Description:", descriptionScrollPane);

		propertyPanel.add(definitionPanel);
		propertyPanel.add(new JSeparator());

		valuePanel = new LabelledItemPanel();
		valuePanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		valueTermField = new StringField(3, 80, 35);
		valuePanel.addItem("Value Term:", valueTermField);

		valueDataTypeField = new StringField(3, 80, 35);
		valuePanel.addItem("Value Data Type:", valueDataTypeField);

		valueDomainField = new StringField(3, 80, 35);
		valuePanel.addItem("Value Domain:", valueDomainField);

		valueHelpField = new StringField(3, 80, 35);
		valuePanel.addItem("Value Help:", valueHelpField);

		valueValidationCodeField = new StringField(3, 80, 35);
		valuePanel.addItem("Value Validation Code:", valueValidationCodeField);

		valueScreenCodeField = new StringField(3, 80, 35);
		valuePanel.addItem("Value Screen Code:", valueScreenCodeField);

		instancePanel = new LabelledItemPanel();
		instancePanel.setBorder(new EmptyBorder(10, 10, 10, 10));

		instanceTermField = new StringField(3, 80, 35);
		instancePanel.addItem("Instance Term:", instanceTermField);

		instanceDataTypeField = new StringField(3, 80, 35);
		instancePanel.addItem("Instance Data Type:", instanceDataTypeField);

		instanceDomainField = new StringField(3, 80, 35);
		instancePanel.addItem("Instance Domain:", instanceDomainField);

		instanceHelpField = new StringField(3, 80, 35);
		instancePanel.addItem("Instance Help:", instanceHelpField);

		instanceValidationCodeField = new StringField(3, 80, 35);
		instancePanel.addItem(
			"Instance Validation Code:",
			instanceValidationCodeField);

		instanceScreenCodeField = new StringField(3, 80, 35);
		instancePanel.addItem("Instance Screen:", instanceScreenCodeField);

		entityPanel = new LabelledItemPanel();
		entityPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		entities = new OrderedListField(310, 160);
		entityPanel.addItem("Entities:", entities);

		keyWordPanel = new LabelledItemPanel();
		keyWordPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		keyWords = new OrderedListField(290, 160);
		keyWordPanel.addItem("Keywords:", keyWords);

		tabPane = new JTabbedPane(JTabbedPane.TOP);
		tabPane.addTab("Value", valuePanel);
		tabPane.setMnemonicAt(0, KeyEvent.VK_V);
		tabPane.addTab("Instance", instancePanel);
		tabPane.setMnemonicAt(1, KeyEvent.VK_I);
		tabPane.addTab("Entities", entityPanel);
		tabPane.setMnemonicAt(2, KeyEvent.VK_E);
		tabPane.addTab("Keywords", keyWordPanel);
		tabPane.setMnemonicAt(3, KeyEvent.VK_K);

		propertyPanel.add(tabPane);

		getContentPane().add(propertyPanel, BorderLayout.CENTER);

		bottomPanel = new JPanel();
		setComponentSize(bottomPanel, new Dimension(485, 50));
		bottomPanel.setLayout(new BorderLayout());
		bottomPanel.add(new JSeparator(), BorderLayout.NORTH);

		finishButton = new JButton("Finish");
		setComponentSize(finishButton, new Dimension(75, 23));
		finishButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doFinish();
				setVisible(false);
				dispose();
			}
		});

		cancelButton = new JButton("Cancel");
		setComponentSize(cancelButton, new Dimension(75, 23));
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doCancel();
				setVisible(false);
				dispose();
			}
		});

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.setBorder(new EmptyBorder(5, 10, 5, 10));
		buttonPanel.add(finishButton);
		buttonPanel.add(
			Box.createRigidArea(new Dimension(5, buttonPanel.getHeight())));
		buttonPanel.add(cancelButton);
		bottomPanel.add(buttonPanel, BorderLayout.EAST);
		getContentPane().add(bottomPanel, BorderLayout.SOUTH);

		pack();

		int x =
			parentComponent.getX()
				+ ((parentComponent.getWidth() - getWidth()) / 2);
		int y =
			parentComponent.getY()
				+ ((parentComponent.getHeight() - getHeight()) / 2);

		setLocation(x, y);

		show();
	}

	private void doCancel() {
		parameterDefinition = null;
		parameterCategory = null;
	}

	private void doFinish() {
		
	}

	private void setComponentSize(JComponent component, Dimension dimension) {
		component.setMaximumSize(dimension);
		component.setMinimumSize(dimension);
		component.setPreferredSize(dimension);
	}

	public static void main(String[] args) {
		final JFrame launcher = new JFrame("Test Definition Dialog");
		JButton launchButton = new JButton("Go...");
		launchButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				new ConfigurationEditorDefinitionDialog(launcher, null);
			}

		});
		launcher.getContentPane().add(launchButton);

		launcher.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		launcher.pack();
		launcher.show();
	}

	/* (non-Javadoc)
	 * @see gov.va.med.hds.cd.spectrum.text.ILongListFieldSelectionListener#itemSelected(java.lang.Object)
	 */
	public void itemSelected(Object selectedItem) {
//		List callParams = new ArrayList();
//		callParams.add(((IBufferItem) selectedItem).getId());
//		ICallRequest request = new CallRequest("ORR GET PARAMETER DEFINITION", callParams);
//		ICallResultHandler handler = new ParameterDefinitionCallHandler();
//
//		dao.query(request, handler, this);
	}

	/* (non-Javadoc)
	 * @see gov.va.med.hds.cd.config.IConfigDAOListener#callFinished(gov.va.med.hds.cd.config.ConfigDAOEvent)
	 */
	public void callFinished(ConfigDAOEvent iCe) {
		List resultItems;
		if (iCe.getException() != null) {
			runtime.getLogger(getClass()).error("A configuration call finished due to an exception", iCe.getException());
		} else {
			resultItems = (List) iCe.getResultObject();
			Iterator itIt = resultItems.iterator();
			while (itIt.hasNext()) {
				parameterDefinition = (IParameterDefinition) itIt.next();
				setFields(parameterDefinition);
			}
			resultItems.clear();
		}

	}

	private void setFields(IParameterDefinition pd) {
		clearFields();

		parameterCategory = new ParameterCategory(pd);
		displayTextField.setValue(pd.getDisplayText());
		multipleValued.setSelected(pd.isMultiValued());
		prohibitEditing.setSelected(pd.isProhibitEditing());
		description.setText(pd.getDescription());

		valueTermField.setValue(pd.getValueTerm());
		valueDataTypeField.setValue(pd.getValueType());
		valueDomainField.setValue(pd.getValueDomain());
		valueHelpField.setValue(pd.getValueHelp());
		valueValidationCodeField.setValue(pd.getValueValidationCode());
		valueScreenCodeField.setValue(pd.getValueScreenCode());

		instanceTermField.setValue(pd.getInstanceTerm());
		instanceDataTypeField.setValue(pd.getInstanceType());
		instanceDomainField.setValue(pd.getInstanceDomain());
		instanceHelpField.setValue(pd.getInstanceHelp());
		instanceValidationCodeField.setValue(pd.getInstanceValidationCode());
		instanceScreenCodeField.setValue(pd.getInstanceScreenCode());
		
		entities.setList(pd.getEntities().toArray());
		keyWords.setList(pd.getKeyWords().toArray());
	}

	private void clearFields() {
		displayTextField.setValue("");

		multipleValued.setSelected(false);
		prohibitEditing.setSelected(false);
		description.setText("");
		description.setColumns(35);
		description.setRows(3);

		valueTermField.setValue("");
		valueDataTypeField.setValue("");
		valueDomainField.setValue("");
		valueHelpField.setValue("");
		valueValidationCodeField.setValue("");
		valueScreenCodeField.setValue("");

		instanceTermField.setValue("");
		instanceDataTypeField.setValue("");
		instanceDomainField.setValue("");
		instanceHelpField.setValue("");
		instanceValidationCodeField.setValue("");
		instanceScreenCodeField.setValue("");
		
//		entities.getList()
	}
	/**
	 * @return IParameterCategory
	 */
	public IParameterCategory getParameterCategory() {
		return parameterCategory;
	}

}
