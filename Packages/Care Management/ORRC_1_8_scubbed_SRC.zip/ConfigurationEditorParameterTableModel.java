package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.config.internal.Parameter;
import gov.va.med.hds.cd.spectrum.jsorttable.SortTableModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorParameterTableModel extends AbstractTableModel
	implements SortTableModel {
		
	ParameterColumn columns[] = { new ParameterNameColumn(),
								new ParameterEntityColumn(),
								new ParameterInstanceColumn(),
								new ParameterValueColumn()};
		
	public static final int NAME		= 0;
	public static final int ENTITY	= 1;
	public static final int INSTANCE	= 2;
	public static final int VALUE	= 3;

	private List data;
	private IParameterCategory parameterCategory;
	
	static final boolean DEBUG = false;
	
	public ConfigurationEditorParameterTableModel(IParameterCategory pCat) {
		if (pCat == null)
			data = new ArrayList();
		else {
			data = pCat.parametersAsArrayList();
			parameterCategory = pCat;
		}
	}

	public int getColumnCount() {
		return columns.length;
	}

	public int addParameter(Parameter parameter, IParameterCategory pCat) {
		parameterCategory = pCat;
		data.add(parameter);
		int newRow = data.indexOf(parameter);
		fireTableDataChanged();
		return newRow;
	}
	
	public void updateParameter(Parameter parameter, int pIndex, IParameterCategory pCat) {
		parameterCategory = pCat;
		data.set(pIndex, parameter);
		fireTableDataChanged();
	}
	
	public int getRowCount() {
		return data.size();
	}

	public String getColumnName(int col) {
		return columns[col].getColumnName();
	}
	
	public void setParameterList(IParameterCategory pCat) {
		data = pCat.parametersAsArrayList();
		fireTableDataChanged();	
	}

	public Object getValueAt(int row, int col) {
	
		Parameter param = getParameterAt(row);
		return columns[col].getField(param);

	}

	public Parameter getParameterAt(int row){
		Parameter pt = (Parameter) data.get(row);
		return pt;
	}
	
	public Class getColumnClass(int c) {
		return getValueAt(0, c).getClass();
	}

	public boolean isCellEditable(int row, int col) {
		return false;
	}
	
	public boolean isSortable(int col) {
		return true;
	}

	public void sortColumn(int col, boolean ascending) {
		columns[col].setSortOrder(ascending);
		Collections.sort(data, columns[col]);
	}
	
	private interface ParameterColumn extends Comparator {
		public void setSortOrder(boolean ascending);
		public String getColumnName();
		public Object getField(Parameter p);
	}
	
	private abstract class AbstractParameterColumn implements ParameterColumn {
      	boolean ascending;
		public void setSortOrder(boolean ascending) { this.ascending = ascending; }
      	public int compare(Object a, Object b) {
      		Parameter pa = (Parameter) a;
      		Parameter pb = (Parameter) b;
      		Object cOne = getField(pa);
      		Object cTwo = getField(pb);
      		if (ascending && cOne instanceof Comparable) {
				return ((Comparable) cOne).compareTo(cTwo);
			} else if (cTwo instanceof Comparable) {
				return ((Comparable) cTwo).compareTo(cOne);
			}
			return 1;
        }		
	}
	
	private class ParameterNameColumn extends AbstractParameterColumn {
		public String getColumnName() { return "Parameter Name"; }
		public Object getField(Parameter p) { return p.getName(); }
	}
	
	private class ParameterEntityColumn extends AbstractParameterColumn {
		public String getColumnName() { return "Entity"; }
		public Object getField(Parameter p) { return p.getExtEntity(); }
	}
	
	private class ParameterInstanceColumn extends AbstractParameterColumn {
		public String getColumnName() { return "Instance"; }
		public Object getField(Parameter p) { return p.getInstance(); }
	}

	private class ParameterValueColumn extends AbstractParameterColumn {
		public String getColumnName() { return "Value"; }
		public Object getField(Parameter p) { return p.getValue(); }
	}
	
}
