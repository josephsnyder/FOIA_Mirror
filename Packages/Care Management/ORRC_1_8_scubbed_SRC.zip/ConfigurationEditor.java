package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.ConfigurationChangeEvent;
import gov.va.med.hds.cd.config.ConfigurationException;
import gov.va.med.hds.cd.config.ConfigurationReadyEvent;
import gov.va.med.hds.cd.config.IConfigurationChangeListener;
import gov.va.med.hds.cd.config.IConfigurationEditorModel;
import gov.va.med.hds.cd.config.IConfigurationReadyListener;
import gov.va.med.hds.cd.config.IConfigurator;
import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.config.internal.ConfigurationEditorModel;
import gov.va.med.hds.cd.config.internal.ParameterCategory;
import gov.va.med.hds.cd.config.internal.ParameterTree;
import gov.va.med.hds.cd.prism.IDesktop;
import gov.va.med.hds.cd.prism.PrismUtilities;
import gov.va.med.hds.cd.prism.visualcomponent.IVisualComponent;
import gov.va.med.hds.cd.runtime.IConfigurationElement;
import gov.va.med.hds.cd.runtime.IRuntimeContext;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JSplitPane;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

/**
 * @author Joel Russell
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 **/
public class ConfigurationEditor
	extends JPanel
	implements
		IVisualComponent,
		IConfigurationReadyListener,
		IConfigurationChangeListener,
		TreeSelectionListener {

	private IRuntimeContext runtime;
	private IConfigurationEditorModel configEditorModel;
	private BorderLayout layout = new BorderLayout();
	private JLabel statusBar = new JLabel("Retrieving data...");
	private JSplitPane splitPane;
	private ConfigurationEditorContentPanel editorPanel;
	private ConfigurationEditorTreePanel configTree;
	private JPopupMenu categoryPopupMenu = new JPopupMenu();
	private IParameterCategory parameterCategory = null;
	private int newCategorySuffix = 1;
	private int newParameterSuffix = 1;
	private ParameterDefinitionModel parameterDefinitionModel;
	protected ConfigurationEditorDefinitionDialog definitionDialog;
	private IDesktop desktop;
	private IParameterCategory retrieveNode =
		new ParameterCategory("Retrieving data...", null);
	private ParameterTree configTreeModel;
	private IParameterCategory configRoot = new ParameterCategory("Root", null);

	public JComponent getComponent() {
		return this;
	}

	public void setInitializationData(
		IRuntimeContext runtime,
		IConfigurationElement config,
		String propertyName,
		Object data)
		throws Exception {
		this.runtime = runtime;
		this.desktop = PrismUtilities.getDesktop(runtime);
		configEditorModel = new ConfigurationEditorModel(runtime);

		parameterDefinitionModel =
			new ParameterDefinitionModel(
				(IConfigurator) runtime.getPluginInstance(
					IConfigurator.PLUGIN_ID));

		initGUI();
	}

	/** This method is called from within the constructor to initialize the form. */
	private void initGUI() {
		// set attributes of main panel
		setPreferredSize(new Dimension(640, 460));
		setLayout(new BorderLayout());

		// add status bar
		add(statusBar, BorderLayout.SOUTH);

		// create Tree Panel
		configTree = new ConfigurationEditorTreePanel(configEditorModel);
		configTree.setBounds(new java.awt.Rectangle(73, 213, 74, 72));
		configTree.getTree().addTreeSelectionListener(this);
		configTree.getTreeModel().addTreeModelListener(
			new ConfigTreeModelListener());

		// create editorPanel
		editorPanel =
			new ConfigurationEditorContentPanel(parameterDefinitionModel);

		// create splitPane
		splitPane =
			new JSplitPane(
				JSplitPane.HORIZONTAL_SPLIT,
				configTree,
				editorPanel);
		splitPane.setOneTouchExpandable(true);
		add(splitPane, BorderLayout.CENTER);

		//create newCategory menu item
		JMenu newCategory = new JMenu("New");

		//create addNode menu item
		JMenuItem addNode = new JMenuItem("Category");
		addNode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				parameterCategory =
					new ParameterCategory(
						"New Category " + newCategorySuffix++,
						configTree.getSelectedNode().getConfiguration());
				configTree.addNode(parameterCategory);
			}
		});
		newCategory.add(addNode);

		//create addParameter subMenu
		JMenuItem addParameter = new JMenuItem("Parameter");
		addParameter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				definitionDialog =
					new ConfigurationEditorDefinitionDialog(
						ConfigurationEditor
							.this
							.desktop
							.getActiveWindow()
							.getFrame(),
						ConfigurationEditor.this.runtime);
				parameterCategory = definitionDialog.getParameterCategory();
				if (parameterCategory != null) {
					configTree.addNode(parameterCategory);
				}
			}
		});
		newCategory.add(addParameter);

		categoryPopupMenu.add(newCategory);

		//create deleteNode menu item
		JMenuItem deleteNode = new JMenuItem("Delete");
		deleteNode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				configTree.removeCurrentNode();
				createCategoryPanel(parameterCategory);
			}
		});
		categoryPopupMenu.add(deleteNode);
		categoryPopupMenu.addSeparator();
		//create refreshTree menu item
		JMenuItem refreshTree = new JMenuItem("Refresh");
		refreshTree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				configTree.refresh();
			}
		});
		categoryPopupMenu.add(refreshTree);
		categoryPopupMenu.addSeparator();

		//create importConfiguration menu item
		JMenuItem importConfiguration = new JMenuItem("Import...");
		importConfiguration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		categoryPopupMenu.add(importConfiguration);

		//create exportConfiguration menu item
		JMenuItem exportConfiguration = new JMenuItem("Export...");
		exportConfiguration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		categoryPopupMenu.add(exportConfiguration);

		// add listener to configTree to invoke categoryPopupMenu
		MouseListener popupListener = new OutlinePopupListener();

		configTree.getTree().addMouseListener(popupListener);

	}

	private void createCategoryPanel(IParameterCategory pc) {
		editorPanel.resetContents(pc);
	}

	/**
	 * @see javax.swing.event.TreeSelectionListener#valueChanged(javax.swing.event.TreeSelectionEvent)
	 */
	public void valueChanged(TreeSelectionEvent e) {
		IParameterCategory category =
			(IParameterCategory) configTree
				.getTree()
				.getLastSelectedPathComponent();

		if (category == null)
			return;

		parameterCategory = category;
		createCategoryPanel(category);
	}

	class ConfigTreeModelListener implements TreeModelListener {
		public void treeNodesChanged(TreeModelEvent e) {
			IParameterCategory category =
				(IParameterCategory) (e.getTreePath().getLastPathComponent());

			try {
				int index = e.getChildIndices()[0];
				category = (IParameterCategory) (category.getChildAt(index));
			} catch (NullPointerException exc) {
			}

			createCategoryPanel(category);
		}
		public void treeNodesInserted(TreeModelEvent e) {
		}
		public void treeNodesRemoved(TreeModelEvent e) {
		}
		public void treeStructureChanged(TreeModelEvent e) {
		}
	}

	class OutlinePopupListener extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			maybeShowPopup(e);
		}

		public void mouseReleased(MouseEvent e) {
			maybeShowPopup(e);
		}

		private void maybeShowPopup(MouseEvent e) {
			if (e.isPopupTrigger()) {
				categoryPopupMenu.show(e.getComponent(), e.getX(), e.getY());
			}
		}
	}
	/**
	 * @see gov.va.med.hds.cd.config.IConfigurationChangeListener#configurationChanged(gov.va.med.hds.cd.config.ConfigurationChangeEvent)
	 */
	public void configurationChanged(ConfigurationChangeEvent cce) {

	}

	/**
	 * @see gov.va.med.hds.cd.config.IConfigurationReadyListener#configurationReady(gov.va.med.hds.cd.config.ConfigurationReadyEvent)
	 */
	public void configurationReady(ConfigurationReadyEvent cre) {
		statusBar.setText("Ready");
		statusBar.revalidate();
	}
	/**
	 * @see gov.va.med.hds.cd.config.IConfigurationReadyListener#configurationCallFailed(gov.va.med.hds.cd.config.ConfigurationException)
	 */
	public void configurationCallFailed(ConfigurationException ce) {
		statusBar.setForeground(Color.RED);
		statusBar.setText("Exception occurred: " + ce.getMessage());
	}
}
