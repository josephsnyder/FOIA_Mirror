package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.spectrum.LabelledItemPanel;
import gov.va.med.hds.cd.spectrum.text.StringField;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorCategoryPropertyPanel extends JPanel {
	private LabelledItemPanel dialogPanel;
	private JLabel paramPropLabel = new JLabel("Edit Category");
	private StringField fullNameEditor =
		new StringField(3, 80, 30);
	private StringField nameEditor =
		new StringField(3, 80, 30);
	private StringField pluginIdEditor =
		new StringField(3, 80, 30);
	private StringField parentEditor =
		new StringField(3, 80, 30);
	private JCheckBox packageRootEditor =
		new JCheckBox();
	private StringField preferencePageEditor =
		new StringField(3, 80, 30);
	private IParameterCategory parameterCategory;
	private ConfigurationEditorParameterTableModel parameterTableModel;
	private int parameterIndex;

	/** Creates new form ConfigurationEditorCategoryPropertyPanel */
	public ConfigurationEditorCategoryPropertyPanel() {
		initGUI();
	}

	private void initGUI() {
		dialogPanel = new LabelledItemPanel();

		setLayout(new BorderLayout());
		add(paramPropLabel, BorderLayout.NORTH);

		dialogPanel.setBorder(
			new CompoundBorder(
				new EtchedBorder(),
				new EmptyBorder(10, 10, 10, 10)));
		dialogPanel.setPreferredSize(new Dimension(360, 300));

		fullNameEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Full Name:", fullNameEditor);
		nameEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Display Name:", nameEditor);
		pluginIdEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		dialogPanel.addItem("Plugin ID:", pluginIdEditor);
		parentEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		parentEditor.setEnabled(false);
		dialogPanel.addItem("Parent:", parentEditor);
		packageRootEditor.setMaximumSize(new Dimension(Short.MAX_VALUE, 35));
		packageRootEditor.setEnabled(false);
		dialogPanel.addItem("Package Root:", packageRootEditor);

		add(dialogPanel, BorderLayout.CENTER);

		setSize(getPreferredSize());
	}

	void setCategory(IParameterCategory pc) {

		parameterCategory = pc;
		IParameterCategory parent = pc.getParent();
		String parentName = (parent == null ? "None" : parent.getName());
		fullNameEditor.setValue(pc.getFullName());
		nameEditor.setValue(pc.toString());
		pluginIdEditor.setValue(pc.getPluginId());
		parentEditor.setValue(parentName);
		preferencePageEditor.setValue(pc.getPreferencePage());
		packageRootEditor.setSelected(pc.isPackageRoot());
		this.revalidate();
	}

	IParameterCategory doApply() {

		//		parameterCategory.setName(nameTextField.getText());
		//
		//		parameterCategory.setPreferencePage(preferencePageTextField.getText());
		//
		return parameterCategory;

	}

	private class TextFieldListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == nameEditor) {
				parameterCategory.setName(e.getActionCommand());
			} else if (e.getSource() == preferencePageEditor) {
				parameterCategory.setPreferencePage(e.getActionCommand());
			}
		}
	}

}
