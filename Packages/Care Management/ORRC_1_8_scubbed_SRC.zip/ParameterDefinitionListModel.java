package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.ConfigurationException;
import gov.va.med.hds.cd.config.IConfigurator;
import gov.va.med.hds.cd.config.IParameterDefinition;
import gov.va.med.hds.cd.config.IParameterDefinitionCallListener;
import gov.va.med.hds.cd.config.ParameterDefinitionException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.ListModel;
import javax.swing.event.EventListenerList;
import javax.swing.event.ListDataListener;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
class ParameterDefinitionListModel
	implements ListModel, IParameterDefinitionCallListener {
	private IConfigurator configurator;
	private EventListenerList listeners = new EventListenerList();
	protected List list = new ArrayList();

	public ParameterDefinitionListModel(IConfigurator configurator) {
		this.configurator = configurator;
		list.add("Retrieving data...");
		try {
			configurator.parameterDefinitionQuery(this);
		} catch (ConfigurationException e) {
		}
	}

	/**
	 * @see javax.swing.ListModel#getSize()
	 */
	public int getSize() {
		return list.size();
	}
	/**
	 * @see javax.swing.ListModel#getElementAt(int)
	 */
	public Object getElementAt(int index) {
		return list.get(index);
	}
	/**
	 * @see javax.swing.ListModel#addListDataListener(javax.swing.event.ListDataListener)
	 */
	public void addListDataListener(ListDataListener lDl) {
		listeners.add(ListDataListener.class, lDl);
	}
	/**
	 * @see javax.swing.ListModel#removeListDataListener(javax.swing.event.ListDataListener)
	 */
	public void removeListDataListener(ListDataListener lDl) {
		listeners.remove(ListDataListener.class, lDl);
	}
	/**
	 * @see gov.va.med.hds.cd.config.IParameterDefinitionCallListener#callSucceeded(java.util.List)
	 */
	public void callSucceeded(List definitions) {
		list.clear();

		Iterator pdIt = definitions.iterator();

		while (pdIt.hasNext()) {
			IParameterDefinition pd = (IParameterDefinition) pdIt.next();
			list.add(pd);
		}
	}
	/**
	 * @see gov.va.med.hds.cd.config.IParameterDefinitionCallListener#callFailed(gov.va.med.hds.cd.config.ParameterDefinitionException)
	 */
	public void callFailed(ParameterDefinitionException e) {
	}
}
