package gov.va.med.hds.cd.config.editor;

import gov.va.med.hds.cd.config.ConfigurationException;
import gov.va.med.hds.cd.config.IConfigurator;
import gov.va.med.hds.cd.config.IParameterDefinition;
import gov.va.med.hds.cd.config.IParameterDefinitionCallListener;
import gov.va.med.hds.cd.config.ParameterDefinitionException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
class ParameterDefinitionModel extends DefaultComboBoxModel {
	private IConfigurator configurator;
	protected Map parameterDefinitionMap = new HashMap();

	public ParameterDefinitionModel(IConfigurator configurator) {
		super();
		addElement("Retrieving data...");
		try {
			configurator.parameterDefinitionQuery(new ParameterDefinitionCallListener());
		} catch (ConfigurationException e) {
		}
	}
	
	public IParameterDefinition get(long id) {
		return (IParameterDefinition) parameterDefinitionMap.get(new Long(id));
	}

	public void setSelectedItem(long id) {
		super.setSelectedItem(get(id));
	}

	class ParameterDefinitionCallListener implements IParameterDefinitionCallListener {

		/**
		 * @see gov.va.med.hds.cd.config.IParameterDefinitionCallListener#callSucceeded(java.util.List)
		 */
		public void callSucceeded(List definitions) {
			removeAllElements();
				
			Iterator pdIt = definitions.iterator();
				
			while (pdIt.hasNext()) {
				IParameterDefinition pd = (IParameterDefinition) pdIt.next();
				addElement(pd);
				parameterDefinitionMap.put(new Long(pd.getId()), pd);
			}
		}
		/**
		 * @see gov.va.med.hds.cd.config.IParameterDefinitionCallListener#callFailed(gov.va.med.hds.cd.config.ParameterDefinitionException)
		 */
		public void callFailed(ParameterDefinitionException e) {
		}

	}
}
