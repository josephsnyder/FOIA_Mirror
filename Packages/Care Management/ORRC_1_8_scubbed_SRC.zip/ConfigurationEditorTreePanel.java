package gov.va.med.hds.cd.config.editor;

import java.awt.Cursor;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceContext;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.io.IOException;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import gov.va.med.hds.cd.config.ConfigurationChangeEvent;
import gov.va.med.hds.cd.config.ConfigurationException;
import gov.va.med.hds.cd.config.ConfigurationReadyEvent;
import gov.va.med.hds.cd.config.IConfiguration;
import gov.va.med.hds.cd.config.IConfigurationChangeListener;
import gov.va.med.hds.cd.config.IConfigurationEditorModel;
import gov.va.med.hds.cd.config.IConfigurationReadyListener;
import gov.va.med.hds.cd.config.IParameterCategory;
import gov.va.med.hds.cd.config.internal.ParameterCategory;
import gov.va.med.hds.cd.config.internal.ParameterTree;
import gov.va.med.hds.cd.spectrum.OutlineRenderer;
import gov.va.med.hds.cd.spectrum.OutlineTree;
import gov.va.med.hds.util.mumps.StringUtil;
/**
 *
 * @author Joel Russell
 *
 * Department of Veterans Affairs
 * OI Field Office - Salt Lake City
 * Health Data Systems
 * 
 **/
public class ConfigurationEditorTreePanel
	extends JPanel
	implements
		IConfigurationReadyListener,
		IConfigurationChangeListener,
		TreeSelectionListener,
		DragGestureListener,
		DropTargetListener,
		DragSourceListener {
	protected IParameterCategory rootNode;
	protected ParameterTree treeModel;
	protected OutlineTree tree;
	protected OutlineRenderer treeCellRenderer;
	protected IConfiguration configuration;

	/** Stores the selected node info */
	protected TreePath selectedTreePath = null;
	protected IParameterCategory selectedNode = null;

	/** Variables needed for DnD */
	private DragSource dragSource = null;
	private DragSourceContext dragSourceContext = null;

	private Toolkit toolkit = Toolkit.getDefaultToolkit();
	private boolean dropOk = false;
	private IConfigurationEditorModel model;
	public ConfigurationEditorTreePanel(IConfigurationEditorModel model) {

		this.model = model;
//		configuration.addConfigurationReadyListener(this);
//		configuration.addConfigurationChangeListener(this);

		treeModel = (ParameterTree) model.getParameterTree();

		tree = new OutlineTree(treeModel);

		//drag and drop
		tree.initializeDnD(this, this, this, this);
		dragSource = tree.getDragSource();
		
		tree.setEditable(true);
		tree.getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);
		tree.setShowsRootHandles(true);
		tree.setRootVisible(true);
		expandAll();

		//Enable tool tips.
		ToolTipManager.sharedInstance().registerComponent(tree);
		treeCellRenderer = new OutlineRenderer();
		tree.setCellRenderer(treeCellRenderer);
		treeCellRenderer.setUseBold(false);

		//Add ScrollPane
		JScrollPane scrollPane = new JScrollPane(tree);
		scrollPane.setVerticalScrollBarPolicy(
			javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(
			javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		setLayout(new GridLayout(1, 0));
		add(scrollPane);

	}

	/** Returns The selected node */
	public IParameterCategory getSelectedNode() {
		return selectedNode;
	}

	/** Reload TreeModel. */
	public void refresh() {
		treeModel.reload();
		expandAll();
	}

	private void expandAll() {
		for (int i = 0; i < tree.getRowCount(); i++) {
			tree.expandRow(i);
		}
	}

	/** Remove the currently selected node. */
	public void removeCurrentNode() {
		TreePath currentSelection = tree.getSelectionPath();
		if (currentSelection != null) {
			IParameterCategory currentNode =
				(IParameterCategory) (currentSelection.getLastPathComponent());
			IParameterCategory parent =
				(IParameterCategory) (currentNode.getParent());
			if (parent != null) {
				// Confirm action
				int okToDelete =
					JOptionPane.showConfirmDialog(
						getRootPane(),
						"Are you sure you want to delete category "
							+ currentNode.toString()
							+ "?",
						"Confirm Deletion",
						JOptionPane.YES_NO_OPTION);
				if (okToDelete == JOptionPane.YES_OPTION) {
					treeModel.removeNodeFromParent(currentNode);
				}
			} else if (parent == null) {
				JOptionPane.showMessageDialog(
					tree.getRootPane(),
					"You may not delete the Root Category...",
					"Error",
					JOptionPane.ERROR_MESSAGE);
			}
			return;
		}

		if (currentSelection == null) {
			JOptionPane.showMessageDialog(
				tree.getRootPane(),
				"Must select a valid Category...",
				"Error",
				JOptionPane.ERROR_MESSAGE);
		}

		// Either there was no selection, or the root was selected.
		toolkit.beep();
	}

	/** Add child to the currently selected node. */
	public IParameterCategory addNode(IParameterCategory child) {
		IParameterCategory parentCategory = null;
		TreePath parentPath = tree.getSelectionPath();

		if (parentPath == null) {
			parentCategory = (IParameterCategory) treeModel.getRoot();
		} else {
			parentCategory =
				(IParameterCategory) (parentPath.getLastPathComponent());
		}
		child.setParent(parentCategory);
		if (parentCategory != null) {
			child.setParentId(parentCategory.getId());
			child.setConfiguration(parentCategory.getConfiguration());
			child.setFullName(
				StringUtil.piece(parentCategory.getFullName(), ' ', 1)
					+ " "
					+ child.getName().toUpperCase());
			child.setPluginId(parentCategory.getPluginId());
			child.setPackageRoot(false);
			child.setPersistent(false);
		}
		return addNode(parentCategory, child, true);
	}

	public IParameterCategory addNode(
		IParameterCategory parent,
		IParameterCategory child) {
		return addNode(parent, child, false);
	}

	public IParameterCategory addNode(
		IParameterCategory parent,
		IParameterCategory child,
		boolean shouldBeVisible) {

		if (parent == null) {
			parent = (IParameterCategory) treeModel.getRoot();
		}

		if (parent.isLeaf()) {
			//TODO: If Parent isLeaf, handle appropriately
		}
		
		treeModel.insertNodeInto(child, parent);

		// Make sure the user can see the lovely new node.
		if (shouldBeVisible) {
			TreePath childPath = new TreePath(child.getPath());
			tree.scrollPathToVisible(childPath);
			tree.setSelectionPath(childPath);
		}
		return child;
	}

	/**
	 * Returns the tree.
	 * @return OutlineTree
	 */
	protected OutlineTree getTree() {
		return tree;
	}

	protected TreeModel getTreeModel() {
		return treeModel;
	}
	/**
	 * @see gov.va.med.hds.cd.config.IConfigurationChangeListener#configurationChanged(gov.va.med.hds.cd.config.ConfigurationChangeEvent)
	 */
	public void configurationChanged(ConfigurationChangeEvent cce) {
		System.out.println("Caught configurationChanged...");
		configuration = cce.getCurrentConfiguration();
		rootNode = configuration.getParameterRoot();
		treeModel.setRoot(rootNode);
		expandAll();
		tree.revalidate();
	}
	/**
	 * @see gov.va.med.hds.cd.config.IConfigurationReadyListener#configurationReady(gov.va.med.hds.cd.config.ConfigurationReadyEvent)
	 */
	public void configurationReady(ConfigurationReadyEvent cre) {
		configuration = cre.getConfiguration();
		rootNode = configuration.getParameterRoot();
//		treeModel.setRoot(rootNode);
		expandAll();
		tree.revalidate();
	}
	/**
	 * @see gov.va.med.hds.cd.config.IConfigurationReadyListener#configurationCallFailed(gov.va.med.hds.cd.config.ConfigurationException)
	 */
	public void configurationCallFailed(ConfigurationException ce) {
		ce.printStackTrace();
	}

	/**
	 * @see javax.swing.event.TreeSelectionListener#valueChanged(javax.swing.event.TreeSelectionEvent)
	 */
	public void valueChanged(TreeSelectionEvent e) {
		selectedTreePath = e.getNewLeadSelectionPath();
		if (selectedTreePath == null) {
			selectedNode = null;
			return;
		}
		selectedNode =
			(IParameterCategory) selectedTreePath.getLastPathComponent();
	}
	/**
	 * @see java.awt.dnd.DragGestureListener#dragGestureRecognized(java.awt.dnd.DragGestureEvent)
	 */
	public void dragGestureRecognized(DragGestureEvent dge) {
		//Get the selected node
		IParameterCategory dragCat = getSelectedNode();
		if (dragCat != null) {

			//Get the Transferable Object
			Transferable transferable = (Transferable) dragCat;

			//Select the appropriate cursor;
			Cursor cursor = DragSource.DefaultMoveDrop;
			int action = dge.getDragAction();
			if (action == DnDConstants.ACTION_COPY) {
				cursor = DragSource.DefaultCopyDrop;
			}

			//begin the drag
			dragSource.startDrag(dge, cursor, transferable, this);
		}
	}
	/**
	 * @see java.awt.dnd.DropTargetListener#dragEnter(java.awt.dnd.DropTargetDragEvent)
	 */
	public void dragEnter(DropTargetDragEvent dtde) {
	}
	/**
	 * @see java.awt.dnd.DropTargetListener#dragOver(java.awt.dnd.DropTargetDragEvent)
	 */
	public void dragOver(DropTargetDragEvent dtde) {
		//set cursor location. Needed in setCursor method
		Point cursorLocationBis = dtde.getLocation();
		TreePath destinationPath =
			tree.getPathForLocation(cursorLocationBis.x, cursorLocationBis.y);

		// if destination path is okay accept drop...
		if (testDropTarget(destinationPath, selectedTreePath) == null) {
			dropOk = true;
			dtde.acceptDrag(DnDConstants.ACTION_COPY_OR_MOVE);
		}
		// ...otherwise reject drop
		else {
			dropOk = false;
			dtde.rejectDrag();
		}
	}
	/**
	 * @see java.awt.dnd.DropTargetListener#dropActionChanged(java.awt.dnd.DropTargetDragEvent)
	 */
	public void dropActionChanged(DropTargetDragEvent dtde) {
	}
	/**
	 * @see java.awt.dnd.DropTargetListener#dragExit(java.awt.dnd.DropTargetEvent)
	 */
	public void dragExit(DropTargetEvent dte) {
	}
	/**
	 * @see java.awt.dnd.DropTargetListener#drop(java.awt.dnd.DropTargetDropEvent)
	 */
	public void drop(DropTargetDropEvent dtde) {
		try {
			Transferable tr = dtde.getTransferable();

			//flavor not supported, reject drop
			if (!tr
				.isDataFlavorSupported(IParameterCategory.CATEGORY_FLAVOR)) {
				dtde.rejectDrop();
			}

			//cast into appropriate data type
			IParameterCategory child =
				(IParameterCategory) tr.getTransferData(
					IParameterCategory.CATEGORY_FLAVOR);

			//get new parent node
			Point loc = dtde.getLocation();
			TreePath destinationPath = tree.getPathForLocation(loc.x, loc.y);

			final String msg =
				testDropTarget(destinationPath, selectedTreePath);
			if (msg != null) {
				dtde.rejectDrop();

				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JOptionPane.showMessageDialog(
							getRootPane(),
							msg,
							"Error Dialog",
							JOptionPane.ERROR_MESSAGE);
					}
				});
				return;
			}

			IParameterCategory newParent =
				(IParameterCategory) destinationPath.getLastPathComponent();

			//get old parent node
			IParameterCategory oldParent = child.getParent();

			int action = dtde.getDropAction();
			boolean copyAction = (action == DnDConstants.ACTION_COPY);

			//child node
			IParameterCategory newChild;
			if (copyAction) {
				newChild = new ParameterCategory(child);
			} else {
				newChild = child;
			}

			try {

				if (!copyAction) {
					treeModel.removeNodeFromParent(child);
//					oldParent.remove(child);
				}

				treeModel.insertNodeInto(newChild, newParent);
//				newParent.insert(newChild);

				if (copyAction) {
					dtde.acceptDrop(DnDConstants.ACTION_COPY);
				} else {
					dtde.acceptDrop(DnDConstants.ACTION_MOVE);
				}

			} catch (java.lang.IllegalStateException ils) {
				dtde.rejectDrop();
			}

			dtde.getDropTargetContext().dropComplete(true);

			//expand nodes appropriately - this probably isnt the best way...
//			treeModel.reload(oldParent);
//			treeModel.reload(newParent);
			TreePath parentPath =
				new TreePath(((ParameterCategory) newParent).getPath());
			tree.expandPath(parentPath);
		} catch (IOException io) {
			dtde.rejectDrop();
		} catch (UnsupportedFlavorException ufe) {
			dtde.rejectDrop();
		}
	}
	/**
	 * Method testDropTarget.
	 * @param destinationPath
	 * @param selectedTreePath
	 * @return String
	 */
	private String testDropTarget(TreePath destination, TreePath dropper) {
		//Typical Tests for dropping

		//Test 1.
		boolean destinationPathIsNull = destination == null;
		if (destinationPathIsNull) {
			return "Invalid drop location.";
		}

		//Test 2.
		IParameterCategory category =
			(IParameterCategory) destination.getLastPathComponent();
		if (!(((ParameterCategory) category).getAllowsChildren())) {
			return "This node does not allow children";
		}

		if (destination.equals(dropper))
			return "Destination cannot be same as source";

		//Test 3.
		if (dropper.isDescendant(destination))
			return "Destination node cannot be a descendant.";

		//Test 4.
		if (dropper.getParentPath().equals(destination))
			return "Destination node cannot be a parent.";

		return null;
	}
	/**
	 * @see java.awt.dnd.DragSourceListener#dragEnter(java.awt.dnd.DragSourceDragEvent)
	 */
	public void dragEnter(DragSourceDragEvent dsde) {
	}
	/**
	 * @see java.awt.dnd.DragSourceListener#dragOver(java.awt.dnd.DragSourceDragEvent)
	 */
	public void dragOver(DragSourceDragEvent dsde) {
		DragSourceContext context = dsde.getDragSourceContext();
		int action = dsde.getUserAction();
		Cursor cursor =
			(dropOk
				? DragSource.DefaultMoveDrop
				: DragSource.DefaultMoveNoDrop);

		if (action == DnDConstants.ACTION_COPY) {
			cursor =
				(dropOk
					? DragSource.DefaultCopyDrop
					: DragSource.DefaultCopyNoDrop);
		}

		context.setCursor(cursor);
	}
	/**
	 * @see java.awt.dnd.DragSourceListener#dropActionChanged(java.awt.dnd.DragSourceDragEvent)
	 */
	public void dropActionChanged(DragSourceDragEvent dsde) {
	}
	/**
	 * @see java.awt.dnd.DragSourceListener#dragExit(java.awt.dnd.DragSourceEvent)
	 */
	public void dragExit(DragSourceEvent dse) {
	}
	/**
	 * @see java.awt.dnd.DragSourceListener#dragDropEnd(java.awt.dnd.DragSourceDropEvent)
	 */
	public void dragDropEnd(DragSourceDropEvent dsde) {
	}
}
