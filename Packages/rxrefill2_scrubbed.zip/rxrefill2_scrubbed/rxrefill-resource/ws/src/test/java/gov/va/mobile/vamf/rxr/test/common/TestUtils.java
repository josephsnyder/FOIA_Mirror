package gov.va.mobile.vamf.rxr.test.common;

import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_ASSIGNING_AUTHORITY;
import gov.va.mobile.vamf.common.ecrud.util.DateUtils;
import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.common.patient.infrastructure.mvi.IMVIService;
import gov.va.mobile.vamf.common.patient.infrastructure.mvi.impl.MVIService;
import gov.va.mobile.vamf.rxr.common.RxrProperties;

import java.util.Calendar;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.Assert;


public class TestUtils extends Assert {
	
	static Logger log = LoggerFactory.getLogger(TestUtils.class);
	
	public static final String ENTERPRISE_ASSIGNING_AUTHORITY = "EDIPI";
	public static final String APP_SOURCE = "rxr";
	public static final String ERROR_PATIENT_ID_1 = "1015228319";
	public static final String PATIENT_ID_2 = "1015228321";
	public static final String PATIENT_ID_3 = "1015228320";
	public static final String PATIENT_ID_4 = "321655012";
	public static final String PATIENT_ID_5 = "1015228322";
	
	public static final String RX_ID_1 = "826935";
	public static final String RX_ID_2 = "826936";
	public static final String RX_ID_3 = "906652";
	public static final String RX_ID_4 = "776950";

	public static String generateToken() {
		return RandomStringUtils.randomAlphanumeric(22);
	}
	
	public static String generatePatientId() {
		return RandomStringUtils.randomNumeric(10);
	}
	
	public static String generateExpiresDate(int minutesToLive) {
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MINUTE, minutesToLive);
		return DateUtils.convertDateToString(now.getTime());
	}

	public static String generatePrescriptionId() {
		return RandomStringUtils.randomNumeric(15);
	}
	
	@Test
	public void testPatientIdToMhvCorrelationId()
	{
		IMVIService mviSoapService = new MVIService();
		
		RxrProperties prop = new RxrProperties(); 
		MVIService.initialize(prop.getProperty(MHV_ASSIGNING_AUTHORITY));	
		String patientId = "321655013";
		try {
			String correlationId = mviSoapService.getMhvId(patientId);
			
			log.info("Converting EDIPI 1015228318, received correlationId: "+correlationId);
			
			assertNotNull(correlationId);
			
		} catch(AppException ae) {
			log.info("Caught exception calling getMhvId: "+ae.getDeveloperMessage());
			
		}
	}
	

	@Test
	public void testPatientIdToMhvCorrelationIdError()
	{
		IMVIService mviSoapService = new MVIService();
		
		RxrProperties prop = new RxrProperties(); 
		MVIService.initialize(prop.getProperty(MHV_ASSIGNING_AUTHORITY));	
		String patientId = "99999999";
		try {
			mviSoapService.getMhvId(patientId);
		} catch(AppException ae) {
			log.info("Caught exception calling getMhvId: "+ae.getDeveloperMessage());
			assertTrue(ae.getStatus() == 400);
		}
	}	
}
