package gov.va.mobile.vamf.rxr.test.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import gov.va.mobile.vamf.common.utility.DateHelper;
import gov.va.mobile.vamf.rxr.domain.EnterpriseSessionMgmtTO;
import static gov.va.mobile.vamf.rxr.test.common.TestUtils.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * The Class RxRefillControllerTest.
 * <p> 
 * A Junit test class that leverages Spring and MockMvc
 * to test the RXRefill Controller endpoints.
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({ "classpath:applicationContext.xml",
						"classpath:dispatcher-servlet.xml",
						"classpath:mongoContext.xml"})
public class RxRefillControllerTest extends AbstractMVCControllerTester{
		
		/** The log. */
		static Logger log = LoggerFactory.getLogger(RxRefillControllerTest.class);
		
		private String sessionToken = null;
		
		/**
		 * Test enterprise session.
		 */
		@Test
		public void testEnterpriseSession()
		{
			log.info("testEnterpriseSession: Start");
			
			//@RequestMapping(value = "/v2/patient/{assigning-authority}/{patient-id}/session",
			try {

				MvcResult result = mockMvc
						.perform(

								get("/v2/patient/"+ENTERPRISE_ASSIGNING_AUTHORITY+"/"+PATIENT_ID_4+"/session")
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Enterprise Session response: {}", result.getResponse()
						.getContentAsString());
				
	    		Gson gson = new GsonBuilder().setDateFormat(DateHelper.MHV_TOKEN_EXPIRES_FORMAT).create();
				EnterpriseSessionMgmtTO sessionTO = gson.fromJson(result.getResponse().getContentAsString(), EnterpriseSessionMgmtTO.class);
				setSessionToken(sessionTO.getToken());
				log.debug("Session Token is: "+getSessionToken());
			} catch (Exception e) {
				log.error("testEnterpriseSession exception: "+e.getMessage());
			}		
		}

		/**
		 * Test enterprise session exception.
		 */
		@Test
		public void testEnterpriseSessionException()
		{
			log.info("testEnterpriseSessionException: Start");
			
			//@RequestMapping(value = "/v2/patient/{assigning-authority}/{patient-id}/session",
			// Pass a patientId that should error
			try {

				MvcResult result = mockMvc
						.perform(

								get("/v2/patient/"+ENTERPRISE_ASSIGNING_AUTHORITY+"/"+ERROR_PATIENT_ID_1+"/session")
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().is4xxClientError())
						.andReturn();
				log.debug("The Enterprise Session Exception response: {}", result.getResponse()
						.getContentAsString());
				
			} catch (Exception e) {
				log.error(e.getMessage());
			}		
		}

		/**
		 * Test active prescriptions.
		 */
		@Test
		public void testActivePrescriptions()
		{
			log.info("testActivePrescriptions: Start");

			// @RequestMapping(value = "/v2/patient/prescription/active",
			
			if (getSessionToken() == null) {
				testEnterpriseSession();
			}
			
			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/active")
								// TODO: send a real enterprise token
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Active Rx response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testActivePrescriptions exception: "+e.getMessage());
			}
		}

		/**
		 * Test active prescriptions.
		 */
		@Test
		public void testHistoricPrescriptions()
		{
			log.info("testHistoricPrescriptions: Start");

			// @RequestMapping(value = "/v2/patient/prescription/historic", 

			if (getSessionToken() == null) {
				testEnterpriseSession();
			}

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/historic")
								// TODO: send a real enterprise token
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Historic Rx response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testHistoricPrescriptions exception: "+e.getMessage());
			}
		}

		/**
		 * Test request prescription refill.
		 */
		@Test
		public void testRequestRefill() 
		{
			log.info("testRequestRefill: Start");

			// @RequestMapping(value = "/v2/patient/{assigning-authority}/{patient-id}/prescription/{rxId}",

			if (getSessionToken() == null) {
				testEnterpriseSession();
			}

			try {


				String url = "/v2/patient/"+ENTERPRISE_ASSIGNING_AUTHORITY+"/"+PATIENT_ID_4+"/prescription/"+"864633";
				MvcResult result = mockMvc
						.perform(
								post(url)
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().is4xxClientError())
						.andReturn();
				log.debug("The Request Rx Refill response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testRequestRefill exception: "+e.getMessage());
			}
			
		}

		/**
		 * Test request prescription refill exception.
		 */
		@Test
		public void testRequestRefillException() 
		{
			log.info("testRequestRefillException: Start");

			// @RequestMapping(value = "/v2/patient/{assigning-authority}/{patient-id}/prescription/{rxId}",

			if (getSessionToken() == null) {
				testEnterpriseSession();
			}

			try {


				String url = "/v2/patient/"+ENTERPRISE_ASSIGNING_AUTHORITY+"/"+PATIENT_ID_2+"/prescription/"+RX_ID_1;
				MvcResult result = mockMvc
						.perform(
								post(url)
								// TODO: send a real enterprise token
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().is4xxClientError())
						.andReturn();
				log.debug("The Request Rx Refill Exception response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testRequestRefillException exception: "+e.getMessage());
			}
			
		}

		/**
		 * Test  prescription tracking.
		 */
		@Test
		public void testPrescriptionTracking() 
		{
			log.info("testPrescriptionTracking: Start");

			// @RequestMapping(value = "/v2/patient/prescription/tracking",

			if (getSessionToken() == null) {
				testEnterpriseSession();
			}

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/tracking")
								// TODO: send a real enterprise token
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed								
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Rx Tracking response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testPrescriptionTracking exception: "+e.getMessage());
			}
			
		}

		/**
		 * Test  prescription tracking.
		 */

		@Test
		public void testPrescriptionTrackingDetail() 
		{
			log.info("testPrescriptionTrackingDetail: Start");

			// @RequestMapping(value = "/v2/patient/prescription/tracking/{rxId}", 

			if (getSessionToken() == null) {
				testEnterpriseSession();
			}

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/tracking/"+"776950")
								// TODO: send a real enterprise token
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed								
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Rx Tracking Detail response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testPrescriptionTrackingDetail exception"+e.getMessage());
			}
			
		}

		/**
		 * Test refillable prescriptions.
		 */
		@Test
		public void testRefillablePrescriptions()
		{
			log.info("testRefillablePrescriptions: Start");

			// @RequestMapping(value = "/v2/patient/prescription/refillable",
			
			if (getSessionToken() == null) {
				testEnterpriseSession();
			}
			
			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/refillable")
								.header("Token", getSessionToken())
								.accept(MediaType.APPLICATION_JSON_VALUE))
								// TODO: andExpect needs to be fixed
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Refillable Rx response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testRefillablePrescriptions exception: "+e.getMessage());
			}
		}

		@Test
		public void testResourceDirectory() 
		{
			log.info("testResourceDirectory: Start");

			// @RequestMapping(value = "/v2/public/resource-directory" 

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/public/resource-directory")
								.accept(MediaType.APPLICATION_JSON_VALUE))
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The Resource Directory response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error("testResourceDirectory exception: "+e.getMessage());
			}
			
		}
		
		@Test
		public void testAllRefillRequests() 
		{
			log.info("testAllRefillRequests: Start");

			// /v2/patient/prescription/refillrequests 

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/refillrequests")
								.accept(MediaType.APPLICATION_JSON_VALUE))
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error(e.getMessage());
			}
			
		}

		@Test
		public void testRefillRequestsByPatient() 
		{
			log.info("testRefillRequestsByPatient: Start");

			// /v2/patient/prescription/refillrequests 

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/refillrequests")
								.header("patientId", PATIENT_ID_4)
								.header("assigningAuthority", ENTERPRISE_ASSIGNING_AUTHORITY)
								.header("count", true)
								.accept(MediaType.APPLICATION_JSON_VALUE))
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error(e.getMessage());
			}
			
		}

		@Test
		public void testRefillRequestsByDateRange() 
		{
			log.info("testRefillRequestsByDateRange: Start");

			// /v2/patient/prescription/refillrequests 

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/refillrequests")
								.header("patientId", PATIENT_ID_4)
								.header("assigningAuthority", ENTERPRISE_ASSIGNING_AUTHORITY)
								.header("startDate", "Wed, 23 Apr 2015")
								.header("endDate", "Wed, 22 Jul 2015")
								.header("count", true)
								.accept(MediaType.APPLICATION_JSON_VALUE))
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error(e.getMessage());
			}
			
		}

		@Test
		public void testRefillRequestsByDateRangeMultiResults() 
		{
			log.info("testRefillRequestsByDateRangeMultiResults: Start");

			// /v2/patient/prescription/refillrequests 

			try {

				MvcResult result = mockMvc
						.perform(
								get("/v2/patient/prescription/refillrequests")
								.header("patientId", PATIENT_ID_4)
								.header("assigningAuthority", ENTERPRISE_ASSIGNING_AUTHORITY)
								.header("startDate", "Wed, 22 Apr 2015")
								.header("endDate", "Wed, 22 Jul 2015")
								.header("count", false)
								.accept(MediaType.APPLICATION_JSON_VALUE))
								.andExpect(status().isOk())
						.andReturn();
				log.debug("The response: {}", result.getResponse()
						.getContentAsString());

			} catch (Exception e) {
				log.error(e.getMessage());
			}
			
		}

		protected String getSessionToken() {
			return sessionToken;
		}
		
		protected void setSessionToken(String sessionToken) {
			this.sessionToken = sessionToken;
		}
		
	}
