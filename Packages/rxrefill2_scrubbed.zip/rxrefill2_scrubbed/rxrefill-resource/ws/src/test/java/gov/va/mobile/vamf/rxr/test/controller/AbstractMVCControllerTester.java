package gov.va.mobile.vamf.rxr.test.controller;

import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

/**
 * The Class AbstractMVCControllerTester.
 * <p>
 * A Junit test abstract class that leverages Spring and MockMvc
 * by setting up MockMVC, Request, Response, Session, Context, etc.
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public abstract class AbstractMVCControllerTester {
	
	/** The log. */
	static Logger log = LoggerFactory.getLogger(AbstractMVCControllerTester.class);
	
	/** The wac. */
	@Autowired
	protected WebApplicationContext wac;
	
	/** The session. */
	@Autowired
	protected MockHttpSession session;
	
	/** The request. */
	@Autowired
	protected MockHttpServletRequest request;

	/** The mock mvc. */
	protected MockMvc mockMvc;

	/**
	 * Setup.
	 */
	@Before
	public void setup() {
		log.info("setup");
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
	}

}
