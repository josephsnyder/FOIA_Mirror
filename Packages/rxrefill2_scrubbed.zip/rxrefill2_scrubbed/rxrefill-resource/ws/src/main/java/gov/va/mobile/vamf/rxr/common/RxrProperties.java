package gov.va.mobile.vamf.rxr.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Class RxrProperties. 
 * 
 * Loads the environment specific properties file at start up.
 * Also supports retrieval of a property value by name.
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public class RxrProperties {

    private static final String PROPERTIES_FILE = "environment.properties";
    private static final Properties PROPERTIES = new Properties();
    
	/** The slf4j logger. */
  	private final static Logger slf4jLogger = LoggerFactory.getLogger(RxrProperties.class);

    static {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        InputStream propertiesFile = classLoader.getResourceAsStream(PROPERTIES_FILE);
        
        try {
            PROPERTIES.load(propertiesFile);            
        } catch (IOException e) {
        	slf4jLogger.error("Could not load Properties file ["+PROPERTIES_FILE+"] from the classpath.");
        } finally {
        	if (propertiesFile != null) {
        		RxrUtils.safeClose(propertiesFile);
        	}
        }
    }

    /**
     * Construct a RxrProperties instance
     */
    public RxrProperties() {
    }

    /**
     * Returns the RxrProperties instance specific property value associated with the given key.
     * @param key The key to be associated with a DAOProperties instance specific value.
     * @return The RxrProperties instance specific property value associated with the given key.
     */
    public String getProperty(String key) {
    	if (PROPERTIES == null) {
    		return null;
    	}
    	
        String property = PROPERTIES.getProperty(key);

        if (property == null || property.trim().length() == 0) {
        	// Make empty value null.
        	property = null;
        }

        return property;
    }

    /**
     * Returns the numeric RxrProperties instance specific property value associated with the given key.
     * @param key The key to be associated with a DAOProperties instance specific value.
     * @return The numeric RxrProperties instance specific property value associated with the given key.
     */
    public Integer getNumericProperty(String key) {
    	if (PROPERTIES == null) {
    		return 0;
    	}
    	
        String property = PROPERTIES.getProperty(key);

        if (property == null || property.trim().length() == 0) {
        	// Make empty value null.
        	return 0;
        } else {
        	try {
        		return new Integer(property);
        	} catch(NumberFormatException nfe) {
        		return 0;
        	}
        }
    }
}