package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class PrescriptionLiteTO.
 * <p>
 * Liteweight object that contains information about a prescription.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "otherPrescriptionListIncluded", namespace = Namespace.VAMF)
public class PrescriptionLiteTO {
	
	/** The prescription name. */
	@XmlElement
	private String prescriptionName;
	
	/** The prescription number. */
	@XmlElement
	private String prescriptionNumber;
	
	/** The ndc number. */
	@XmlElement
	private String ndcNumber;
	
	/** The station number. */
	@XmlElement
	private String stationNumber;
	
	/**
	 * Gets the prescription name.
	 *
	 * @return the prescription name
	 */
	public String getPrescriptionName() {
		return prescriptionName;
	}
	
	/**
	 * Sets the prescription name.
	 *
	 * @param prescriptionName the new prescription name
	 */
	public void setPrescriptionName(String prescriptionName) {
		this.prescriptionName = prescriptionName;
	}
	
	/**
	 * Gets the prescription number.
	 *
	 * @return the prescription number
	 */
	public String getPrescriptionNumber() {
		return prescriptionNumber;
	}
	
	/**
	 * Sets the prescription number.
	 *
	 * @param prescriptionNumber the new prescription number
	 */
	public void setPrescriptionNumber(String prescriptionNumber) {
		this.prescriptionNumber = prescriptionNumber;
	}
	
	/**
	 * Gets the ndc number.
	 *
	 * @return the ndc number
	 */
	public String getNdcNumber() {
		return ndcNumber;
	}
	
	/**
	 * Sets the ndc number.
	 *
	 * @param ndcNumber the new ndc number
	 */
	public void setNdcNumber(String ndcNumber) {
		this.ndcNumber = ndcNumber;
	}
	
	/**
	 * Gets the station number.
	 *
	 * @return the station number
	 */
	public String getStationNumber() {
		return stationNumber;
	}
	
	/**
	 * Sets the station number.
	 *
	 * @param stationNumber the new station number
	 */
	public void setStationNumber(String stationNumber) {
		this.stationNumber = stationNumber;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PrescriptionLiteTO [prescriptionName=" + prescriptionName
				+ ", prescriptionNumber=" + prescriptionNumber + ", ndcNumber="
				+ ndcNumber + ", stationNumber=" + stationNumber + "]";
	}
	
	
}
