package gov.va.mobile.vamf.rxr.service.impl;

import static gov.va.mobile.vamf.common.domain.FaultConstants.GENERIC_APP_ERROR_CODE;
import static gov.va.mobile.vamf.common.domain.FaultConstants.GENERIC_APP_ERROR_MSG;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.ACTIVE_RX;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.ENDPOINT_NOT_FOUND;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MAX_DAYS_SINCE_REFILL_DATE;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_ACTIVE_RX_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_API_BASE_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_ASSIGNING_AUTHORITY;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_HEADER_KEY_APP_TOKEN;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_HEADER_KEY_CORRELATION_ID;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_HEADER_KEY_EXPIRES;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_HEADER_KEY_TOKEN;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_HISTORY_RX_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_PRESCRIPTION_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_REFILL_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_RX_TRACKING_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_SESSION_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_SYSTEM_EXCEPTION;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.REFILLABLE_RX;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.SYSTEM_ISSUES;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.UNKNOWN_APPLICATION_ERROR;
import gov.va.mobile.vamf.common.ecrud.util.DomainUtils;
import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.common.patient.infrastructure.mvi.IMVIService;
import gov.va.mobile.vamf.common.patient.infrastructure.mvi.impl.MVIService;
import gov.va.mobile.vamf.common.utility.DateHelper;
import gov.va.mobile.vamf.rxr.common.RxrProperties;
import gov.va.mobile.vamf.rxr.common.RxrUtils;
import gov.va.mobile.vamf.rxr.domain.EnterpriseSessionMgmtTO;
import gov.va.mobile.vamf.rxr.domain.ErrorTO;
import gov.va.mobile.vamf.rxr.domain.PrescriptionTO;
import gov.va.mobile.vamf.rxr.domain.PrescriptionsTO;
import gov.va.mobile.vamf.rxr.domain.TrackingInfoDetailsTO;
import gov.va.mobile.vamf.rxr.service.IRxRefillMHVClient;
import gov.va.mobilehealth.connection.mvi.client.service.MviClient;
import gov.va.mobilehealth.connection.mvi.client.transferobjects.MVIPersonIdentifier;
import gov.va.mobilehealth.connection.mvi.client.transferobjects.MVIPersonIdentifier.IdentifierTypeClassification;
import gov.va.mobilehealth.connection.mvi.client.transferobjects.PatientTraitsAndCorrIDsContainer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.ProcessingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;

/**
 * The Class RxRefillMHVClientService. 
 * 
 * Implementation class for all REST client calls to 
 * VA MyHealtheVet Rx Refill and Tracking APIs.
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
@Service
public class RxRefillMHVClientService implements IRxRefillMHVClient {
	
	/** The slf4j logger. */
  	private final Logger slf4jLogger = LoggerFactory.getLogger(RxRefillMHVClientService.class);

	/**  MVI Service *. */
  //	@Autowired
  	//private IMVIService mviSoapService;
  	
	@Autowired
	MviClient mviClient;
  	
	/**
	 * Instantiates a new rx refill MHV client service.
	 */
	public RxRefillMHVClientService() {
		slf4jLogger.debug("RxRefillMHVClientService constructor::Initializing MVIService");
		
		RxrProperties prop = new RxrProperties();    	
		
		MVIService.initialize(prop.getProperty(MHV_ASSIGNING_AUTHORITY));		
		
	}
    
	/**
	 * Get Enterprise Session Token from the
	 * to MHV Session Endpoint.
	 *
	 * @param appToken VAMF App Token
	 * @param patientId the patient id
	 * @return the session token
	 * @throws AppException the app exception
	 */
	public EnterpriseSessionMgmtTO getSessionToken(String appToken, String patientId) throws AppException {
    	slf4jLogger.info("RxRefillMHVClientService::getSessionToken - Start");
    	
    	return processGetSessionToken(appToken, patientId);
	}


    /**
     * Post prescription refill request for prescription id
     * to MHV Rx Refill Endpoint.
     *
     * @param id the id
     * @param token is enterprise session token
     * @throws AppException the app exception
     */
  	public void requestRefill(String id, String token) throws AppException {
    	slf4jLogger.info("RxRefillMHVClientService::requestRefill by Id - Start");

    	processRequestRefill(id, token);
    }

	/**
	 * Get trackable prescriptions from the
	 * to MHV Get History Rx Endpoint.
	 *
	 * @param token is enterprise session token
	 * @return the response
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getPrescriptionTracking(String token) throws AppException {
    	slf4jLogger.info("RxRefillMHVClientService::getTrackablePrescriptions - Start");
    	
   		return processGetTrackableRx(token);
	}
	
	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IRxRefillMHVClient#getTrackingDetails(java.lang.String, java.lang.String)
	 */
	public TrackingInfoDetailsTO getTrackingDetails(String token, String rxId) throws AppException {
    	slf4jLogger.info("RxRefillMHVClientService::getTrackingDetails - Start");
    	
    	return processGetTrackableRxDetails(token, rxId);
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IRxRefillMHVClient#getActivePrescriptions(java.lang.String)
	 */
	public PrescriptionsTO getActivePrescriptions(String token) throws AppException {
		slf4jLogger.info("RxRefillMHVClientService::getActivePrescriptions - Start");
	
		return processGetActivePrescriptions(token);
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IRxRefillMHVClient#getHistoricPrescriptions(java.lang.String)
	 */
	public PrescriptionsTO getHistoricPrescriptions(String token) throws AppException {
		slf4jLogger.info("RxRefillMHVClientService::getActivePrescriptions - Start");
		
		return processGetHistoricPrescriptions(token);
	}
	
	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IRxRefillMHVClient#getRefillablePrescriptions(java.lang.String)
	 */
	public PrescriptionsTO getRefillablePrescriptions(String token) throws AppException {
		slf4jLogger.info("RxRefillMHVClientService::getRefillablePrescriptions - Start");

		return processGetRefillablePrescriptions(token);
	}


	/**
	 * Makes a REST client call to the MHV Enterprise Session Endpoint.
	 *
	 * @param appToken VAMF App Token
	 * @param patientId the patient id
	 * @return the enterprise session mgmt
	 * @throws AppException the app exception
	 */
	private EnterpriseSessionMgmtTO processGetSessionToken(String appToken, String patientId) throws AppException
	{
		//slf4jLogger.info("processGetSessionToken:begin: patientId: "+patientId);
		
		EnterpriseSessionMgmtTO sessionMgmt = null;
		// Get the MHV correlation id
		String correlationId = null;
		
    	try {
    		String idType = "NI"; // set based on uniqueId value
    		String idSource = "200DOD"; // station number if dfn, 200DOD if edipi
    		String passedAssignAuth = "USDOD";
    		
    		MVIPersonIdentifier mviPersonIdentifier = new MVIPersonIdentifier(patientId, idType, idSource, passedAssignAuth,	null);
    		slf4jLogger.info("mviPersonIdentifier with : idType: "+idType+" idSource:"+idSource+" passedAssignAuth:"+passedAssignAuth);
    		try {
    			PatientTraitsAndCorrIDsContainer idsCont = mviClient.getPatientIds(mviPersonIdentifier);
        		slf4jLogger.info("Received PatientTraitsAndCorrIDsContainer");
        		slf4jLogger.info("IdentifierTypeClassification.MHVCORRELATIONID:"+IdentifierTypeClassification.MHVCORRELATIONID);	
        		slf4jLogger.info("Size of PatientTraitsAndCorrIDsContainer:"+idsCont.getActiveIdentifiers().size());
        		
        		
        		Set keys = idsCont.getActiveIdentifiers().keySet();
        	    for (Iterator i = keys.iterator(); i.hasNext();) {
        	    	IdentifierTypeClassification key = (IdentifierTypeClassification) i.next();
        	        slf4jLogger.info("Received PatientTraitsAndCorrIDsContainer Key name:"+key.name());
        	        List<MVIPersonIdentifier> keyvalue = idsCont.getActiveIdentifiers().get(key);
        	        if (keyvalue != null){
        	        	slf4jLogger.info("activeMHVID length:"+keyvalue.size());
        	        	slf4jLogger.info("Key Value getIdentifierSource:"+keyvalue.get(0).getIdentifierSource());
        	        	slf4jLogger.info("Key Value getIdentifier:"+keyvalue.get(0).getIdentifier());
        	        	slf4jLogger.info("Key Value getIdentifierStatus:"+keyvalue.get(0).getIdentifierStatus());
        	        	slf4jLogger.info("Key Value getIdentifierType:"+keyvalue.get(0).getIdentifierType());
        	        	slf4jLogger.info("Key Value getAssigningAuthority:"+keyvalue.get(0).getAssigningAuthority());
        	        	
        	        }else{
        	        	slf4jLogger.info("Key Value:NULL");
        	        }
        	       
        	    }
    			// active IEN
    			List<MVIPersonIdentifier> activeMHVID = idsCont.getActiveIdentifiers().get(IdentifierTypeClassification.MHVCORRELATIONID);
        		//slf4jLogger.info("activeMHVID length:"+activeMHVID.size());

    			if (activeMHVID != null) {
    				for (MVIPersonIdentifier mhv : activeMHVID) {
    					correlationId = mhv.getIdentifier();
    	        		slf4jLogger.info("CorrelationId() :"+correlationId);

    					System.out.println("correlationId() :"+correlationId);
    					}
    				}
    		} catch (IllegalArgumentException iae) {
    			iae.printStackTrace();
    		
    			String failureCauseMessage = getClass().getName()+":There was an error fetching identity correlations for the patient with identifier :"
    					+ patientId + ". The error message returned when fetching the correlations was : " + iae.getMessage();
    			    			
        		// Could potentially catch a parse exception on token expires date
        		//String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), RxrUtils.getMethodName(), iae);
        		throw new AppException(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
        													 GENERIC_APP_ERROR_CODE, 
        													 GENERIC_APP_ERROR_MSG,
        													 failureCauseMessage);

    		} catch (Exception e1) {
    			e1.printStackTrace();
    			String failureCauseMessage = getClass().getName()+":There was an error fetching identity correlations for the patient with identifier :"
    					+ patientId + ". The error message returned when fetching the correlations was : " + e1.getMessage();

        		throw new AppException(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
						 GENERIC_APP_ERROR_CODE, 
						 GENERIC_APP_ERROR_MSG,
						 failureCauseMessage);
    		}
    			
    		
    		
    		// Get the MHV correlation id
    		//String correlationId = mviSoapService.getMhvId(patientId);
    		
    		slf4jLogger.info("MHV Correlation Id: "+ correlationId);
    		

    		
	    	List<String> uriNodeList = RxrUtils.initializeMHVUriNodeList();
	    	uriNodeList.add(MHV_SESSION_URL);
	    	slf4jLogger.info("invokeEndpoint:begin: ");
	    	Response response = invokeEndpoint(uriNodeList, buildHeaders(appToken, correlationId), HttpMethod.GET);
	    	int status = response.getStatus();
	    	slf4jLogger.info("invokeEndpoint:end:Status "+status);
	    	if (status == HttpStatus.OK.value()) {
	    		String token = response.getHeaderString(MHV_HEADER_KEY_TOKEN);
	    		String expires = response.getHeaderString(MHV_HEADER_KEY_EXPIRES);
	    		Date expiresDate = DateHelper.parseMHVTokenExpiresDate(expires);
	    		sessionMgmt = new EnterpriseSessionMgmtTO(token, expiresDate); 
	    	} else {
	    		AppException appException = convertMHVErrorResponse(response);
	    		    		
	    		if (appException != null) {
	    			throw appException;
	    		} else {
	    			String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
	    																	 RxrUtils.getMethodName(), 
	    																	 GENERIC_APP_ERROR_MSG);
	    			appException = new AppException(status,
	    											GENERIC_APP_ERROR_CODE,
	    											GENERIC_APP_ERROR_MSG,
	    											developerMessage);
	    			throw appException;
	    		}
	    	}
    	} catch(AppException appException) {
    		throw appException;
    	} catch(Exception ex) {
    		ex.printStackTrace();
    		slf4jLogger.error("Caught exception in processGetSessionToken: "+ex.getMessage());
    		
    		// Could potentially catch a parse exception on token expires date
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), RxrUtils.getMethodName(), ex);
    		AppException appException = new AppException(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
    													 GENERIC_APP_ERROR_CODE, 
    													 GENERIC_APP_ERROR_MSG,
    													 developerMessage);
    		throw appException;
    	}
    	
    	return sessionMgmt;
	}
	
	/**
	 * Makes a REST client call to the MHV Rx Refill Endpoint.
	 *
	 * @param rxId the rx id
	 * @param token is enterprise session token
	 * @throws AppException the app exception
	 */
    private void processRequestRefill(String rxId, String token) throws AppException {

    	try {
	    	List<String> uriNodeList = RxrUtils.initializeMHVUriNodeList();
	    	uriNodeList.add(MHV_PRESCRIPTION_URL);
	    	uriNodeList.add(MHV_REFILL_URL);
	    	uriNodeList.add(rxId);
	    	
	    	Response response = invokeEndpoint(uriNodeList, buildHeaders(token), HttpMethod.POST);
	    	int status = response.getStatus();
	    	
	    	if (status != HttpStatus.OK.value()) {
	    		AppException appException = convertMHVErrorResponse(response);
	    		
	    		if (appException != null) {
	    			throw appException;
	    		} else {
	    			String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
	    																	 RxrUtils.getMethodName(), 
	    																	 GENERIC_APP_ERROR_MSG);
	    			appException = new AppException(status,
	    											GENERIC_APP_ERROR_CODE,
	    											GENERIC_APP_ERROR_MSG,
	    											developerMessage);
	    			throw appException;
	    		}
	    	}
	    	
	    	slf4jLogger.info("processPostRxRefill(): Status code from call to MHV:"+status);
    	} catch(AppException appException) {
    		throw appException;
    	}
    }

	/**
	 * Makes a REST client call to the MHV Get History Rx Endpoint.
	 *
	 * @param token is enterprise session token
	 * @return the prescriptions to
	 * @throws AppException the app exception
	 */
    private PrescriptionsTO processGetTrackableRx(String token) throws AppException {
    	PrescriptionsTO prescriptionsTO = new PrescriptionsTO();
    	
    	try {
	    	List<String> uriNodeList = RxrUtils.initializeMHVUriNodeList();
	    	uriNodeList.add(MHV_PRESCRIPTION_URL);
	    	uriNodeList.add(MHV_HISTORY_RX_URL);
	    	
	    	Response response = invokeEndpoint(uriNodeList, buildHeaders(token), HttpMethod.GET);
	    	int status = response.getStatus();

	    	slf4jLogger.info("processGetTrackableRx(): Status code from call to MHV:"+status);
	    	
	    	if (status == HttpStatus.OK.value()) {
	    		// Get the response data from MHV
	    		//Gson gson = new GsonBuilder().setDateFormat(DateHelper.MHV_TOKEN_EXPIRES_FORMAT).create();
	    		Gson gson = new GsonBuilder().setDateFormat("EEE, d MMM yyyy").create();
	    		String json = response.readEntity(String.class);
		    	slf4jLogger.debug("processGetTrackableRx() JSON from MHV:"+json);
		    	System.out.println("processGetTrackableRx() JSON from MHV:"+json);
	    		PrescriptionsTO allPrescriptionsTO = gson.fromJson(json, PrescriptionsTO.class);

	    		List<PrescriptionTO> allPrescriptionTOList = allPrescriptionsTO.getPrescriptionList();
	    		
	    		// Need to filter these prescriptions before returning the list
	    		// Filter: isTrackable and refillDate <= 45 days ago
	    		List<PrescriptionTO> filteredPrescriptionTOList = new ArrayList<PrescriptionTO>();
	    		if ((allPrescriptionTOList!=null) && (!allPrescriptionTOList.isEmpty())){
		    		for(PrescriptionTO allPrescriptionTO: allPrescriptionTOList) {
		    			if (isTrackable(allPrescriptionTO.getIsTrackable(), allPrescriptionTO.getRefillDate())) {
		    				filteredPrescriptionTOList.add(allPrescriptionTO);
		    			}
		    		}
		    		prescriptionsTO.setPrescriptionList(filteredPrescriptionTOList);
	    		}
	    	} else {
	    		AppException appException = convertMHVErrorResponse(response);
	    		
	    		if (appException != null) {
	    			throw appException;
	    		} else {
	    			String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
	    																	 RxrUtils.getMethodName(), 
	    																	 GENERIC_APP_ERROR_MSG);
	    			appException = new AppException(status,
	    											GENERIC_APP_ERROR_CODE,
	    											GENERIC_APP_ERROR_MSG,
	    											developerMessage);
	    			throw appException;
	    		}
	    	}
    	} catch(AppException appException) {
    		throw appException;
    	}
    	
    	return prescriptionsTO;
    }
    
    /**
     * Process get trackable rx details.
     *
     * @param token the token
     * @param rxId the rx id
     * @return the tracking info details to
     * @throws AppException the app exception
     */
    private TrackingInfoDetailsTO processGetTrackableRxDetails(String token, String rxId) throws AppException {
    	TrackingInfoDetailsTO trackingInfoDetailsTO = new TrackingInfoDetailsTO();

    	try {
	    	List<String> uriNodeList = RxrUtils.initializeMHVUriNodeList();
	    	uriNodeList.add(MHV_PRESCRIPTION_URL);
	    	uriNodeList.add(MHV_RX_TRACKING_URL);
	    	uriNodeList.add(rxId);
	    	
	    	Response response = invokeEndpoint(uriNodeList, buildHeaders(token), HttpMethod.GET);
	    	int status = response.getStatus();
	    	
	    	slf4jLogger.info("processGetTrackableRxDetails(): Status code from call to MHV:"+status);
	    	
	    	if (status == HttpStatus.OK.value()) {
	    		// Get the response data from MHV
	    		//Gson gson = new GsonBuilder().setDateFormat(DateHelper.MHV_TOKEN_EXPIRES_FORMAT).create();
	    		Gson gson = new GsonBuilder().setDateFormat("EEE, d MMM yyyy").create();
	    		String json = response.readEntity(String.class);
	    		System.out.println("processGetTrackableRxDetails() JSON from MHV:"+json);
	    		trackingInfoDetailsTO = gson.fromJson(json, TrackingInfoDetailsTO.class);
	    	} else {
	    		AppException appException = convertMHVErrorResponse(response);
	    		
	    		if (appException != null) {
	    			throw appException;
	    		} else {
	    			String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
	    																	 RxrUtils.getMethodName(), 
	    																	 GENERIC_APP_ERROR_MSG);
	    			appException = new AppException(status,
	    											GENERIC_APP_ERROR_CODE,
	    											GENERIC_APP_ERROR_MSG,
	    											developerMessage);
	    			throw appException;
	    		}
	    	}
    	} catch(AppException appException) {
    		throw appException;
    	}
    	
    	return trackingInfoDetailsTO;

    }
    
    /**
     * Process get active prescriptions.
     *
     * @param token the token
     * @return the prescriptions to
     * @throws AppException the app exception
     */
    private PrescriptionsTO processGetActivePrescriptions(String token) throws AppException {
    	PrescriptionsTO prescriptionsTO = new PrescriptionsTO();
    	
    	try {
	    	List<String> uriNodeList = RxrUtils.initializeMHVUriNodeList();
	    	uriNodeList.add(MHV_PRESCRIPTION_URL);
	    	uriNodeList.add(MHV_ACTIVE_RX_URL);
	    	
	    	Response response = invokeEndpoint(uriNodeList, buildHeaders(token), HttpMethod.GET);
	    	int status = response.getStatus();
	    	
	    	slf4jLogger.info("processGetActivePrescriptions(): Status code from call to MHV:"+status);
	    	
	    	if (status == HttpStatus.OK.value()) {
	    		// Get the response data from MHV
	    		//Gson gson = new GsonBuilder().setDateFormat(DateHelper.MHV_TOKEN_EXPIRES_FORMAT).create();
	    		Gson gson = new GsonBuilder().setDateFormat("EEE, d MMM yyyy").create();
	    		String json = response.readEntity(String.class);

	    		prescriptionsTO = gson.fromJson(json, PrescriptionsTO.class);
	    	} else {
	    		AppException appException = convertMHVErrorResponse(response);
	    		
	    		if (appException != null) {
	    			throw appException;
	    		} else {
	    			String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
	    																	 RxrUtils.getMethodName(), 
	    																	 GENERIC_APP_ERROR_MSG);
	    			appException = new AppException(status,
	    											GENERIC_APP_ERROR_CODE,
	    											GENERIC_APP_ERROR_MSG,
	    											developerMessage);
	    			throw appException;
	    		}
	    	}
    	} catch(AppException appException) {
    		throw appException;
    	}
    	
    	return prescriptionsTO;
    }
    
    /**
     * Process get historic prescriptions.
     *
     * @param token the token
     * @return the prescriptions to
     * @throws AppException the app exception
     */
    private PrescriptionsTO processGetHistoricPrescriptions(String token) throws AppException {
    	PrescriptionsTO prescriptionsTO = new PrescriptionsTO();
    	
    	try {
	    	List<String> uriNodeList = RxrUtils.initializeMHVUriNodeList();
	    	uriNodeList.add(MHV_PRESCRIPTION_URL);
	    	uriNodeList.add(MHV_HISTORY_RX_URL);
	    	
	    	Response response = invokeEndpoint(uriNodeList, buildHeaders(token), HttpMethod.GET);
	    	int status = response.getStatus();

	    	slf4jLogger.info("processGetHistoricPrescriptions(): Status code from call to MHV:"+status);
	    	
	    	if (status == HttpStatus.OK.value()) { 
	    		// Get the response data from MHV
	    		//Gson gson = new GsonBuilder().setDateFormat(DateHelper.MHV_TOKEN_EXPIRES_FORMAT).create();
	    		Gson gson = new GsonBuilder().setDateFormat("EEE, d MMM yyyy").create();
	    		String json = response.readEntity(String.class);
		    	slf4jLogger.debug("processGetHistoricPrescriptions() JSON from MHV:"+json);
		    	System.out.println("processGetHistoricPrescriptions() JSON from MHV:"+json);
	    		prescriptionsTO = gson.fromJson(json, PrescriptionsTO.class);
	    	} else {
	    		AppException appException = convertMHVErrorResponse(response);
	    		
	    		if (appException != null) {
	    			throw appException;
	    		} else {
	    			String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
	    																	 RxrUtils.getMethodName(), 
	    																	 GENERIC_APP_ERROR_MSG);
	    			appException = new AppException(status,
	    											GENERIC_APP_ERROR_CODE,
	    											GENERIC_APP_ERROR_MSG,
	    											developerMessage);
	    			throw appException;
	    		}
	    	}
    	} catch(AppException appException) {
    		throw appException;
    	}
    	
    	return prescriptionsTO;    	
    }

    /**
     * Process get refillable prescriptions.
     *
     * @param token the token
     * @return the prescriptions to
     * @throws AppException the app exception
     */
    private PrescriptionsTO processGetRefillablePrescriptions(String token) throws AppException {
    	slf4jLogger.info("processGetRefillablePrescriptions(): Begin");
    	PrescriptionsTO prescriptionsTO = processGetActivePrescriptions(token);
    	
    	if (prescriptionsTO != null && 
    		prescriptionsTO.getPrescriptionList() != null && 
    		prescriptionsTO.getPrescriptionList().size() > 0) {
    		List<PrescriptionTO> refillablePrescriptionList = new ArrayList<PrescriptionTO>();
    		
    		for(PrescriptionTO prescriptionTO: prescriptionsTO.getPrescriptionList()) {
    			if (prescriptionTO.getIsRefillable()) {
    				// Update the refillStatus to refillable from active
    				if (prescriptionTO.getRefillStatus().equalsIgnoreCase(ACTIVE_RX)) {
    					prescriptionTO.setRefillStatus(REFILLABLE_RX);
    				}
    				refillablePrescriptionList.add(prescriptionTO);
    			}
    		}
    		prescriptionsTO.setPrescriptionList(refillablePrescriptionList);
    	}
    	slf4jLogger.info("processGetRefillablePrescriptions(): End");
    	return prescriptionsTO;
    }

    	
    /**
     * Invoke endpoint.
     *
     * @param uriNodeList the uri node list
     * @param headers the headers
     * @param httpMethod the http method
     * @return the response
     * @throws AppException the app exception
     */
    private Response invokeEndpoint(List<String> uriNodeList, 
    								Map<String,String> headers, 
    								String httpMethod) throws AppException {

    	slf4jLogger.info("invokeEndpoint(): Begin");
    	Client client = ClientBuilder.newClient(); 

    	try {
	    	WebTarget target = RxrUtils.buildMHVTarget(client, DomainUtils.createURI(getMHVBaseUrl()), uriNodeList);
	    	slf4jLogger.info("Final target Path:"+target.getUri().getPath());
	    	System.out.println("Final target Path:"+target.getUri().getPath());
	    	Invocation targetInvocation = RxrUtils.getInvocation(target, httpMethod,
	    										 headers, MediaType.APPLICATION_JSON_TYPE);
	    	return targetInvocation.invoke();
    	} catch(Exception ex) {
    		slf4jLogger.error(ex.toString());
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), RxrUtils.getMethodName(), ex);
    		AppException appException = new AppException(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
    													 GENERIC_APP_ERROR_CODE, 
    													 GENERIC_APP_ERROR_MSG,
    													 developerMessage);
    		throw appException;
    	} finally {
    		if (client != null) {
    	    	client.close();    			
    		}
    		slf4jLogger.info("invokeEndpoint(): End");
    	}
    }
    
    /**
     * Gets the MHV base url.
     *
     * @return the MHV base url
     */
    private String getMHVBaseUrl() {
		RxrProperties properties = new RxrProperties();    	
		return properties.getProperty(MHV_API_BASE_URL);
    }
    
    /**
     * Gets the max days since last refill.
     *
     * @return the max days since last refill
     */
    private int getMaxDaysSinceLastRefill() {
		RxrProperties properties = new RxrProperties();    	
		try {
			String prop = properties.getProperty(MAX_DAYS_SINCE_REFILL_DATE);
			if (prop != null) {
				return Integer.parseInt(prop);
			} else {
				return 0;
			}
		} catch(NumberFormatException nfe) {
			return 0;
		}
    }
    
    /**
     * Builds the generic headers.
     *
     * @return the map
     */
    private Map<String,String> buildHeaders() {
    	Map<String,String> headers = new HashMap<String,String>();
    	headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
    	headers.put(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON);
    	
    	return headers;
    }
    
    /**
     * Builds the headers.
     *
     * @param token the token
     * @return the map
     */
    private Map<String,String> buildHeaders(String token) {
    	Map<String,String> headers = buildHeaders();
    	headers.put(MHV_HEADER_KEY_TOKEN, token);    	
    	
    	return headers;
    }
    
    /**
     * Builds the headers.
     *
     * @param appToken the app token
     * @param correlationId the correlation id
     * @return the map
     */
    private Map<String,String> buildHeaders(String appToken, String correlationId) {
    	Map<String,String> headers = buildHeaders();
    	headers.put(MHV_HEADER_KEY_APP_TOKEN, appToken);    	
    	headers.put(MHV_HEADER_KEY_CORRELATION_ID, correlationId);
    	
    	return headers;
    }
    
    /**
     * Checks if prescription is trackable.
     *
     * @param isTrackable is prescription trackable
     * @param refillDate the refill date
     * @return boolean, true if refillable, false if not refillable
     */
    private boolean isTrackable(Boolean isTrackable, Date refillDate) {
    	if (! isTrackable) {
    		return false;
    	}
    	Calendar cRefillDate = Calendar.getInstance();
    	cRefillDate.setTime(refillDate);

    	// Refill Date must be within the last MAX_DAYS_SINCE_REFILL_DATE days
    	Calendar refillDateMax = Calendar.getInstance();
    	refillDateMax.add(Calendar.DAY_OF_MONTH, (getMaxDaysSinceLastRefill() * -1));
    	if (refillDateMax.after(cRefillDate)) {
    		return false;
    	} else {
    		return true;
    	}
    }
    
    /**
     * Convert MHV error response.
     *
     * @param response the response
     * @return the app exception
     */
    private AppException convertMHVErrorResponse(Response response) {
    	AppException appException = null;
    	int status = response.getStatus();
    	slf4jLogger.debug("convertMHVErrorResponse: Begin");
    	
    	if (status == HttpStatus.NOT_FOUND.value()){
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
    																 RxrUtils.getMethodName(),
    																 ENDPOINT_NOT_FOUND);

    		appException = new AppException(status,
											GENERIC_APP_ERROR_CODE,
											SYSTEM_ISSUES,
											developerMessage);
    		throw appException;
    	}

    	if (status != HttpStatus.BAD_REQUEST.value()) {
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
					 RxrUtils.getMethodName(),
					 MHV_SYSTEM_EXCEPTION);

			appException = new AppException(status,
			HttpStatus.BAD_REQUEST.value(),
			MHV_SYSTEM_EXCEPTION,
			developerMessage);
			throw appException;
    	}
    	if (status != HttpStatus.INTERNAL_SERVER_ERROR.value()) {
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
					 RxrUtils.getMethodName(),
					 MHV_SYSTEM_EXCEPTION);

			appException = new AppException(status,
			HttpStatus.BAD_REQUEST.value(),
			MHV_SYSTEM_EXCEPTION,
			developerMessage);
			throw appException;
    	}    	
    	
    	try {
    		Gson gson = new GsonBuilder().create();
    		String json = response.readEntity(String.class);
    		slf4jLogger.info("MHV Error response: "+json);
    		ErrorTO errorTO = gson.fromJson(json, ErrorTO.class);
    		// Need to add the status from the response
    		appException = errorTO.convertToAppException(status);
    	} catch(ProcessingException pe) {
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
					 												 RxrUtils.getMethodName(), 
					 												 pe.getMessage());
    		appException = new AppException(HttpStatus.INTERNAL_SERVER_ERROR.value(), 
    										GENERIC_APP_ERROR_CODE,
    										UNKNOWN_APPLICATION_ERROR, developerMessage);
		} catch(IllegalStateException ise) {
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
					 												 RxrUtils.getMethodName(), 
					 												 ise.getMessage());
    		appException = new AppException(HttpStatus.INTERNAL_SERVER_ERROR.value(), 
    										GENERIC_APP_ERROR_CODE,
    										UNKNOWN_APPLICATION_ERROR, developerMessage);
    	} catch(JsonSyntaxException jse) {
    		String developerMessage = RxrUtils.buildDeveloperMessage(getClass().getName(), 
					 												 RxrUtils.getMethodName(), 
					 												 jse.getMessage());
    		appException = new AppException(HttpStatus.INTERNAL_SERVER_ERROR.value(), 
    										GENERIC_APP_ERROR_CODE,
    										UNKNOWN_APPLICATION_ERROR, developerMessage);
    	}
    	slf4jLogger.debug("convertMHVErrorResponse: End");
    	return appException;
    }
}	