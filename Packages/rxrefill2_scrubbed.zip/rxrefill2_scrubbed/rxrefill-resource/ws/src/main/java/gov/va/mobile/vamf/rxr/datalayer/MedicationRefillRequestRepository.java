package gov.va.mobile.vamf.rxr.datalayer;

import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequest;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Service;

public interface MedicationRefillRequestRepository extends
		MongoRepository<MedicationRefillRequest, String> {

	/**
	 * Retrieve prescription refill requests from the database between a certain
	 * time period - the startDate and endDate ARE NOT inclusive.
	 *
	 * @param patientId
	 *            the patient id
	 * @param requestDate
	 *            is start date the data should be filtered by
	 * @param requestDate
	 *            is end date the data should be filtered by
	 * @return List of MedicationRefillRequest
	 *
	 */
	public List<MedicationRefillRequest> findByPatientIdAndAssigningAuthorityAndRequestDateBetween(
			String patientId, String assigningAuthority, Date requestDateStart,
			Date requestDateEnd);

	/**
	 * Retrieve prescription refill requests from the database between a certain
	 * time period - the startDate and endDate ARE inclusive.
	 *
	 * @param patientId
	 * @param assigningAuthority
	 * @param requestDateStart
	 *            is start date the data should be filtered by - in ISO8601
	 *            format String representation
	 * @param requestDateEnd
	 *            is end date the data should be filtered by - in ISO8601 format
	 *            String representation
	 * @return
	 */
	@Query(value = "{ 'patientId' : ?0 , 'assigningAuthority' : ?1 , 'requestDate' : { '$gte' :  ?2 , '$lte' : ?3}}")
	public List<MedicationRefillRequest> findByPatientIdAndAssigningAuthorityAndRequestDateBetweenInclusive(
			String patientId, String assigningAuthority,
			Date requestDateStart, Date requestDateEnd);

	/**
	 * Retrieve prescription refill requests from the database for a patient id.
	 *
	 * @param patientId
	 *            the patient id
	 * @return List of MedicationRefillRequest
	 * @throws AppException
	 *             the app exception
	 */
	public List<MedicationRefillRequest> findByPatientIdAndAssigningAuthority(
			String patientId, String assigningAuthority);

}