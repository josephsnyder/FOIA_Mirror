package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.ecrud.util.Operators;

/**
 * The Class FilterAttributes. 
 * 
 * Helper class to build filters for Mongo Database requests.
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public class FilterAttributes {
	
	/** The request date. */
	Operators requestDate;

	/**
	 * Gets the request date.
	 *
	 * @return the requestDate
	 */
	public Operators getRequestDate() {
		return requestDate;
	}

	/**
	 * Sets the request date.
	 *
	 * @param requestDate the requestDate to set
	 */
	public void setRequestDate(Operators requestDate) {
		this.requestDate = requestDate;
	}
	

}
