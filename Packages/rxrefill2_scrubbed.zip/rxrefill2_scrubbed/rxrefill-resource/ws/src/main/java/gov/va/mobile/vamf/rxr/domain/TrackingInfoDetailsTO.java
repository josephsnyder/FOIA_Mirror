package gov.va.mobile.vamf.rxr.domain;

import java.util.Date;
import java.util.List;

import gov.va.mobile.vamf.common.domain.Namespace;
import gov.va.mobile.vamf.common.marshallers.LongDateTimeTimeZoneMarshaller;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * The Class TrackingInfoDetailsTO.
 * <p>
 *	Contains details about a trackable prescription
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 * @see TrackingInfoTO
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "trackingInfoDetails", namespace = Namespace.VAMF)
public class TrackingInfoDetailsTO {
	
	/** The prescription name. */
	@XmlElement
	private String prescriptionName;
	
	/** The prescription number. */
	@XmlElement
	private String prescriptionNumber;
	
	/** The facility name. */
	@XmlElement
	private String facilityName ;
	
	/** The rx info phone number. */
	@XmlElement
	private String rxInfoPhoneNumber;
	
	/** The ndc number. */
	@XmlElement
	private String ndcNumber;
	
	/** The last updated time. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date lastUpdatedtime;
	
	/** The tracking info. */
	@XmlElementWrapper(name="trackingInfo")
	private List<TrackingInfoTO> trackingInfo;
	
	/**
	 * Gets the prescription name.
	 *
	 * @return the prescription name
	 */
	public String getPrescriptionName() {
		return prescriptionName;
	}
	
	/**
	 * Sets the prescription name.
	 *
	 * @param prescriptionName the new prescription name
	 */
	public void setPrescriptionName(String prescriptionName) {
		this.prescriptionName = prescriptionName;
	}
	
	/**
	 * Gets the prescription number.
	 *
	 * @return the prescription number
	 */
	public String getPrescriptionNumber() {
		return prescriptionNumber;
	}
	
	/**
	 * Sets the prescription number.
	 *
	 * @param prescriptionNumber the new prescription number
	 */
	public void setPrescriptionNumber(String prescriptionNumber) {
		this.prescriptionNumber = prescriptionNumber;
	}
	
	/**
	 * Gets the facility name.
	 *
	 * @return the facility name
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * Sets the facility name.
	 *
	 * @param facilityName the new facility name
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	/**
	 * Gets the rx info phone number.
	 *
	 * @return the rx info phone number
	 */
	public String getRxInfoPhoneNumber() {
		return rxInfoPhoneNumber;
	}
	
	/**
	 * Sets the rx info phone number.
	 *
	 * @param rxInfoPhoneNumber the new rx info phone number
	 */
	public void setRxInfoPhoneNumber(String rxInfoPhoneNumber) {
		this.rxInfoPhoneNumber = rxInfoPhoneNumber;
	}
	
	/**
	 * Gets the ndc number.
	 *
	 * @return the ndc number
	 */
	public String getNdcNumber() {
		return ndcNumber;
	}
	
	/**
	 * Sets the ndc number.
	 *
	 * @param ndcNumber the new ndc number
	 */
	public void setNdcNumber(String ndcNumber) {
		this.ndcNumber = ndcNumber;
	}
	
	/**
	 * Gets the last updated time.
	 *
	 * @return the last updated time
	 */
	public Date getLastUpdatedtime() {
		return lastUpdatedtime;
	}
	
	/**
	 * Sets the last updated time.
	 *
	 * @param lastUpdatedTime the new last updated time
	 */
	public void setLastUpdatedtime(Date lastUpdatedtime) {
		this.lastUpdatedtime = lastUpdatedtime;
	}
	
	/**
	 * Gets the tracking info.
	 *
	 * @return the tracking info
	 */
	public List<TrackingInfoTO> getTrackingInfo() {
		return trackingInfo;
	}
	
	/**
	 * Sets the tracking info.
	 *
	 * @param trackingInfo the new tracking info
	 */
	public void setTrackingInfo(List<TrackingInfoTO> trackingInfo) {
		this.trackingInfo = trackingInfo;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TrackingInfoDetailsTO [prescriptionName=" + prescriptionName
				+ ", prescriptionNumber=" + prescriptionNumber
				+ ", facilityNumber=" + facilityName + ", rxInfoPhoneNumber="
				+ rxInfoPhoneNumber + ", ndcNumber=" + ndcNumber
				+ ", lastUpdatedTime=" + lastUpdatedtime + ", trackingInfo="
				+ trackingInfo + "]";
	}
	
	

}
