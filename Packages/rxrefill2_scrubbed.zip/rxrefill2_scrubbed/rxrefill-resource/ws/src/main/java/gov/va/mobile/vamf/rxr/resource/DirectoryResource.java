package gov.va.mobile.vamf.rxr.resource;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;
import gov.va.mobile.vamf.common.resource.GenericDirectoryResource;

import org.springframework.stereotype.Controller;

/**
 * The Class DirectoryResource.
 * <p>
 * Spring REST endpoint controller for exposing public resources of the Prescription Resource.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a>
 */
@Controller
public class DirectoryResource extends GenericDirectoryResource {

	/** The Constant VERSION. */
	static final String VERSION = "/v2";
	
	/**
	 * Instantiates a new directory resource.
	 */
	public DirectoryResource() {
		setVersion(VERSION);
	}
	
	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.common.resource.GenericDirectoryResource#populatePublicLinks()
	 */
	@Override
	protected void populatePublicLinks() {
		
		// session
		getRs().add(buildTemplatedLink(PrescriptionResource.class,
				getVersion()+"/patient/{assigning-authority}/{patient-id}/session", "session"));
		
		// active
		getRs().add(linkTo(methodOn(PrescriptionResource.class)
				.activePrescriptions("sessionToken")).withRel("active"));
		
		// refillable
		getRs().add(linkTo(methodOn(PrescriptionResource.class)
				.refillablePrescriptions("sessionToken")).withRel("refillable"));
		
		// historic
		getRs().add(linkTo(methodOn(PrescriptionResource.class)
				.historicPrescriptions("sessionToken")).withRel("historic"));
		
		// tracking
		getRs().add(linkTo(methodOn(PrescriptionResource.class)
				.prescriptionTracking("sessionToken")).withRel("tracking"));
		
		// trackingdetail
		getRs().add(buildTemplatedLink(PrescriptionResource.class,
				getVersion()+"/patient/prescription/tracking/{rxId}", "trackingdetail"));
		
		// requestrefill
		getRs().add(buildTemplatedLink(PrescriptionResource.class,
				getVersion()+"/patient/{assigning-authority}/{patient-id}/prescription/{rxId}{?appSource=rxr}","requestrefill"));
		
		// refillrequests
		getRs().add(buildTemplatedLink(PrescriptionResource.class,
				getVersion()+"/patient/prescription/refillrequests","refillrequests"));
				
	}
}
