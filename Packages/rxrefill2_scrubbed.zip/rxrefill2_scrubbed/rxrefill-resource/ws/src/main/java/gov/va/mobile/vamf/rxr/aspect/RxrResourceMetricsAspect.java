package gov.va.mobile.vamf.rxr.aspect;

import gov.va.mobile.vamf.common.metrics.AbstractMetricsRecordingAspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class RxrResourceMetricsAspect extends AbstractMetricsRecordingAspect {

		/** The slf4j logger. */
  		private final Logger slf4jLogger = LoggerFactory.getLogger(RxrResourceMetricsAspect.class);

		public RxrResourceMetricsAspect() {
			slf4jLogger.debug("Constructing RxrResourceMetricsAspect");
		}

		// The @Pointcut definition should be updated to reflect the location of the
		// package you would like to audit.
		// The pointcut below will apply to any execution of a method,
		// irrespective of return type (*)
		// for any method(.)
		// in any class(.)
		// in the package gov.va.mobile.vamf.rxr.resource
		// with any argument (..)
		@Override
		@Pointcut("execution(* gov.va.mobile.vamf.rxr.resource.*.*(..))")
		public void restServicePointcut() {
			slf4jLogger.debug("Joinpoint hit");
		}

	}