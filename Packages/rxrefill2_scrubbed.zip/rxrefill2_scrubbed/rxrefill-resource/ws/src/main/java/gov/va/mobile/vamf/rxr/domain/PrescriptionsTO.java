package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class PrescriptionsTO.
 * <p>
 *	Wrapper for a list of PrescriptionTO objects.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 * @see PrescriptionTO
 */
@XmlAccessorType(value=XmlAccessType.NONE)
@XmlRootElement(name="prescriptions", namespace = Namespace.VAMF)
public class PrescriptionsTO {

	/** The prescription list. */
	@XmlElementWrapper(name="prescriptionList")
	private List<PrescriptionTO> prescriptionList;

	/**
	 * Gets the prescription list.
	 *
	 * @return the prescription list
	 */
	public List<PrescriptionTO> getPrescriptionList() {
		return prescriptionList;
	}

	/**
	 * Sets the prescription list.
	 *
	 * @param prescriptionList the new prescription list
	 */
	public void setPrescriptionList(List<PrescriptionTO> prescriptionList) {
		this.prescriptionList = prescriptionList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PrescriptionsTO [prescriptionList=" + prescriptionList + "]";
	}
	
	
}