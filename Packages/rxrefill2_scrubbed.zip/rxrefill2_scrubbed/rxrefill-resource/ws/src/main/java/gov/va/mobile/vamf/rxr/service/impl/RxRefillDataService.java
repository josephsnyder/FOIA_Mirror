package gov.va.mobile.vamf.rxr.service.impl;

import static gov.va.mobile.vamf.common.domain.FaultConstants.GENERIC_APP_ERROR_CODE;
import static gov.va.mobile.vamf.common.domain.FaultConstants.GENERIC_APP_ERROR_MSG;
import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.common.RxrUtils;
import gov.va.mobile.vamf.rxr.datalayer.MedicationRefillRequestRepository;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequest;
import gov.va.mobile.vamf.rxr.service.IRxRefillData;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * The Class RxRefillDataService.
 * <p>
 * Provides services for database access.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 *
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a>
 */
@Service
public class RxRefillDataService implements IRxRefillData {

	@Autowired
	MedicationRefillRequestRepository repository;

	/**
	 * Instantiates a new rx refill data service.
	 */
	public RxRefillDataService() {
	}

	/**
	 * Retrieve prescription refill requests from the database within a certain
	 * time period.
	 *
	 * @param patientId
	 *            the patient id
	 * @param assigningAuthority
	 *            the assigning authority
	 * @param startDate
	 *            is start date the data should be filtered by
	 * @param endDate
	 *            is end date the data should be filtered by
	 * @return the medication refill requests
	 * @throws AppException
	 *             the app exception
	 */
	public List<MedicationRefillRequest> getMedicationRefillRequests(
			String patientId, String assigningAuthority, Date startDate,
			Date endDate) throws AppException {
		if (patientId == null && startDate == null && endDate == null) {
			return getAllMedicationRefillRequests();
		} else if (startDate == null && endDate == null) {
			return getMedicationRefillRequestsByPatient(patientId,
					assigningAuthority);
		} else {

			return getMedicationRefillRequestsByPatientAndRequestDates(
					patientId, assigningAuthority, startDate, endDate);
		}
	}

	private List<MedicationRefillRequest> getMedicationRefillRequestsByPatientAndRequestDates(
			String patientId, String assigningAuthority, Date requestDateStart,
			Date requestDateEnd) {

		List<MedicationRefillRequest> refillRequests = new ArrayList<MedicationRefillRequest>();
		try {
			refillRequests = repository
					.findByPatientIdAndAssigningAuthorityAndRequestDateBetween(
							patientId, assigningAuthority, requestDateStart,
							requestDateEnd);
		} catch (Exception ex) {
			String developerMessage = RxrUtils.buildDeveloperMessage(getClass()
					.getName(), RxrUtils.getMethodName(), ex);
			AppException appException = new AppException(
					Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
					GENERIC_APP_ERROR_CODE, GENERIC_APP_ERROR_MSG,
					developerMessage);
			throw appException;
		}
		return refillRequests;

	}

	/**
	 * Retrieve prescription refill requests from the database for a certain
	 * patient.
	 *
	 * @param patientId
	 *            the patient id
	 * @param assigningAuthority
	 *            the assigning authority
	 * @return the medication refill requests by patient
	 * @throws AppException
	 *             the app exception
	 */
	public List<MedicationRefillRequest> getMedicationRefillRequestsByPatient(
			String patientId, String assigningAuthority) throws AppException {

		List<MedicationRefillRequest> refillRequests = new ArrayList<MedicationRefillRequest>();
		try {
			refillRequests = repository.findByPatientIdAndAssigningAuthority(
					patientId, assigningAuthority);
		} catch (Exception ex) {
			String developerMessage = RxrUtils.buildDeveloperMessage(getClass()
					.getName(), RxrUtils.getMethodName(), ex);
			AppException appException = new AppException(
					Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
					GENERIC_APP_ERROR_CODE, GENERIC_APP_ERROR_MSG,
					developerMessage);
			throw appException;
		}
		return refillRequests;
	}

	/**
	 * Retrieve prescription refill requests from the database.
	 *
	 * @return the all medication refill requests
	 * @throws AppException
	 *             the app exception
	 */
	public List<MedicationRefillRequest> getAllMedicationRefillRequests()
			throws AppException {
		List<MedicationRefillRequest> allRefillRequests = new ArrayList<MedicationRefillRequest>();
		try {
			allRefillRequests = repository.findAll();
		} catch (Exception ex) {
			String developerMessage = RxrUtils.buildDeveloperMessage(getClass()
					.getName(), RxrUtils.getMethodName(), ex);
			AppException appException = new AppException(
					Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
					GENERIC_APP_ERROR_CODE, GENERIC_APP_ERROR_MSG,
					developerMessage);
			throw appException;
		}
		return allRefillRequests;
	}

	/**
	 * Write successful prescription refill requests to the database.
	 *
	 * @param refillRequest
	 *            the refill request
	 * @throws AppException
	 *             the app exception
	 */
	public void writeMedicationRefillRequest(
			MedicationRefillRequest refillRequest) throws AppException {

		try {
			repository.save(refillRequest);
		} catch (Exception ex) {
			ex.printStackTrace();
			String developerMessage = RxrUtils.buildDeveloperMessage(getClass()
					.getName(), RxrUtils.getMethodName(), ex);
			AppException appException = new AppException(
					Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(),
					GENERIC_APP_ERROR_CODE, GENERIC_APP_ERROR_MSG,
					developerMessage);
			throw appException;
		}
	}

}