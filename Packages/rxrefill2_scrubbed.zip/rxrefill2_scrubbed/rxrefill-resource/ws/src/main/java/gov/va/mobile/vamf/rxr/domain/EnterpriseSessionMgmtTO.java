package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;
import gov.va.mobile.vamf.common.marshallers.LongDateTimeTimeZoneMarshaller;
import gov.va.mobile.vamf.common.utility.DateHelper;

import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The Class EnterpriseSessionMgmtTO. 
 * 
 * Transfer Object containing Enterprise Session information, 
 * including token and expiration date.
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "enterpriseSessionMgmt", namespace = Namespace.VAMF)
public class EnterpriseSessionMgmtTO {
	
	/** The token. */
	@XmlElement
	private String token;
	
	/** The expires date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date expiresDate;
	
	/**
	 * Instantiates a new enterprise session mgmt to.
	 */
	public EnterpriseSessionMgmtTO() {
	}
	
	/**
	 * Instantiates a new enterprise session mgmt to.
	 *
	 * @param token the token
	 * @param expiresDate the expires date
	 */
	public EnterpriseSessionMgmtTO(String token, Date expiresDate) {
		this.expiresDate = expiresDate;
		this.token = token;
	}

	/**
	 * Gets the token.
	 *
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	
	/**
	 * Sets the token.
	 *
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	
	/**
	 * Gets the expires date.
	 *
	 * @return the expiresDate
	 */
	public Date getExpiresDate() {
		return expiresDate;
	}
	
	/**
	 * Sets the expires date.
	 *
	 * @param expiresDate the expiresDate to set
	 */
	public void setExpiresDate(Date expiresDate) {
		this.expiresDate = expiresDate;
	}
	
	/**
	 * Checks if is expired.
	 *
	 * @return the boolean
	 */
	@JsonIgnore
	@XmlTransient
	public Boolean isExpired() {
		if (getExpiresDate() == null) {
			return true;
		}
		
		Calendar expires = Calendar.getInstance();
		expires.setTime(getExpiresDate());
		
		Calendar now = Calendar.getInstance();
		
		if (now.after(expires)) {
			return true;
		} else {
			return false;
		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("token [").append(getToken()).append("], ");
		sb.append("expiresDate [")
			.append(DateHelper.format(getExpiresDate(), DateHelper.MHV_TOKEN_EXPIRES_FORMAT))
			.append("], ");
		sb.append("token expired? [").append(isExpired()).append("] ");

		return sb.toString();
	}
}
