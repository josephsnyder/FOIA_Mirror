package gov.va.mobile.vamf.rxr.domain;

import java.util.Date;

import gov.va.mobile.vamf.common.domain.Namespace;
import gov.va.mobile.vamf.common.ecrud.domain.*;
import gov.va.mobile.vamf.common.marshallers.LongDateTimeTimeZoneMarshaller;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The Class MedicationRefillRequest.
 * <p>
 * This object contains information about successful medication refill requests triggered
 * using VAMF applications.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "medicationRefillRequest", namespace = Namespace.VAMF)
public class MedicationRefillRequest extends AbstractPersistentDocumentEntity<MedicationRefillRequest>  {
	
	/** The patient id. */
	@XmlElement
	private String patientId;
	
	/** The assigning authority. */
	@XmlElement
	private String assigningAuthority;
	
	/** The prescriptionId id. */
	@XmlElement
	private String prescriptionId;
	
	/** The request date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date requestDate;
	
	/** The app source. */
	@XmlElement
	private String appSource;
	
	/**
	 * Instantiates a new medication refill request.
	 */
	public MedicationRefillRequest() {
	}
	
	/**
	 * Instantiates a new medication refill request.
	 *
	 * @param prescriptionId the prescription id
	 * @param patientId the patient id
	 * @param assigningAuthority the assigning authority
	 * @param requestDate the request date
	 * @param appSource the app source
	 */
	public MedicationRefillRequest(String prescriptionId, String patientId, 
								   String assigningAuthority, Date requestDate, 
								   String appSource) {
		super();
		this.prescriptionId = prescriptionId;
		this.patientId = patientId;
		this.assigningAuthority = assigningAuthority;
		this.requestDate = requestDate;
		this.appSource = appSource;
		this.setDocCreatedBy(patientId);
		this.setDocLastModifiedBy(patientId);
		this.setDocCreatedDate(requestDate);
		this.setDocUpdatedDate(requestDate);
	}

	/**
	 * Gets the patient id.
	 *
	 * @return the patient id
	 */
	public String getPatientId() {
		return patientId;
	}

	/**
	 * Sets the patient id.
	 *
	 * @param patientId the new patient id
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	/**
	 * Gets the assigning authority.
	 *
	 * @return the assigningAuthority
	 */
	public String getAssigningAuthority() {
		return assigningAuthority;
	}

	/**
	 * Sets the assigning authority.
	 *
	 * @param assigningAuthority the assigningAuthority to set
	 */
	public void setAssigningAuthority(String assigningAuthority) {
		this.assigningAuthority = assigningAuthority;
	}

	/**
	 * Gets the medication id.
	 *
	 * @return the medication id
	 */
	public String getPrescriptionId() {
		return prescriptionId;
	}

	/**
	 * Sets the medication id.
	 *
	 * @param prescriptionId the new prescription id
	 */
	public void setPrescriptionId(String prescriptionId) {
		this.prescriptionId = prescriptionId;
	}

	/**
	 * Gets the request date.
	 *
	 * @return the request date
	 */
	public Date getRequestDate() {
		return requestDate;
	}

	/**
	 * Sets the request date.
	 *
	 * @param requestDate the new request date
	 */
	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	/**
	 * Gets the app source.
	 *
	 * @return the app source
	 */
	public String getAppSource() {
		return appSource;
	}

	/**
	 * Sets the app source.
	 *
	 * @param appSource the new app source
	 */
	public void setAppSource(String appSource) {
		this.appSource = appSource;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MedicationRefillRequest [patientId=" + patientId
				+ ", prescriptionId=" + prescriptionId + ", requestDate="
				+ requestDate + ", appSource=" + appSource + "]";
	}

	@Override
	protected boolean requiredEquals(MedicationRefillRequest arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected int requiredHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	

	
	
}
