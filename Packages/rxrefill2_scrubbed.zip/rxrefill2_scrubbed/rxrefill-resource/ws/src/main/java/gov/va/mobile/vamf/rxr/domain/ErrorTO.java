package gov.va.mobile.vamf.rxr.domain;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.http.HttpStatus;

import gov.va.mobile.vamf.common.domain.Namespace;
import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.common.RxrUtils;
import static gov.va.mobile.vamf.common.domain.FaultConstants.GENERIC_APP_ERROR_CODE;

/**
 * The Class ErrorTO.
 * 
 * Transfer Object containing Error information sent to the client. 
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "error", namespace = Namespace.VAMF)
public class ErrorTO {

	/** The error code. */
	@XmlElement
	private int errorCode;
	
	/** The developer message. */
	@XmlElement
	private String developerMessage;
	
	/** The message. */
	@XmlElement
	private String message;
	
	/**
	 * Gets the error code.
	 *
	 * @return the errorCode
	 */
	public int getErrorCode() {
		return errorCode;
	}
	
	/**
	 * Sets the error code.
	 *
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
	/**
	 * Gets the developer message.
	 *
	 * @return the developerMessage
	 */
	public String getDeveloperMessage() {
		return developerMessage;
	}
	
	/**
	 * Sets the developer message.
	 *
	 * @param developerMessage the developerMessage to set
	 */
	public void setDeveloperMessage(String developerMessage) {
		this.developerMessage = developerMessage;
	}
	
	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	
	/**
	 * Sets the message.
	 *
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Convert to app exception.
	 *
	 * @param status the status
	 * @return the app exception
	 */
	public AppException convertToAppException(int status) {
		if (getDeveloperMessage() == null || getDeveloperMessage().isEmpty()) {
			setDeveloperMessage(getMessage());
		}
		if (status == HttpStatus.NOT_FOUND.value()) {
			setErrorCode(GENERIC_APP_ERROR_CODE);
		}
		
		// Set user message based on error code
		setMessage(RxrUtils.getUserMessage(getErrorCode()));
		
		AppException appException = new AppException(status, getErrorCode(), getMessage(), getDeveloperMessage());
		return appException;
	}
}
