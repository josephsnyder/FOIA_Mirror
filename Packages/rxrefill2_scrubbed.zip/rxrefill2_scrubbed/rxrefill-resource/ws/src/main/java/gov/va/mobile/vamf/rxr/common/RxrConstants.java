package gov.va.mobile.vamf.rxr.common;

/**
 * The Class RxrConstants. 
 * 
 * Constants utilized by the Rx Refill Web Services
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public final class RxrConstants {
		 
	// Database Constants
	public static final String RXREFILL_DB = "rxrefilldb";
	public static final String MED_REFILL_REQ_COLLECTION = "medicationrefillrequests";
	public static final String ENT_SESS_MGMT_COLLECTION = "enterprisesessionmgmt";
	public static final String PATIENT_ID_DB_ATTR = "patientId";
	public static final String PRESCRIPTION_ID_DB_ATTR = "prescriptionId";
	public static final String RQST_DATE_DB_ATTR = "requestDate";
	public static final String APP_SRC_DB_ATTR = "appSource";
	public static final String DOC_CREATED_DT_DB_ATTR = "docCreatedDate";
	public static final String DOC_UPDATED_DT_DB_ATTR = "docUpdatedDate";
	public static final String TOKEN_DB_ATTR = "token";
	public static final String EXPIRES_DT_DB_ATTR = "expiresDate";
		
	// MHV URL Nodes
	public static final String MHV_API_URL = "mhv-api";
	public static final String MHV_SESSION_URL = "session";
	public static final String MHV_PATIENT_VERSION_URL = "patient/v1";
	public static final String MHV_PRESCRIPTION_URL = "prescription";
	public static final String MHV_REFILL_URL = "rxrefill";
	public static final String MHV_ACTIVE_RX_URL = "getactiverx";
	public static final String MHV_HISTORY_RX_URL = "gethistoryrx";
	public static final String MHV_RX_TRACKING_URL = "rxtracking";
	
	// MHV Header Constants
	public static final String MHV_HEADER_KEY_APP_TOKEN = "appToken";
	public static final String MHV_HEADER_KEY_CORRELATION_ID = "mhvCorrelationId";
	public static final String MHV_HEADER_KEY_TOKEN = "Token";
	public static final String MHV_HEADER_KEY_EXPIRES = "Expires";
	
	// Environmental property constants
	public static final String MHV_API_BASE_URL = "mhv-api-base-url";
	public static final String ECRUD_API_BASE_URL = "ecrud-api-base-url";
	public static final String APP_TOKEN = "rxr-app-token";
	public static final String MAX_DAYS_SINCE_REFILL_DATE = "max_days_since_last_refill_date";
	
	public static final String ENTERPRISE_ASSIGNING_AUTHORITY = "EDIPI";
	public static final String DEFAULT_APP_SOURCE = "rxr";
	
	public static final String UNKNOWN_APPLICATION_ERROR = "Unknown application error occurred";
	public static final String MHV_ID_NOT_FOUND_ERROR_MSG = "Your My Health Vet Id was not found. Please contact MHV Help Desk.";
	public static final String MHV_ID_MULTIPLE_FOUND_ERROR_MSG = "You have more than one My Health Vet Id. Please contact MHV Help Desk.";
	public static final String ENDPOINT_NOT_FOUND = "The remote system has responded with a Not Found status";
	
	// MVI / MHV Correlation Call constants
	public static final String MVI_ENDPOINT = "mvi-endpoint";
	public static final String MVI_CONNECTION_TIMEOUT = "mvi-connection-timeout";
	public static final String MVI_READ_TIMEOUT = "mvi-read-timeout";
	public static final String MHV_ASSIGNING_AUTHORITY = "mhv-assigining-authority";

	// User friendly messages
	public static final String SYSTEM_ISSUES = "System is currently experiencing issues. Please retry in a few minutes.";
	public static final String SYSTEM_ISSUES_CONTACT_HELPDESK = SYSTEM_ISSUES
			+ " If this problem continues to occur, please contact the help desk and report this issue.";
	public static final String USER_NOT_ACCEPTED_MHV_AGREEMENT = "You have not accepted the Rx Agreement. Please log in to MHV to accept it";
	public static final String USER_NOT_ACCEPTED_TERMS = "You have not accepted the latest Terms and Conditions. Please log in to MHV to accept it";
	public static final String ACCOUNT_LOCKED = "Your account is locked.  Please contact the help desk and report this issue";
	public static final String SYSTEM_ISSUE_RESTART_APP = "System experienced a problem. Please close the application and retry.";
	public static final String MHV_SYSTEM_EXCEPTION = "MHV is currently experiencing technical difficulties. Please try again later to view the most recent prescription information";
	// Prescription status
	public static final String ACTIVE_RX = "active";
	public static final String REFILLABLE_RX = "refillable";
	
}
