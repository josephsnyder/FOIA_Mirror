/**
 * 
 */
package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;
import gov.va.mobile.vamf.common.marshallers.LongDateTimeTimeZoneMarshaller;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * The Class PrescriptionTO.
 * <p>
 *	Contains details about a prescription
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "prescription", namespace = Namespace.VAMF)
public class PrescriptionTO {

	/** The refill status. */
	@XmlElement
	private String refillStatus; 
	
	/** The refill submit date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date refillSubmitDate;
	
	/** The refill date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date refillDate;
	
	/** The refill remaining. */
	@XmlElement
	private Integer refillRemaining;
	
	/** The facility name. */
	@XmlElement
	private String facilityName;
	
	/** The is refillable. */
	@XmlElement
	private Boolean isRefillable;
	
	/** The is trackable. */
	@XmlElement
	private Boolean isTrackable; 
	
	/** The prescription id. */
	@XmlElement
	private Long prescriptionId; 
	
	/** The ordered date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date orderedDate;
	
	/** The quantity. */
	@XmlElement
	private Integer quantity;
	
	/** The expiration date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date expirationDate;
	
	/** The prescription number. */
	@XmlElement
	private String prescriptionNumber;
	
	/** The prescription name. */
	@XmlElement
	private String prescriptionName;
	
	/** The dispensed date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date dispensedDate;
	
	/** The station number. */
	@XmlElement
	private String stationNumber;
	
	
	/**
	 * Gets the refill status.
	 *
	 * @return the refill status
	 */
	public String getRefillStatus() {
		return refillStatus;
	}
	
	/**
	 * Sets the refill status.
	 *
	 * @param refillStatus the new refill status
	 */
	public void setRefillStatus(String refillStatus) {
		this.refillStatus = refillStatus;
	}
	
	/**
	 * Gets the refill submit date.
	 *
	 * @return the refill submit date
	 */
	public Date getRefillSubmitDate() {
		return refillSubmitDate;
	}
	
	/**
	 * Sets the refill submit date.
	 *
	 * @param refillSubmitDate the new refill submit date
	 */
	public void setRefillSubmitDate(Date refillSubmitDate) {
		this.refillSubmitDate = refillSubmitDate;
	}
	
	/**
	 * Gets the refill date.
	 *
	 * @return the refill date
	 */
	public Date getRefillDate() {
		return refillDate;
	}
	
	/**
	 * Sets the refill date.
	 *
	 * @param refillDate the new refill date
	 */
	public void setRefillDate(Date refillDate) {
		this.refillDate = refillDate;
	}
	
	/**
	 * Gets the refill remaining.
	 *
	 * @return the refill remaining
	 */
	public Integer getRefillRemaining() {
		return refillRemaining;
	}
	
	/**
	 * Sets the refill remaining.
	 *
	 * @param refillRemaining the new refill remaining
	 */
	public void setRefillRemaining(Integer refillRemaining) {
		this.refillRemaining = refillRemaining;
	}
	
	/**
	 * Gets the facility name.
	 *
	 * @return the facility name
	 */
	public String getFacilityName() {
		return facilityName;
	}
	
	/**
	 * Sets the facility name.
	 *
	 * @param facilityName the new facility name
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}
	
	/**
	 * Gets the checks if is refillable.
	 *
	 * @return the checks if is refillable
	 */
	public Boolean getIsRefillable() {
		return isRefillable;
	}
	
	/**
	 * Sets the checks if is refillable.
	 *
	 * @param isRefillable the new checks if is refillable
	 */
	public void setIsRefillable(Boolean isRefillable) {
		this.isRefillable = isRefillable;
	}
	
	/**
	 * Gets the checks if is trackable.
	 *
	 * @return the checks if is trackable
	 */
	public Boolean getIsTrackable() {
		return isTrackable;
	}
	
	/**
	 * Sets the checks if is trackable.
	 *
	 * @param isTrackable the new checks if is trackable
	 */
	public void setIsTrackable(Boolean isTrackable) {
		this.isTrackable = isTrackable;
	}
	
	/**
	 * Gets the prescription id.
	 *
	 * @return the prescription id
	 */
	public Long getPrescriptionId() {
		return prescriptionId;
	}
	
	/**
	 * Sets the prescription id.
	 *
	 * @param prescriptionId the new prescription id
	 */
	public void setPrescriptionId(Long prescriptionId) {
		this.prescriptionId = prescriptionId;
	}
	
	/**
	 * Gets the ordered date.
	 *
	 * @return the ordered date
	 */
	public Date getOrderedDate() {
		return orderedDate;
	}
	
	/**
	 * Sets the ordered date.
	 *
	 * @param orderedDate the new ordered date
	 */
	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}
	
	/**
	 * Gets the quantity.
	 *
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}
	
	/**
	 * Sets the quantity.
	 *
	 * @param quantity the new quantity
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	/**
	 * Gets the expiration date.
	 *
	 * @return the expiration date
	 */
	public Date getExpirationDate() {
		return expirationDate;
	}
	
	/**
	 * Sets the expiration date.
	 *
	 * @param expirationDate the new expiration date
	 */
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	/**
	 * Gets the prescription number.
	 *
	 * @return the prescription number
	 */
	public String getPrescriptionNumber() {
		return prescriptionNumber;
	}
	
	/**
	 * Sets the prescription number.
	 *
	 * @param prescriptionNumber the new prescription number
	 */
	public void setPrescriptionNumber(String prescriptionNumber) {
		this.prescriptionNumber = prescriptionNumber;
	}
	
	/**
	 * Gets the prescription name.
	 *
	 * @return the prescription name
	 */
	public String getPrescriptionName() {
		return prescriptionName;
	}
	
	/**
	 * Sets the prescription name.
	 *
	 * @param prescriptionName the new prescription name
	 */
	public void setPrescriptionName(String prescriptionName) {
		this.prescriptionName = prescriptionName;
	}
	
	/**
	 * Gets the dispensed date.
	 *
	 * @return the dispensed date
	 */
	public Date getDispensedDate() {
		return dispensedDate;
	}
	
	/**
	 * Sets the dispensed date.
	 *
	 * @param dispensedDate the new dispensed date
	 */
	public void setDispensedDate(Date dispensedDate) {
		this.dispensedDate = dispensedDate;
	}
	
	/**
	 * Gets the station number.
	 *
	 * @return the station number
	 */
	public String getStationNumber() {
		return stationNumber;
	}
	
	/**
	 * Sets the station number.
	 *
	 * @param stationNumber the new station number
	 */
	public void setStationNumber(String stationNumber) {
		this.stationNumber = stationNumber;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PrescriptionTO [refillStatus=" + refillStatus
				+ ", refillSubmitDate=" + refillSubmitDate + ", refillDate="
				+ refillDate + ", refillRemaining=" + refillRemaining
				+ ", facilityName=" + facilityName + ", isRefillable="
				+ isRefillable + ", isTrackable=" + isTrackable
				+ ", prescriptionId=" + prescriptionId + ", orderedDate="
				+ orderedDate + ", quantity=" + quantity + ", expirationDate="
				+ expirationDate + ", prescriptionNumber=" + prescriptionNumber
				+ ", prescriptionName=" + prescriptionName + ", dispensedDate="
				+ dispensedDate + ", stationNumber=" + stationNumber + "]";
	}
	
	
}
