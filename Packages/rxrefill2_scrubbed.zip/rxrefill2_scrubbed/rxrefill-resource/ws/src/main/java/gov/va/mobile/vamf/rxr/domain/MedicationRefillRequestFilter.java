package gov.va.mobile.vamf.rxr.domain;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 * The Class MedicationRefillRequestFilter. 
 * 
 * Helper class to build filter queries for Mongo Database requests.
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public class MedicationRefillRequestFilter extends MedicationRefillRequest {

	/** The and. */
	@SerializedName("$and")
	private List<FilterAttributes> and;
	
	/** The or. */
	@SerializedName("$or")
	private List<FilterAttributes> or;

	/**
	 * Gets the and.
	 *
	 * @return the and
	 */
	public List<FilterAttributes> getAnd() {
		return and;
	}

	/**
	 * Sets the and.
	 *
	 * @param and the and to set
	 */
	public void setAnd(List<FilterAttributes> and) {
		this.and = and;
	}

	/**
	 * Gets the or.
	 *
	 * @return the or
	 */
	public List<FilterAttributes> getOr() {
		return or;
	}

	/**
	 * Sets the or.
	 *
	 * @param or the or to set
	 */
	public void setOr(List<FilterAttributes> or) {
		this.or = or;
	}
	
	
}
