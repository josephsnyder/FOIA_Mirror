package gov.va.mobile.vamf.rxr.service.impl;

import static gov.va.mobile.vamf.rxr.common.RxrConstants.APP_TOKEN;
import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.common.RxrProperties;
import gov.va.mobile.vamf.rxr.domain.EnterpriseSessionMgmtTO;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequest;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequests;
import gov.va.mobile.vamf.rxr.domain.PrescriptionsTO;
import gov.va.mobile.vamf.rxr.domain.TrackingInfoDetailsTO;
import gov.va.mobile.vamf.rxr.service.IPrescriptionService;
import gov.va.mobile.vamf.rxr.service.IRxRefillData;
import gov.va.mobile.vamf.rxr.service.IRxRefillMHVClient;
//import static gov.va.mobile.vamf.rxr.common.RxrConstants.ENTERPRISE_ASSIGNING_AUTHORITY;
//import static gov.va.mobile.vamf.common.domain.FaultConstants.INVALID_OR_MISSING_CODE;
//import static gov.va.mobile.vamf.common.domain.FaultConstants.INVALID_OR_MISSING_MSG;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.DEFAULT_APP_SOURCE;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// TODO: Auto-generated Javadoc
/**
 * The Class PrescriptionService.
 * 
 * Implementation class for Rx Refill Services
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
@Service
public class PrescriptionService implements IPrescriptionService {
	
	/**  MHV Client Service *. */
  	@Autowired
  	private IRxRefillMHVClient rxRefillMHVClientService;
  	
  	/**  Prescription Refill Data Service *. */
  	@Autowired
  	private IRxRefillData rxRefillDataService;
	
	/**
	 * Instantiates a new prescription service.
	 */
	public PrescriptionService() {
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getEnterpriseSession(java.lang.String, java.lang.String)
	 */
	@Override
	public EnterpriseSessionMgmtTO getEnterpriseSession(String assigningAuthority, String patientId) throws AppException {
		validateEnterpriseAssigningAuthority(assigningAuthority);
		
   		// Get a new Enterprise Token from MHV
		RxrProperties properties = new RxrProperties();    	
    	String appToken = properties.getProperty(APP_TOKEN);
    	
    	return rxRefillMHVClientService.getSessionToken(appToken, patientId);
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getActivePrescriptions(java.lang.String)
	 */
	@Override
	public PrescriptionsTO getActivePrescriptions(String sessionToken) throws AppException{

    	// Call MHV Enterprise Active Prescriptions Service
    	return rxRefillMHVClientService.getActivePrescriptions(sessionToken);
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getHistoricPrescriptions(java.lang.String)
	 */
	@Override
	public PrescriptionsTO getHistoricPrescriptions(String sessionToken) throws AppException{

    	// Call MHV Enterprise Active Prescriptions Service
    	return rxRefillMHVClientService.getHistoricPrescriptions(sessionToken);
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getPrescriptionTracking(java.lang.String)
	 */
	@Override
	public PrescriptionsTO getPrescriptionTracking(String sessionToken) throws AppException{

    	// Call MHV Enterprise Prescription Tracking Service
    	return rxRefillMHVClientService.getPrescriptionTracking(sessionToken);
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getTrackingDetails(java.lang.String, java.lang.String)
	 */
	@Override
	public TrackingInfoDetailsTO getTrackingDetails(String sessionToken, String rxId) throws AppException{

		// Call MHV Enterprise Prescription Tracking Details Service
    	return rxRefillMHVClientService.getTrackingDetails(sessionToken, rxId);
	}


	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#refillPrescription(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void refillPrescription(String sessionToken, String rxId, String patientId, 
								   String assigningAuthority, String appSource) throws AppException {

		// Call MHV Enterprise Request Refill Service
		rxRefillMHVClientService.requestRefill(rxId, sessionToken);
		
		// Write refill prescription request to the database
		if (appSource == null || appSource.isEmpty()) {
			appSource = DEFAULT_APP_SOURCE;
		}
	
    	Date now = Calendar.getInstance().getTime();
    	MedicationRefillRequest refillRequest = new MedicationRefillRequest(rxId, patientId, 
    													assigningAuthority, now,
    													appSource);

		rxRefillDataService.writeMedicationRefillRequest(refillRequest);
	}


	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getRefillRequests(java.lang.String, java.lang.String, java.util.Date, java.util.Date, boolean)
	 */
	@Override
	public MedicationRefillRequests getRefillRequests(String patientId, String assigningAuthority,
			Date startDate, Date endDate, boolean count) throws AppException {

		MedicationRefillRequests requests = new MedicationRefillRequests();
		requests.setMedicationRefills(rxRefillDataService.getMedicationRefillRequests(patientId, assigningAuthority, startDate, endDate));
		
		return requests;
	}

	/* (non-Javadoc)
	 * @see gov.va.mobile.vamf.rxr.service.IPrescriptionService#getRefillablePrescriptions(java.lang.String)
	 */
	public PrescriptionsTO getRefillablePrescriptions(String sessionToken) throws AppException {
		// Get Refillable Prescriptions
    	return rxRefillMHVClientService.getRefillablePrescriptions(sessionToken);	
	}

	/**
	 * Validate enterprise assigning authority.
	 *
	 * @param assigningAuthority the assigning authority
	 * @throws AppException the app exception
	 */
	private void validateEnterpriseAssigningAuthority(String assigningAuthority) throws AppException {
		// TODO Uncomment
		/**
		if (assigningAuthority == null || ! assigningAuthority.equals(ENTERPRISE_ASSIGNING_AUTHORITY)) {
			String developerMessage = "Assigning authority path parameter was missing or invalid.";
    		AppException appException = new AppException(Response.Status.BAD_REQUEST.getStatusCode(),
    													 INVALID_OR_MISSING_CODE,
    													 INVALID_OR_MISSING_MSG,
    													 developerMessage);
    		throw appException;
		}
		**/
	}
	
	/**
	 * Sets the rx refill MHV client service.
	 *
	 * @param rxRefillMHVClientService the new rx refill MHV client service
	 */
	public void setRxRefillMHVClientService(IRxRefillMHVClient rxRefillMHVClientService) {
		this.rxRefillMHVClientService = rxRefillMHVClientService;
		
	}
	
	/**
	 * Sets the rx refill data service.
	 *
	 * @param rxRefillDataService the new rx refill data service
	 */
	public void setRxRefillDataService(IRxRefillData rxRefillDataService) { 
		this.rxRefillDataService = rxRefillDataService;
	}
	
}
