package gov.va.mobile.vamf.rxr.common;

import static gov.va.mobile.vamf.rxr.common.RxrConstants.ACCOUNT_LOCKED;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.ECRUD_API_BASE_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_API_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.MHV_PATIENT_VERSION_URL;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.RXREFILL_DB;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.SYSTEM_ISSUES;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.SYSTEM_ISSUES_CONTACT_HELPDESK;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.SYSTEM_ISSUE_RESTART_APP;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.UNKNOWN_APPLICATION_ERROR;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.USER_NOT_ACCEPTED_MHV_AGREEMENT;
import static gov.va.mobile.vamf.rxr.common.RxrConstants.USER_NOT_ACCEPTED_TERMS;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * The Class RxrUtils. 
 * 
 * Provides common utilities used by the Rx Refill Services.
 * 
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public final class RxrUtils {

	/** The slf4j logger. */
  	private final static Logger slf4jLogger = LoggerFactory.getLogger(RxrProperties.class);

	/** Load User Friendly Messages in Map with corresponding error codes */
	public final static Map<String, String> userMessageMap = new HashMap<String, String>();
	
	static {
		userMessageMap.put("[99][901][904]", SYSTEM_ISSUES);
		userMessageMap.put("[101][102][103][104][105][107][108][109][110][111][117][132]", SYSTEM_ISSUES_CONTACT_HELPDESK);
		userMessageMap.put("[106]", ACCOUNT_LOCKED);
		userMessageMap.put("[114]", USER_NOT_ACCEPTED_TERMS);		
		userMessageMap.put("[135]", USER_NOT_ACCEPTED_MHV_AGREEMENT);
		userMessageMap.put("[136][137][138]", SYSTEM_ISSUE_RESTART_APP);
	}

	/**
	 * Gets the user message.
	 *
	 * @param errorCode the error code
	 * @return the user message
	 */
	public static String getUserMessage(int errorCode) {
		Iterator<String> keys = userMessageMap.keySet().iterator();
		String searchCode = "["+errorCode+"]";
		String message = "";
		while(keys.hasNext()) {
			String key = keys.next();
			if (key.indexOf(searchCode) > -1) {
				message = userMessageMap.get(key);
			}
		}
		if (message.isEmpty()) {
			message = UNKNOWN_APPLICATION_ERROR;
		}
		return message;
	}
	
	/**
	 * Initializes a list with common url nodes for calling My Health eVet endpoints.
	 * 
	 * @return List of Strings, with nodes MHV_API_URL and MHV_PATIENT_VERSION_URL 
	 */
    public static List<String> initializeMHVUriNodeList() {
    	List<String> uriNodeList = new ArrayList<String>();
    	uriNodeList.add(MHV_API_URL);
    	uriNodeList.add(MHV_PATIENT_VERSION_URL);
    	
    	return uriNodeList;
    }
    
	/**
	 * Builds a WebTarget object, which is used to construct an Invocation object.
	 *
	 * @param client the client
	 * @param baseURI the base uri
	 * @param uriNodeList the uri node list
	 * @return the web target
	 */
	public static WebTarget buildMHVTarget(Client client, URI baseURI, List<String> uriNodeList) {
		
		slf4jLogger.debug("baseURL(): "+baseURI);
		WebTarget target = client.target(baseURI);
		
		if (uriNodeList != null && uriNodeList.size() > 0) {
			for (String node: uriNodeList) {
				target = target.path(node);	
				slf4jLogger.debug("node(): "+node);
			}
		}

		return target;
	}
	
	/**
	 * Builds an Invocation object which is used to make a RESTFUL 
	 * web service call to My Health eVet.
	 *
	 * @param target the target
	 * @param httpMethod the http method
	 * @param headers the headers
	 * @param acceptType the accept type
	 * @return the invocation
	 */
	public static Invocation getInvocation(WebTarget target, String httpMethod, 
											Map<String,String> headers, MediaType acceptType) {
		Iterator<Entry<String,String>> headerIter = null;
		if (headers != null) {
			headerIter = headers.entrySet().iterator();
		}

		// Server Accepts
		Builder builder = target.request(acceptType);

		// Add the header key/value pairs
		if (headerIter != null) {
			while(headerIter.hasNext()) {
				Entry<String,String> entry = headerIter.next(); 
				builder.header(entry.getKey(), entry.getValue());
			}
		}

		Invocation invocation = null;
		if (httpMethod.equals(HttpMethod.GET)) {
			invocation = builder.buildGet();
		} else if (httpMethod.equals(HttpMethod.POST)) {
			invocation = builder.buildPost(null);
		} else if (httpMethod.equals(HttpMethod.PUT)) {
			invocation = builder.buildPut(null);
		} else if (httpMethod.equals(HttpMethod.DELETE)) {
			invocation = builder.buildDelete();
		} else {
			invocation = target.request().buildGet();
		}
		return invocation;
	}

    /**
     * Gets the data base url.
     *
     * @return the data base url
     */
    public static String getDataBaseUrl() {
		RxrProperties properties = new RxrProperties();    	
		StringBuilder sb = new StringBuilder(properties.getProperty(ECRUD_API_BASE_URL));
		sb.append(RXREFILL_DB);
		
		return sb.toString();
    }

    /**
     * Gets the method name.  This is used to identify where exceptions
     * occur when building developer facing messages.
     *
     * @return the method name
     */
    public static String getMethodName() {
        return Thread.currentThread().getStackTrace()[2].getMethodName();
    } 
    
    /**
     * Builds the developer message.
     *
     * @param className the class name
     * @param methodName the method name
     * @param ex the ex
     * @return the string
     */
    public static String buildDeveloperMessage(String className, String methodName, Exception ex) {
    	return buildDeveloperMessage(className, methodName, ex.getMessage());
    }
    
    /**
     * Builds the developer message.
     *
     * @param className the class name
     * @param methodName the method name
     * @param msg the msg
     * @return the string
     */
    public static String buildDeveloperMessage(String className, String methodName, String msg) {
    	StringBuilder sb = new StringBuilder();
    	sb.append("Caught exception in ").append(className).append(":").append(methodName);
    	sb.append(":").append(msg);
    	
    	return sb.toString();
    }
    
    /**
     * Safe close.
     *
     * @param is the input stream
     */
    public static void safeClose(InputStream is) {
    	if (is != null) {
    		try {
    			is.close();
    		} catch(IOException ioe) {
    			slf4jLogger.error(ioe.getMessage());
    		}
    	}
    }
}
