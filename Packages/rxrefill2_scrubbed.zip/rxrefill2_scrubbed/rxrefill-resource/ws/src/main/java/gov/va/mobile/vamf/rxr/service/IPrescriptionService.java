package gov.va.mobile.vamf.rxr.service;

import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.domain.EnterpriseSessionMgmtTO;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequests;
import gov.va.mobile.vamf.rxr.domain.PrescriptionsTO;
import gov.va.mobile.vamf.rxr.domain.TrackingInfoDetailsTO;

import java.util.Date;

/**
 * The Interface IPrescriptionService.
 */
public interface IPrescriptionService {
	

	/**
	 * Gets the enterprise session.
	 *
	 * @param assigningAuthority the assigning authority
	 * @param patientId the patient id
	 * @return the enterprise session
	 * @throws AppException the app exception
	 */
	public EnterpriseSessionMgmtTO getEnterpriseSession(String assigningAuthority, String patientId) throws AppException;
	
	/**
	 * Gets the active prescriptions.
	 *
	 * @param sessionToken the session token
	 * @return the active prescriptions
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getActivePrescriptions(String sessionToken) throws AppException;
	
	/**
	 * Gets the historic prescriptions.
	 *
	 * @param sessionToken the session token
	 * @return the historic prescriptions
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getHistoricPrescriptions(String sessionToken) throws AppException;
	
	/**
	 * Gets the prescription tracking.
	 *
	 * @param sessionToken the session token
	 * @return the prescription tracking
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getPrescriptionTracking(String sessionToken) throws AppException;
	
	/**
	 * Gets the tracking details.
	 *
	 * @param sessionToken the session token
	 * @param rxId the rx id
	 * @return the tracking details
	 * @throws AppException the app exception
	 */
	public TrackingInfoDetailsTO getTrackingDetails(String sessionToken, String rxId) throws AppException;
	
	/**
	 * Refill prescription.
	 *
	 * @param sessionToken the session token
	 * @param rxId the rx id
	 * @param patientId the patient id
	 * @param assigningAuthority the assigning authority
	 * @param appSource the app source
	 * @throws AppException the app exception
	 */
	public void refillPrescription(String sessionToken, String rxId, String patientId, 
								   String assigningAuthority, String appSource) throws AppException;
	
	/**
	 * Gets the refill requests.
	 *
	 * @param patientId the patient id
	 * @param assigningAuthority the assigning authority
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param count the count
	 * @return the refill requests
	 * @throws AppException the app exception
	 */
	public MedicationRefillRequests getRefillRequests(String patientId, String assigningAuthority, 
														Date startDate, Date endDate, boolean count) throws AppException;

	/**
	 * Gets the refillable prescriptions.
	 *
	 * @param sessionToken the session token
	 * @return the refillable prescriptions
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getRefillablePrescriptions(String sessionToken) throws AppException;

	/**
	 * Sets the rx refill mhv client service.
	 *
	 * @param rxRefillMHVClientService the new rx refill mhv client service
	 */
	public void setRxRefillMHVClientService(IRxRefillMHVClient rxRefillMHVClientService);
	
	/**
	 * Sets the rx refill data service.
	 *
	 * @param rxRefillDataService the new rx refill data service
	 */
	public void setRxRefillDataService(IRxRefillData rxRefillDataService); 

}
