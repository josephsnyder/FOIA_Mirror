package gov.va.mobile.vamf.rxr.service;

import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.domain.EnterpriseSessionMgmtTO;
import gov.va.mobile.vamf.rxr.domain.PrescriptionsTO;
import gov.va.mobile.vamf.rxr.domain.TrackingInfoDetailsTO;

/**
 * The Interface Rx Refill MHV Client contains all the REST client calls to 
 * VA MyHealtheVet Rx Refill and Tracking APIs.
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */
public interface IRxRefillMHVClient {
  
	/**
	 * Get Enterprise Session Token from the
	 * to MHV Session Endpoint.
	 *
	 * @param appToken VAMF App Token
	 * @param correlationId the correlation id
	 * @return the session token
	 * @throws AppException the app exception
	 */
	public EnterpriseSessionMgmtTO getSessionToken(String appToken, String correlationId) throws AppException;
    
    /**
     * Post prescription refill request for prescription id
     * to MHV Rx Refill Endpoint.
     *
     * @param rxId the rx id
     * @param token is enterprise session token
     * @throws AppException the app exception
     */
	public void requestRefill(String rxId, String token) throws AppException;

	/**
	 * Get trackable prescriptions from the
	 * to MHV Get History Rx Endpoint.
	 *
	 * @param token is enterprise session token
	 * @return the response
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getPrescriptionTracking(String token) throws AppException;
	
	/**
	 * Gets the active prescriptions.
	 *
	 * @param token the token
	 * @return the active prescriptions
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getActivePrescriptions(String token) throws AppException;
	
	/**
	 * Gets the historic prescriptions.
	 *
	 * @param token the token
	 * @return the historic prescriptions
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getHistoricPrescriptions(String token) throws AppException;
	
	/**
	 * Gets the tracking details.
	 *
	 * @param token the token
	 * @param rxId the rx id
	 * @return the tracking details
	 */
	public TrackingInfoDetailsTO getTrackingDetails(String token, String rxId) throws AppException;

	/**
	 * Gets the refillable prescriptions.
	 *
	 * @param token the token
	 * @return the refillable prescriptions
	 * @throws AppException the app exception
	 */
	public PrescriptionsTO getRefillablePrescriptions(String token) throws AppException;

}