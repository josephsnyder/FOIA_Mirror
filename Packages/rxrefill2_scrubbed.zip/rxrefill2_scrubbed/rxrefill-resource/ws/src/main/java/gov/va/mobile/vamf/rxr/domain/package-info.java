@XmlJavaTypeAdapters({
        @XmlJavaTypeAdapter(value=XSSProtectionMapper.class, type=String.class)
})
package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.marshallers.XSSProtectionMapper;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapters;