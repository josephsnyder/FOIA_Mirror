package gov.va.mobile.vamf.rxr.service;

import java.util.Date;
import java.util.List;

import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequest;

/**
 * The Interface Rx Refill Data contains methods for accessing DAO classes 
 * for data layer access via an ECRUD API layer.
 * <p> 
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A> 
 * </p> 
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a> 
 */

public interface IRxRefillData {

    /**
     * Retrieve prescription refill requests from the database
     * within a certain time period.
     *
     * @param patientId the patient id
     * @param assigningAuthority the assigning authority
     * @param startDate is start date the data should be filtered by
     * @param endDate is end date the data should be filtered by
     * @return the medication refill requests
     * @throws AppException the app exception
     */
    public List<MedicationRefillRequest> getMedicationRefillRequests(String patientId, String assigningAuthority,
    																 Date startDate, Date endDate) 
    																 throws AppException;
	
    /**
     * Retrieve prescription refill requests from the database
     * for a certain patient.
     *
     * @param patientId the patient id
     * @param assigningAuthority the assigning authority
     * @return the medication refill requests by patient
     * @throws AppException the app exception
     */
    public List<MedicationRefillRequest> getMedicationRefillRequestsByPatient(String patientId, 
    																		  String assigningAuthority) 
    																		  throws AppException;
	
    /**
     * Retrieve prescription refill requests from the database.
     *
     * @return the all medication refill requests
     * @throws AppException the app exception
     */
    public List<MedicationRefillRequest> getAllMedicationRefillRequests() throws AppException;
	
    /**
     * Write successful prescription refill requests to the database.
     *
     * @param refillRequest the refill request
     * @throws AppException the app exception
     */
    public void writeMedicationRefillRequest(MedicationRefillRequest refillRequest) throws AppException;

}