package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;
import gov.va.mobile.vamf.common.marshallers.LongDateTimeTimeZoneMarshaller;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

/**
 * The Class TrackingInfoTO.
 * <p>
 * Contains information on the tracking and other prescription included in a prescription shipment
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 * @see PrescriptionLiteTO
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "trackingInfo", namespace = Namespace.VAMF)
public class TrackingInfoTO {
	
	/** The shipped date. */
	@XmlElement
	@XmlJavaTypeAdapter(LongDateTimeTimeZoneMarshaller.class)
	private Date shippedDate;
	
	/** The delivery service. */
	@XmlElement
	private String deliveryService;
	
	/** The tracking number. */
	@XmlElement
	private String trackingNumber;
	
	/** The other prescriptions included. */
	@XmlElementWrapper(name="otherPrescriptionListIncluded")
	private List<PrescriptionLiteTO> otherPrescriptionListIncluded;
	
	/**
	 * Gets the shipped date.
	 *
	 * @return the shipped date
	 */
	public Date getShippedDate() {
		return shippedDate;
	}
	
	/**
	 * Sets the shipped date.
	 *
	 * @param shippedDate the new shipped date
	 */
	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}
	
	/**
	 * Gets the delivery service.
	 *
	 * @return the delivery service
	 */
	public String getDeliveryService() {
		return deliveryService;
	}
	
	/**
	 * Sets the delivery service.
	 *
	 * @param deliveryService the new delivery service
	 */
	public void setDeliveryService(String deliveryService) {
		this.deliveryService = deliveryService;
	}
	
	/**
	 * Gets the tracking number.
	 *
	 * @return the tracking number
	 */
	public String getTrackingNumber() {
		return trackingNumber;
	}
	
	/**
	 * Sets the tracking number.
	 *
	 * @param trackingNumber the new tracking number
	 */
	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}
	
	/**
	 * Gets the other prescriptions included.
	 *
	 * @return the other prescriptions included
	 */
	public List<PrescriptionLiteTO> getOtherPrescriptionListIncluded() {
		return otherPrescriptionListIncluded;
	}
	
	/**
	 * Sets the other prescriptions included.
	 *
	 * @param otherPrescriptionsIncluded the new other prescriptions included
	 */
	public void setOtherPrescriptionListIncluded(
			List<PrescriptionLiteTO> otherPrescriptionListIncluded) {
		this.otherPrescriptionListIncluded = otherPrescriptionListIncluded;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TrackingInfoTO [shippedDate=" + shippedDate
				+ ", deliveryService=" + deliveryService + ", trackingNumber="
				+ trackingNumber + ", otherPrescriptionListIncluded="
				+ otherPrescriptionListIncluded + "]";
	}
	
	
}
