package gov.va.mobile.vamf.rxr.resource;

import gov.va.mobile.vamf.common.exception.AppException;
import gov.va.mobile.vamf.rxr.domain.EnterpriseSessionMgmtTO;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequestDetails;
import gov.va.mobile.vamf.rxr.domain.MedicationRefillRequests;
import gov.va.mobile.vamf.rxr.domain.PrescriptionsTO;
import gov.va.mobile.vamf.rxr.domain.TrackingInfoDetailsTO;
import gov.va.mobile.vamf.rxr.service.IPrescriptionService;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * The Class PrescriptionResource.
 * <p>
 * Spring REST endpoint controller for implementation needed for working with Enterprise Prescriptions and Tracking.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 */
@Controller
public class PrescriptionResource {
	
	/** The prescription service. */
	@Autowired
	private IPrescriptionService prescriptionService;

	/**
	 * Get MHV Session Token.
	 *
	 * @param assigningAuthority the assigning authority
	 * @param patientId the patient id
	 * @return the prescriptions to
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/{assigning-authority}/{patient-id}/session", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody EnterpriseSessionMgmtTO enterpriseSession(
			@PathVariable("assigning-authority") String assigningAuthority,
			@PathVariable("patient-id") String patientId) throws AppException {
		
		return prescriptionService.getEnterpriseSession(assigningAuthority, patientId);
	}
	
	/**
	 * Active prescriptions.
	 *
	 * @param sessionToken the session token
	 * @return the prescriptions
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/prescription/active", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody PrescriptionsTO activePrescriptions(
			@RequestHeader(value="Token") String sessionToken) throws AppException {
		
		return prescriptionService.getActivePrescriptions(sessionToken);
	}
	
	/**
	 * Request refill.
	 *
	 * @param sessionToken the session token
	 * @param assigningAuthority the assigning authority
	 * @param patientId the patient id
	 * @param rxId the rx id
	 * @param appSource the app source
	 * @return the response entity
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/{assigning-authority}/{patient-id}/prescription/{rxId}", 
					method = RequestMethod.POST, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody ResponseEntity<String> requestRefill(
			@RequestHeader	(value="Token") String sessionToken,
			@PathVariable("assigning-authority") String assigningAuthority,
			@PathVariable("patient-id") String patientId,
			@PathVariable("rxId") String rxId,
			@RequestParam(value="appSource", required=false) String appSource) throws AppException {
		
		prescriptionService.refillPrescription(sessionToken, rxId, patientId, assigningAuthority, appSource);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	
	/**
	 * Historic prescriptions.
	 *
	 * @param sessionToken the session token
	 * @return the prescriptions to
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/prescription/historic", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody PrescriptionsTO historicPrescriptions(
			@RequestHeader(value="Token") String sessionToken) throws AppException {

		return prescriptionService.getHistoricPrescriptions(sessionToken);
	}
	

	/**
	 * Prescription tracking.
	 *
	 * @param sessionToken the session token
	 * @return the prescriptions to
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/prescription/tracking", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody PrescriptionsTO prescriptionTracking(
			@RequestHeader(value="Token") String sessionToken)  throws AppException {
		
		return prescriptionService.getPrescriptionTracking(sessionToken);
	}
	
	/**
	 * Prescription tracking detail.
	 *
	 * @param sessionToken the session token
	 * @param rxId the rx id
	 * @return the tracking info details to
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/prescription/tracking/{rxId}", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody TrackingInfoDetailsTO prescriptionTrackingDetail(
			@RequestHeader(value="Token") String sessionToken,
			@PathVariable("rxId") String rxId) throws AppException {

		return prescriptionService.getTrackingDetails(sessionToken, rxId);
	}
	
	/**
	 * Refill requests.
	 *
	 * @param patientId the patient id
	 * @param assigningAuthority the assigning authority
	 * @param startDate the start date
	 * @param endDate the end date
	 * @param count the count
	 * @return the medication refill requests
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/prescription/refillrequests", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody MedicationRefillRequestDetails refillRequests(
			@RequestHeader(value="patientId", required=false) String patientId,
			@RequestHeader(value="assigningAuthority", required=false) String assigningAuthority,
			@RequestHeader(value="startDate", required=false) Date startDate,
			@RequestHeader(value="endDate", required=false) Date endDate,
			@RequestHeader(value="count", required=false) boolean count) throws AppException
	{
		MedicationRefillRequestDetails requestDetails = new MedicationRefillRequestDetails();
		MedicationRefillRequests requests = prescriptionService.getRefillRequests(patientId, assigningAuthority, 
																				  startDate, endDate, count);
		Integer requestCount = 0;
		
		if (requests != null && requests.getMedicationRefills() != null) {
			requestCount = requests.getMedicationRefills().size(); 
		}
		
		if (count) {
			requestDetails.setCount(requestCount);
		} else {
			if ( requestCount == 1) {
				requestDetails.setMedicationRefillRequest(requests.getMedicationRefills().get(0));
			} else if (requestCount > 1) {
				requestDetails.setMedicationRefillRequests(requests);
			}
		}
		
		return requestDetails;
	}

	/**
	 * Active prescriptions.
	 *
	 * @param sessionToken the session token
	 * @return the prescriptions
	 * @throws AppException the app exception
	 */
	@RequestMapping(value = "/v2/patient/prescription/refillable", 
					method = RequestMethod.GET, 
					produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public @ResponseBody PrescriptionsTO refillablePrescriptions(
			@RequestHeader(value="Token") String sessionToken) throws AppException {
		return prescriptionService.getRefillablePrescriptions(sessionToken);
	}

	/**
	 * Sets the prescription service.
	 *
	 * @param prescriptionService the new prescription service
	 */
	public void setPrescriptionService(IPrescriptionService prescriptionService) {
		this.prescriptionService = prescriptionService;
	}

}
