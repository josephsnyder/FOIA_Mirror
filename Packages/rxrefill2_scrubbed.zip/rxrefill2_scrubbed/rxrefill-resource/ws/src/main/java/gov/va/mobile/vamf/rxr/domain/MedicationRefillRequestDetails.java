package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * The Class MedicationRefillRequestDetails.
 * <p>
 * Wrapper for Medication Refill Request Details.
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:chris.gorman@hp.com">Chris Gorman</a>
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "medicationRefillRequestDetails", namespace = Namespace.VAMF)
@JsonInclude(Include.NON_NULL)  
public class MedicationRefillRequestDetails {
	
	/** The medication refill request. */
	@XmlElement
	MedicationRefillRequest medicationRefillRequest;
	
	/** The medication refill requests. */
	@XmlElement
	MedicationRefillRequests medicationRefillRequests;
	
	/** The Count. */
	@XmlElement
	Integer Count;

	/**
	 * Instantiates a new medication refill request details.
	 */
	public MedicationRefillRequestDetails() {
	}
	
	/**
	 * Gets the medication refill request.
	 *
	 * @return the medicationRefillRequest
	 */
	public MedicationRefillRequest getMedicationRefillRequest() {
		return medicationRefillRequest;
	}

	/**
	 * Sets the medication refill request.
	 *
	 * @param medicationRefillRequest the medicationRefillRequest to set
	 */
	public void setMedicationRefillRequest(
			MedicationRefillRequest medicationRefillRequest) {
		this.medicationRefillRequest = medicationRefillRequest;
	}

	/**
	 * Gets the medication refill requests.
	 *
	 * @return the medicationRefillRequests
	 */
	public MedicationRefillRequests getMedicationRefillRequests() {
		return medicationRefillRequests;
	}

	/**
	 * Sets the medication refill requests.
	 *
	 * @param medicationRefillRequests the medicationRefillRequests to set
	 */
	public void setMedicationRefillRequests(
			MedicationRefillRequests medicationRefillRequests) {
		this.medicationRefillRequests = medicationRefillRequests;
	}

	/**
	 * Gets the count.
	 *
	 * @return the count
	 */
	public Integer getCount() {
		return Count;
	}

	/**
	 * Sets the count.
	 *
	 * @param count the count to set
	 */
	public void setCount(Integer count) {
		Count = count;
	}

}
