package gov.va.mobile.vamf.rxr.domain;

import gov.va.mobile.vamf.common.domain.Namespace;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class MedicationRefillRequests.
 * <p>
 * List wrapper for Medication Refill Request
 * </p>
 * <p>
 * <A HREF="http://www.hp.com"> Hewlett-Packard Enterprise Services</A>
 * </p>
 * 
 * @author <a href="mailto:david.aar.lucas@hp.com">Aaron Lucas</a>
 */
@XmlAccessorType(value = XmlAccessType.NONE)
@XmlRootElement(name = "medicationRefillRequests", namespace = Namespace.VAMF)
public class MedicationRefillRequests {
	
	/** The refill requests. */
	@XmlElementWrapper(name="medicationRefills")
	private List<MedicationRefillRequest> medicationRefills;

	/**
	 * Gets the refill requests.
	 *
	 * @return the refill requests
	 */
	public List<MedicationRefillRequest> getMedicationRefills() {
		return medicationRefills;
	}

	/**
	 * Sets the refill requests.
	 *
	 * @param refillRequests the new refill requests
	 */
	public void setMedicationRefills(List<MedicationRefillRequest> refillRequests) {
		this.medicationRefills = refillRequests;
	}

}
