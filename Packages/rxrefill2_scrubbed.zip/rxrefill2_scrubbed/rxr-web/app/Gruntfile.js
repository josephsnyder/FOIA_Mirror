module.exports = function(grunt){
  var asset = {
    libs: [
      'bower_components/modernizr/modernizr.js',
      'bower_components/jquery/dist/jquery.min.js',
      'bower_components/bootstrap/dist/js/bootstrap.min.js',
      'bower_components/underscore/underscore.js',
      'bower_components/backbone/backbone.js',
      'bower_components/marionette/lib/backbone.marionette.min.js',
      'bower_components/handlebars/handlebars.js',
      'common/lib/template_helpers.js',
      'common/lib/bootstrap-datepicker.min.js'
    ],
    css: [
      'bower_components/bootstrap/dist/css/bootstrap.css',
      'common/css/bootstrap-datepicker3.css'
    ],
    veteran: [
      'common/js/app.js',
      'common/lib/resource_directory_util.js',
      'common/lib/LoginUtils.js',
      'common/lib/app_utils.js',
      'common/js/model/*.js',
      'common/js/collection/*.js',
      'common/_temp/app_json.js',
      'common/_temp/vet_templates.js',
      'common/js/view/*.js',
      'veteran/js/view/*.js',
      'veteran/js/route.js',
      'veteran/js/app.js'
    ]
  };

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    concat: {
      veteran: {
        src: asset.css,
        dest: 'veteran/_build/css/lib.css'
      }
    },
    connect: {
        veteran: {
            options: {
                base: ['veteran/index.html', 'veteran/_build', 'common/data', ''],
                port: 5000,
                hostname: '0.0.0.0'
            }
        },
        test: {
            options: {
                base: ['veteran/index.html', 'veteran/_build', 'common/data', ''],
                port: 6000,
                hostname: '0.0.0.0'
            }
        }
    },
    handlebars: {
        veteran: {
            options: {
                namespace: "RXR.Template",
                processName: function (filePath) {
                    var fileName = filePath.match(/.*\/([a-zA-Z0-9\_\-]+)\.html$/);
                    return fileName[1];
                }
            },
            files: {
                "common/_temp/vet_templates.js": ["common/js/template/*.html", "veteran/js/template/*.html"]
            }
        }
    },
    sass: {
        veteran: {
            files: [{
                expand: true,
                cwd: 'common/sass',
                src: ['app.scss'],
                dest: 'veteran/_build/css',
                ext: '.css'
            }]
        }
    },
    json: {
        app: {
            options: {
                namespace: 'RXR_Data',
                includePath: false
            },
            src: ['common/data/app.json', 'common/data/resource_directory.json'],
            dest: 'common/_temp/app_json.js'
        }
    },
    uglify: {
        options: {
            mangle: false,
            sourceMap: false
        },
        vet_libs: {
            files: {
                'veteran/_build/js/libs.js': asset.libs
            }
        },
        veteran: {
            files: {
                'veteran/_build/js/app.js': asset.veteran
            }
        }
    },
    watch: {
        template: {
            files: ["common/js/template/*.html", "veteran/js/template/*.html"],
            tasks: ['handlebars']
        },
        veteran: {
            files: asset.veteran,
            tasks: ['uglify:veteran']
        },
        scss: {
            files: 'common/sass/**/*',
            tasks: 'sass'
        }
    },
    clean: {
      build: {
        src: ['veteran/_build/*']
      },
      all: {
          src: ['veteran/_build/*', 'node_modules','bower_components']
      }
    },
    copy: {
      veteran_build: {
        files: [
          {src:'veteran/index.html', dest: 'veteran/_build/index.html'},
          {expand: true, flatten: true, src:'veteran/css/*', dest:'veteran/_build/css/'},
          {expand: true, flatten: true, src:'veteran/font/*', dest:'veteran/_build/fonts/'},
          {expand: true, flatten: true, src:'veteran/img/*', dest:'veteran/_build/img/'},
          {expand: true, flatten: true, src:'veteran/js/*', dest:'veteran/_build/js/'},
          {expand: true, flatten: true, src:'common/data/*', dest:'veteran/_build/'},
          {expand: true, flatten: true, src:'bower_components/bootstrap/fonts/*', dest:'veteran/_build/fonts/'},
          {src:'bower_components/bootstrap/dist/css/bootstrap.css.map', dest:'veteran/_build/css/bootstrap.css.map'}
        ]
      }
    },
    war: {
        build_veteran_war: {
            options: {
                war_name: "<%= pkg.name %>-veteran",
                war_dist_folder: "veteran/_build",
                webxml_welcome: "index.html",
                webxml_display_name: "Rx Refill"
            },
            files: [{
                expand: true,
                cwd: 'veteran/_build',
                src: ['index.html', 'css/*', 'js/*', 'img/*', '*.json'],
                dest: ''
            }]
        }
    },
    jasmine: {
        anonymous: {
            src: [
                'veteran/_build/js/libs.js',
                'veteran/_build/js/app.js'
            ],
            options: {
                '--web-security': false,
                '--local-to-remote-url-access': true,
                '--ignore-ssl-errors': true,
                specs: ['common/js/test/base.js','common/js/test/anonymous.js'],
                vendor: [
                    'bower_components/modernizr/modernizr.js',
                    'bower_components/jquery/dist/jquery.min.js',
                    'bower_components/bootstrap/dist/js/bootstrap.min.js',
                    'bower_components/underscore/underscore.js',
                    'bower_components/backbone/backbone.js',
                    'bower_components/marionette/lib/backbone.marionette.min.js',
                    'bower_components/handlebars/handlebars.js',
                    'bower_components/jasmine-jquery/lib/jasmine-jquery.js',
                    'bower_components/sinonjs/sinon.js',
                    'bower_components/jasmine-sinon/lib/jasmine-sinon.js'
                ],
                host: 'http://localhost:5000',
                styles: [
                    'veteran/_build/css/*.css'
                ],
                keepRunner: true
            }
        },
        authenticated: {
            src: [
                'veteran/_build/js/libs.js',
                'veteran/_build/js/app.js'
            ],
            options: {
                '--web-security': false,
                '--local-to-remote-url-access': true,
                '--ignore-ssl-errors': true,
                specs: ['common/js/test/base.js','common/js/test/authenticated.js'],
                vendor: [
                    'bower_components/modernizr/modernizr.js',
                    'bower_components/jquery/dist/jquery.min.js',
                    'bower_components/bootstrap/dist/js/bootstrap.min.js',
                    'bower_components/underscore/underscore.js',
                    'bower_components/backbone/backbone.js',
                    'bower_components/marionette/lib/backbone.marionette.min.js',
                    'bower_components/handlebars/handlebars.js',
                    'bower_components/jasmine-jquery/lib/jasmine-jquery.js',
                    'bower_components/sinonjs/sinon.js',
                    'bower_components/jasmine-sinon/lib/jasmine-sinon.js'
                ],
                host: 'http://localhost:5000',
                styles: [
                    'veteran/_build/css/*.css'
                ],
                keepRunner: true
            }
        }
    }
  });

  // Load grunt plugins.
  grunt.loadNpmTasks('grunt-war');
  grunt.loadNpmTasks('grunt-json');
  grunt.loadNpmTasks('grunt-bower');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-concat');
  grunt.loadNpmTasks('grunt-contrib-connect');
  grunt.loadNpmTasks('grunt-contrib-handlebars');
  grunt.loadNpmTasks('grunt-contrib-jasmine');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-uglify');

  // Default task(s).
    //ex: grunt test:token
  grunt.registerTask('test', function (value) {
      if (!value) {
          grunt.task.run('build', 'connect:test', 'jasmine:anonymous');
      }
      else {
          grunt.task.run('build', 'writeConfig:token:' + value, 'connect:test', 'jasmine:authenticated');
      }
  });
    //cleans out the node package manager and bower components directories so that a new clean build can be completed
    //after running type npm install then bower install to reload the project's dependencies
    grunt.registerTask('refresh_build_setup', ['clean:all']);
    grunt.registerTask('configuration_dev', ['app_config:vet:false']);
    grunt.registerTask('configuration_prod', ['app_config:vet:true']);
    grunt.registerTask('build', ['clean:build', 'copy', 'concat', 'sass', 'handlebars', 'json', 'uglify']);
    grunt.registerTask('dev', ['configuration_dev','build', 'connect:veteran', 'watch']);
    grunt.registerTask('war_build', ['updateAppData', 'build', 'war']);
    grunt.registerTask('war_build_dev', ['configuration_dev', 'updateAppData', 'build', 'war']);
    grunt.registerTask('war_build_release', ['configuration_prod', 'updateAppData', 'build', 'war']);
    grunt.registerTask('writeConfig', 'Write to config file', function (key, value) {
      var projectFile = "common/js/test/fixtures/config.json";
      if (!grunt.file.exists(projectFile)) {
          grunt.log.error("file " + projectFile + " not found");
          return true;//return false to abort the execution
      }
      var project = grunt.file.readJSON(projectFile);
      //grunt.log.write(project.token)
      project[key] = value;
      grunt.file.write(projectFile, JSON.stringify(project, null, 2));
    });
  grunt.registerTask('updateAppData', function () {
      var projectFile = "common/data/app.json";
      if (!grunt.file.exists(projectFile)) {
          grunt.log.error("file " + projectFile + " not found");
          return true;//return false to abort the execution
      }
      var project = grunt.file.readJSON(projectFile);
      project['last-update-date'] = grunt.template.today("mm/dd/yy");
      grunt.file.write(projectFile, JSON.stringify(project, null, 2));
  });
    // App Update config
    grunt.registerTask('app_config', function (type, prod) {
        var jsonFile = "common/data/app.json";
        if (!grunt.file.exists(jsonFile)) {
            grunt.log.error("file " + jsonFile + " not found");
            return true;//return false to abort the execution
        }
        var json = grunt.file.readJSON(jsonFile);
        //json['last-update-date'] = grunt.template.today("mm/dd/yy");
        json['appConfig'].veteran = (type === "vet") ? true : false;
        json['appConfig'].provider = (type === "pro") ? true : false;
        json['appConfig'].cordova = (type === "cor") ? true : false;
        json['appConfig'].prod = (prod === "true") ? true : false;
        grunt.file.write(jsonFile, JSON.stringify(json, null, 2));
        //grunt.file.write('common/_temp/app.json', JSON.stringify(json, null, 2));
    });

};
