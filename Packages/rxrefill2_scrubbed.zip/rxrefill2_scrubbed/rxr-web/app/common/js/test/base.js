﻿window.RXR = window.RXR || {};
//this loads fixtures from a fixtures folder
//relative to where SpecRunner.html lives
jasmine.getFixtures().fixturesPath = 'common/js/test/fixtures/';

jasmine.getJSONFixtures().fixturesPath = 'common/js/test/fixtures/';

//var jasmineEnv = jasmine.getEnv();

//jasmineEnv.updateInterval = 1000;

//container-fluid were our app lives
setFixtures(sandbox({
    id: 'container',
    class: 'container-fluid hidden'
}));

/*------------------------------------------------------------------------------
 Note to Unit Test Developer:

 Two session tokens are required to be set within the test\fixtures\config.json file
 before running any tests!!!

 Log into RXRefill via Launchpad and open up the console window:

     window.sessionStorage.token = "token"
     window.sessionStorage.mhvToken = "mhvToken"

 After populating these values into the config.json file, you will only have 15 minutes
 to run your tests.
------------------------------------------------------------------------------- */
var config = getJSONFixture('config.json');

App_Utils.SetSessionToken("token", config['token']);
App_Utils.SetSessionToken("mhvToken", config['mhvToken']);

//Set an var for container
var container = $("#container");
//Everything should be ready to start that badboy
//App.start();

//Turn off debug option so final operations are called
App.debug = false;

function isEmpty(el) {
    return !$.trim(el.html())
}

RXR.Layout = new RXR.View.layout();
RXR.Layout.render();
RXR.Layout.header.show(RXR.View.Header = new RXR.View.header());
RXR.Layout.footer.show(new RXR.View.footer());
App.route = new RXR.Router();
Backbone.history.start();

App.loadResource = function () {
    var ready = 0;
    var readyCheck = function () {
        if (ready === 3) { // set to 3
            App.vent.trigger('resource:loaded');
        }
    };
    var successMustStart = function () {
        RXR_Data.HAResources = new RXR.Collection.HAResources();
        RXR_Data.HAResources.fetch({ success: successHandler });

        RXR_Data.MILResources = new RXR.Collection.MILResources();
        RXR_Data.MILResources.fetch({ success: successHandler });

        RXR_Data.RXRResources = new RXR.Collection.RXRResources();
        RXR_Data.RXRResources.fetch({ success: successHandler });
    };
    var successHandler = function (collection, response, options) {
        ready++;
        readyCheck();
    };
    RXR_Data.AppResources = new App_Resources.Collection.AppResources(RXR_Data.resource_directory.links);
    successMustStart();

};

var resourcesLoaded = false;
beforeEach(function (done) {
    App.vent.on('resource:loaded', function () {
        resourcesLoaded = true;
        done();
    });

    if (!resourcesLoaded) {
        App.loadResource();
    }
    else { done();}
});
    
describe("RXR", function () {
    describe("Object", function () {    
        it('RXR should be defined', function () {
            expect(window.RXR).toBeDefined();
        });
        it('Main Container should exist', function () {
            expect(container).toHaveClass('container-fluid');
        });
    });
    describe("User Authenticated", function() {
        it ('The token from the browser', function() {
            var myToken = App_Utils.GetSessionToken('token');
            //expect(myToken).toBeDefined();
            expect(myToken).toEqual(jasmine.anything());
        });

    });
    describe("Right of Access", function() {
        var roaLoaded = false;
        beforeEach(function() {
            App.vent.on('roa:accepted', function() {
                roaLoaded = true;
            });
        });

        it ("Right Of Access accepted event called", function() {
            //App.vent.trigger('load:user', {reset:true, init: false });
            App_Utils.RightOfAccess();
            // this will always work in debug mode
            expect(roaLoaded).toBeTruthy();
        });
    });
    describe("RXR-1089", function () {
        RXR.Layout.modal.show(RXR.View.EulaModal = new RXR.View.eulaModal());
        describe("No Eula localStorage set", function () {
            eulaShown = false;
            beforeEach(function (done) {
                App_Utils.DeleteLocalStorage('RXR_Eula');
                App.vent.on('eula:shown', function () {
                    eulaShown = true;
                    done();
                });
                if (_.isNull(App_Utils.GetLocalStorage('RXR_Eula'))) {
                    RXR.View.EulaModal.show();
                }
            });
            it('Eula should be shown if no local storage key is found', function () {
                expect(eulaShown).toBe(true);
            });
        });
        describe("Eula localStorage set", function () {
            eulaShown = false;
            beforeEach(function (done) {
                App_Utils.SetLocalStorage('RXR_Eula', { accept_date: new Date().getTime() });
                if (_.isNull(App_Utils.GetLocalStorage('RXR_Eula'))) {
                    eulaShown = true;
                    done();
                }
                else { eulaShown = false; done();}
            });
            it('Eula should not be shown if local storage key is found', function () {
                expect(eulaShown).toBe(false);
            });
        });
        describe("Setting Eula", function () {
            beforeEach(function (done) {
                eulaExists = false;
                App_Utils.DeleteLocalStorage('RXR_Eula');
                App_Utils.SetLocalStorage('RXR_Eula', { accept_date: new Date().getTime() });
                if (_.isNull(App_Utils.GetLocalStorage('RXR_Eula'))) {
                    eulaExists = false;
                    done();
                }
                else { eulaExists = true; done(); }
            });
            it('Eula should set', function () {
                expect(eulaExists).toBe(true);
            });
        });
        describe("Deleting Eula", function () {
            beforeEach(function (done) {
                eulaExists = true;
                App_Utils.SetLocalStorage('RXR_Eula', { accept_date: new Date().getTime() });
                App_Utils.DeleteLocalStorage('RXR_Eula');             
                if (_.isNull(App_Utils.GetLocalStorage('RXR_Eula'))) {
                    eulaExists = false;
                    done();
                }
                else { eulaExists = true; done(); }
            });
            it('Eula should set', function () {
                expect(eulaExists).toBe(false);
            });
        });
    });   
    describe("RXR-1014", function () {
        var errorShown = false;        
        beforeEach(function (done) {
            if (errorShown) { done(); }
            App.vent.on('error:shown', function (data) {
                done();
                errorShown = true;
            });
        });
        it('Error Header should be displayed when error is thrown', function () {
            App.vent.trigger('website:error', "test");
            var length = container.find("#errorBanner").children("ul").children().length;
            expect(length > 0).toBe(true);
        });
    });

    describe("Links view", function() {
        var myLinkView = new RXR.View.Links();

        beforeEach(function(done) {
            spyOn(myLinkView, 'render').and.callThrough();
            myLinkView = new RXR.View.Links();
            $('#test-append').html(myLinkView.render().$el);
            done();
        });

        it("Link view should be defined", function() {
          expect(myLinkView).toBeDefined();
        });

        it("Does the view contain a link for My Complete Medication List (RXR-568)", function() {
            expect($('#test-append a[href="https://www.dmaindomain.ext/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=faqsHome#MHVMeds"').length).toBe(1);
        });

        it("Does the view contain a link for Blue Button Download (RXR-569)", function() {
            expect($('#test-append a[href="https://www.dmaindomain.ext/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=faqsHome#BlueButton"').length).toBe(1);
        });

        it("Does the view contain a link for Health Summary (VA Continuity of Care Document (CCD)) (RXR-570)", function() {
            expect($('#test-append a[href="https://www.dmaindomain.ext/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=faqsHome#CCD"').length).toBe(1);
        });
    });

    /*
    describe("RXR-553", function() {
        var history = false;
        var detailID;
        beforeEach(function (done) {
            RXR.Layout.content.show(new RXR.View.RxHistory);
            App.vent.on('history:loaded', function () {
                history = true;
                detailID = RXR.Data.View.RxHistory.items[0].prescriptionId;
                done();
            });
            App.vent.on('history:failed', function () {
                history = false;
                done();
            });
            App.vent.trigger('enterpriseSession:loaded', { init: true });
        });

        it("Prescription Detail loaded", function() {
            expect(RXR.Data.View.RxHistory.items).toBeDefined();
            expect(detailID).toBeDefined();
            // first populate the history grid
            //$('#test-append').html(RXR.Template.RxHistory(RXR.Data.View.RxHistory));
            // next get the first hyperlink and split it into an array
            //var detailHref = $('.med-container a')[0].href.split('/');
            //console.log("detailHref", detailHref);


            //expect(detailHref.length).toBeGreaterThan(0);
            //var detailId = detailHref[detailHref.length - 1];
            //console.log("detailId: " + detailId);

            // while the view data is still in memory load detail page

            $('#test-append').html(new RXR.View.RxDetail({id:detailID}).render().$el);
            //console.log("html:" + $('#test-append').html());
            expect($('#' + detailID).length).toEqual(1);
        });
    });
*/
});







