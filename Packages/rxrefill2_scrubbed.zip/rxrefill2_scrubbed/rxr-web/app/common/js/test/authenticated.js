﻿function getMHVSession() {
    var x = new RXR.Model.session();
    x.fetch({
        success: function (model, response) {
            //Enterprise Session Token lets store in sessionStorage
            console.log('session fetch successful', response);
            App_Utils.SetSessionToken('mhvToken', response.token);
            return response.token;
        },
        error: function (model, response) {
            console.log("session error response:", response);
            return null;
        }
    });
};

function LoadResources() {
    console.log("in LoadResources...")
    var ready = 0;

    var readyCheck = function () {
        ready++;
        console.log("in readycheck..." + ready);
        if (ready === 3) {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = 30000;
            App.vent.trigger('test_resources:loaded');
            RXR.Layout.header.show(RXR.View.Header = new RXR.View.header());
            RXR.Layout.footer.show(new RXR.View.footer());
        }
    };
    var successMustStart = function () {
        RXR_Data.HAResources = new RXR.Collection.HAResources();
        RXR_Data.HAResources.fetch({ success: successHandler });

        RXR_Data.MILResources = new RXR.Collection.MILResources();
        RXR_Data.MILResources.fetch({ success: successHandler });

        RXR_Data.RXRResources = new RXR.Collection.RXRResources();
        RXR_Data.RXRResources.fetch({ success: successHandler });
    };
    var successHandler = function (collection, response, options) {
        readyCheck();
    };
    RXR_Data.AppResources = new App_Resources.Collection.AppResources(RXR_Data.resource_directory.links);
    successMustStart();
}


describe("Authenticated", function () {
    var resourcesLoaded = false;

    beforeEach(function (done) {
        App.vent.on('resource:loaded', function () {
            resourcesLoaded = true;
            done();
        });

        if (!resourcesLoaded) {
            App.loadResource();
            //LoadResources();
        }
        else { done();}
    });


    describe("Resources Loaded", function () {

        it('Resource Files are successfully loaded', function () {
            expect(resourcesLoaded).toBe(true);
        });

    });

    describe("Eula Accepted", function () {
        //jasmine.DEFAULT_TIMEOUT_INTERVAL = 80000;
        beforeEach(function (done) {
            App_Utils.DeleteLocalStorage('RXR_Eula');
            App.vent.on('eula:shown', function () {
                App_Utils.SetLocalStorage('RXR_Eula', { accept_date: new Date().getTime() });
                RXR.View.EulaModal.hide();
                done();
            });
            App.vent.on('eula:hidden', function () {
                RXR.Layout.header.show(RXR.View.header = new RXR.View.Header());
                RXR.Layout.footer.show(new RXR.View.footer());
                RXR.Router = new RXR.Router();
                Backbone.history.start();
                done();
            });
            App.checkEula();
        });
        it('Eula should be set', function () {
            expect(App_Utils.GetLocalStorage('RXR_Eula')).not.toEqual(null);
        });
    });
    describe("RXR-694", function () {
        var user = {};
        //var roa = {};
        var userLoaded = false;
        //jasmine.DEFAULT_TIMEOUT_INTERVAL = 20000;
        App_Utils.SetRequestHeader();

        beforeEach(function (done) {
            //Set Authorize Request header
            //setTimeout(App_Utils.SetRequestHeader, 0);

            //Trigger event to load user
            //App.vent.trigger('load:user', { reset: true });
            
            if (userLoaded) { done(); }
            App.vent.on('user:loaded', function () {
                console.log("user loaded event");
                userLoaded = true;
                user = RXR.Model.User.toJSON();
                //roa = RXR.Model.ROA.toJSON();
                done();
            });
            App.vent.on('user:failed', function () { done(); });
            App.vent.trigger('load:user', { reset: true, init: true });
        });
        it('Users object should contain mhpuser', function () {
            expect(user.mhpuser).toHaveData();
        });

        //it ('ROA object should contain rightOfAccessAccepted', function() {
        //    expect(roa.rightOfAccessAccepted).toHaveData();
        //});

    });
    describe("RXR-696", function () {
        describe("Get Last Accessed Time", function () {
            var latLoaded = false;
            beforeEach(function (done) {
                if (latLoaded) { done(); }
                App.vent.on('lastAccessedTime:success', function () {
                    latLoaded = true;
                    done();
                });
                App.vent.on('lastAccessedTime:failed', function () { done(); });
            });
            it('Last Accessed Time fetch should succeed', function () {
                expect(latLoaded).toBe(true);
            });
        });
        describe("Modal should be present if 180 seconds remain", function () {
            var modalLoaded = false;
            beforeEach(function (done) {
                if (modalLoaded) { done(); }
                App.vent.on('keepaAlive:started', function () {
                    App.KeepAliveCount = 0;
                    App.KeepAliveTimeLeft = 150;
                    App.vent.on('timeoutModal:visible', function () {
                        modalLoaded = true;
                        done();
                    });
                });
                App.vent.trigger('load:user', { init: true });
            });
            it('Timeout Modal should be loaded', function () {
                expect(modalLoaded).toBe(true);
                App.KeepAliveCount = 170;
                App.KeepAliveTimeLeft = 900;
            });
        });
    });
    describe("Enterprise Session loaded", function () {
        var enterpriseSession = false;
        beforeEach(function (done) {
            App.vent.on('enterpriseSession:loaded', function () {
                enterpriseSession = true;
                done();
            });
            App.vent.on('enterpriseSession:failed', function () {
                enterpriseSession = false;
                done();
            });
            App.vent.trigger('load:user', { init: true });
        });
        it('Request should return a value', function () {
            expect(enterpriseSession).toBe(true);
        });
    });


    describe("RXR-551", function () {
        var detailID = null;
        var history = false;
        var detail = false;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 80000;
        beforeEach(function (done) {
            RXR.Layout.content.show(new RXR.View.RxHistory);
            App.vent.on('history:loaded', function () {
                history = true;
                detailID = RXR.Data.View.RxHistory.items[0].prescriptionId;

                RXR.Layout.content.show(new RXR.View.RxDetail({ id: detailID }));
                done();
            });
            App.vent.on('history:failed', function () {
                history = false;
                done();
            });
            App.vent.on('imageDetails:loaded', function () {
                detail = true;
                done();
            });
            App.vent.trigger('enterpriseSession:loaded', { init: true });
        });
        it('Rx History should return data', function () {
            expect(history).toBe(true);
        });

        it('Rx History Detail should return data', function () {
            expect(detail).toBe(true);
        });
    });

    describe("RXR-552", function () {
        var detailID = null;
        var detail = false;
        beforeEach(function (done) {
            RXR.Layout.content.show(new RXR.View.RxDetail({ id: detailID }));
            done();
            App.vent.on('imageDetails:loaded', function () {
                detail = true;
                done();
            });
            //App.vent.on('history:failed', function () {
            //    detail = false;
            //    done();
            //});
            //App.vent.trigger('enterpriseSession:loaded', { init: true });
        });
        it('Rx History Detail should return data', function () {
            //var div = container.find("#" + detailID);
            expect(detail).toBe(true);
        });
    });


    describe("Track Delivery and Details", function () {
        var myView;
        var tracks = false;
        var imageShown = false;
        var trackingID;

        beforeEach(function (done) {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = 500000;

            App.vent.on('rxtracking:loaded', function() {
                console.log("rx tracking loaded called");
                tracks = true;
                trackingID = RXR.Data.View.RxTracking.items[0].prescriptionId;
                done();
            });

            App.vent.on('imageDetailsImage:loaded', function() {
                imageShown = true;
                done();
            });

            myView = new RXR.View.RxTracking();
            RXR.Layout.content.show(myView);

            App.vent.trigger('enterpriseSession:loaded', { init: true });
        });

        it('Tracking Delivery returned data', function() {
            expect(tracks).toBe(true);
            expect(RXR.Data.View.RxTracking.items).toBeDefined();
        });

        it("Tracking grid populated with all records", function() {
            $('#test-append').html(RXR.Template.RxTrackingList(RXR.Data.View.RxTracking));
            expect($('#test-append .med-container').length).toEqual(RXR.Data.View.RxTracking.items.length);
        });

        it("RXR-548 - Tracking Detail loaded", function() {
            expect(trackingID).toBeDefined();

            $('#test-append').html(new RXR.View.RxTrackingDetail({id:trackingID}).render().$el);
            // check template field
            expect($('#' + trackingID).length).toEqual(1);
        });

         it("RXR-1015 - Display prescription image is shown", function() {
             jasmine.DEFAULT_TIMEOUT_INTERVAL = 500000;
             expect(trackingID).toBeDefined();
             $('#test-append').html(new RXR.View.RxTrackingDetail({id:trackingID}).render().$el);

             App.vent.on('rxtracking:loaded', function() {
                 console.log($('#test-append').html());
                 // add click event here
                 $('#test-append .viewImageLink').trigger('click');
                 expect(imageShown).toBe(true);
             });
         });

        it("RXR-1016 - Image disclaimer shown", function() {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = 500000;
            expect(trackingID).toBeDefined();
            $('#test-append').html(new RXR.View.RxTrackingDetail({id:trackingID}).render().$el);

            App.vent.on('rxtracking:loaded', function() {
                console.log($('#test-append').html());
                // add click event here
                $('#test-append .viewImageLink').trigger('click');
                expect(imageShown).toBe(true);

                expect($('#image-modal p').html()).toBe("The image displayed is for identification purposes only and does not mean that it is the dose to be taken. If the medication image shown does not match what you are taking please contact your VA Pharmacy.");
            });
        });
    });

    describe("RXR-1018 - Refillable Medications", function() {
        var listLoaded = false;
        var myView;
        var detailID;

        beforeEach(function(done) {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = 250000;
            if (window.sessionStorage.token == "null") {
                App_Utils.SetSessionToken("token", config['token']);
            }

            App.vent.on('rxlist:loaded', function () {
                listLoaded = true;
                detailID = RXR.Data.View.RxList.items[0].prescriptionId;
                done();
            });

            myView = new RXR.View.RxList();
            RXR.Layout.content.show(myView);
            App.vent.trigger('enterpriseSession:loaded', { init: true });
        });

        it('Refillable Medications should return data', function () {
            expect(listLoaded).toBe(true);
            expect(RXR.Data.View.RxList.items).toBeDefined();
        });

        it("Refillable Medications grid populated with all records", function() {
            $('#test-append').html(RXR.Template.RxList(RXR.Data.View.RxList));
            expect($('#test-append .med-container').length).toEqual(RXR.Data.View.RxList.items.length);
        });

        it("Refillable Medications Detail loaded", function() {
            expect(detailID).toBeDefined();

            $('#test-append').html(new RXR.View.RxRefillDetail({id:detailID}).render().$el);
            // check template field
            expect($('#' + detailID).length).toEqual(1);
        });


    });

    describe("RXR-551, RXR-552, RXR-553 - History View and Details", function () {
        var history = false;
        var myView;
        var detailID;

        beforeEach(function (done) {
            jasmine.DEFAULT_TIMEOUT_INTERVAL = 250000;
            myView = new RXR.View.RxHistory();
            RXR.Layout.content.show(myView);

            App.vent.on('history:loaded', function () {
                console.log("history loaded");
                history = true;
                detailID = RXR.Data.View.RxHistory.items[0].prescriptionId;
                done();
            });
            App.vent.on('history:failed', function () {
                console.log("history failed");
                history = false;
                done();
            });

            App.vent.trigger('enterpriseSession:loaded', { init: true });
        });
        it('Rx History should return data', function () {
            console.log("in unit test");
            expect(history).toBe(true);
            expect(RXR.Data.View.RxHistory.items).toBeDefined();
        });

        it("History grid populated with all records", function() {
            $('#test-append').html(RXR.Template.RxHistory(RXR.Data.View.RxHistory));
            expect($('#test-append .med-container').length).toEqual(RXR.Data.View.RxHistory.items.length);
        });

        it("Match first hyperlink with what is in the data", function() {
            expect(detailID).toBeDefined();

            // first populate the history grid
            //$('#test-append').html(RXR.Template.RxHistory(RXR.Data.View.RxHistory));
            $("#test-append").html(myView.render().$el);
            // next get the first hyperlink and split it into an array
            var detailHref = $('.med-container a')[0].href.split('/');

            expect(detailHref.length).toBeGreaterThan(0);
            var detailHrefID = detailHref[detailHref.length - 1];

            // while the view data is still in memory load detail page
            expect(detailID.toString()).toEqual(detailHrefID.toString());
        });

        describe("History Sort functionality", function() {
            var sortValue = [];
            var firstEntry;
            beforeEach(function() {
                $("#test-append").html(myView.render().$el);
            });

            it("Checking Prescription sort", function() {
                sortValue = [];
                for (var i = 0; i < RXR.Data.View.RxHistory.items.length; i++) {
                    sortValue.push(RXR.Data.View.RxHistory.items[i].prescriptionName);
                }

                expect(sortValue.length).toBeGreaterThan(0);

                // sort ascending, verify 1st entry matches
                $('#test-append #sortMenu a[data-sort="prescriptionName"][data-asc="true"]').trigger('click');
                sortValue.sort();

                // first populate the history grid
                firstEntry = $('.med-container').attr("data-prescriptionname");

                // only check the first entry
                expect(firstEntry).toEqual(sortValue[0]);

                // check the reverse order
                sortValue.reverse();
                $('#test-append #sortMenu a[data-sort="prescriptionName"][data-asc="false"]').trigger('click');

                // only check the first entry
                firstEntry = $('.med-container').attr("data-prescriptionname");
                expect(firstEntry).toEqual(sortValue[0]);
            });

            it("Checking Facility sort", function() {
                sortValue = [];

                for (var i = 0; i < RXR.Data.View.RxHistory.items.length; i++) {
                    sortValue.push(RXR.Data.View.RxHistory.items[i].facilityName);
                }
                expect(sortValue.length).toBeGreaterThan(0);

                // sort ascending, verify 1st entry matches
                $('#test-append #sortMenu a[data-sort="facilityName"][data-asc="true"]').trigger('click');
                sortValue.sort();

                // first populate the history grid
                firstEntry = $('.med-container').attr("data-facilityname");

                // only check the first entry
                expect(firstEntry).toEqual(sortValue[0]);

                // check the reverse order
                sortValue.reverse();
                $('#test-append #sortMenu a[data-sort="facilityName"][data-asc="false"]').trigger('click');

                // only check the first entry
                firstEntry = $('.med-container').attr("data-facilityname");
                expect(firstEntry).toEqual(sortValue[0]);
            });

            it("Checking Status sort", function() {
                sortValue = [];

                for (var i = 0; i < RXR.Data.View.RxHistory.items.length; i++) {
                    sortValue.push(RXR.Data.View.RxHistory.items[i].refillStatus);
                }
                expect(sortValue.length).toBeGreaterThan(0);

                // sort ascending, verify 1st entry matches
                $('#test-append #sortMenu a[data-sort="refillStatus"][data-asc="true"]').trigger('click');
                sortValue.sort();
                firstEntry = $('.med-container').attr("data-refillstatus");

                // only check the first entry
                expect(firstEntry).toEqual(sortValue[0]);

                // check the reverse order
                sortValue.reverse();
                $('#test-append #sortMenu a[data-sort="refillStatus"][data-asc="false"]').trigger('click');

                // only check the first entry
                firstEntry = $('.med-container').attr("data-refillstatus");
                expect(firstEntry).toEqual(sortValue[0]);
            });

        });

        it("Prescription Detail loaded", function() {
            expect(RXR.Data.View.RxHistory.items).toBeDefined();
            expect(detailID).toBeDefined();

            $('#test-append').html(new RXR.View.RxDetail({id:detailID}).render().$el);
            // check template field
            expect($('#' + detailID).length).toEqual(1);
        });
    });

});