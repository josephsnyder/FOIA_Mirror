﻿describe("Anonymous", function () {
    describe("RXR-694, RXR-695", function () {
        var cleanupComplete, tokenDeleted, cookieExists = false;
        beforeEach(function (done) {
            if (cleanupComplete) { done(); }               
            App.vent.on('AppCleanup:complete', function () {
                tokenDeleted = (App_Utils.GetSessionToken() == null);
                cookieExists = App_Utils.CookieExists('JSESSIONID');
                cleanupComplete = true;
                done();
            });
            App_Utils.AppCleanup();
        });
        it('User is not Authenticated sessionStorage token should be null', function () {
            expect(App_Utils.GetSessionToken()).toBe(null);
        });
        it('Token should not exist', function () {
            expect(tokenDeleted).toBe(true);
        });
        it('Cookie should not exist', function () {
            expect(cookieExists).toBe(false);
        });
    });

    describe("RXR-1131", function() {
        var myHeader;

        beforeEach(function() {
            myHeader = new RXR.View.header()
        });

        it("verify custom method 'logout' exists", function() {
            expect(myHeader.logout).toBeDefined();
        });

        it("verify App_Utils is defined", function() {
            expect(App_Utils).toBeDefined();
        });

        /*
        it("call logout, make sure logout utility is called", function() {
            spyOn(App_Utils, 'LaunchpadLogout');
            myHeader.logout();
            expect(App_Utils.LaunchpadLogout).toHaveBeenCalled();
        });
        */

    });

});







