RXR.Collection.RXRResources = Backbone.Collection.extend({
    key : 'resource-directory-rxr',
    model : App_Resources.Model.HateoasResource,
    url: function () {
        return App_Utils.GetDomainPath() + RXR_Data.AppResources.get('resource-directory-rxr').toJSON().href;
    },
    parse: function (response) {
        return response.links;
    }
});