RXR.Collection.MILResources = Backbone.Collection.extend({
    key : 'resource-directory-mil',
    model : App_Resources.Model.HateoasResource,
    url: function () {
        return App_Utils.GetDomainPath() + RXR_Data.AppResources.get('resource-directory-mil').toJSON().href;
    },
    parse: function (response) {
        return response.links;
    }
});