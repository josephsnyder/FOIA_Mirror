RXR.Collection.RxHistory = Backbone.Collection.extend({
    key: 'Rx History',
    model: RXR.Model.RxHistory,
    sortField: 'refillDate',
    sortDirection: 0,
    url: function () {
        return RXR_Data.RXRResources.get('historic').toJSON().href;
    },
    parse: function (response) {
        if (response.prescriptionList == null)
            return [];
        else
            return response.prescriptionList;
    },
    comparator: function(a, b) {
        var x, y;
        if(this.sortField === 'refillDate') {
            x = new Date(a.get('refillDate')).toISOString();
            y = new Date(b.get('refillDate')).toISOString();
            //x = Date.parse(a.get('refillDate'));
            //y = Date.parse(b.get('refillDate'));
        }
        else if(this.sortField === 'refillSubmitDate') {
            x = new Date(a.get('refillSubmitDate')).toISOString();
            y = new Date(b.get('refillSubmitDate')).toISOString();
            //x = Date.parse(a.get('refillSubmitDate'));
            //y = Date.parse(b.get('refillSubmitDate'));
        }
        else {
            x = a.get(this.sortField);
            y = b.get(this.sortField);
        }

        if(x == y) return 0;

        if (this.sortDirection === 1) {
            return x > y ? 1 : -1;
        } else {
            return x < y ? 1 : -1;
        }

    }
});

