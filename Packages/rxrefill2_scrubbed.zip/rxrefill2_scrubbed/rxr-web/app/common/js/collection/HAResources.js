RXR.Collection.HAResources = Backbone.Collection.extend({
    key : 'resource-directory-ha',
    model : App_Resources.Model.AtomResource,
    url: function () {
        return App_Utils.GetDomainPath() + RXR_Data.AppResources.get('resource-directory-ha').toJSON().href;
    },
    parse: function (response) {
        return response.link;
    }
});