RXR.Collection.RxList = Backbone.Collection.extend({
    key: 'Rx List',
    model: RXR.Model.RxList,
    sortField: 'prescriptionName',
    sortDirection: 1,    
    url: function () {
        return RXR_Data.RXRResources.get('refillable').toJSON().href;
    },
    parse: function (response) {
        if (response.prescriptionList == null)
            return [];
        else
            return response.prescriptionList;
    },
    comparator: function(a, b) {
        var x, y;
        if(this.sortField === 'orderedDate') {
            x = Date.parse(a.get('orderedDate'));
            y = Date.parse(b.get('orderedDate'));
        } else if(this.sortField === 'refillDate') {
            x = Date.parse(a.get('refillDate'));
            y = Date.parse(b.get('refillDate'));
        } else if(this.sortField === 'dispensedDate') {
            x = Date.parse(a.get('dispensedDate'));
            y = Date.parse(b.get('dispensedDate'));
        }
        else {
            x = a.get(this.sortField);
            y = b.get(this.sortField);
        }

        if(x == y) return 0;

        if (this.sortDirection === 1) {
            return x > y ? 1 : -1;
        } else {
            return x < y ? 1 : -1;
        }

    }
});
