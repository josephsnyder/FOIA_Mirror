//RXR.Collection.RxTracking = Backbone.Collection.extend({
//    url: function () { RXR_Data.RXRResources.get('tracking').toJSON().href; },
//    model : RXR.Model.RxTracking,
//    initialize: function () {
//        this.on("sync", this.unwrap);
//    },
//    /**
//    * The service does not return an array, as a true collection should. Instead
//    * it is wrapped inside of a prescriptionList key. We need to unwrap it.
//    */
//    unwrap: function (collection) {
//        var models = collection.at(0).get('prescriptionList');
//        if (models) {
//            collection.reset(models);
//        }
//    }
//});
RXR.Collection.RxTracking = Backbone.Collection.extend({
    key: 'Rx Tracking',
    model: RXR.Model.RxTracking,
    sortField: 'refillDate',
    sortDirection: 0,
    url: function () {
        return RXR_Data.RXRResources.get('tracking').toJSON().href;
    },
    parse: function (response) {
        if (response.prescriptionList == null)
            return [];
        else
            return response.prescriptionList;
    },
    comparator: function(a, b) {
        var x, y;
        if(this.sortField === 'orderedDate') {
            x = Date.parse(a.get('orderedDate'));
            y = Date.parse(b.get('orderedDate'));
        } else if(this.sortField === 'refillDate') {
            x = Date.parse(a.get('refillDate'));
            y = Date.parse(b.get('refillDate'));
        } else if(this.sortField === 'dispensedDate') {
            x = Date.parse(a.get('dispensedDate'));
            y = Date.parse(b.get('dispensedDate'));
        }
        else {
            x = a.get(this.sortField);
            y = b.get(this.sortField);
        }

        if(x == y) return 0;

        if (this.sortDirection === 1) {
            return x > y ? 1 : -1;
        } else {
            return x < y ? 1 : -1;
        }

    }
});