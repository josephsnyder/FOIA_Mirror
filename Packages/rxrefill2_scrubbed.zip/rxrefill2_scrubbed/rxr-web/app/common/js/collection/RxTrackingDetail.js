RXR.Collection.RxTrackingDetail = Backbone.Collection.extend({
    key: 'Rx Tracking',
    model: RXR.Model.RxTrackingDetail,
    initialize: function (options) {
        this.url = function () {
            return RXR_Data.RXRResources.get('trackingdetail').toJSON().href.replace("{rxId}", options.id);
        }
    }
});