RXR.Model.session = Backbone.Model.extend({
    key:"Enterprise Session",
    defaults: {
        token: '',
        expiresDate: ''
    },    
    url: function () {
        var userIdentifier = RXR.Model.User.attributes.mhpuser.userIdentifier;
        var url = RXR_Data.RXRResources.get("session").toJSON().href.replace("{assigning-authority}", userIdentifier.assigningAuthority).replace("{patient-id}", userIdentifier.uniqueId);
        return url;
    }
});