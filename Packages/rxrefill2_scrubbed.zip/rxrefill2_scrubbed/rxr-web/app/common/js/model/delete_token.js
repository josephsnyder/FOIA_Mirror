RXR.Model.deleteToken = Backbone.Model.extend({
    key: "Delete Token",
    defaults: {
        id: 1
    },
    url : function () {
        return RXR_Data.HAResources.get('token').get('href');
    }
});