RXR.Model.RxImage = Backbone.Model.extend({
    key: "Tracking Prescription Image",
    defaults  : {}
});
