RXR.Model.roa = Backbone.Model.extend({
    key: "Right of Access",
    defaults: {
        'userId': null,
        'object-type': null,
        'rightOfAccessAccepted': null,
        'rightOfAccessDate': null
    },
    url: function () {
        return App_Utils.GetDomainPath() + 'MobileHealthPlatformWeb/rest/mhpuser/right-of-access';
    }
});