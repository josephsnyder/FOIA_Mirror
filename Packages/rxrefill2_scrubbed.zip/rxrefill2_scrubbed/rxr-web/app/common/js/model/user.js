RXR.Model.user = Backbone.Model.extend({
    key: "User fetch",
    defaults: {
        'clientTimeout' : null,
        'object-type'   : null,
        'mhpuser'       : null
    },    
    url: function(){
        return RXR_Data.HAResources.get("public-user-session").toJSON().href;
    }
});