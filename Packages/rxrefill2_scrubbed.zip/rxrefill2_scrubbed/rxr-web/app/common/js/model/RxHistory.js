RXR.Model.RxHistory = Backbone.Model.extend({
    idAttribute: "prescriptionNumber",
    defaults  : {
        "refillStatus"        : null,
        "refillSubmitDate"    : null,
        "refillDate"          : null,
        "refillRemaining"     : null,
        "facilityName"        : null,
        "isRefillable"        : null,
        "isTrackable"         : null,
        "prescriptionId"      : null,
        "orderedDate"         : null,
        "quantity"            : null,
        "expirationDate"      : null,
        "prescriptionNumber"  : null,
        "prescriptionName"    : null,
        "dispensedDate"       : null,
        "stationNumber"       : null
    }
});
