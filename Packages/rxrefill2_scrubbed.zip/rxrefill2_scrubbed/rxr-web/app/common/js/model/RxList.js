RXR.Model.RxList = Backbone.Model.extend({
    idAttribute: "prescriptionNumber",
    defaults  : {
        "dispensedDate"       : null,
        "expirationDate"      : null,
        "facilityName"        : null,
        "isRefillable"        : null,
        "isTrackable"         : null,
        "orderedDate"         : null,
        "prescriptionId"      : null,
        "prescriptionName"    : null,
        "prescriptionNumber"  : null,
        "quantity"            : null,
        "refillDate"          : null,
        "refillRemaining"     : null,
        "refillStatus"        : null,
        "refillSubmitDate"    : null,
        "stationNumber"       : null
    }
});
