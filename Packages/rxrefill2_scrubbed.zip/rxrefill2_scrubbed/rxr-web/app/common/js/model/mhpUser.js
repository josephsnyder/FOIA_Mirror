RXR.Model.mhpUser = Backbone.Model.extend({
    key: "Get MHP User",
    defaults: {
        "id":"",
        "lastName":"",
        "firstName":"",
        "displayName":"",
        "rightOfAccessAccepted":false,
        "link":"",
        "vistaLocation":"",
        "facilityName":""
    },
    url: function() {
        return RXR_Data.HAResources.get("mhpuser").toJSON().href;
    }
});