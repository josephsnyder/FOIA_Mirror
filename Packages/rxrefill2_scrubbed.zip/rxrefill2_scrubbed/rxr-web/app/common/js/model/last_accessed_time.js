RXR.Model.lastAccessedTime = Backbone.Model.extend({
    key: "Last Accessed Time",
    defaults: {
        'lastAccessedTime'        : null,
        'lastLoginTime'           : null,
        'timeToExpireInSeconds'   : null,
        'userId'                  : null
    },
    url: function () {
        return RXR_Data.HAResources.get("last-accesstime").toJSON().href;
    }
});