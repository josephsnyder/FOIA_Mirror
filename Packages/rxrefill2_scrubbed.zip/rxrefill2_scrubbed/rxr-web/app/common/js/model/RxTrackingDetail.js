RXR.Model.RxTrackingDetail = Backbone.Model.extend({
    idAttribute: "prescriptionNumber",
    defaults  : {
        "prescriptionId"      : null,
        "prescriptionName"    : null,
        "prescriptionNumber"  : null,
        "rxInfoPhoneNumber"   : null,
        "facilityNumber"      : null,
        "ndcNumber"           : null,
        "refillDate"          : null,
        "lastUpdatedTime"     : null,
        "trackingInfo": {}
    }
});
