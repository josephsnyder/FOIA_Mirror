RXR.Model.RxImageDetails = Backbone.Model.extend({
    key: "Tracking Prescription Details",
    defaults  : {
        "acceptedImageMetadata" : null,
        "links"                 : null
    },
    initialize: function (options) {
        this.url = function () {
            return RXR_Data.MILResources.get('metadata').toJSON().href.replace("{ndc}", options.ndc);
        } 
    }
});
