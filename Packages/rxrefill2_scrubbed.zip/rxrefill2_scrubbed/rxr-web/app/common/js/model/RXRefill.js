RXR.Model.RXRefill = Backbone.Model.extend({
    key: "Rx Refill Request",
    defaults: {},
    url: function () {
        var userIdentifier = RXR.Model.User.attributes.mhpuser.userIdentifier;
        var prescription = RXR.Data.View.RxRefillDetail;
        var url = RXR_Data.RXRResources
            .get("requestrefill").toJSON().href
            .replace("{assigning-authority}", userIdentifier.assigningAuthority)
            .replace("{patient-id}", userIdentifier.uniqueId)
            .replace("{rxId}", prescription.prescriptionId)
            .replace("{?appSource=rxr}", "?appSource=rxr");
        return url;
    }
});