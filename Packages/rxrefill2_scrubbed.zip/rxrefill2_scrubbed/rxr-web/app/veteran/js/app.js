
  window.App = new RXR.App({ container: "div.container-fluid" });

  App.checkEula = function () {
      //Need to check that EULA has been accepted
      if (_.isNull(App_Utils.GetLocalStorage('RXR_Eula'))) {
          RXR.Layout.modal.show(RXR.View.EulaModal = new RXR.View.eulaModal());
          RXR.View.EulaModal.show();
      }
      else { App.vent.trigger('eula:accepted'); }
  };

  App.loadResources = function () {
      var ready = 0;
      var readyCheck = function () {
          if (ready === 3) { // set to 3
              App.vent.trigger('resources:loaded');
          }
      };
      var successMustStart = function () {
          RXR_Data.HAResources = new RXR.Collection.HAResources();
          RXR_Data.HAResources.fetch({
              success: function() {
                  RXR_Data.MILResources = new RXR.Collection.MILResources();
                  RXR_Data.MILResources.fetch({ success: successHandler });

                  RXR_Data.RXRResources = new RXR.Collection.RXRResources();
                  RXR_Data.RXRResources.fetch({ success: successHandler });
                  successHandler();
              }
          });

      };
      var successHandler = function (collection, response, options) {
          ready++;
          readyCheck();
      };
      RXR_Data.AppResources = new App_Resources.Collection.AppResources(RXR_Data.resource_directory.links);
      successMustStart();
  };

  App.loginOptions = function() {
    var redirectUri = (App.debug) ? 'http://localhost:5000' : App_Utils.GetDomainPath()+"rx-refill/",
    options = {
      appName: 'rx-refill',
      autoRedirect: true,
      redirectUri: redirectUri,
      resourcesLink: App_Utils.GetDomainPath()+'RxRefillServices',
      authorizeUrl: RXR_Data.HAResources.findWhere({title:'oauth-authorize'}).get('href')
    };
    return options;
  };

  App.on('start', function () {
      RXR.Layout = new RXR.View.layout();
      RXR.Layout.render();
      if (window.location.href.indexOf("token") > -1) {
          App_Utils.SetSessionToken('token', App_Utils.GetUrlParameter('token'));
          window.location = App_Utils.SetUrl();
      }
      else {
          App.loadResources();
      }
  });

  App.vent.on('eula:accepted', function () {
      RXR.Layout.header.show(RXR.View.Header = new RXR.View.header());
      RXR.Layout.footer.show(new RXR.View.footer());
      App.route = new RXR.Router();
      Backbone.history.start();
      //Set Authorize Request header
      App_Utils.SetRequestHeader();
      //Trigger event to load user
      App.vent.trigger('load:user', { init: true });
  });

  App.vent.on('resources:loaded', function () {
    App.loginUtils = new LoginUtils(App.loginOptions());
    //App.loginUtils.authorize(); //Call this in the console to test login

    if (App_Utils.GetSessionToken() != null) {
      App.checkEula();
    }
    else {
      //App_Utils.LaunchpadLogin();
      App.loginUtils.checkForAuthCode();
      setTimeout(function(){
        if (App_Utils.GetSessionToken()) {
          location.reload()
        }
      }, 1000);
    }
  });
