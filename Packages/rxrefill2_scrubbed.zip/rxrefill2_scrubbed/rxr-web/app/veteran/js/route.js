RXR.Router = Backbone.Router.extend({
  routes: {
    ""                          : "home",
    "home"                      : "home",
    "refillable-va-medications" : "RxList",
      "list": "RxListNEW",
    "refill-details/:number"    : "RxRefillDetail",
    "prescription-history"      : "RxHistory",
    "details/:number"           : "RxDetail",
    "track-delivery"            : "RxTrackingList",
    "trackdetails/:number"      : "RxTrackingDetail",
    "trackurl/*path"            : "trackurl",
    "links"                     : "links",
    '*notFound'                 : 'notFound'
    },

    initialize: function(){
      //This runs after the route handler has executed
      this.on("route", function(route, params){
        //Usability shade at bottoms of screen, to indicate additional content
        this.scroll();
        $('[data-toggle="popover"]').popover();
        $(window).on('resize scroll', this.scroll);
        //var wrapper = $("#content").find("div");
        //wrapper.unwrap();
      });
    },

    home: function () {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.HomeLinks);
      document.title = 'Rx Refill Application';
    },

    links: function () {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.Links);
      //$('#pageTop').focus();
      document.title = 'Medication Information on My HealtheVet';
      this.modal('#important-modal');
      //setTimeout(function() {$('#important-label').focus();},500);
    },

    RxList: function () {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.RxList);
      //$('#pageTop').focus();
      document.title = 'Refillable VA Medications';
      this.modal('#important-modal');
      //setTimeout(function() {$('#important-label').focus();},500);
    },

    RxListNEW: function () {
        RXR.Layout.content.empty();
        RXR.Layout.content.show(new RXR.View.RxListLayout({collection: new RXR.Collection.RxList()}));
        //$('#pageTop').focus();
        document.title = 'Refillable VA Medications';
        this.modal('#important-modal');
        //setTimeout(function() {$('#important-label').focus();},500);
    },

    RxDetail: function (id) {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.RxDetail({id:id}));
      document.title = 'Prescription History - Details';
    },

    RxRefillDetail: function (id) {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.RxRefillDetail({id:id}));
      document.title = 'Refillable VA Medications - Details';
    },


    RxHistory: function () {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.RxHistory);
      document.title = 'Prescription History';
      this.modal('#important-modal');
    },


    RxHistoryBAD: function () {
        RXR.Layout.content.empty();
        RXR.Layout.content.show(new RXR.View.RxHistoryLayout({collection: new RXR.Collection.RxHistory()}));
        document.title = 'Prescription History';
        this.modal('#important-modal');
    },

    RxTrackingList: function () {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.RxTracking);
      document.title = 'Track Delivery';
      this.modal('#important-modal');
      //setTimeout(function() {$('#important-label').focus();},500);
    },

    RxTrackingDetail: function (id) {
      RXR.Layout.content.empty();
      RXR.Layout.content.show(new RXR.View.RxTrackingDetail({id:id}));
      document.title = 'Track Delivery - Details';
      if (!App_Utils.GetLocalStorage('RXR_Important_Modal')) {
        $('#important-tracking-modal').modal('show');
        // delay modal display so that VO will announce it last
        setTimeout(function() {
          //this.modal('#important-tracking-modal');
          $('#important-tracking-label').focus();
        },500);
      }
    },

    trackurl: function(path) {
        RXR.trackurl = new RXR.RxTrackingLinkView(path);
    },

    notFound: function () {
        RXR.notFound = new RXR.NotFound({ model: new RXR.BaseModel(RXR.appData["not-found"]) });
    },

    modal: function(selector){
      if (!_.contains(this.modals, window.location.hash)) { // Show modal once
        this.modals.push(window.location.hash);
        //setTimeout(function(){$(selector).modal();}, 200);
        $(selector).modal();
      }
    },

    modals: [], // Previously viewed modals

    scroll: function(){
      var scrollable;

      scrollable = ($(window).scrollTop() + $(window).height() === $(document).height()) ? false : true;
      $('.scrollbar-gradient').toggleClass('hidden', !scrollable);
    }
});
