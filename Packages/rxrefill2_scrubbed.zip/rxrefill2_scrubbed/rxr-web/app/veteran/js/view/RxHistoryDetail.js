RXR.View.RxHistoryDetail = Backbone.Marionette.ItemView.extend({
    template  : RXR.Template.detail,
    onDomRefresh: function () {
        $('[data-toggle="popover"]').popover();     // needed for 1st time page load
    },
    onRender: function () {
        //this.$el.html(this.template(RXR.Data.View.RxDetail));
        App_Utils.FocusOnLoad();
    }
});