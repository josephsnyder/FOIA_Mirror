RXR.View.timeoutModal = Backbone.Marionette.ItemView.extend({
    template: RXR.Template.timeoutModal,
    events: {
        "click #logout"                 : "logout",
        "click #stay"                   : "stay",
        "shown.bs.modal #timeout-modal" : "onModalShown",
        "hidden.bs.modal #timeout-modal": "onModalHidden"
    },

    initialize: function () {
        RXR.Model.LastAccessedTime = new RXR.Model.lastAccessedTime();
        
        App.KeepAliveModal = false;
    },
    start: function () {
        var self = this;

        // only check access time if Airplane mode is off.
        if (navigator.onLine) {
            RXR.Model.LastAccessedTime.fetch({
                success: function (model, response) {
                    App.vent.trigger('lastAccessedTime:success');
                    App.KeepAliveTimeLeft = Number(response.timeToExpireInSeconds);
                    self.keepaAlive();
                },
                error: function (model, response) {
                    App.vent.trigger('lastAccessedTime:failed');
                    if (response.status === 401) {
                        clearInterval(App.KeepAliveInterval); //stop the loop for heavens sake
                        // Probably init logout
                    }
                    else {
                    }
                }
            });
        }
    },
    keepaAlive: function () {
        var self = this;
        App.KeepAliveCount = 0;
        if(App.KeepAliveInterval){clearInterval(App.KeepAliveInterval);}
        App.KeepAliveInterval = setInterval(function () {
            App.KeepAliveCount++;
            App.KeepAliveTimeLeft--;
            if (App.KeepAliveCount > 120 && !App.KeepAliveModal) { self.start(); }
            if (App.KeepAliveTimeLeft <= 120) {
                if (!App.KeepAliveModal || (App.KeepAliveTimeLeft > 0 && App.KeepAliveTimeLeft <= 120)) {
                    self.show();                  
                }
                if (App.KeepAliveTimeLeft <= 0) {
                    clearInterval(App.KeepAliveInterval);
                    self.logout();
                }
                self.modalCountdown();
            }
            if (App.debug) {
                if (!$("#debug").length) {
                    $("body").append("<div id='debug' style='position:absolute; right:50px; top:45px;'></div>");
                }
                $("#debug").html(self.calculateTimeRemaining(App.KeepAliveTimeLeft));
            }
        }, 1000);
        App.vent.trigger('keepaAlive:started');
    },
    logout: function () {
        RXR.View.Header.logout();
    },
    stay: function () {
        clearInterval(App.KeepAliveInterval);
        //Trigger event to load user this will reset timeout
        App.vent.trigger('load:user', {reset:true});
        this.hide();
        App.vent.trigger('timeoutModal:hidden');
    },
    show: function () {
        App.KeepAliveModal = true;
        $("#timeout-modal").modal("show");
        App.vent.trigger('timeoutModal:visible');
    },
    hide: function () {
        App.KeepAliveModal = false;
        $("#timeout-modal").modal("hide");        
    },
    modalCountdown: function () {
        var remainder = this.calculatePercentRemaining(App.KeepAliveTimeLeft, 120);
        $("#timeout-modal .time-remaining").html(this.calculateTimeRemaining(App.KeepAliveTimeLeft));
    },
    calculatePercentRemaining: function (a, b) {
        return ((a / b) * 100).toFixed(2);
    },
    calculateTimeRemaining: function (a) {
        var minutes = Math.floor(a / 60);
        var seconds = (a - (60 * minutes));
        if (minutes > 0) {
            seconds < 10 ? seconds = "0" + seconds : seconds = seconds;
        }
        var formattedValue = "";
        minutes > 0 ? formattedValue += minutes + ":" + seconds + " minutes" : formattedValue += seconds + " seconds";
        return formattedValue;
    },
    onRender: function () {
        this.$el.html(this.template(this.model));
        App_Utils.FocusOnModal();
    },
    onModalShown: function () {
        App_Utils.ModalContainerShown();
    },
    onModalHidden: function () {
        App_Utils.ModalContainerHidden();
    }
});