RXR.View.header = Backbone.Marionette.ItemView.extend({
    template: RXR.Template.header,
    errors: { error: [] },
    failedResources : {resource:[]},
    events: {
        "click #logout"               : "logout",
        "click #userMenuLink"         : "userMenuDropdown",
        "click #nav-dropdown"         : "featuresMenuDropdown",
        "click #phoneFeaturesMenuLink": "hamburgerMenuDropdown",
        "shown.bs.modal #help-modal"  : "onModalShown",
        "shown.bs.modal #about-modal" : "onModalShown",
        'hidden.bs.modal #about-modal': 'onModalHidden',
        'hidden.bs.modal #help-modal' : 'onModalHidden'
    },
    initialize: function () {
        var self = this;
        
        RXR.Data.View.Header = RXR.Data.View.Header || { mhpuser: null, showNav: false, launchpad: "", app: RXR.Data.app };
        App.vent.on('load:user', function (options) {
            //Now get the user
            RXR.Model.User = new RXR.Model.user();
            RXR.Model.User.on("change", function () {
                RXR.Data.View.Header.mhpuser = this.toJSON().mhpuser;
                RXR.Data.View.Header.launchpad = RXR_Data.HAResources.get("launchpad-link").toJSON().href;
                RXR.Data.View.Header.showNav = true;
                self.render();
            });

            if (_.isEmpty(RXR.Data.View.Header) || options.reset || options.init) {
                RXR.Model.User.fetch({
                    change: true,
                    success: function (model, response) {
                        App.vent.on('roa:accepted', function (data) {
                            RXR.Layout.timeout.show(RXR.View.TimeoutModal = new RXR.View.timeoutModal());
                            //We have a user start/restart timeout process
                            App.vent.trigger('user:loaded');
                            RXR.View.TimeoutModal.start();
                            if (options.init) {  //NOTE: this section of code is not in MHPRO
                                //Get Enterprise Session Token
                                RXR.Model.Session = new RXR.Model.session();
                                RXR.Model.Session.fetch({
                                    success: function (model, response) {
                                      //Enterprise Session Token lets store in sessionStorage
                                      App_Utils.SetSessionToken('mhvToken', response.token);
                                        
                                        // NOTE:  the mhv expiration does not reset every time this fetch is called,
                                        //        check expiresDate to see if it is going to expire before the login session, 
                                        //        if it does, reset the login timer to the mhv timer.
                                        /*
                                        if (response.expiresDate != undefined) {
                                            App.MHVExpiresDate = response.expiresDate;
                                            var tDate = new Date(response.expiresDate);
                                            var nowDate = new Date();
                                            var dif = tDate.getTime() - nowDate.getTime();
                                            var secondsToExpire = Math.abs(dif / 1000);
                                            
                                            if (secondsToExpire < App.KeepAliveTimeLeft) {
                                                App.KeepAliveTimeLeft = secondsToExpire;
                                            }
                                        }
                                        */
                                        
                                      if (App_Utils.GetMHVToken()) {
                                        App.EnterpriseToken = true;
                                        App.vent.trigger('enterpriseSession:loaded');
                                      }
                                    },
                                    error: function (model, response) {
                                        /*TODO: Why is this commented out?
                                        console.log("session error model:", model);
                                        console.log("session error response:", response);
                                        if (response.status == 500) {
                                            console.log("error response token: " + response.token);
                                            if (response.token != undefined) {
                                                App.vent.trigger('enterpriseSession:loaded');
                                                App.EnterpriseToken = true;
                                                //Enterprise Session Token lets store in sessionStorage
                                                App_Utils.SetSessionToken('mhvToken', response.token);
                                            }
                                            else {
                                                App.vent.trigger('enterpriseSession:failed');
                                            }
                                        }
                                        */
                                        if (response.status === 401) {
                                            // User is not authenticated
                                            //self.logout();
                                            self.appCleanup();
                                        }
                                        else {

                                        }
                                    }
                                });
                            }
                        });
                        App_Utils.RightOfAccess();
                    },
                    error: function (model, response) {
                        App.vent.trigger('user:failed');
                        if (response.status === 401) {
                            // User is not authenticated
                            App_Utils.ClearSessionToken();
                            //self.logout();
                            self.appCleanup();
                        }
                        else {

                        }
                    },
                    complete: function (model, response) {

                    }
                });
            }

        });

        App.vent.on('website:error', function (data) {
            var isErr = false;
            for (var i=0; i < self.errors.error.length; i++) {
                if (data === self.errors.error[i])
                {
                    isErr = true;               // got this error message already
                    break;
                }
            }

            if (!isErr) {
                self.errors.error.push(data);   // display the same error message once only
            }

            //self.errors.error.push(data);
            self.render();
        });

        this.listenTo(App.vent, 'resources:failed', function (data) {
            self.failedResources.resource.push(data);
            self.render();
        });

        window.addEventListener("offline", function(e) {
            App.vent.trigger('website:error', 'Your internet connection appears to be unavailable. Please try again when you regain connectivity.');
        });

    },
    appCleanup: function () {
        if (App.KeepAliveInterval) { clearInterval(App.KeepAliveInterval); }
        App_Utils.AppCleanup();
    },
    logout: function () {
        App.vent.on('AppCleanup:complete', function (data) {
            //App_Utils.ReturnToLaunchpad();
            App_Utils.LaunchpadLogout();
        });
        this.appCleanup();
    },
    onRender: function () {
        this.$el.html(this.template(RXR.Data.View.Header));

        $('#errorSection').html(RXR.Template.resourceFailedBanner({"resources":this.failedResources, "help": RXR.Data.app.help}));

        if (this.errors.error.length > 0) {
            $('#errorSection').append(RXR.Template.errorBanner({ "errors": this.errors, "help": RXR.Data.app.help }));
            App.vent.trigger('error:shown');
        }

        $('.spinner-image').addClass('hidden');  // when errors, this needs to be removed manually

        // for initial app page load where header finishes loading last
        App_Utils.FocusOnLoad();
    },
    userMenuDropdown: function () {
      // On dropdown open
      $('#header-login').on('shown.bs.dropdown', function(event) {
          // Set aria-expanded to true
          $('#userMenuLink').attr('aria-expanded', true);

          // Set focus on the first link in the dropdown
          // Note: the 1.5 seconds delay allows VO to finish announcing the submenu's expanded state
          // based on a 50% speaking rate (iOS 9)
          setTimeout(function() {
              $('#userMenu li:first-child a').focus();
          }, 1500);

          // hide everything else "outside" of dropdown and its parent
          $('#logo-va, #skipNav, .app-title-area, main, footer').attr('aria-hidden', 'true');

          // also hide errorBanner if it's displayed
          var $err = $('#errorBanner');
          if ($err.css('display') === 'block'){
              $err.attr('aria-hidden', 'true');
          }
      });

      // On dropdown close
      $('#header-login').on('hidden.bs.dropdown', function(event) {
          // Set aria-expanded to false; focus will be auto set to #userMenuLink
          $('#userMenuLink').attr('aria-expanded', false);

          // un-hide everything "outside" of dropdown and its parent
          $('#logo-va, #skipNav, .app-title-area, #errorBanner, main, footer').removeAttr('aria-hidden');
      });
    },
    featuresMenuDropdown: function () {
      // On dropdown open
      $('#menu-list').on('shown.bs.dropdown', function() {

          // Set aria-expanded to true
          $('#nav-dropdown').attr('aria-expanded', true);

          // Set focus on the first link in the dropdown
           setTimeout(function() {
               $('#tabletFeaturesMenu li:first-child a').focus();
           }, 1500);

          // hide other elements
          $('.va-title-area, .titleAreaLogo, #home, #about, #help, #errorBanner, main, footer, .scrollbar-gradient').attr('aria-hidden', 'true');
      });

      // On dropdown close
      $('#menu-list').on('hidden.bs.dropdown', function() {
          // Set aria-expanded to false
          $('#nav-dropdown').attr('aria-expanded', false);

          // un-hide other elements
          $('.va-title-area, .titleAreaLogo, #home, #about, #help, #errorBanner, main, footer, .scrollbar-gradient').removeAttr('aria-hidden');
      });
    },
    hamburgerMenuDropdown: function () {
      // On dropdown open
      $('#hamburger-list').on('shown.bs.dropdown', function() {

          // Set aria-expanded to true
          $('#phoneFeaturesMenuLink').attr('aria-expanded', true);

          // Set focus on the first link in the dropdown
           setTimeout(function() {
               $('#phoneFeaturesMenu li:first-child a').focus();
           }, 1500);

          // hide other elements
          $('.va-title-area, .titleAreaLogo, #home, #about, #help, #errorBanner, main, footer, .scrollbar-gradient').attr('aria-hidden', 'true');
      });

      // On dropdown close
      $('#hamburger-list').on('hidden.bs.dropdown', function() {
          // Set aria-expanded to false
          $('#phoneFeaturesMenuLink').attr('aria-expanded', false);

          // un-hide other elements
          $('.va-title-area, .titleAreaLogo, #home, #about, #help, #errorBanner, main, footer, .scrollbar-gradient').removeAttr('aria-hidden');
      });
    },
    onModalShown: function () {
        App_Utils.HeaderModalShown();
    },
    onModalHidden: function () {
        App_Utils.HeaderModalHidden();
    }
});
