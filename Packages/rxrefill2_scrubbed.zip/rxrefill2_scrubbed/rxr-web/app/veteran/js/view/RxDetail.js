RXR.View.RxDetail = Backbone.Marionette.ItemView.extend({
  id        : null,
  template  : RXR.Template.detail,
  collection: RXR.Collection.RxHistory,
  model     : RXR.Model.RxList,

  initialize: function(){
    var _self, model;
    RXR.Data.View.RxDetail = {};
    //RXR.Data.View.RxHistory = {};  why is this cleared out??

    _self           = this;
    _self.id        = parseInt(this.id);
    _self.collection = new RXR.Collection.RxHistory;
    this.model      = new RXR.Model.RxHistory({id:this.id});

    var fetch = function () {
        if (_.isEmpty(RXR.Data.View.RxHistory.items)) {
            _self.collection.fetch({
                cache: false,
                reset: true,
                headers: { 'Token': App_Utils.GetMHVToken() },
                success: function () { App.vent.trigger('details:loaded'); },
                error: function () { App.vent.trigger('details:failed'); }
            });
            _self.collection.on('sync', function (collection) {
                model = _.first(collection.where({ prescriptionId: _self.id })) || {};
                RXR.Data.View.RxHistory.items = collection.toJSON();
                _.extend(RXR.Data.View.RxDetail, model.toJSON());
                _self.render();
            });
        }
        else {
            model = _.first(_.where(RXR.Data.View.RxHistory.items, { prescriptionId: _self.id })) || {};
            _.extend(RXR.Data.View.RxDetail, model);
        }
    };
    if (App.EnterpriseToken) {
        fetch();
    }
    App.vent.on('enterpriseSession:loaded', function () {
        fetch();
    });
  },
  onDomRefresh: function () {
     $('[data-toggle="popover"]').popover();     // needed for 1st time page load
  },
  onRender: function () {
      $('[data-toggle="popover"]').popover();
      this.$el.html(this.template(RXR.Data.View.RxDetail));
      App_Utils.FocusOnLoad();
  }
});
