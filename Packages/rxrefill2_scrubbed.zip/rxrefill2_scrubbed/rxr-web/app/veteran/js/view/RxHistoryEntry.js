RXR.View.RxHistoryEntry = Backbone.Marionette.CompositeView.extend({
    template  : RXR.Template.RxHistoryEntry,
    className: "med-container col-xs-12"
});