RXR.View.RequestRefillModal = Backbone.Marionette.ItemView.extend({
    template: RXR.Template.refillRequestModal,
    events: {
        "click .btn-primary": "redirect",
        "shown.bs.modal #refillRequestModal" : "onModalShown",
        "hidden.bs.modal #refillRequestModal": "onModalHidden"
    },
    initialize: function () {
        var self = this;
        RXR.Data.View.RXRefill = {};
        self.render();
    },
    redirect: function () {
        App.route.navigate('refillable-va-medications', { trigger: true });
    },
    updateModal: function (obj) {
        $("#refill-status").html(obj.status);
        $("#refill-message").html(obj.message);
    },
    attemptRefill: function () {
        var self = this;
        RXR.Data.RXRefill = new RXR.Model.RXRefill();
        RXR.Data.RXRefill.fetch({
            type: 'POST',
            dataType: "text",
            contentType: false,
            processData: false,
            headers: { 'Token': App_Utils.GetMHVToken() },
            success: function (model, response) {
                self.updateModal({ status: "Success", message: "<p tabindex='0'>Refill was successfully submitted.</p> <div class='center-buttons'><button type='button' class='btn btn-primary' data-dismiss='modal'>OK</button></div>" });
                // set focus after success call
                App_Utils.FocusOnModal('#refill-message p');
                App.vent.trigger('refill:success');
            },
            error: function (model, response) {
                self.updateModal({ status: "Error", message: "<p tabindex='0'>Refill was not successfully submitted.</p> <div class='center-buttons'><button type='button' class='btn btn-primary' data-dismiss='modal'>OK</button></div>" });
                // set focus after call
                App_Utils.FocusOnModal('#refill-message p');
            },
            complete: function () {

            }
        });
        //setTimeout(function () {
        //    self.updateModal({ status: "Success", message: "Refill was successfully submitted" });
        //}, 2000)
    },
    show: function () {
        $("#refillRequestModal").modal("show");
        App.vent.trigger('refillRequestModal:shown');
        this.attemptRefill();
    },
    hide: function () {
        $("#refillRequestModal").modal("hide");
        App.vent.trigger('refillRequestModal:hidden');
    },
    onRender: function () {
        this.$el.html(this.template(RXR.Data.View.RXRefill));
    },
    onModalShown: function () {
        App_Utils.ModalContainerShown();
    },
    onModalHidden: function () {
        App_Utils.ModalContainerHidden();
    }
});
