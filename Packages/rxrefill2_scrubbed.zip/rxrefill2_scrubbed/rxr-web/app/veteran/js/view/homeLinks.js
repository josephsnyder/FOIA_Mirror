RXR.View.HomeLinks = Backbone.Marionette.ItemView.extend({
  template  : RXR.Template.homeLinks,

  initialize: function(){
    this.$el.data('view', 'HomeLinks');
    RXR.Data.View.HomeLinks = _.first(_.where(RXR.Data.app.links, {id:1}));
  },

  onRender: function(){
    this.$el.html(this.template(RXR.Data.View.HomeLinks));

    // for subsequent Home page loads
    App_Utils.FocusOnLoad();
  }
});
