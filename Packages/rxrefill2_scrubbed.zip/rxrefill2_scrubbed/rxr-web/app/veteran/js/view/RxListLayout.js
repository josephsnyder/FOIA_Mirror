RXR.View.RxListLayout = Backbone.Marionette.LayoutView.extend({
    template  : RXR.Template.RxListLayout,
    collection: RXR.Collection.RxList,
    detailView: false,
    regions: {
        'detailRegion': '#refillDetailContainer',
        'headerRegion': '#refillHeaderContainer',
        'listRegion': '#refillListContainer'
    },
    events: {
        "click .dropdown-menu a"      : "sort",
        "click #sortBtn"              : "sortDropdownOpen",
        "click .refill-detail"        : "showRefillDetail",
        "click button.title-back-btn" : "goBack"
    },
    collectionEvents: {
        sync: 'onShow'
    },
    initialize: function () {
        var self = this;

        RXR.Data.View.RxList = RXR.Data.View.RxList || {};
        if (App.EnterpriseToken) {
            this.fetchRecords();
        }
        App.vent.on('enterpriseSession:loaded', function () {
            self.fetchRecords();
        });

        App.vent.on('refill:success', function () {
            self.fetchRecords();
        });

    },
    fetchRecords: function() {
        var self = this;

        this.collection.fetch({
            headers: { 'Token': App_Utils.GetMHVToken() },
            cache: false,
            reset: true,
            success: function () {
                RXR.Data.View.RxList.items = self.collection.toJSON(); // View Model
                RXR.Data.View.RxList.totalCount = RXR.Data.View.RxList.items.length;
                App.vent.trigger('rxlist:loaded');

                self.showLists();
            },
            error: function (model, response) {
                App.vent.trigger('rxlist:failed');
            },
            complete: function () {
                $('.link-items').removeClass('spinner-background');
            }
        });
    },
    showLists: function() {
        if (this.detailView == false) {
            this.detailRegion.empty();
            this.headerRegion.show(new Marionette.ItemView({
                template: RXR.Template.RxRefillHeader
            }));
            this.listRegion.empty();
            this.listRegion.show(new RXR.View.RxListEntries({collection: this.collection}));
        }
    },
    goBack: function(e) {
        if (this.detailView) {
            this.detailRegion.empty();
            this.headerRegion.show(new Marionette.ItemView({
                template: RXR.Template.RxRefillHeader
            }));

            $('#refillListContainer').removeClass('hidden');
            this.detailView = false;
        }
        else {
            App_Utils.BackButton();
        }
    },
    showRefillDetail: function(e) {
        var prescriptionId = $(e.currentTarget).data('id');

        $('#refillListContainer').addClass('hidden');
        this.headerRegion.empty();
        this.headerRegion.show(new Marionette.ItemView({
            template: RXR.Template.RxRefillDetailHeader
        }));
        this.detailRegion.empty();
        this.detailRegion.show(new RXR.View.RxRefillDetail({ id: prescriptionId }));
        this.detailView = true;
        document.title = 'Refillable VA Medications - Details';
    },
    sort: function(e) {
        console.log('sort called...');
        var $el = $(e.currentTarget);
        var ns = $el.data('sort');
        var sortOrder = $el.data('asc');

        if (sortOrder) {
            this.collection.sortDirection = 1;
        } else {
            this.collection.sortDirection = -1;
        }

        this.collection.sortField = ns;
        this.collection.sort();

        $('#sortMenu').removeClass('open');

        //this.render();
        this.showLists();

        return false;
    },
/*
    sort: function(event) {
        event.preventDefault();
        event.stopPropagation();
        var $link = $(event.currentTarget);
        var sortOrder = $link.data('asc');
        var sortVal = $link.data("sort").toLowerCase();


        var $links = $('div.med-container');
        var $items = $('div.link-items');
        var sorted = _.sortBy($links, function (link) {
            return $(link).data(sortVal);
        });

        if (!sortOrder) {
            sorted.reverse();
        }
        $items.empty();
        $items.append(sorted);
        $('#sortBtn').dropdown('toggle');

        // set focus to list count
        setTimeout(function () {
            $('[data-toggle="popover"]').popover();
            $('.list-count').focus();
        }, 1200);
    },
    */
    onDomRefresh: function () {
        $('[data-toggle="popover"]').popover();     // needed for 1st time page load
    },
    onShow: function () {
        if (this.collection) {
            if (this.collection.length > 0) {
                this.showLists();
            }
            else {
                this.listRegion.show(new Marionette.ItemView({
                    template: _.template('<p class="missing-record center">No records found.</p>')
                }));
            }
        }
        //this.$el.html(this.template(RXR.Data.View.RxList));
        App_Utils.FocusOnLoad();
        $('[data-toggle="popover"]').popover();
    },
    sortDropdownOpen: function () {
        App_Utils.SetSort('#refillListContainer');
    }
});
