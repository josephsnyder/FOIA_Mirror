RXR.View.RxHistoryEntries = Backbone.Marionette.CompositeView.extend({
    template: RXR.Template.RxHistoryEntries,
    //collection: RXR.Collection.RxHistory,
    childView: RXR.View.RxHistoryEntry,
    childViewContainer: '#linkItems',
    ui: {
        'page'        : 'ul.pagination a',
        'filter'      : 'ul.dropdown-menu a[data-filter]',
        'listCount'   : '#list-count',
        'linkItems'   : '#linkItems'
    },
    events: {
        "click .dropdown-menu a": "sort",
        "click #sortBtn"        : "sortDropdownOpen"
    },
    initialize: function() {

    },
    sort: function(e) {
        var $el = $(e.currentTarget);
        var ns = $el.data('sort');
        var sortOrder = $el.data('asc');

        if (sortOrder) {
            this.collection.sortDirection = 1;
        } else {
            this.collection.sortDirection = -1;
        }

        this.collection.sortField = ns;
        this.collection.sort();

        $('#sortMenu').removeClass('open');

        this.render();

        return false;
    },
    onDomRefresh: function() {
        $('[data-toggle="popover"]').popover();
    },
    onShow: function() {
        if (this.collection.length > 0) this.ui.listCount.html(this.collection.length + ' Total Prescriptions');
        this.ui.linkItems.removeClass('spinner-background');
    },
    sortDropdownOpen: function () {
        App_Utils.SetSort('#historyListContainer');
    }
});