RXR.View.RxHistory = Backbone.Marionette.LayoutView.extend({
  template  : RXR.Template.RxHistory,
  collection: RXR.Collection.RxHistory,
    detailView: false,
  events: {
    "click .dropdown-menu a": "sort",
    "click #sortBtn"        : "sortDropdownOpen",
      "click .history-detail": "showHistoryDetail",
      'click .title-back-btn'       : 'goBack'
  },
    regions: {
        'details': '#historyDetailContainer',
        'header': '#historyHeaderContainer'
    },

    initialize: function () {
      var self = this;
      RXR.Data.View.RxHistory = RXR.Data.View.RxHistory || {};
/*
      var fetch = function () {
          self.collection.fetch({
              cache: false,
              reset: true,
              headers: { 'Token': App_Utils.GetMHVToken() },
              success: function () {
                  RXR.Data.View.RxHistory.items = self.collection.toJSON(); // View Model
                  RXR.Data.View.RxHistory.totalCount = RXR.Data.View.RxHistory.items.length;

                  App.vent.trigger('history:loaded');
              },
              error: function (model, response) {
                  App.vent.trigger('history:failed');
              },
              complete: function () {
                  $('.link-items').removeClass('spinner-background');
              }
          });
      };
*/

      if (App.EnterpriseToken) {
          this.fetchRecords();
      }

      App.vent.on('enterpriseSession:loaded', function () {
          self.fetchRecords();
      });

      this.collection.on('sync', self.render);
  },
    goBack: function() {
      console.log('in goBack.  detailView=' + this.detailView);
      if (this.detailView) {
          this.details.empty();
          this.header.show(new Marionette.ItemView({
              template: RXR.Template.RxHistoryHeader
          }));
          $('#historyListContainer').removeClass('hidden');
          this.detailView = false;
      }
      else {
          //RXR.Router.navigate('home', {trigger: true, replace: true});
          App_Utils.BackButton();
      }
    },
    fetchRecords: function () {
        var self = this;
        this.collection = new RXR.Collection.RxHistory({
            sortField: 'refillDate',
            sortDirection: 0
        });
        this.collection.fetch({
            cache: false,
            reset: true,
            headers: {'Token': App_Utils.GetMHVToken()},
            success: function () {
                RXR.Data.View.RxHistory.items = self.collection.toJSON(); // View Model
                RXR.Data.View.RxHistory.totalCount = RXR.Data.View.RxHistory.items.length;
                // reset sort order on fetch
                RXR.Data.View.RxHistory.sortOrder = true;
                RXR.Data.View.RxHistory.sortColumn = 'refillDate';

                App.vent.trigger('history:loaded');
            },
            error: function (model, response) {
                App.vent.trigger('history:failed');
            },
            complete: function () {
                $('.link-items').removeClass('spinner-background');
            }
        });
    },
    showHistoryDetail: function(e) {
        var prescriptionId = $(e.currentTarget).data('id');

        $('#historyListContainer').addClass('hidden');
        this.header.empty();
        this.header.show(new Marionette.ItemView({
            template: RXR.Template.RxHistoryDetailHeader
        }));
        this.details.empty();
        this.details.show(new RXR.View.RxHistoryDetail({model: this.collection.get(prescriptionId)}));
        this.detailView = true;
    },
    sort: function (event) {
        event.preventDefault();
        event.stopPropagation();
        var $link = $(event.currentTarget);
        var sortOrder = $link.data('asc');
        var sortVal = $link.data("sort").toLowerCase();

        RXR.Data.View.RxHistory.sortOrder = sortOrder;
        RXR.Data.View.RxHistory.sortColumn = sortVal; //$link.data("sort");

        this.sortList(sortVal, sortOrder);
    },
    sortList: function(sortVal, sortOrder) {
        console.log('calling sortList (' + sortVal + ', ' + sortOrder + ')');
        var $links = $('div.med-container');
        var $items = $('div.link-items');
        var sorted = _.sortBy($links, function (link) {
            return $(link).data(sortVal);
        });

        if (!sortOrder) {
            sorted.reverse();
        }
        $items.empty();
        $items.append(sorted);
        $('#sortBtn').dropdown('toggle');

        // set focus to list count
        setTimeout(function () {
            $('[data-toggle="popover"]').popover();
            $('.list-count').focus();
        }, 1200);
    },
    onDomRefresh: function () {
        $('[data-toggle="popover"]').popover();     // needed for 1st time page load
    },
    onRender: function () {
        this.$el.html(this.template(RXR.Data.View.RxHistory));

        /*  not needed
        if (this.detailView == false) {
            $('#historyHeaderContainer').removeClass('hidden');
            this.header.show(new Marionette.ItemView({
                template: RXR.Template.RxHistoryHeader
            }));
        }
        */
        setTimeout(function () {
            App_Utils.FocusOnLoad();
            $('[data-toggle="popover"]').popover();
        }, 2000);
    },
    sortDropdownOpen: function () {
        App_Utils.SetSort('#historyListContainer');
    }
});
