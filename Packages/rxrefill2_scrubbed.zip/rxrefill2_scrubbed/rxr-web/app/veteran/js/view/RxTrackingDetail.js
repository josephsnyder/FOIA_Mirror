RXR.View.RxTrackingDetail = Backbone.Marionette.ItemView.extend({
    id: null,
    template: RXR.Template.RxTrackingDetail,
    collection: RXR.Collection.RxTrackingDetail,
    events: {
        "click .viewImageLink": "viewImage",
        "click .tracking-url": "trackingUrl",
        "click .collapse-btn": "setCollapseState"
    },
    viewImage: function (e) {
        // turn on spinner
        //$('#mySpinner').toggleClass('active');
        $('#mySpinner').addClass('active');

        // when load event is fired, it should hide the spinner
        App.vent.on('imageDetailsImage:loaded', function() {
            $('#mySpinner').removeClass('active');
        });
        App.vent.on('imageDetailsImage:failed', function() {
            $('#mySpinner').removeClass('active');
        });
        App.vent.on('imageDetails:failed', function() {
            $('#mySpinner').removeClass('active');
        });
        RXR.Layout.modal.empty();
        RXR.Layout.modal.show(new RXR.View.imageModal({ "ndc": $(e.currentTarget).attr("ndc") }));
    },
    trackingUrl: function (e) {
        if (!App_Utils.GetLocalStorage('RXR_Leave_Modal')) {
            RXR.Layout.modal.empty();
            RXR.Layout.modal.show(RXR.View.LeavingModal = new RXR.View.leavingModal());
        }
        App.CurrentEvent = e; //Save event.
        if (!App_Utils.GetLocalStorage('RXR_Leave_Modal')) {//show leaving modal if local storage setting does not exist.
            e.stopPropagation();
            e.preventDefault();
            RXR.View.LeavingModal.show();
        }
        else {
            // open link in new window
            //window.open($(e.target).attr("href"), $(e.target).attr("target"));
            return true;
        }
    },
    initialize: function () {
        var self = this;
        RXR.Data.View.RxTrackingDetail = {};
        self.collection = new RXR.Collection.RxTrackingDetail({ id: this.id });
        var fetch = function () {
            self.collection.fetch({
                cache: false,
                reset: true,
                headers: { 'Token': App_Utils.GetMHVToken() },
                success: function () {
                    RXR.Data.View.RxTrackingDetail = self.collection.toJSON()[0];
                    App.vent.trigger('trackingDetail:loaded');
                },
                error: function (model, response) {
                    App.vent.trigger('trackingDetail:failed');
                },
                complete: function () { }
            });
        };
        if (App.EnterpriseToken) {
            fetch();
        }
        App.vent.on('enterpriseSession:loaded', function () {
            fetch();
        });

        self.collection.on('sync', self.render);
    },

    onRender: function () {
       // console.log(this.$el.children())
       // this.$el.unwrap();
        this.$el.html(this.template(RXR.Data.View.RxTrackingDetail));  // this is not needed in marionette
        App_Utils.FocusOnLoad();
    },
    setCollapseState: function (e) {
      var activeSpanID = e.target.id;   // Grabs the span ID (heading{{@index}}) that's nested in the active button
      var activeButtonID = activeSpanID.replace("heading", "button");  // Set the active button ID
      var activePanelID = activeButtonID.replace("button", "accordion");  // Set the active panel ID

      // On panel expand
      $('#' + activePanelID).on('show.bs.collapse', function() {

          // Set aria-expanded to true
          $('#' + activeButtonID).attr('aria-expanded', true);

          // set focus to first item in the panel, added slight delay in focus to resolve issues with screen reader
          setTimeout(function() {
              $('#' + activePanelID + ' div.track-details div:first-child').focus();
          }, 300);

      });

      // On panel collapse
      $('#' + activePanelID).on('hide.bs.collapse', function() {

          // Set aria-expanded to false
          $('#' + activeButtonID).attr('aria-expanded', false);

      });


    }
});
