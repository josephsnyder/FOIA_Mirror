RXR.View.footer = Backbone.Marionette.ItemView.extend({
  template: RXR.Template.footer,

  events: {
    "shown.bs.modal #important-modal"          : 'setFocusToModal',
    "shown.bs.modal #important-tracking-modal" : 'setFocusToModal',
    'hidden.bs.modal #important-modal'         : 'setFocusToTop',
    'hidden.bs.modal #important-tracking-modal': 'setFocusToTop',
    'click #displayImportantModal': 'importantClick'
  },

  importantClick: function(e) {
    if ($(e.currentTarget).is(':checked')) {
      App_Utils.SetLocalStorage('RXR_Important_Modal', { date: new Date().getTime() });
    }
    else {
      App_Utils.DeleteLocalStorage('RXR_Important_Modal');
    }
    // now sure why this code was here???
    //setTimeout(function() {$('#displayModal').focus();},500);
  },
  onRender: function(){
    this.$el.html(this.template(RXR.Data));
  },
  setFocusToModal: function() {
    App_Utils.FooterModalShown();
  },
  setFocusToTop: function() {
    App_Utils.FooterModalHidden();

    // for pages with Important Info modal
    App_Utils.FocusOnLoad();
  }
});
