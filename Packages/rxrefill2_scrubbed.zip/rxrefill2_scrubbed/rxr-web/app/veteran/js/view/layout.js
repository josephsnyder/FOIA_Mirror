RXR.View.layout = Marionette.LayoutView.extend({
  el        : "div.container-fluid",
  template  : RXR.Template.layout,
  regions   : {
    header  : "header",
    footer  : "footer",
    content: "section.content",
    modal: "section.modal-container",
    timeout: "section.timeout-container"
  }
});
