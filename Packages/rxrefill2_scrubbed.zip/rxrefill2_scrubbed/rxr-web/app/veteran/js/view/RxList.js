RXR.View.RxList = Backbone.Marionette.LayoutView.extend({
  template  : RXR.Template.RxList,
  collection: RXR.Collection.RxList,
    detailView: false,
    regions: {
        'detailRegion': '#refillDetailContainer',
        'headerRegion': '#refillHeaderContainer',
        'listRegion': '#refillListContainer'
    },
  events: {
    "click .dropdown-menu a"       : "sort",
    "click #sortBtn"               : "sortDropdownOpen",
      "click .refill-detail"        : "showRefillDetail",
      "click button.title-back-btn" : "goBack"
  },
  initialize: function () {
      var self = this;
      RXR.Data.View.RxList = RXR.Data.View.RxList || {};
      self.collection = new RXR.Collection.RxList({
          sortField: 'prescriptionName',
          sortDirection: 1
      });
      var fetch = function () {
          self.collection.fetch({
              headers: { 'Token': App_Utils.GetMHVToken() },
              cache: false,
              reset: true,
              success: function () {
                  RXR.Data.View.RxList.items = self.collection.toJSON(); // View Model
                  RXR.Data.View.RxList.totalCount = RXR.Data.View.RxList.items.length;
                  App.vent.trigger('rxlist:loaded');
              },
              error: function (model, response) {
                  App.vent.trigger('rxlist:failed');
              },
              complete: function () {
                  $('.link-items').removeClass('spinner-background');
              }
          });
      };
      if (App.EnterpriseToken) {
          fetch();
      }
      App.vent.on('enterpriseSession:loaded', function () {
          fetch();
      });

      App.vent.on('refill:success', function () {
          fetch();
      });

      self.collection.on('sync', self.render);
  },
    showRefillDetail: function(e) {
        var prescriptionId = $(e.currentTarget).data('id');

        $('#refillListContainer').addClass('hidden');
        this.headerRegion.empty();
        this.headerRegion.show(new Marionette.ItemView({
            template: RXR.Template.RxRefillDetailHeader
        }));
        this.detailRegion.empty();
        this.detailRegion.show(new RXR.View.RxRefillDetail({ id: prescriptionId }));
        this.detailView = true;
        document.title = 'Refillable VA Medications - Details';
    },
    goBack: function(e) {
        if (this.detailView) {
            this.detailRegion.empty();
            this.headerRegion.show(new Marionette.ItemView({
                template: RXR.Template.RxRefillHeader
            }));

            $('#refillListContainer').removeClass('hidden');
            this.detailView = false;
        }
        else {
            App_Utils.BackButton();
        }
    },
  sort: function(event) {
    event.preventDefault();
    event.stopPropagation();
    var $link = $(event.currentTarget);
    var sortOrder = $link.data('asc');
    var sortVal = $link.data("sort").toLowerCase();

    var $links = $('div.med-container');
    var $items = $('div.link-items');
    var sorted = _.sortBy($links, function (link) {
      return $(link).data(sortVal);
    });

    if (!sortOrder) {
      sorted.reverse();
    }
    $items.empty();
    $items.append(sorted);
    $('#sortBtn').dropdown('toggle');

    // set focus to list count
    setTimeout(function () {
        $('[data-toggle="popover"]').popover();
        $('.list-count').focus();
    }, 1200);
  },
  onDomRefresh: function () {
    $('[data-toggle="popover"]').popover();     // needed for 1st time page load
  },
  onRender: function () {
      this.$el.html(this.template(RXR.Data.View.RxList));
      App_Utils.FocusOnLoad();
      $('[data-toggle="popover"]').popover();
  },
  sortDropdownOpen: function () {
      App_Utils.SetSort('#refillListContainer');
  }
});
