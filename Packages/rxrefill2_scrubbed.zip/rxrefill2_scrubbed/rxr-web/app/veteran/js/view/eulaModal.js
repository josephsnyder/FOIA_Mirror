RXR.View.eulaModal = Backbone.Marionette.ItemView.extend({
    template: RXR.Template.eulaModal,
    events: {
        "click #eula-decline": "decline",
        "click #eula-accept": "accept",
        "shown.bs.modal #eula-modal" : "onModalShown",
        "hidden.bs.modal #eula-modal": "onModalHidden"
    },
    decline: function () {
        App_Utils.ReturnToLaunchpad();
    },
    accept: function () {
        App_Utils.SetLocalStorage('RXR_Eula', { accept_date: new Date().getTime() });
        App.vent.trigger('eula:accepted');
        this.hide();
    },
    show: function () {
        $("#eula-modal").modal("show");
        App.vent.trigger('eula:shown');
    },
    hide: function () {
        $("#eula-modal").modal("hide");
    },
    onRender: function () {
        this.$el.html(this.template(this.model));
    },
    onModalShown: function () {
        App_Utils.ModalContainerShown();
    },
    onModalHidden: function () {
        App_Utils.ModalContainerHidden();
    }
});