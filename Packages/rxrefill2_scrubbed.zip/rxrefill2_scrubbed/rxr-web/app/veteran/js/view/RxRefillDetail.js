RXR.View.RxRefillDetail = Backbone.Marionette.ItemView.extend({
  id        : null,
  template  : RXR.Template.refillDetail,
  collection: RXR.Collection.RxList,
  model     : RXR.Model.RxList,
  events    : {
      "click .requestRefill"        : "refillRequest",
      "click #refillPrescription"   : "refillPrescription",
      "shown.bs.modal #refillModal" : "onModalShown",
      "hidden.bs.modal #refillModal": "onModalHidden"
  },
  initialize: function(){
    var _self, model;
    RXR.Data.View.RxRefillDetail = {};
    RXR.Data.View.RxList = RXR.Data.View.RxList || {};
    _self = this;
    _self.id = parseInt(this.id);
    _self.collection = new RXR.Collection.RxList;
    _self.model = new RXR.Model.RxList({ id: this.id });

    var fetch = function () {
        if (_.isEmpty(RXR.Data.View.RxList.items)) {
            _self.collection.fetch({ 
                headers: { 'Token': App_Utils.GetMHVToken() },
                cache: false,
                reset: true
            });
            _self.collection.on('sync', function (collection) {
                model = _.first(collection.where({ prescriptionId: _self.id })) || {};
                RXR.Data.View.RxList.items = collection.toJSON();
                _.extend(RXR.Data.View.RxRefillDetail, model.toJSON());
                _self.render();
            });
        }
        else {
            model = _.first(_.where(RXR.Data.View.RxList.items, { prescriptionId: _self.id })) || {};
            _.extend(RXR.Data.View.RxRefillDetail, model);
        }
    };
    if (App.EnterpriseToken) {
        fetch();
    }
    App.vent.on('enterpriseSession:loaded', function () {
        fetch();
    });
  },
  refillRequest: function () {
      $('#refillModal').modal();
  },
  refillPrescription: function () {
      $('#refillModal').modal("hide");
      RXR.Layout.modal.empty();
      RXR.Layout.modal.show(RXR.Data.View.RequestRefillModal = new RXR.View.RequestRefillModal());
      RXR.Data.View.RequestRefillModal.show();
  },
  onDomRefresh: function () {
      $('[data-toggle="popover"]').popover();     // needed for 1st time page load
  },
  onRender: function(){
      $('[data-toggle="popover"]').popover();
      this.$el.html(this.template(RXR.Data.View.RxRefillDetail));
      //App_Utils.FocusOnLoad();
      setTimeout(function(){ App_Utils.FocusOnLoad(); }, 1000);
  },
  onModalShown: function () {
      App_Utils.MainModalShown();
  },
  onModalHidden: function () {
      App_Utils.MainModalHidden();
  }
});
