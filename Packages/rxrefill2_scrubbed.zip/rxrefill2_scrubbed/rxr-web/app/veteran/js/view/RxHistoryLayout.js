/*  NOTE:  this code is not stable and is not consistently displaying the data,
           and when exiting the page, the home page will not render.  The culprit
            seems to be related to the collectionEvent.
 */

RXR.View.RxHistoryLayout = Backbone.Marionette.LayoutView.extend({
    template: RXR.Template.RxHistoryLayout,
    //collection: RXR.Collection.RxHistory,
    detailView: false,
    regions: {
        'detailRegion': '#historyDetailContainer',
        'headerRegion': '#historyHeaderContainer',
        'listRegion': '#historyListContainer'
    },

    events: {
        "click .history-detail" : "showHistoryDetail",
        "click button.title-back-btn" : "goBack"
    },

    collectionEvents: {
        sync: 'onShow'
    },
    initialize: function() {
        this.collection = new RXR.Collection.RxHistory();

        var self = this;
        RXR.Data.View.RxHistory = RXR.Data.View.RxHistory || {};
        if (App.EnterpriseToken) {
            this.fetchRecords();
        }

        App.vent.on('enterpriseSession:loaded', function () {
            self.fetchRecords();
        });

    },
    goBack: function(e) {
        e.preventDefault();
        if (this.detailView) {
            this.detailRegion.empty();
            this.headerRegion.show(new Marionette.ItemView({
                template: RXR.Template.RxHistoryHeader
            }));
            $('#historyListContainer').removeClass('hidden');
            this.detailView = false;
            document.title = 'Prescription History';
        }
        else {
            // should never be here
            //App_Utils.BackButton();
            //App.route.navigate('home', { trigger: true });  this does not work!!
            // must call manually
            RXR.Layout.content.empty();
            RXR.Layout.content.show(new RXR.View.HomeLinks);
            document.title = 'Rx Refill Application';
        }
    },
    fetchRecords: function () {
        var self = this;
        this.collection.fetch({
            cache: false,
            reset: true,
            headers: {'Token': App_Utils.GetMHVToken()},
            success: function () {
                RXR.Data.View.RxHistory.items = self.collection.toJSON(); // View Model
                RXR.Data.View.RxHistory.totalCount = RXR.Data.View.RxHistory.items.length;
                // reset sort order on fetch
                RXR.Data.View.RxHistory.sortOrder = true;
                RXR.Data.View.RxHistory.sortColumn = 'refillDate';

                App.vent.trigger('history:loaded');
                this.showList();
            },
            error: function (model, response) {
                App.vent.trigger('history:failed');
            }
        });
    },
    showList: function() {
        if (this.detailView == false) {
            if (this.collection.length > 0) {
                this.listRegion.empty();
                this.listRegion.show(new RXR.View.RxHistoryEntries({
                    collection: this.collection,
                    childView: RXR.View.RxHistoryEntry
                }), {preventDestroy: true});

                $('#list-count').html(this.collection.length + ' Total Prescriptions');
            }
            else {
                this.listRegion.show(new Marionette.ItemView({
                    template: _.template('<p class="missing-record center">No records found.</p>')
                }));
            }
        }
    },
    showHistoryDetail: function(e) {
        var prescriptionId = $(e.currentTarget).data('id');

        $('#historyListContainer').addClass('hidden');
        this.headerRegion.empty();
        this.headerRegion.show(new Marionette.ItemView({
            template: RXR.Template.RxHistoryDetailHeader
        }));
        this.detailRegion.empty();
        this.detailRegion.show(new RXR.View.RxHistoryDetail({model: this.collection.get(prescriptionId)}));
        this.detailView = true;
        document.title = 'Prescription History - Details';
    },
    onShow: function() {
        if (this.detailView == false) {
            this.headerRegion.show(new Marionette.ItemView({
                template: RXR.Template.RxHistoryHeader
            }));
        }

        if (this.collection) {
            this.showList();
        }

        setTimeout(function () {
            App_Utils.FocusOnLoad();
            $('[data-toggle="popover"]').popover();
        }, 2000);
    },
    onDomRefresh: function () {
        $('[data-toggle="popover"]').popover();     // needed for 1st time page load
    }
});
