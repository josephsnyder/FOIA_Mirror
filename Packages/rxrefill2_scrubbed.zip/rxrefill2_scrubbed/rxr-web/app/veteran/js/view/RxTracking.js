RXR.View.RxTracking = Backbone.Marionette.LayoutView.extend({
  template  : RXR.Template.RxTrackingList,
  collection: RXR.Collection.RxTracking,
    detailView: false,
  events: {
    "click .dropdown-menu a" : "sort",
    "click #sortBtn"         : "sortDropdownOpen",
    "click .tracking-detail" : "showTrackingDetail",
      'click .title-back-btn'       : 'goBack'
  },
    regions: {
        'details': '#trackingDetailContainer',
        'header': '#trackingHeaderContainer'
    },
  initialize: function () {
      var self = this;
      RXR.Data.View.RxTracking = RXR.Data.View.RxTracking || {};
      /*
      var fetch = function () {
          self.collection.fetch({
              cache: false,
              reset: true,
              headers: { 'Token': App_Utils.GetMHVToken() },
              success: function () {
                  RXR.Data.View.RxTracking.items = self.collection.toJSON(); // View Model
                  RXR.Data.View.RxTracking.totalCount = RXR.Data.View.RxTracking.items.length;
                  App.vent.trigger('rxtracking:loaded');
              },
              error: function (model, response) {
                  App.vent.trigger('rxtracking:failed');
              },
              complete: function () {
                  $('.link-items').removeClass('spinner-background');
              }
          });
      };
      */

      if (App.EnterpriseToken) {
          this.fetchRecords();
      }
      App.vent.on('enterpriseSession:loaded', function () {
          self.fetchRecords();
      });

      self.collection.on('sync', self.render);
  },
    goBack: function() {
        if (this.detailView) {
            this.details.empty();
            this.header.show(new Marionette.ItemView({
                template: RXR.Template.RXTrackingListHeader
            }));

            $('#trackingListContainer').removeClass('hidden');
            this.detailView = false;
        }
        else {
            App_Utils.BackButton();
        }
    },
    showTrackingDetail: function(e) {
        console.log('In showTrackingDetail...');
        var rxId = $(e.currentTarget).data('id');

        $('#trackingListContainer').addClass('hidden');

        this.header.empty();
        this.header.show(new Marionette.ItemView({
            template: RXR.Template.RxTrackingDetailHeader
        }));
        this.details.empty();
        this.details.show(new RXR.View.RxTrackingDetail({id:rxId}));
        document.title = 'Track Delivery - Details';
        if (!App_Utils.GetLocalStorage('RXR_Important_Modal')) {
            $('#important-tracking-modal').modal('show');
            // delay modal display so that VO will announce it last
            setTimeout(function() {
                //this.modal('#important-tracking-modal');
                $('#important-tracking-label').focus();
            },500);
        }
        this.detailView = true;

        /*
         var selectedModel = new RXR.Collection.RxTrackingDetail({ id: this.id });
        selectedModel.fetch({
            cache: false,
            reset: true,
            headers: { 'Token': App_Utils.GetMHVToken() },
            success: function (response) {
                console.log('successful fetch of tracking detail', response);
                $('#trackingHeaderContainer').addClass('hidden');
                $('#trackingListContainer').addClass('hidden');

                _self.details.empty();
                //this.details.show(new RXR.View.RxTrackingDetail({model: selectedModel}));
                _self.details.show(new Marionette.ItemView({
                    template: RXR.Template.RxTrackingDetail,
                    model: selectedModel.toJSON()[0]
                }));
                _self.detailView = true;
            }
        });

        var selectedModel = new RXR.Model.RxTrackingDetail();
        var url = RXR_Data.RXRResources.get('trackingdetail').toJSON().href.replace("{rxId}",rxId);

        selectedModel.fetch({
            url: url,
            TYPE: 'GET',
            dataType: 'json',
            contentType: 'application/json',
            headers: { 'Token': App_Utils.GetMHVToken() },
            cache: false,
            reset: true,
            success: function(response) {
                console.log('successful fetch of tracking detail', response);
                _self.details.empty();
                //this.details.show(new RXR.View.RxTrackingDetail({model: selectedModel}));
                _self.details.show(new Marionette.ItemView({
                    template: RXR.Template.RxTrackingDetail,
                    model: selectedModel
                }));
                _self.detailView = true;
            }
        });
        */
    },
    fetchRecords: function() {
        var self = this;
        this.collection = new RXR.Collection.RxTracking({
            sortField: 'refillDate',
            sortDirection: 0
        });
        this.collection.fetch({
            cache: false,
            reset: true,
            headers: { 'Token': App_Utils.GetMHVToken() },
            success: function () {
                RXR.Data.View.RxTracking.items = self.collection.toJSON(); // View Model
                RXR.Data.View.RxTracking.totalCount = RXR.Data.View.RxTracking.items.length;

                // reset sort order on fetch
                RXR.Data.View.RxTracking.sortOrder = true;
                RXR.Data.View.RxTracking.sortColumn = 'refillDate';

                App.vent.trigger('rxtracking:loaded');
            },
            error: function (model, response) {
                App.vent.trigger('rxtracking:failed');
            },
            complete: function () {
                $('.link-items').removeClass('spinner-background');
            }
        });
    },
  sort: function(event) {
        event.preventDefault();
        event.stopPropagation();
        var $link = $(event.currentTarget);
        RXR.Data.View.RxTracking.sortOrder = $link.data('asc');
        RXR.Data.View.RxTracking.sortColumn = $link.data("sort").toLowerCase();

        this.sortList();
  },
    sortList: function() {
        var sortOrder = RXR.Data.View.RxTracking.sortOrder;
        var sortVal = RXR.Data.View.RxTracking.sortColumn;

        var $links = $('div.med-container');
        var $items = $('div.link-items');
        var sorted = _.sortBy($links, function (link) {
            return $(link).data(sortVal);
        });

        if (!sortOrder) {
            sorted.reverse();
        }
        $items.empty();
        $items.append(sorted);

        $('#sortBtn').dropdown('toggle');

        // set focus to list count
        setTimeout(function () {
            $('[data-toggle="popover"]').popover();
            $('.list-count').focus();
        }, 1200);
    },
  onDomRefresh: function () {
    $('[data-toggle="popover"]').popover();     // needed for 1st time page load
  },
  onRender: function () {
      var self = this;
      this.$el.html(this.template(RXR.Data.View.RxTracking));

      /*  not needed
      if (this.detailView == false) {
          $('#historyHeaderContainer').removeClass('hidden');
          this.header.show(new Marionette.ItemView({
              template: RXR.Template.RXTrackingListHeader
          }));
      }
      */

      setTimeout(function() {
          //if (RXR.Data.View.RxTracking.sortColumn) self.sortList();
          App_Utils.FocusOnLoad();
          $('[data-toggle="popover"]').popover();
      }, 1000);
  },

  sortDropdownOpen: function () {
      App_Utils.SetSort('#trackingListContainer');
  }
});
