// device APIs are available
//
function onDeviceReady() {
    // Register the event listener
    //document.addEventListener("backbutton", onBackKeyDown, false);
    //$.mobile.pushStateEnabled = false;
    //$.mobile.hashListeningEnabled = false;
}

function onBackKeyDown() {
    console.log("onBackKeyDown");
    if (RXR.Data.Tracking.isHome) {
        navigator.app.exitApp();
    } else {
        window.history.go(-1);
    }
}