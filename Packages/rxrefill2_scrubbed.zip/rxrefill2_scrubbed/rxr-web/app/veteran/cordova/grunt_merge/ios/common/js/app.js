"use strict";

var RXR = {
    "App": {},
    "Data": {},
    "View": {},
    "Model": {},
    "Router": {},
    "Template": {},
    "Collection": {}
};

RXR.App = Marionette.Application.extend({
    initialize: function (options) {
        RXR.Data = RXR_Data;
        RXR.Data.View = {};
        App_Utils.ErrorHandling();

        RXR.Data.Tracking = {};
        RXR.Data.Tracking.isHome = true;

        RXR.Data.Tracking.isRoaAccepted = false;
        RXR.Data.Tracking.isUserPressedCancelOnROA = false;
    }
});