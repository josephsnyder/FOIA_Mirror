RXR.View.layout = Marionette.LayoutView.extend({
  el        : "div.container-fluid",
  template  : RXR.Template.layout,
  regions   : {
    header  : "header",
    footer  : "footer",
    content: "section.content",
    modal: "section.modal-container",
    timeout: "section.timeout-container"
  },
    events: {
        "click #btnErrorClose"          : "onErrorClose"
    },
    onErrorClose: function() {
        App.vent.trigger('reset:error');
    },
    initialize: function () {
        window.addEventListener("offline", function(e) {
            App.vent.trigger('website:error', 'Your internet connection appears to be unavailable. Please try again when you regain connectivity.');
            //clearInterval(App.KeepAliveInterval);
        });

        window.addEventListener("online", function(e) {
            //RXR.View.TimeoutModal.start();
        });
    }
});
