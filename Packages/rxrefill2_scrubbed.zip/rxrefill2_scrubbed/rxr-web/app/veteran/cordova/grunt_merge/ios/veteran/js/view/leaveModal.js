RXR.View.leavingModal = Backbone.Marionette.ItemView.extend({
    template: RXR.Template.leaveModal,
    events: {
        "click #continue-leave"         : "leave",
        "click #displayModal"           : "modalSetting",
        "shown.bs.modal #leaving-modal" : 'onModalShown',
        'hidden.bs.modal #leaving-modal': 'onModalHidden'
    },
    leave: function () {
        console.log("Leave");
        //window.open($(App.CurrentEvent.currentTarget).attr("href"), $(App.CurrentEvent.currentTarget).attr("target"));
        window.open($(App.CurrentEvent.currentTarget).attr("href"), "_system");
        this.hide();
    },
    modalSetting: function (e) {
        if ($(e.currentTarget).is(':checked')) {
            App_Utils.SetLocalStorage('RXR_Leave_Modal', { date: new Date().getTime() });
        }
        else {
            App_Utils.DeleteLocalStorage('RXR_Leave_Modal');
        }
        $("#displayModal").focus();    
    },
    show: function () {
        $("#leaving-modal").modal("show");
        App.vent.trigger('leaving:shown');
    },
    hide: function () {
        $("#leaving-modal").modal("hide");
    },
    onRender: function () {
        this.$el.html(this.template(this.model));
    },
    onModalShown: function () {
        App_Utils.ModalContainerShown();
    },
    onModalHidden: function () {
        App_Utils.ModalContainerHidden();
    }
});