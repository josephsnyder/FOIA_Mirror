RXR.View.Links = Backbone.Marionette.ItemView.extend({
  template  : RXR.Template.links,
  initialize: function(){
      RXR.Data.View.Links = _.first(_.where(RXR.Data.app.links, { id: 2 }));
      if (!App_Utils.GetLocalStorage('RXR_Leave_Modal')) {
          RXR.Layout.modal.empty();
          RXR.Layout.modal.show(RXR.View.LeavingModal = new RXR.View.leavingModal());
      }
  },
  events: {
      "click a":"popoverClicked"
  },
  popoverClicked: function (e) {
      console.log("popoverclicked " + $(e.currentTarget).data('content'));
      App.CurrentEvent = e;
      if ($(e.target).attr('data-toggle')) { //cancel propogation if popover is clicked.
          e.stopPropagation();
          e.preventDefault();
          return false;
      }
      else if ($(e.currentTarget).data('content') == 'back') { // back button?
          window.open($(e.target).attr("href"), "_system");
          //return true;
      }
      else if (!App_Utils.GetLocalStorage('RXR_Leave_Modal')) {//show leaving modal if local storage setting does not exist.
          e.stopPropagation();
          e.preventDefault();
          RXR.View.LeavingModal.show();
      }
      else if ($(e.currentTarget).data('content') == 'exit') {  // user clicked external link
          window.open($(e.target).attr("href"), "_system");
          //return true;
      }
  },
  onRender: function () {
      this.$el.html(this.template(RXR.Data.View.Links));
      App_Utils.FocusOnLoad();
  }
});
