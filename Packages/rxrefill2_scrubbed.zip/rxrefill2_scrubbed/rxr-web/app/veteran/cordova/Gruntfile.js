module.exports = function(grunt) {
    var path;
    path = {
        libs: [
            'bower_components/modernizr/modernizr.js',
            'bower_components/jquery/dist/jquery.min.js',
            'bower_components/bootstrap/dist/js/bootstrap.min.js',
            'bower_components/underscore/underscore.js',
            'bower_components/backbone/backbone.js',
            'bower_components/marionette/lib/backbone.marionette.min.js',
            'bower_components/handlebars/handlebars.js',
            '_temp/common/lib/template_helpers.js',
            '_temp/common/lib/bootstrap-datepicker.min.js'
        ],
        css: [
            'bower_components/bootstrap/dist/css/bootstrap.css',
            'common/css/bootstrap-datepicker3.css',
            '_temp/common/css/**/*.css'
        ],
        veteran: [
            '_temp/common/js/app.js',
            '_temp/common/lib/resource_directory_util.js',
            '_temp/common/lib/LoginUtils.js',
            '_temp/common/lib/app_utils.js',
            '_temp/common/js/model/*.js',
            '_temp/common/js/collection/*.js',
            '_temp/common/_temp/app_json.js',
            '_temp/common/_temp/vet_templates.js',
            '_temp/common/js/view/*.js',
            '_temp/common/js/app.js',
            '_temp/veteran/js/view/*.js',
            '_temp/veteran/js/route.js',
            '_temp/veteran/js/app.js',
            '_temp/common/js/cordova.js'
        ],
        app: '../../../app',
        temp: '_temp',
        cordovaWeb: 'www',
        platforms: 'platforms',
        sourceDirs: [
            'common/css/**',
            'common/data/**',
            'common/js/**',
            'common/img/**',
            'common/lib/**',
            'common/sass/**',
            'veteran/audio/**',
            'veteran/video/**',
            'veteran/css/**',
            'veteran/font/**',
            'veteran/img/**',
            'veteran/js/**',
            'veteran/index.html'
        ],
        appDependencies: [
            '**'
        ]
    };

    grunt.initConfig({
        clean: {
            cordova: {
                src: [
                    path.temp,
                    path.cordovaWeb,
                    path.platforms
                ]
            }
        },

        copy: {
            source: {
                files: [
                    {
                        expand: true,
                        cwd: path.app,
                        src: [
                            path.sourceDirs
                        ],
                        dest: path.temp
                    },
                    { expand: true, cwd: path.app, src:'bower.json', dest:'.' }
                ]
            },

            veteran_build: {
                files: [
                    {src: path.temp + '/veteran/index.html', dest: path.temp + '/veteran/_build/index.html'},
                    {expand: true, flatten: true, src: path.temp + '/veteran/css/*', dest: path.temp + '/veteran/_build/css/'},
                    {expand: true, flatten: true, src: path.temp + '/veteran/fonts/*', dest: path.temp + '/veteran/_build/fonts/'},
                    {expand: true, flatten: true, src: path.temp + '/common/img/*', dest: path.temp + '/veteran/_build/img/'},
                    {expand: true, flatten: true, src: path.temp + '/veteran/js/*', dest: path.temp + '/veteran/_build/js/'},
                    {expand: true, flatten: true, src: path.temp + '/veteran/audio/*', dest: path.temp + '/veteran/_build/audio/'},
                    {expand: true, flatten: true, src: path.temp + '/veteran/video/*', dest: path.temp + '/veteran/_build/video/'},
                    {expand: true, flatten: true, src: path.temp + '/common/data/*', dest: path.temp + '/veteran/_build/'},
                    {expand: true, flatten: true, src: 'bower_components/bootstrap/fonts/*', dest: path.temp + '/veteran/_build/fonts/'},
                    {src:'bower_components/bootstrap/dist/css/bootstrap.css.map', dest: path.temp + '/veteran/_build/css/bootstrap.css.map'}
                ]
            },

            grunt_merge_android: {
                files: [
                    {expand: true, cwd: 'grunt_merge/android', src: '**', dest: path.temp + '/'},
                    {expand: true, cwd: path.temp + '/veteran', src: '**', dest: path.temp + '/veteran/_build'}
                ]
            },

            grunt_merge_ios: {
                files: [
                    {expand: true, cwd: 'grunt_merge/ios', src: '**', dest: path.temp + '/'},
                    {expand: true, cwd: path.temp + '/veteran', src: '**', dest: path.temp + '/veteran/_build'}
                ]
            },

            copy_ios_build_files: {
                files: [
                    {src: 'build.gradle', dest: path.platforms + '/ios/build.gradle'},
                    {src: 'RX_Refill.mobileprovision', dest: path.platforms + '/ios/RX_Refill.mobileprovision'},
                    {src: 'VACertificates.p12', dest: path.platforms + '/ios/VACertificates.p12'},
                    {src: 'gradlew', dest: path.platforms + '/ios/gradlew'}
                ]
            },

            setup: {
                files: [
                    {
                        expand: true,
                        cwd: path.temp + '/veteran/_build',
                        src: [
                            path.appDependencies
                        ],
                        dest: path.cordovaWeb
                    }
                ]
            },

            signing_config: {
                files: [
                    {src: 'grunt_merge/android/ant.properties', dest: 'platforms/android/ant.properties'},
                    {src: 'grunt_merge/android/release-signing.properties', dest: 'platforms/android/release-signing.properties'},
                    {src: 'grunt_merge/android/android.jks', dest: 'platforms/android/android.jks'}
                ]
            }
        },

        shell: {
            addCordovaPlugins: {
                command: 'node tasks/plugins.js'
            },
            platformAddAndroid: {
                command: 'cordova platform add android'
            },
            platformAddIos: {
                command: 'cordova platform add ios'
            },
            prepareAndroid: {
                command: 'cordova prepare android'
            },
            prepareIos: {
                command: 'cordova prepare ios'
            },
            buildAndroidDebug: {
                command: 'cordova build android'
            },
            buildAndroidRelease: {
                //TODO: setup release keystore stuff...
                command: 'cordova build android --release'
            },
            buildIosDebug: {
                command: 'cordova build ios'
            },
            buildIosRelease: {
                command: 'cordova build ios'
            }
        },

        concat: {
            veteran: {
                src: path.css,
                dest: path.temp + '/veteran/_build/css/lib.css'
            }
        },
        handlebars: {
            veteran: {
                options: {
                    namespace: 'RXR.Template',
                    processName: function(filePath){
                        var fileName = filePath.match(/.*\/([a-zA-Z0-9\_\-]+)\.html$/);
                        return fileName[1];
                    }
                },
                files: {
                    "_temp/common/_temp/vet_templates.js": [path.temp + "/common/js/template/*.html", path.temp + "/veteran/js/template/*.html"]
                }
            }
        },
        sass: {
            veteran: {
                files: [{
                    expand: true,
                    cwd: path.temp + '/common/sass',
                    src: ['app.scss'],
                    dest: path.temp + '/veteran/_build/css',
                    ext: '.css'
                }]
            }
        },
        json: {
            app: {
                options: {
                    namespace: 'RXR_Data',
                    includePath: false
                },
                src: ['_temp/common/data/app.json', '_temp/common/data/resource_directory.json'],
                dest: '_temp/common/_temp/app_json.js'
            }
        },
        uglify: {
            options: {
                mangle: false
            },
            vet_libs: {
                files: {
                    '_temp/veteran/_build/js/libs.js': path.libs
                }
            },
            veteran: {
                files: {
                    '_temp/veteran/_build/js/app.js': path.veteran
                }
            }
        },
        connect: {
            veteran: {
                options: {
                    base: 'www',
                    port: 3001
                }
            }
        },
        watch:{
            androidApp: {
                files: 'grunt_merge/android/common/js/**/*',
                tasks: ['copy:grunt_merge_android', 'handlebars', 'uglify', 'copy:Setup']
            },
            iosApp: {
                files: 'grunt_merge/ios/common/js/**/*',
                tasks: ['copy:grunt_merge_ios', 'handlebars', 'uglify', 'copy:setup']
            },
            iosAppVeteran: {
                files: 'grunt_merge/ios/veteran/**/*',
                tasks: ['copy:grunt_merge_ios', 'handlebars', 'uglify', 'copy:setup']
            },
            androidscss: {
                files: 'grunt_merge/android/common/sass/**/*',
                tasks: ['copy:grunt_merge_android', 'sass', 'uglify', 'copy:Setup']
            },
            iosscss: {
                files: 'grunt_merge/ios/common/sass/**/*',
                tasks: ['copy:grunt_merge_ios', 'sass', 'uglify', 'copy:Setup']
            }
        },

        // STRING-REPLACE
        'string-replace': {
            // resource urls to use IP addresses so this can be tested on phones (cannot modify host file on devices)
            devResourceUrl: {
                options: {
                    replacements: [
                        {
                            pattern: /:\/\/vet-test.DOMdomaindomain.ext/ig,
                            replacement: function (match, p1, offset, string) {
                                return '://127.000.000.1';
                            }
                        }
                    ]
                },
                src: 'www/js/app.js',
                dest: 'www/js/app.js'
            },
            // update the version code stored in AndroidManifest.xml
            androidVersionCode: {
                options: {
                    replacements: [
                        {
                            pattern: /android-versionCode=['"](\d*)['"]/ig,
                            replacement: function (match, p1, offset, string) {
                                var buildNum = grunt.option('buildNum');
                                return 'android-versionCode="' + buildNum + '"';
                            }
                        }
                    ]
                },
                files: {
                    'config.xml': 'config.xml'
                }
            },
            // update the version name stored in AndroidManifest.xml
            androidVersionName: {
                options: {
                    replacements: [
                        {
                            pattern: /version=['"](\d*).(\d*).(\d*)['"]/ig,
                            replacement: function (match, p1, offset, string) {
                                var buildNum = grunt.option('buildNum');
                                return 'version="1.0.' + buildNum + '"';
                            }
                        }
                    ]
                },
                files: {
                    'config.xml': 'config.xml'
                }
            }
        }
    });

    grunt.loadNpmTasks('grunt-json');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-connect');
    grunt.loadNpmTasks('grunt-contrib-handlebars');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-shell');
    grunt.loadNpmTasks('grunt-string-replace');

    grunt.registerTask('useForce', '', function(){
        if(!grunt.option('force')){
            grunt.option('force', true);
        }
    });

    var envEndpointUrl = '';
    grunt.registerTask('setEnvUrl', function(buildType) {
        var devEndpoint = 'vet-test.DOMdomaindomain.ext/';
        var sqaEndpoint = 'vet-int.DOMdomaindomain.ext/';
        var prodEndpoint = 'veteran.DOMdomaindomain.ext/';

        if(buildType === 'prod'){
            envEndpointUrl = prodEndpoint
        }else if(buildType === 'sqa'){
            envEndpointUrl = sqaEndpoint
        }else {
            envEndpointUrl = devEndpoint
        }
    });

    grunt.registerTask('updateAppData', function () {
        var projectFile = "_temp/common/data/app.json";
        if (!grunt.file.exists(projectFile)) {
            grunt.log.error("file " + projectFile + " not found");
            return true;//return false to abort the execution
        }
        var json = grunt.file.readJSON(projectFile);

        // update the last-update-date field in the app.json
        json['last-update-date'] = grunt.template.today("mm/dd/yy");

        // update the appConfig.environment field in the app.json
        json['appConfig'].environment = envEndpointUrl;

        grunt.file.write(projectFile, JSON.stringify(json, null, 2));
    });

    grunt.registerTask('setupCordovaIos', ['clean', 'copy:source', 'copy:veteran_build', 'copy:grunt_merge_ios', 'updateAppData', 'concat', 'sass', 'handlebars', 'json', 'uglify', 'copy:setup']);
    grunt.registerTask('buildIosDebug', ['useForce', 'setEnvUrl:dev', 'setupCordovaIos', 'shell:addCordovaPlugins', 'shell:platformAddIos', 'shell:prepareIos', 'shell:buildIosDebug']);
    grunt.registerTask('buildIosReleaseSQA', ['useForce', 'setEnvUrl:sqa', 'setupCordovaIos', 'shell:addCordovaPlugins', 'shell:platformAddIos', 'shell:prepareIos', 'shell:buildIosRelease', 'copy:copy_ios_build_files']);
    grunt.registerTask('buildIosReleaseProd', ['useForce', 'setEnvUrl:prod', 'setupCordovaIos', 'shell:addCordovaPlugins', 'shell:platformAddIos', 'shell:prepareIos', 'shell:buildIosRelease', 'copy:copy_ios_build_files']);
    grunt.registerTask('serveIos', ['setEnvUrl:dev', 'setupCordovaIos', 'connect', 'watch']);
};