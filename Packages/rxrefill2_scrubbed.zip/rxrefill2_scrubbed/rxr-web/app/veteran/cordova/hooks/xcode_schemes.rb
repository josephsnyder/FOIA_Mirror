#!/usr/bin/env ruby
require 'xcodeproj'
xcproj = Xcodeproj::Project.open("platforms/ios/RX Refill.xcodeproj")
xcproj.recreate_user_schemes
xcproj.save