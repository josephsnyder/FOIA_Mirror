module.exports = function(grunt) {

    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
		
		/*
		 * Directories and dependencies
		 */
		dirs: {
			build: '_build',
            modules: 'node_modules',                            // Grunt modules, gitignored
			components: 'bower_components',						// managed by Bower, gitignored
			dependencies: [									// external dependencies, gitignored
                'backbone/backbone.js',
                'bootstrap/dist/css/bootstrap.min.css',
                'bootstrap/dist/fonts/**',
                'bootstrap/dist/js/bootstrap.min.js',
                'handlebars/handlebars.js',
                'jquery-2.1.0.min/index.js',
                'underscore/underscore-min.js',
                'underscore/underscore-min.map'             // suppress 404
			],
			testDependencies: [
                'jasmine/lib/jasmine-core/**',
                'sinonjs/sinon.js',
                'jasmine-sinon/lib/jasmine-sinon.js',
                'jasmine-jquery/lib/jasmine-jquery.js'
			],
			tomcat: '../tomcat'
		},

        /*
         * Miscellaneous variables used in this config, e.g. server port numbers
         */
        vars: {
            tomcat_usr: 'xxxxx',                                // Tomcat Console admin user
            tomcat_port: 8080,                                  // Default Tomcat port
            static_port: 9000                                   // Static Grunt sever for AAP
        },
		
		/*
        concat: {
            // Configuration for concatinating files goes here.
        }
		*/
		
		/*
		 * Clean out /app directory with options. Running "clean" (with no specific sub-task) essentially removes
		 * all dependencies not tracked by git, e.g. /_build, /bower_components, /node_modules, /js/libs/**.
		 *
		 * @build: Remove dirs.build before build process to ensure fresh content.
		 * @libs: Remove everything under js/libs in working directory (there should not be any manually checked-in files).
		 * @npm: Remove /bower_components, /node_modules.
		 */
		 clean: {
			 build: {
				src: ['<%= dirs.build %>'] 
			 },
             libs: {
               src: [
                   'js/libs/*/**',
                   '!js/libs/.gitkeep'
               ]
             },
			 npm: {
				src: [
                    '<%= dirs.components %>/**',
                    '<%= dirs.modules %>/**'
                ]
			 }
		 },

		/*
		 * Copy all needed files to root directory for frontend development. Assume dirs.components exists.
		 *
		 * @dev: Copy external dependencies into local working directories.
		 * @build: Copy external dependencies into build directory.
		 */
		copy: {
			dev: {
				files: [
				{
					// Copy needed external dependencies from bower_components to js/libs
					expand: true,
					flatten: false,
					nonull: true,
					cwd: '<%= dirs.components %>',
					src: [
						'<%= dirs.dependencies %>', '<%= dirs.testDependencies %>'
					],
					/*
					rename: function (dest, src) {
						return dest + src.replace('index.js', 'jquery.js');
					},*/
					dest: 'js/libs/'
				}
				]
			},
			build: {
				files: [
				{
					// Copy needed external dependencies from dirs.components to dirs.build/js/libs
					// TODO: uglify/concate for production
					expand: true,
					flatten: false,
					nonull: true,
					cwd: '<%= dirs.components %>',
					src: [
						'<%= dirs.dependencies %>', '<%= dirs.testDependencies %>'
					],
					dest: '<%= dirs.build %>/js/libs/'
				},
				{
					// Copy /img and all html files to build
					// TODO: imagemin and uglify for production
					expand: true,
					nonull: true,
					cwd: '.',
					src: [
						'css/**',
						'img/**',
						'js/**',
						'!js/libs',						// get fresh dependencies from dirs.components
						'*.html'                   // this file should be under js/models
					],
					dest: '<%= dirs.build %>'
				}
				]
			},
			build_release: {
				files: [
					{
						// Copy needed external dependencies from dirs.components to dirs.build/js/libs
						// TODO: uglify/concate for production
						expand: true,
						flatten: false,
						nonull: true,
						cwd: '<%= dirs.components %>',
						src: [
							'<%= dirs.dependencies %>'
						],
						dest: '<%= dirs.build %>/js/libs/'
					},
					{
						// Copy /img and all html files to build
						// TODO: imagemin and uglify for production
						expand: true,
						nonull: true,
						cwd: '.',
						src: [
							'css/**',
							'img/**',
							'js/**',
							'!js/libs',						// get fresh dependencies from dirs.components
							'!js/tests/**',					//remove unit test from servers
							'index.html'                   // this file should be under js/models
						],
						dest: '<%= dirs.build %>'
					}
				]
			}
		},
		
		/*
		 * Run Maven target to build Tomcat container.
		 * This should NOT be part of the daily build.
		 */
		 shell: {
			tomcat: {
				options: {
					stdout: true,
					execOptions: {
						cwd: '<%= dirs.tomcat %>'
					}
				},
				command: 'mvn install'			// run maven script
			}
		 },
		
		/*
		 * Build a WAR file for Tomcat deployment from the dirs.build folder.
		 * Do not use 'tomcat_war' from grunt-tomcat-deploy which has limited configuration.
		 * .war will be created inside the dirs.build folder.
		 */
		war: {
			target: {
				options: {
					war_dist_folder: '<%= dirs.build %>',    			// Folder where to generate the WAR
					war_name: '<%= pkg.name %>',     					// aap.war will be generated               	
					war_verbose: true,
					webxml_welcome: 'index.html',
					webxml_display_name: 'Ask a Pharmacist (AAP)'
				},
				files: [
				{
					// Most direct way... may eventually want to uglify/concate some of these files
                    // links.json is not expected to be at root but should be under js/models
					expand: true,
					cwd: '<%= dirs.build %>',
					src: ['css/*', 'img/*', 'js/**', '*.html'],       // data files should be in js/models
					dest: ''
				}
				]
			}
		},

        /*
         * Static web server at http://localhost:9000/.
         * -> Depends on 'watch'.
         */
        connect: {
            server: {
                options: {
                    port: '<%= vars.static_port %>',
                    base: '.'
                }
            }
        },

        /*
         * Watch and copy updated files to static web server, etc.
         * -> Works with 'connect'.
         */
		watch: {
			options: {
				dataFormat: function(time) {
					grunt.log.writeln('The watch finished in ' + time + 'ms at ' + (new Date()).toString() + '\n' +
                        'Waiting...\n');
				}
			}
			
			// may eventually want to watch for specific file patterns and run other tasks, e.g. uglify, imagemin...
			// TODO: livereload (need browser plugins)
			
		} // watch

    });

    //grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-clean');
	grunt.loadNpmTasks('grunt-contrib-connect');
	grunt.loadNpmTasks('grunt-contrib-copy');
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.loadNpmTasks('grunt-newer');
	grunt.loadNpmTasks('grunt-shell');
	grunt.loadNpmTasks('grunt-tomcat-deploy');
	grunt.loadNpmTasks('grunt-war');

	// Development: connect static server, copy any new external dependencies to working dir, watch for updates
    grunt.registerTask('default', ['connect', 'newer:copy:dev', 'watch']);

    // Build war: delete build dir and recreate folder for war assembly
    grunt.registerTask('war_build', ['clean:build', 'clean:libs', 'copy:build', 'war']);

	// Build war: delete build dir and recreate folder for war assembly
	grunt.registerTask('war_build_release', ['clean:build', 'clean:libs', 'copy:build_release', 'war']);

    // Deploy war: build and [re]deploy to Tomcat; assume Tomcat is running
    grunt.registerTask('war_deploy', ['war_build', 'tomcat_redeploy']);
	
	// Install Tomcat container - requires manual processing after task is run
	grunt.registerTask('tomcat_install', ['shell:tomcat']);
};