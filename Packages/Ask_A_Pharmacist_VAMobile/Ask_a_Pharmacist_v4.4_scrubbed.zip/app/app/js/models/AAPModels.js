"use strict";
AAP.BaseModel = Backbone.Model.extend({});

AAP.resourceLink = Backbone.Model.extend({
    idAttribute: "title",
    defaults: {
        "rel": "external",
        "title": "",
        "href": "",
        "object-type": ""
    }
});