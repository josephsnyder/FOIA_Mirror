"use strict";
window.AAP = window.AAP || {
    init: function (json) {
        AAP.EulaAccepted = false;
        //get data
        AAP.appData = json; //This is our apps data.
        //create the router
        AAP.router = new AAP.Router();
        //for routing purposes
        Backbone.history.start();
        AAP.Resources = new AAP.ResourcesCollection();
        var footerData = { //build data
            "developed-by": AAP.appData.about["developed-by"],
            "address": AAP.appData.address,
            "app-version": AAP.appData["app-version"],
            "last-update-date": AAP.appData["last-update-date"],
        };
        var navigationData = { //build data
            "app-name": AAP.appData["app-name"],
            "links": AAP.appData.navigation
        };
        AAP.appData.banner.returnURL = AAP.Resources.get('launchpad-link').get('href');
        AAP.banner = new AAP.BannerView({ model: new AAP.BaseModel(AAP.appData.banner) }); //Create the banner
        AAP.footer = new AAP.FooterView({ model: new AAP.BaseModel(footerData) }); //Create the footer
        AAP.navigation = new AAP.NavigationView({ model: new AAP.BaseModel(navigationData) }); //Create the Nav
        checkLocalStorage();
        setAria();
        if(AAP.EulaAccepted)
        {
            $('#mainContent').removeClass('hidden');
        }
        AAP.userAuthenticated();

        $(document).on('shown.bs.dropdown', function(event) {
            var dropdown = $(event.target);

            // Set aria-expanded to true and remove the hidden attribute
            dropdown.find('.dropdown-menu').attr('aria-expanded', true);
            dropdown.find('.dropdown-menu').removeAttr('aria-hidden');

            // Set focus on the first link in the dropdown
            setTimeout(function() {
                dropdown.find('.dropdown-menu li:first-child a').focus();
            }, 10);
        });
        // On dropdown close
        $(document).on('hidden.bs.dropdown', function(event) {
            var dropdown = $(event.target);

            // Set aria-expanded to false and hidden to true
            dropdown.find('.dropdown-menu').attr('aria-expanded', false);
            dropdown.find('.dropdown-menu').attr('aria-hidden', true);

            // Set focus back to dropdown toggle
            dropdown.find('.dropdown-toggle').focus();
        });

        //close quick navigation when item is selected
        $("a.quickNavigation").click(function() {
            $("#quickNavDropdown").removeClass("open");
        });
        $(document).on("click", function(event){
            $("#quickNavDropdown").removeClass("open");
        });
        $(".link-container").on("click", function(event){
            $("#quickNavDropdown").removeClass("open");
        });
        $(".link-title").on("click", function(event){
            $("#quickNavDropdown").removeClass("open");
        });



    },
    start: function () {
        //get the global json file
        $.getJSON(urlPath() + "js/models/AAP.json", function (json) {
            //initiallize the app
            AAP.init(json);
        });
    },

    userAuthenticated: function () {
        var token = AAP.getSessionToken();
        if ((token != null && token != '"null"') && token.length > 1) {
            AAP.userSession(token);
        }
        else {
            AAP.userLogout();
        }
    },
    userSession: function (token) {
        $.ajax({
            type: "GET",
            beforeSend: function (request) {
                request.setRequestHeader('Authorization', 'Bearer ' + AAP.cleanToken(token));
            },
            headers: {
                Accept: "application/json; charset=utf-8",
                "Content-Type": "application/json; charset=utf-8"
            },
            url: AAP.Resources.get("public-user-session").toJSON().href,
            contentType: "application/json",
            success: function (data, status) {
                AAP.appData.banner.user = {};
                AAP.appData.banner.user.authenticated = true;
                AAP.appData.banner.user.firstName = data.mhpuser.firstName;
                AAP.appData.banner.user.lastName = data.mhpuser.lastName;
                AAP.banner.model = new AAP.BaseModel(AAP.appData.banner);
                AAP.banner.render();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                AAP.clearSessionToken();
                AAP.userLogout();
            }
        });
    },
    userLogout: function () {
        var token = AAP.getSessionToken();
        if ((token != null && token != '"null"') && token.length > 1) {
            $.ajax({
                type: "DELETE",
                beforeSend: function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + AAP.cleanToken(token));
                },
                url: AAP.Resources.get("token").get('href'),
                success: function (data, status) {
                    AAP.clearSessionToken();
                    AAP.deleteCookie('JSESSIONID');
                    window.location = AAP.Resources.get('logout').get('href') + '?' + new Date().getTime() + '&redirect_uri=' + AAP.getReferencePath();
                }
            });
        }
        AAP.appData.banner.user = {};
        AAP.appData.banner.user.authenticated = false;
        AAP.appData.banner.user.firstName = "";
        AAP.appData.banner.user.lastName = "";
        AAP.banner.model = new AAP.BaseModel(AAP.appData.banner);
        AAP.banner.render();
    },
    getSessionToken: function () {
        return sessionStorage.getItem('token');
    },
    clearSessionToken: function () {
        sessionStorage.setItem('token', '"null"');
    },
    cleanToken: function (token) {
        return token.replace(/"/g, "");
    },
    getDomainPath: function () {
        if (document.location.hostname == "localhost") {
            return AAP.getReferencePath();
        }
        else {
            return window.location.protocol + "//" + window.location.host + "/";
        }
    },
    getReferencePath: function () {
        if (document.location.hostname == "localhost") {
            return "https://vet-test.mobilehealth.domain/";
        }
        else {
            var referencePath = window.location.protocol + "//" + window.location.host + window.location.pathname;
            var index = referencePath.indexOf("index.html");
            if (index !== -1) {
                referencePath = referencePath.substring(0, index);
            }
            return referencePath;
        }
    },
    deleteCookie: function (cookieName) {
	    document.cookie = encodeURIComponent(cookieName) + "=deleted; expires=" + new Date(0).toUTCString();
    }
}

AAP.Router = Backbone.Router.extend({
    routes: {
        "": "index",
        "rx-refill-and-pharmacy-services": "MHV",
        "pill-and-bottle-information": "PBI",
        "trusted-medication-resources": "TMR",
        "about-va-pharmacies": "AVP",
        "track-my-medications": "TMM",
        "medication-articles": "MA",
        "drug-interactions": "DI",
        "consumer-drug-herbal-supplement-information": "CDHSI",
        "PillBottle": "PillBottle",
        "KnowYourMedicationLabel": "KnowYourMedicationLabel",
        "VANationalFormulary": "VANationalFormulary",
        "HowVAHelpsVeterans": "HowVAHelpsVeterans",
        "HowVAPharmaciesOperate": "HowVAPharmaciesOperate",
        "drug-interaction-articles": "DIA",
        "adverse-drug-event-information": "ADEI",
        "safety-articles": "SafetyArticles",
        "medications": "Medications",
        "reporting-medication-errors": "ReportingMedicationErrors",
        "safety-practices": "SafetyPractices",
        '*notFound': 'notFound'
    },

    buildView: function (id) {
        AAP.index = new AAP.PageLinksView({
            collection: new AAP.LinkCollection(AAP.appData, { id: id, parse: true })
        });
        $(".navbar-brand").focus();
        setTimeout(function () { $('[data-toggle="popover"]').popover(); }, 500);
    },

    index: function () {
        AAP.index = new AAP.HomeLinksView({
            collection: new AAP.LinkCollection(AAP.appData, { id: 1, parse: true })
        });
        setTimeout(function () { $('[data-toggle="popover"]').popover(); }, 500);
        document.title = 'Ask A Pharmacist';
    },

    HowVAPharmaciesOperate: function () {
        AAP.content = new AAP.ContentView({ url: urlPath() + "js/templates/HowVAPharmacyOperate.html" });
        $(".navbar-brand").focus();
        document.title = 'How Do VA Pharmacies Operate?';
        $("#quickNavDropdown").removeClass("open");
    },

    VANationalFormulary: function () {
        AAP.content = new AAP.ContentView({ url: urlPath() + "js/templates/VANationalFormulary.html" });
        $(".navbar-brand").focus();
        document.title = 'Veterans Affairs (VA) National Formulary - Frequently Asked ';
        $("#quickNavDropdown").removeClass("open");
    },

    HowVAHelpsVeterans: function () {
        AAP.content = new AAP.ContentView({ url: urlPath() + "js/templates/HowVAPharmacistHelpVeterans.html" });
        $(".navbar-brand").focus();
        document.title = 'How VA Pharmacist Help Veterans';
        $("#quickNavDropdown").removeClass("open");
    },

    PillBottle: function () {
        AAP.content = new AAP.ContentView({ url: urlPath() + "js/templates/PillBottle.html" });
        $(".navbar-brand").focus();
        document.title = 'Pill Bottle Information';
        $("#quickNavDropdown").removeClass("open");
    },

    KnowYourMedicationLabel: function () {
        AAP.content = new AAP.ContentView({ url: urlPath() + "js/templates/KnowYourMedicationLabel.html" });
        $(".navbar-brand").focus();
        document.title = 'Know your Medication Label';
        $("#quickNavDropdown").removeClass("open");
    },

    MHV: function () { this.buildView(2); document.title = 'Prescription Refill and Pharmacy Services'; $("#quickNavDropdown").removeClass("open");},

    PBI: function () { this.buildView(3); document.title = 'Pill and Bottle Information'; $("#quickNavDropdown").removeClass("open");},

    TMR: function () { this.buildView(4); document.title = 'VA Trusted Medication Resources'; $("#quickNavDropdown").removeClass("open");},

    AVP: function () { this.buildView(5); document.title = 'About VA Pharmacies'; $("#quickNavDropdown").removeClass("open");},

    TMM: function () { this.buildView(6); document.title = 'Track My Medications'; $("#quickNavDropdown").removeClass("open");},

    MA: function () { this.buildView(7); document.title = 'Medication Articles on My HealtheVet';$("#quickNavDropdown").removeClass("open"); },

    DI: function () { this.buildView(8); document.title = 'Drug Interactions and Adverse Drug Events'; $("#quickNavDropdown").removeClass("open");},

    CDHSI: function () { this.buildView(9); document.title = 'Consumer Drug, Herbal & Supplement Information'; $("#quickNavDropdown").removeClass("open");},

    DIA: function () { this.buildView(10); document.title = 'Drug Interaction Information'; $("#quickNavDropdown").removeClass("open");},

    ADEI: function () { this.buildView(11); document.title = 'Adverse Drug Event Information'; $("#quickNavDropdown").removeClass("open");},

    SafetyArticles: function () { this.buildView(12); document.title = 'Get the latest Safety Articles on Medications';$("#quickNavDropdown").removeClass("open"); },

    Medications: function () { this.buildView(13); document.title = 'Medications';$("#quickNavDropdown").removeClass("open"); },

    ReportingMedicationErrors: function () { this.buildView(14); document.title = 'Reporting Medication Errors';$("#quickNavDropdown").removeClass("open"); },

    SafetyPractices: function () { this.buildView(15); document.title = 'Safety Practices';$("#quickNavDropdown").removeClass("open"); },

    notFound: function () {
        AAP.notFound = new AAP.NotFound({ model: new AAP.BaseModel(AAP.appData["not-found"]) });
    }
});