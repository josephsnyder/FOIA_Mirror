"use strict";
AAP.BaseView = Backbone.View.extend({
    initialize: function () {     
        this.render($(this.template));
    },
    render: function () {
        var template = Handlebars.compile($(this.template).html());
        this.$el.html(template(this.model.toJSON()));
        return this;
    }
});

AAP.LinkCollectionView = Backbone.View.extend({
    initialize: function () {
        this.collection.bind("reset", this.render, this);
        this.collection.bind("add", this.render, this);
        this.collection.bind("remove", this.render, this);
        var data = {};
        if (this.collection.models[0]) {
            data = this.collection.models[0].attributes.title
        }
        AAP.pageTitle = new AAP.PageTitleView({ model: new AAP.BaseModel({ title: data }) }); //Create the Title
        this.render();
    },
    render: function () {
        var self = this;
        var els = [];
        this.collection.each(function (item) {
            var itemView = new self.ItemView({ model: item, className: self.className, tagName: self.tagName });
            els.push(itemView.render().el);
        });
        this.$el.html(els);
        return this;
    }
});

AAP.LinkView = AAP.BaseView.extend({
    initialize: function () {
        $("#aap-link, #aap-content").empty();
        $('[data-toggle="popover"]').popover();
    },
    template: "#linkTempate",
    tagName: (this.tagName ? this.tagName : "div"),
    className: (this.className ? this.className : ""),
    events: {
        "click a": "externalWarning"
    },
    externalWarning: function (event) {
        externalLink(event);
    }
});

AAP.LeaveModalView = Backbone.View.extend({
    initialize: function () {
        this.render($(this.template));
    },
    el: "#aap-leave-modal",
    template: "#aapLeaveModal",
    events: {
        "click #aapLeave": "leaveAAP",
        "click #aapStay": "stayAAP",
        "change #displayModal": "modalSetting"
    },
    leaveAAP: function () {
        $('#aap-modal').modal('hide');
        window.location = this.model.attributes.url;
    },
    stayAAP: function () {
        $('#aap-modal').modal('hide');
    },
    modalSetting: function (event) {
        var object = { show: ($(event.currentTarget).is(':checked') ? false : true), timestamp: new Date().getTime() }
        localStorage.setItem('AAP_Modal', JSON.stringify(object));
        $("#displayModal").focus();
    },
    render: function () {
        var template = Handlebars.compile($(this.template).html());
        this.$el.html(template(this.model.toJSON()));
        modalFocus('#aap-modal');
        return this;
    }
});

AAP.HomeLinksView = AAP.LinkCollectionView.extend({
    el: "#aap-link",
    className: "home row",
    tagName: "div",
    ItemView: AAP.LinkView
});

AAP.PageLinksView = AAP.LinkCollectionView.extend({
    el: "#aap-link",
    className: "page row",
    tagName: "div",
    ItemView: AAP.LinkView
});

AAP.BannerView = AAP.BaseView.extend({
    events: {
        "click #logout": "logout"
    },
    logout: function () {     
        AAP.userLogout();
    },
    el: "#bannerContainer",
    template: "#bannerTemplate"
});

AAP.FooterView = AAP.BaseView.extend({
    el: "#footerContainer",
    template: "#footerTemplate"
});

AAP.PageTitleView = AAP.BaseView.extend({
    el: "#aap-page-title",
    template: "#pageTitleTemplate"
});

AAP.NotFound = AAP.BaseView.extend({
    initialize: function () {
        $("#aap-link, #aap-content").empty();
        AAP.pageTitle = new AAP.PageTitleView({ model: new AAP.BaseModel({ title: this.model.attributes.title }) }); //Create the Title
        this.render();
    },
    el: "#aap-content",
    template: "#notFoundTemplate"
});

AAP.NavigationView = AAP.BaseView.extend({
    el: "#aap-nav",
    template: "#aapNavigation",
    events: {
        "click nav": "test",
        "click .nav li a[data-external]": "externalWarning",
        "click .navbar-toggle": "mobileNav",
        "click .navbar a[data-click]": "modal",
        "click .phone-nav li a": "collapseNav",
        "click .navbar-nav li a.dropdown-toggle": "toggleNav",
        "click .dropdown-menu li a": "closeOpenNav"
    },
    closeOpenNav: function () {
        $(".navbar-nav li a.dropdown-toggle").trigger('click');       
    },
    toggleNav: function (event) {
        var state = $(event.target).attr('aria-expanded');
        state === 'false' ? state = true : state = false;
        $(event.target).attr('aria-expanded', state);
    },
    collapseNav: function () {
        $(".navbar-toggle").click();
    },
    externalWarning: function (event) {
        externalLink(event);
    },
    mobileNav: function () {
        $('#aap-navbar').on('show.bs.collapse', function () {
            if ($(".menu-backdrop").length < 1) {
                $('body').append('<div class="menu-backdrop fade in"></div>')
            }
        });
        $('#aap-navbar').on('hide.bs.collapse', function () {
            $('.menu-backdrop').remove()
        });
    },
    modal: function (event) {
        var data = {};
        var help = AAP.appData.help;
        var about = AAP.appData.about;
        var id = $(event.currentTarget).text();
        if (id == 'About') {
            data = about;
            data.title = id;
        }
        if (id == 'Help') {
            data = help;
            data.title = id;
        }
        AAP.contentModal = new AAP.ModalView({ model: new AAP.BaseModel(data) }); //Create the Modal
        modalFocus('#aap-modal-content');
    }
});

AAP.ModalView = AAP.BaseView.extend({
    events: {
        "click a": "closeModal"
    },
    closeModal: function () {
        $('#aap-modal-content').modal('hide');
    },
    el: "#aap-content-modal",
    template: "#aapModal"
});

AAP.EULAModalView = AAP.BaseView.extend({
    events: {
        "click #acceptEulaBtn": "acceptEula",
        "click #declineEulaBtn": "declineEula",
        "click #eulaOkBtn": "eulaOk"
    },
    acceptEula: function () {
        localStorage.setItem('AAP_Eula', JSON.stringify({ show: false, timestamp: new Date().getTime() }));
        $('#eula-modal').modal('hide');
        AAP.EulaAccepted = true;
        $('#mainContent').removeClass('hidden');
    },
    declineEula: function () {
        AAP.EulaAccepted = false;
        window.location = AAP.getDomainPath() + "launchpad";
    },
    eulaOk: function () {
        $('#eula-declined-modal').modal('hide');
        AAP.EulaAccepted = false;
    },
    el: "#aap-content-modal",
    template: "#eulaModal"
});

AAP.ContentView = Backbone.View.extend({
    el: "#aap-content",
    events: {
        "click a[data-external]": "externalWarning"
    },
    initialize: function (options) {
        $("#aap-page-title, #aap-link").empty();
        this.url = options.url;
        this.render();
    },
    externalWarning: function (event) {
        externalLink(event);
    },
    render: function () {     
        var html = $.ajax({ type: "GET", url: this.url, async: false }).responseText;
        this.$el.html(html);
        return this;
    }
});
