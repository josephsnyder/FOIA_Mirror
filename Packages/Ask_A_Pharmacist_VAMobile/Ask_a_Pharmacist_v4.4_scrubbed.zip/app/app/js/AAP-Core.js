﻿//If a title is blank do not show element
Handlebars.registerHelper('unless_blank', function (item, block) {
    return (item && item.replace(/\s/g, "").length) ? block.fn(this) : block.inverse(this);
});

//If html is in string convert it.
Handlebars.registerHelper('HTML', function (string) {
    return (string ? new Handlebars.SafeString(string) : '')
});

Handlebars.registerHelper('modalMessage', function (val) {
    return (val === true ? "- Opens a simulated dialog" : "");
});

Handlebars.registerHelper('ifequal', function (val1, val2, options) {
    var context = (options.fn.contexts && options.fn.contexts[0]) || this;
    if (val1 === val2) {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
});

Handlebars.registerHelper("inc", function (value, options) {
    return parseInt(value) + 8;
});

externalLink = function (event) {
    event.stopPropagation();
    event.preventDefault();
    if ($(event.target).attr('data-toggle')) { return false; }  
    var userPref = (JSON.parse(localStorage.getItem('AAP_Modal'))).show;
    var userMsg = $(event.currentTarget).data('modal-warning') ? $(event.currentTarget).data('modal-warning') : '';
    var data = {
        showModal: ((userMsg.length > 0) ? true : userPref),
        url: $(event.currentTarget).attr('href'),
        msg: userMsg
    };
    if (data.showModal && $(event.currentTarget).data('external')) {
        AAP.leaveModalView = new AAP.LeaveModalView({ model: new AAP.BaseModel(data) });
    }
    else { window.location = data.url; }
}

checkLocalStorage = function () {
    if (_.isNull(localStorage.getItem('AAP_Modal'))) {
        localStorage.setItem('AAP_Modal', JSON.stringify({ show: true, timestamp: new Date().getTime() }));
    }
    else {
        var timestamp = (JSON.parse(localStorage.getItem('AAP_Modal'))).timestamp;
        var tsYesterday = new Date();
        tsYesterday.setDate(tsYesterday.getDate() - 1)
        var yesterday = tsYesterday.getTime();
        if(yesterday > timestamp) {
            localStorage.setItem('AAP_Modal', JSON.stringify({show: true, timestamp: new Date().getTime()}));
        }
    }
    if (_.isNull(localStorage.getItem('AAP_Eula'))) {
        AAP.eulaModal = new AAP.EULAModalView({ model: new AAP.BaseModel({}) }); //Create the Modal
        modalFocus('#eula-modal');
    }
    else{
        AAP.EulaAccepted =true;
    }
}

var scripts = document.getElementsByTagName("script"),
    src = scripts[scripts.length - 1].src;

urlPath = function () {    
    var url = src.substring(0, src.indexOf("/js"));
    return url.length > 1 ? url + '/' : '/';
}

modalFocus = function (obj) {
    AAP.lastFocus = document.activeElement;
    $(obj).modal('show');
    $(obj).on('shown.bs.modal', function (e) {       
        $(e.target).focus();
        $(".container-fluid").attr('aria-hidden', 'true');
        $(".modal-backdrop").attr('aria-hidden', 'true');
    });
    $(obj).on('hidden.bs.modal', function (e) {
        $(".container-fluid").attr('aria-hidden', 'false');
        $(".modal-backdrop").attr('aria-hidden', 'false');
        AAP.lastFocus.focus();
    });
}

    var setAria = function () {
        AAP.width = $(document).width();
        if (AAP.width < 768){
            $('#phone-nav').removeAttr('aria-hidden');     // do not add aria-hidden="false"
            $('#tablet-nav').attr('aria-hidden','true');
            $('#navbarHamburgerBtn').removeAttr('aria-hidden');
        }
        else {
            $('#tablet-nav').removeAttr('aria-hidden');      // do not add aria-hidden="false"
            $('#phone-nav').attr('aria-hidden', 'true');
            $('#navbarHamburgerBtn').attr('aria-hidden', 'true');
        }
    };

    setTimeout(function() {
        setAria();
    } ,500);

    $(document).ready(function () {
        setAria();
        ($(".scrollbar-gradient").length < 1) ? $('body').append('<div class="scrollbar-gradient"><div>') : false;
        $(window).on('resize scroll', function () {
            if ($(window).scrollTop() + $(window).height() == $(document).height() && $(".scrollbar-gradient:visible")) {
                $(".scrollbar-gradient").hide();
            }
            else {
                if ($(".scrollbar-gradient:hidden")) {
                    $(".scrollbar-gradient").show();
                }
            }
            (AAP.width != $(document).width()) ? setAria() : false;

    });


    var hasScrollbar = function () {
        // The Modern solution
        if (typeof window.innerWidth === 'number')
            return window.innerWidth > document.documentElement.clientWidth

        // rootElem for quirksmode
        var rootElem = document.documentElement || document.body

        // Check overflow style property on body for fauxscrollbars
        var overflowStyle

        if (typeof rootElem.currentStyle !== 'undefined')
            overflowStyle = rootElem.currentStyle.overflow

        overflowStyle = overflowStyle || window.getComputedStyle(rootElem, '').overflow

        // Also need to check the Y axis overflow
        var overflowYStyle

        if (typeof rootElem.currentStyle !== 'undefined')
            overflowYStyle = rootElem.currentStyle.overflowY

        overflowYStyle = overflowYStyle || window.getComputedStyle(rootElem, '').overflowY

        var contentOverflows = rootElem.scrollHeight > rootElem.clientHeight
        var overflowShown = /^(visible|auto)$/.test(overflowStyle) || /^(visible|auto)$/.test(overflowYStyle)
        var alwaysShowScroll = overflowStyle === 'scroll' || overflowYStyle === 'scroll'

        return (contentOverflows && overflowShown) || (alwaysShowScroll)
    }
    hasScrollbar() ? $(".scrollbar-gradient").show() : $(".scrollbar-gradient").hide();
    $('body').on('click', '.header-container #backArrow', function () {
        if (Backbone.history) {
            Backbone.history.history.back();
        }
    });
});