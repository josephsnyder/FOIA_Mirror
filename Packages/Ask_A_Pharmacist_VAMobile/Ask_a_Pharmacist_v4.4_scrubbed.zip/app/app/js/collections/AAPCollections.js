AAP.LinkCollection = Backbone.Collection.extend({
    model: AAP.BaseModel,
    initialize: function (data, options) {
        this.id = options.id;
    },
    parse: function (response) {
        var id = this.id;
        var obj = {};
        _.each(response, function (key, value) {
            if (value === "links") {
                _.each(key, function (item) {
                    if (item.id === id) {
                        obj = item;
                    }
                });
            }
        });    
        return obj;
    }
});

AAP.ResourcesCollection = Backbone.Collection.extend({
    model: AAP.resourceLink,
    url: function(){
        return AAP.getDomainPath() + "MobileHealthPlatformWeb/rest/public/resource-directory"; //Kicks-off dynamic URIs
    },
    parse: function (response) {
        return response.link;
    },
    initialize: function () {
        this.fetch({async: false, global: true});
    }
});