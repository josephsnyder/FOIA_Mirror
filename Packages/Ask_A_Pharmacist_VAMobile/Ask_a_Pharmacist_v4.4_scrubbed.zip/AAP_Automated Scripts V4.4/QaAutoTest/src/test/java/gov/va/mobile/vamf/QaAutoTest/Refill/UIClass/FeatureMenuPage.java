package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class FeatureMenuPage {
	public static WebDriver driver;
	
	public FeatureMenuPage(WebDriver driver){
		FeatureMenuPage.driver = driver;
	}
	
	
	
	public RefillableVAMedicationPage clickRefillableVAMedications() throws Exception{
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[contains(text(),'Refillable VA Medications')])[2]")).click();
		Thread.sleep(3000);
		
		return new RefillableVAMedicationPage(driver);
	}
	
	public TrackDeliveryPage clickTrackDelivery() throws Exception{
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[contains(text(),'Track Delivery')])[2]")).click();
		Thread.sleep(3000);
		
		return new TrackDeliveryPage(driver);
	}
	
	public PrescriptionHistoryPage clickPrescriptionHistory() throws Exception{
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[contains(text(),'Prescription History')])[2]")).click();
		Thread.sleep(3000);
		
		return new PrescriptionHistoryPage(driver);
	}
	
	public LinkModulePage clickLinks() throws Exception{
		driver.findElement(By.xpath("(//a[contains(text(),'Links')])[2]")).click();
		Thread.sleep(3000);
		
		return new LinkModulePage(driver);
	}
	
	public FeatureMenuPage clickAbout() throws Exception{
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[contains(text(),'About')])[2]")).click();
		Thread.sleep(3000);
		
		return new FeatureMenuPage(driver);
	}
	
	public FeatureMenuPage clickHelp() throws Exception{
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//a[contains(text(),'Help')])[2]")).click();
		Thread.sleep(3000);
		
		return new FeatureMenuPage(driver);
	}
}
