package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverFallsDetailsPage {
private static WebDriver driver; 
	
//Sitting Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-1']")
		public WebElement click_SittingDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[1]/a")
		public WebElement click_SittingDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")
		public WebElement click_SittingDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")
		public WebElement click_SittingDropdown1Value; 
		
//Arises Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-2']")
		public WebElement click_ArisesDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[1]/a")
		public WebElement click_ArisesDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")
		public WebElement click_ArisesDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")
		public WebElement click_ArisesDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")
		public WebElement click_ArisesDropdown2Value; 

//Arising Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-3']")
		public WebElement click_ArisingDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[1]/a")
		public WebElement click_ArisingDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")
		public WebElement click_ArisingDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")
		public WebElement click_ArisingDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")
		public WebElement click_ArisingDropdown2Value; 
				
//Standing 5 seconds Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-4']")
		public WebElement click_Standing5SecondsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[1]/a")
		public WebElement click_Standing5SecondsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")
		public WebElement click_Standing5SecondsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")
		public WebElement click_Standing5SecondsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")
		public WebElement click_Standing5SecondsDropdown2Value; 
				
				
//Standing Section ======================================================================================================

		@FindBy(how = How.XPATH, using = ".//*[@id='falls-dropdown-5']")
		public WebElement click_StandingDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[1]/a")
		public WebElement click_StandingDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")
		public WebElement click_StandingDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")
		public WebElement click_StandingDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")
		public WebElement click_StandingDropdown2Value; 
		
		
//Stability Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-6']")
		public WebElement click_StabilityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[1]/a")
		public WebElement click_StabilityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[2]/a")
		public WebElement click_StabilityDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[3]/a")
		public WebElement click_StabilityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[4]/a")
		public WebElement click_StabilityDropdown2Value; 
		
//Visual Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-7']")
		public WebElement click_VisualDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[1]/a")
		public WebElement click_VisualDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[2]/a")
		public WebElement click_VisualDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[3]/a")
		public WebElement click_VisualDropdown1Value; 				
	
//Turning Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-8']")
		public WebElement click_TurningDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[1]/a")
		public WebElement click_TurningDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[2]/a")
		public WebElement click_TurningDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[3]/a")
		public WebElement click_TurningDropdown1Value; 
		

//Sitting down Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='falls-dropdown-9']")
		public WebElement click_SittingDownDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[1]/a")
		public WebElement click_SittingDownDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[2]/a")
		public WebElement click_SittingDownDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[3]/a")
		public WebElement click_SittingDownDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[4]/a")
		public WebElement click_SittingDownDropdown2Value; 

		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverFallsDetailsPage(WebDriver driver){
			CaregiverFallsDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Falls Details Title
	     */
	    public CaregiverFallsDetailsPage verifyFallsDetailsTitle() throws Exception{
	    	Thread.sleep(1000);
	    	assertEquals("Falls Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Falls Details Text
	     */
	    public CaregiverFallsDetailsPage verifyFallsDetailsText() throws Exception{
	    	Thread.sleep(1000);
	    	assertEquals("The details provided here will help us to understand your father's current Falls.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverFallsDetailsPage(driver);
	    }
	    
//Sitting Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Sitting Label
		 */
		public CaregiverFallsDetailsPage verifySittingLabel() throws Exception{
			assertEquals("Sitting", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Sitting drop down.
		 */
		public CaregiverFallsDetailsPage click_SittingDropdown() throws Exception{
			Thread.sleep(1000);
			click_SittingDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Sitting category Select an option drop down value for Sitting
	    */
		public CaregiverFallsDetailsPage verifySittingSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-1']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Sitting Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_SittingDropdownSelectAnOptionValue() throws Exception{
			click_SittingDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Sitting category 0 value
		*/
		public CaregiverFallsDetailsPage verifySittingSelection0() throws Exception{
			assertEquals("0 - Leans or slides in chair", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Sitting 0 value
		 */
		public CaregiverFallsDetailsPage click_SittingDropdown0Value() throws Exception{
			click_SittingDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Sitting category 1 value
		*/
		public CaregiverFallsDetailsPage verifySittingSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Steady", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Sitting 1 value
		 */
		public CaregiverFallsDetailsPage click_SittingDropdown1Value() throws Exception{
			click_SittingDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
	    
//Arises Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Arises Label
		 */
		public CaregiverFallsDetailsPage verifyArisesLabel() throws Exception{
			assertEquals("Arises", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Arises drop down.
		 */
		public CaregiverFallsDetailsPage click_ArisesDropdown() throws Exception{
			Thread.sleep(1000);
			click_ArisesDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Arises category Select an option drop down value for Arises
	    */
		public CaregiverFallsDetailsPage verifyArisesSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-2']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Arises Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_ArisesDropdownSelectAnOptionValue() throws Exception{
			click_ArisesDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Arises category 0 value
		*/
		public CaregiverFallsDetailsPage verifyArisesSelection0() throws Exception{
			assertEquals("0 - Unable", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Arises 0 value
		 */
		public CaregiverFallsDetailsPage click_ArisesDropdown0Value() throws Exception{
			click_ArisesDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Arises category 1 value
		*/
		public CaregiverFallsDetailsPage verifyArisesSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Uses arms", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Arises 1 value
		 */
		public CaregiverFallsDetailsPage click_ArisesDropdown1Value() throws Exception{
			click_ArisesDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Arises category 2 value
		*/
		public CaregiverFallsDetailsPage verifyArisesSelection2() throws Exception{
			assertEquals("2 - Able no arms", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Arises 2 value
		 */
		public CaregiverFallsDetailsPage click_ArisesDropdown2Value() throws Exception{
			click_ArisesDropdown2Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
//Arising Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Arising Label
		 */
		public CaregiverFallsDetailsPage verifyArisingLabel() throws Exception{
			assertEquals("Arising", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Arising drop down.
		 */
		public CaregiverFallsDetailsPage click_ArisingDropdown() throws Exception{
			Thread.sleep(1000);
			click_ArisingDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Arising category Select an option drop down value for Arising
	    */
		public CaregiverFallsDetailsPage verifyArisingSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-3']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Arising Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_ArisingDropdownSelectAnOptionValue() throws Exception{
			click_ArisingDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Arising category 0 value
		*/
		public CaregiverFallsDetailsPage verifyArisingSelection0() throws Exception{
			assertEquals("0 - Unable", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Arising 0 value
		 */
		public CaregiverFallsDetailsPage click_ArisingDropdown0Value() throws Exception{
			click_ArisingDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Arising category 1 value
		*/
		public CaregiverFallsDetailsPage verifyArisingSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - More than one attempts", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Arising 1 value
		 */
		public CaregiverFallsDetailsPage click_ArisingDropdown1Value() throws Exception{
			click_ArisingDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Arising category 2 value
		*/
		public CaregiverFallsDetailsPage verifyArisingSelection2() throws Exception{
			assertEquals("2 - Able first time", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Arising 2 value
		 */
		public CaregiverFallsDetailsPage click_ArisingDropdown2Value() throws Exception{
			click_ArisingDropdown2Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
			
//Standing 5 seconds Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Standing 5 seconds Label
		 */
		public CaregiverFallsDetailsPage verifyStanding5SecondsLabel() throws Exception{
			assertEquals("Standing 5 seconds", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Standing 5 seconds drop down.
		 */
		public CaregiverFallsDetailsPage click_Standing5SecondsDropdown() throws Exception{
			Thread.sleep(1000);
			click_Standing5SecondsDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Standing 5 seconds category Select an option drop down value for Standing5Seconds
	    */
		public CaregiverFallsDetailsPage verifyStanding5SecondsSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-4']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Standing 5 seconds Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_Standing5SecondsDropdownSelectAnOptionValue() throws Exception{
			click_Standing5SecondsDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Standing 5 seconds category 0 value
		*/
		public CaregiverFallsDetailsPage verifyStanding5SecondsSelection0() throws Exception{
			assertEquals("0 - Unsteady", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Standing 5 seconds 0 value
		 */
		public CaregiverFallsDetailsPage click_Standing5SecondsDropdown0Value() throws Exception{
			click_Standing5SecondsDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Standing5Seconds category 1 value
		*/
		public CaregiverFallsDetailsPage verifyStanding5SecondsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Steady with support", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Standing5Seconds 1 value
		 */
		public CaregiverFallsDetailsPage click_Standing5SecondsDropdown1Value() throws Exception{
			click_Standing5SecondsDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Standing5Seconds category 2 value
		*/
		public CaregiverFallsDetailsPage verifyStanding5SecondsSelection2() throws Exception{
			assertEquals("2 - Steady no support", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Standing5Seconds 2 value
		 */
		public CaregiverFallsDetailsPage click_Standing5SecondsDropdown2Value() throws Exception{
			click_Standing5SecondsDropdown2Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
//Standing Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Standing Label
		 */
		public CaregiverFallsDetailsPage verifyStandingLabel() throws Exception{
			assertEquals("Standing", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Standing drop down.
		 */
		public CaregiverFallsDetailsPage click_StandingDropdown() throws Exception{
			Thread.sleep(1000);
			click_StandingDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Standing category Select an option drop down value for Standing
	    */
		public CaregiverFallsDetailsPage verifyStandingSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-5']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Standing Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_StandingDropdownSelectAnOptionValue() throws Exception{
			click_StandingDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Standing category 0 value
		*/
		public CaregiverFallsDetailsPage verifyStandingSelection0() throws Exception{
			assertEquals("0 - Unsteady", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Standing 0 value
		 */
		public CaregiverFallsDetailsPage click_StandingDropdown0Value() throws Exception{
			click_StandingDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Standing category 1 value
		*/
		public CaregiverFallsDetailsPage verifyStandingSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Steady with wide base", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Standing 1 value
		 */
		public CaregiverFallsDetailsPage click_StandingDropdown1Value() throws Exception{
			click_StandingDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Standing category 2 value
		*/
		public CaregiverFallsDetailsPage verifyStandingSelection2() throws Exception{
			assertEquals("2 - Steady narrow base", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Standing 2 value
		 */
		public CaregiverFallsDetailsPage click_StandingDropdown2Value() throws Exception{
			click_StandingDropdown2Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
			
//Stability Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Stability Label
		 */
		public CaregiverFallsDetailsPage verifyStabilityLabel() throws Exception{
			assertEquals("Stability", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Stability drop down.
		 */
		public CaregiverFallsDetailsPage click_StabilityDropdown() throws Exception{
			Thread.sleep(1000);
			click_StabilityDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Stability category Select an option drop down value for Stability
	    */
		public CaregiverFallsDetailsPage verifyStabilitySelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-6']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Stability Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_StabilityDropdownSelectAnOptionValue() throws Exception{
			click_StabilityDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Stability category 0 value
		*/
		public CaregiverFallsDetailsPage verifyStabilitySelection0() throws Exception{
			assertEquals("0 - Falls easily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Stability 0 value
		 */
		public CaregiverFallsDetailsPage click_StabilityDropdown0Value() throws Exception{
			click_StabilityDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Stability category 1 value
		*/
		public CaregiverFallsDetailsPage verifyStabilitySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Catches self", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Stability 1 value
		 */
		public CaregiverFallsDetailsPage click_StabilityDropdown1Value() throws Exception{
			click_StabilityDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Stability category 2 value
		*/
		public CaregiverFallsDetailsPage verifyStabilitySelection2() throws Exception{
			assertEquals("2 - Steady", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Stability 2 value
		 */
		public CaregiverFallsDetailsPage click_StabilityDropdown2Value() throws Exception{
			click_StabilityDropdown2Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
//Visual Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Visual Label
		 */
		public CaregiverFallsDetailsPage verifyVisualLabel() throws Exception{
			assertEquals("Visual", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Visual drop down.
		 */
		public CaregiverFallsDetailsPage click_VisualDropdown() throws Exception{
			Thread.sleep(1000);
			click_VisualDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Visual category Select an option drop down value for Visual
	    */
		public CaregiverFallsDetailsPage verifyVisualSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-7']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Visual Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_VisualDropdownSelectAnOptionValue() throws Exception{
			click_VisualDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Visual category 0 value
		*/
		public CaregiverFallsDetailsPage verifyVisualSelection0() throws Exception{
			assertEquals("0 - Needs visual", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Visual 0 value
		 */
		public CaregiverFallsDetailsPage click_VisualDropdown0Value() throws Exception{
			click_VisualDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Visual category 1 value
		*/
		public CaregiverFallsDetailsPage verifyVisualSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Does not need visual", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Visual 1 value
		 */
		public CaregiverFallsDetailsPage click_VisualDropdown1Value() throws Exception{
			click_VisualDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
//Turning Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Turning Label
		 */
		public CaregiverFallsDetailsPage verifyTurningLabel() throws Exception{
			assertEquals("Turning", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Turning drop down.
		 */
		public CaregiverFallsDetailsPage click_TurningDropdown() throws Exception{
			Thread.sleep(1000);
			click_TurningDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Turning category Select an option drop down value for Turning
	    */
		public CaregiverFallsDetailsPage verifyTurningSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-8']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Turning Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_TurningDropdownSelectAnOptionValue() throws Exception{
			click_TurningDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Turning category 0 value
		*/
		public CaregiverFallsDetailsPage verifyTurningSelection0() throws Exception{
			assertEquals("0 - Unsteady or discontinuous steps", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Turning 0 value
		 */
		public CaregiverFallsDetailsPage click_TurningDropdown0Value() throws Exception{
			click_TurningDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Turning category 1 value
		*/
		public CaregiverFallsDetailsPage verifyTurningSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Steady/continuous steps", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Turning 1 value
		 */
		public CaregiverFallsDetailsPage click_TurningDropdown1Value() throws Exception{
			click_TurningDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
//Sitting down Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Sitting down Label
		 */
		public CaregiverFallsDetailsPage verifySittingDownLabel() throws Exception{
			assertEquals("Sitting down", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[1]/label")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Sitting down drop down.
		 */
		public CaregiverFallsDetailsPage click_SittingDownDropdown() throws Exception{
			Thread.sleep(1000);
			click_SittingDownDropdown.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Sitting down category Select an option drop down value for SittingDown
	    */
		public CaregiverFallsDetailsPage verifySittingDownSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='falls-dropdown-9']")).getText());
			return new CaregiverFallsDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Sitting down Select an option drop value
		 */
		public CaregiverFallsDetailsPage click_SittingDownDropdownSelectAnOptionValue() throws Exception{
			click_SittingDownDropdownSelectAnOptionValue.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Sitting down category 0 value
		*/
		public CaregiverFallsDetailsPage verifySittingDownSelection0() throws Exception{
			assertEquals("0 - Unsafe (misjudges)", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Sitting down 0 value
		 */
		public CaregiverFallsDetailsPage click_SittingDownDropdown0Value() throws Exception{
			click_SittingDownDropdown0Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify SittingDown category 1 value
		*/
		public CaregiverFallsDetailsPage verifySittingDownSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Uses arms/not smooth", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SittingDown 1 value
		 */
		public CaregiverFallsDetailsPage click_SittingDownDropdown1Value() throws Exception{
			click_SittingDownDropdown1Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SittingDown category 2 value
		*/
		public CaregiverFallsDetailsPage verifySittingDownSelection2() throws Exception{
			assertEquals("2 - Safe/smooth motion", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SittingDown 2 value
		 */
		public CaregiverFallsDetailsPage click_SittingDownDropdown2Value() throws Exception{
			click_SittingDownDropdown2Value.click();
			return new CaregiverFallsDetailsPage(driver);
		}

//Buttons Section ===================================================================================================================
		
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverFallsDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverFallsDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverFallsDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverFallsDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverFallsDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverFallsDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverFallsDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverFallsDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverFallsDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverFallsDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverFallsDetailsPage click_ContinueButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverFallsDetailsPage(driver);
	    }
	    
//Popup section.
		/**
		 * This method is used to verify Cancel Popup message and No and yes buttons button.
		 */
		public CaregiverFallsDetailsPage verifyCancelPopupMessage() throws Exception{
			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on No button on popup message on Cancel
		 */
		public CaregiverFallsDetailsPage click_NoButtonOnCancelPopup() throws Exception{
			click_NoButtonOnPopup.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to click on Yes button on popup message on Cancel
		*/
		public CaregiverFallsDetailsPage click_YesButtonOnCancelPopup() throws Exception{
		click_YesButtonOnPopup.click();
		return new CaregiverFallsDetailsPage(driver);
		}
			    
		/**
		 * This method is used to verify Continue Popup message and No and yes buttons button.
		 */
		public CaregiverFallsDetailsPage verifyContinuePopupMessage() throws Exception{
			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
			return new CaregiverFallsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on No button on popup message on Cancel
		 */
		public CaregiverFallsDetailsPage click_NoButtonOnContinuePopup() throws Exception{
			click_NoButtonOnPopup.click();
			return new CaregiverFallsDetailsPage(driver);
		}
		
		/**
		* This method is used to click on Yes button on popup message on Cancel
		*/
		public CaregiverFallsDetailsPage click_YesButtonOnContinuePopup() throws Exception{
		click_YesButtonOnPopup.click();
		return new CaregiverFallsDetailsPage(driver);
		}

		    /**
		 * This method is used to verify Reset Popup message for Reset button.
		 */
		public CaregiverFallsDetailsPage verifyResetPopupMessage() throws Exception{
			driver.switchTo().alert();
			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
			return new CaregiverFallsDetailsPage(driver);
		}
		 /**
		 * This method is used to close Reset Popup message for Reset button.
		 */
		public CaregiverFallsDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
		driver.switchTo().alert();
		click_ResetPopupMessageCloseIcon.click();
		return new CaregiverFallsDetailsPage(driver);
		}
		
}
	    
