package gov.va.mobile.vamf.QaAutoTest.AAP.UITest;

import static org.junit.Assert.*;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.AboutVAPharmaciesPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.ConsumerDrugHerbalSupplementInformationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.HomePage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.LandingPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.LoginPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.PillBottleInformationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.RecallsMarketWithdrawalsSafetyAlertsonFDAPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.TrustedMedicationResoucePage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.USFoodAndDrugAdministrationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.MyHealthVetPharmacyServicesPage;

import org.junit.*;
import org.junit.runners.MethodSorters;

import java.io.File;
import java.io.FileInputStream;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.thoughtworks.selenium.webdriven.commands.IsTextPresent;

/*
 *  Smoke Test for AAP Application
 *  
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AAPSmokeTest {
	//declare Objects - Webdriver, LoginPage Object & variables
	static WebDriver driver;
	LandingPage newLandingPage;
	LoginPage newLoginPage;
	HomePage newHomePage;
	AboutVAPharmaciesPage newAboutVAPharmaciesPage;
	MyHealthVetPharmacyServicesPage newmyHealthVetPharmacyServicesPage;
	TrustedMedicationResoucePage newTrustedMedicationResoucePage;
	ConsumerDrugHerbalSupplementInformationPage newConsumerDrugHerbalSupplementInformationPage;
	RecallsMarketWithdrawalsSafetyAlertsonFDAPage newRecallsMarketWithdrawalsSafetyAlertsonFDAPage; //Please work on the pop up
	PillBottleInformationPage newPillBottleInformationPage;
	USFoodAndDrugAdministrationPage newUSFoodAndDrugAdministrationPage;
	String vURL, UserName, Password, Browser;
	
	private boolean acceptNextAlert = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	@Before
	
	public void SetUP()throws Exception{
		//initialize Objects
		
		//driver = new FirefoxDriver();
		
		//driver = new SafariDriver();
		
		File file = new File(System.getProperty("user.dir")+ "//ExtDependencies//IEDriverServer.exe");
		
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		driver = new InternetExplorerDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		newLandingPage = PageFactory.initElements(driver, LandingPage.class);
		newHomePage = PageFactory.initElements(driver, HomePage.class);
		newLoginPage = PageFactory.initElements(driver, LoginPage.class);
		newAboutVAPharmaciesPage = PageFactory.initElements(driver, AboutVAPharmaciesPage.class);
		newmyHealthVetPharmacyServicesPage = PageFactory.initElements(driver, MyHealthVetPharmacyServicesPage.class);
		newTrustedMedicationResoucePage = PageFactory.initElements(driver, TrustedMedicationResoucePage.class);
		newConsumerDrugHerbalSupplementInformationPage = PageFactory.initElements(driver, ConsumerDrugHerbalSupplementInformationPage.class);
		newRecallsMarketWithdrawalsSafetyAlertsonFDAPage = PageFactory.initElements(driver, RecallsMarketWithdrawalsSafetyAlertsonFDAPage.class);
		newPillBottleInformationPage = PageFactory.initElements(driver, PillBottleInformationPage.class); 
		newUSFoodAndDrugAdministrationPage = PageFactory.initElements(driver, USFoodAndDrugAdministrationPage.class); 
		
		//load data from resource file
		Properties properties = new Properties();
		String path = System.getProperty("user.dir")+ "//src//test//resources//datafile//data.properties";
		
		FileInputStream fs = new FileInputStream(path);
		properties.load(fs);
			
			UserName = properties.getProperty("UserName");
			Password = properties.getProperty("Password");
			vURL = properties.getProperty("URL");
			Browser = properties.getProperty("Browser");		
			
		System.out.println("Test started");
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		}
	
	

	/*
	 * The following test is related to the Manual Test Case # TS-AAP-103 Verify Multiple page app and Home button - link
	 * Test Purpose: As an AAP Team Member, I want to create the multiple page application template so that the AAP application has a defined structure.  As an Ask a Pharmacist team member I want to develop the AAP Home button elements, so that all design elements and requirements are completed for application development.
	 */ 	
 	
	@Test
	public void TSAAP103VerifyMultiplepageappandHomebuttonlink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.clickPillBottleInformation();
		
		//newHomePage.clickHomeTab();
		//newHomePage.myHealthVetPharmacyServices();
		//newLoginPage.OpenURL(vURL);
		//newLandingPage.clickHomeTab().myHealthVetPharmacyServices();
		//newHomePage.myHealthVetPharmacyServices();
		
		//newLandingPage.clickHomeTab();
		//newHomePage.trustedMedicationResources();
		//newLandingPage.clickHomeTab();
		//newHomePage.sendSecureMessage();
		//newLandingPage.clickHomeTab();
		//newHomePage.aboutVAPharmacies();
		//newLandingPage.clickHomeTab();
		//newHomePage.pillBottleInformation();
	}
	
	@Test
	public void TSAAP103_1VerifyMultiplepageappandHomebuttonlink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.myHealthVetPharmacyServices();
		
//		newLandingPage.clickHomeTab();
//		newHomePage.trustedMedicationResources();
//		newLandingPage.clickHomeTab();
//		newHomePage.sendSecureMessage();
//		newLandingPage.clickHomeTab();
//		newHomePage.aboutVAPharmacies();
//		newLandingPage.clickHomeTab();
//		newHomePage.pillBottleInformation();
	}
	
	@Test
	public void TSAAP103_2VerifyMultiplepageappandHomebuttonlink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.trustedMedicationResources();
		

	}
	
	@Test
	public void TSAAP103_3VerifyMultiplepageappandHomebuttonlink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.aboutVAPharmacies();

	}
	
	@Test
	public void TSAAP103_4VerifyMultiplepageappandHomebuttonlink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.sendSecureMessage();

	}
	
	/*
	 * The following test is related to the Manual Test Case # TS-AAP-104 Verify Multiple page app and Home button - Features menu or hamburger menu
	 * Test Purpose: As an AAP Team Member, I want to create the multiple page application template so that the AAP application has a defined structure.  As an Ask a Pharmacist team member I want to develop the AAP Home button elements, so that all design elements and requirements are completed for application development.
	 */ 
	
	@Test
	public void TSAAP104VerifyMultiplePageAppAndHomebuttonFeatures() throws Exception{
		newLoginPage.OpenURL(vURL);
		//driver.manage().window().maximize();
	    newLandingPage.clickFeaturesTab();
		newHomePage.myHealthVetPharmacyServicesUnderFeature();
	
	  
	}
	
	
	@Test
	public void TSAAP104_1VerifyMultiplePageAppAndHomebuttonFeatures() throws Exception{
		newLoginPage.OpenURL(vURL);
		//driver.manage().window().maximize();
	    
		//newLandingPage.clickHomeTab();
		newLandingPage.clickFeaturesTab();
		newHomePage.pillBottleInformationUnderFeature();
		  		
	}
	
	@Test
	public void TSAAP104_2VerifyMultiplePageAppAndHomebuttonFeatures() throws Exception{
		newLoginPage.OpenURL(vURL);
		//driver.manage().window().maximize();
	    
		newLandingPage.clickHomeTab();
		newLandingPage.clickFeaturesTab();
		Thread.sleep(3000);
		newHomePage.trustedMedicationResourcesUnderFeature();
		 
		
	}
	
	@Test
	public void TSAAP104_3VerifyMultiplePageAppAndHomebuttonFeatures() throws Exception{
		newLoginPage.OpenURL(vURL);
		Thread.sleep(3000);
		//driver.manage().window().maximize();
		//driver.switchTo().alert().accept();
		newLandingPage.clickHomeTab();
		newLandingPage.clickFeaturesTab();
		newHomePage.sendSecureMessageUnderFeature();
		
		
	}
	
	
	@Test
	public void TSAAP104_4VerifyMultiplePageAppAndHomebuttonFeatures() throws Exception{
		  //driver.navigate().to ("http://localhost:8080/AAPSprint3_war4/#consumer-drug-herbal-supplement-information");
		  newLoginPage.OpenURL(vURL);
		  newLandingPage.clickHomeTab();
			newLandingPage.clickFeaturesTab();
			newHomePage.aboutVAPharmaciesUnderFeature();
			 
		
	}
	/*
	 * The following test is related to the Manual Test Case # TS-AAP-105 Verify page titles - link
	 * Test Purpose: AAP main body content display is developed and designed in a manner similar to mockups keeping functional and non-functional requirements in mind.
	 */ 	
	
	@Test
	public void TSAAP105VerifyPageTitlesLink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.myHealthVetPharmacyServices();
		newHomePage.clickPillBottleInformation();
		newLandingPage.clickHomeTab();
		newHomePage.trustedMedicationResources();
		

	}
	
	@Test
	public void TSAAP105_1VerifyPageTitlesLink() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.aboutVAPharmacies();

	}
	
	
	/*
	 * The following test is related to the Manual Test Case # TS-AAP-106 Verify page titles - menu items
	 * Test Purpose: AAP main body content display is developed and designed in a manner similar to mockups keeping functional and non-functional requirements in mind.
	 */ 
	
	@Test //No myHealthVetPharmacyServicesUnderFeature
	public void TSAAP106VerifyPageTitlesMenuItems() throws Exception{
//		newLoginPage.OpenURL(vURL);
//		driver.manage().window().maximize();
//		newLandingPage.clickFeaturesTab();
//		newHomePage.myHealthVetPharmacyServicesUnderFeature();
//		 try {	    
//			  driver.findElement(By.xpath("//*[@id='aap-page-title']/h1")).getText();
//			    assertEquals("My HealtheVet Pharmacy Services",  driver.findElement(By.xpath("//*[@id='aap-page-title']/h1")).getText());	
//			    Thread.sleep(3000);
//		    }   
//		    catch (Error e) {
//			    System.out.println("Text Error " + driver.getTitle());	
//			    e.printStackTrace();
//		       verificationErrors.append(e.toString());
//	    }
	  
			
		
	}
	
	
	
	@Test
	public void TSAAP106_1VerifyPageTitlesMenuItems() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newLandingPage.clickFeaturesTab();
			  
			newLandingPage.clickHomeTab();
			//newLandingPage.clickFeaturesTab();
			//newLandingPage.clickHomeTab();
			newHomePage.clickPillBottleInformation();
		
				
		
	}
	
	
	@Test
	public void TSAAP106_2VerifyPageTitlesMenuItems() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		
			  
		
			newLandingPage.clickHomeTab();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
		 
						
		
	}
	
	@Test
	public void TSAAP106_3VerifyPageTitlesMenuItems() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newLandingPage.clickFeaturesTab();
		newLandingPage.clickHomeTab();
		newLandingPage.clickFeaturesTab();
		newHomePage.aboutVAPharmaciesUnderFeature();
	 
			
						
		
	}
	/*
	 * The following test is related to the Manual Test Case # TS-AAP-106 Verify page titles - menu items
	 * Test Purpose: AAP header is developed and designed in a manner similar to mockups keeping functional and non-functional requirements in mind.
	 */ 
	
	@Test
	public void TSAAP107VerifyPageHeader() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
	    try {
	   	    driver.findElement(By.className("img-responsive")).isDisplayed();
	        assertTrue(isElementPresent(By.className("img-responsive")));
	     
	    } catch (Error e) {
	      System.out.println("Elemnet Error : " + driver.findElement(By.className("img-responsive")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }

	    try {
	        driver.findElement(By.xpath("//*[@id='aap-nav']/nav/div/div[1]/a")).getText();
	        assertEquals("Ask a Pharmacist",  driver.findElement(By.xpath("//*[@id='aap-nav']/nav/div/div[1]/a")).getText());	
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='aap-nav']/nav/div/div[1]/a")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }
	    
	    try {
	        driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[1]/a")).getText();
	        assertEquals("Home",  driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[1]/a")).getText());	
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[1]/a")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }
	    
	    try {
	        driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[2]/a")).getText();
	        assertEquals("Features",  driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[2]/a")).getText());	
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[2]/a")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }
	    try {
	        driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[3]/a")).getText();
	        assertEquals("About",  driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[3]/a")).getText());	
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[3]/a")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }    
	  
	    try {
	        driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[4]/a")).getText();
	        assertEquals("Help",  driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[4]/a")).getText());
	        System.out.println("Test Case TSAAP107VerifyPageHeader() is passed");		
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='aap-navbar']/ul[2]/li[4]/a")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }   
		newLandingPage.clickHomeTab();
		//newHomePage.verifyHomeElements();
		Thread.sleep(3000);
	}

	/*
	 * The following test is related to the Manual Test Case # TS-AAP-108 Verify page footer
	 * Test Purpose: AAP footer is developed and designed in a manner similar to mockups keeping functional and non-functional requirements in mind.
	 */ 
	
	@Test
	public void TSAAP108VerifyPageFooter() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		try {
	       String footer =  driver.findElement(By.xpath(".//*[@id='footerContainer']/footer/address")).getTagName();
	        Thread.sleep(3000);
	        System.out.println(footer);
	        assertTrue(footer.equals("address"));
	       // assertEquals("U.S. Department of Veterans Affairs | 810 Vermont Avenue, NW Washington DC 20420 |",  driver.findElement(By.xpath("//*[@id='footerContainer']/footer/address")).getText());	
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='footerContainer']/footer/address")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }
		try {
	        String footer2 = driver.findElement(By.xpath("//*[@id='footerContainer']/footer")).getTagName();
	        Thread.sleep(3000);
	        System.out.println(footer2);
	        //assertEquals("Last reviewed/Updated | 3/12/15 | 810 Vermont Avenue, NW Washington DC 20420 | App Version: | 1.0", driver.findElement(By.xpath("//*[@id='footerContainer']/footer/address")).getText());
	        System.out.println("Test Case TSAAP108VerifyPageFooter() is passed");	
	     
	    } catch (Error e) {
	      System.out.println("Text Error : " + driver.findElement(By.xpath("//*[@id='footerContainer']/footer")));
	      e.printStackTrace();
	      verificationErrors.append(e.toString());
	    }   
	}

	/*
	 * The following test is related to the Manual Test Case # TS-AAP-110 Verify Help menu 
	 * Test Purpose: As an Ask a Pharmacist team member I want to develop the AAP help menu information elements, so that all design elements and requirements are completed for application development..
	 */ 	
	
	@Test
	public void TSAAP110VerifyHelpMenu() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		
		newHomePage.click_HelpLink();
		
		
	}	
	 /*
	 * The following test is related to the Manual Test Case # TS-AAP-109 Verify About menu  
	 * Test Purpose: As an Ask a Pharmacist team member I want to develop the AAP about menu information elements, so that all design elements and requirements are completed for application development.
	 */ 	

	@Test
	public void TSAAP109VerifyAboutMenu() throws Exception{
		newLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
		newHomePage.click_AboutLink();
	}	


	@After
	public void tearDown() throws Exception {
		driver.quit();
	String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  
  

}
