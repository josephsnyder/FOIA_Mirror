package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AdverseDrugEventInformation {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	//Web Elements on Adverse Drug Event Information Page.
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
			public WebElement click_DrugInteractionsChecker;

			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
			public WebElement click_TrackadversedrugeventsinFDA;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
			public WebElement click_MedlineAllergyInformation;
			
			public AdverseDrugEventInformation(WebDriver driver){
				AdverseDrugEventInformation.driver = driver;
				//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			}
			
			/**
			 * This method is used to Click on Drug Interactions Checker
			 */
			public  AdverseDrugEventInformation click_DrugInteractionsChecker() throws Exception{
				click_DrugInteractionsChecker.click();
				return new AdverseDrugEventInformation(driver);
			}
			
			
			/**
			 * This method is used to Click on TRack Adverse drug events in FDA
			 */
			public  AdverseDrugEventInformation click_TrackadversedrugeventsinFDA() throws Exception{
				click_TrackadversedrugeventsinFDA.click();
				return new AdverseDrugEventInformation(driver);
			}			
			
			
			public AdverseDrugEventInformation verifyUSFoodAndDrugAdministrationLink()throws Exception{
			assertEquals("http://www.fda.gov/Safety/MedWatch/SafetyInformation/default.htm", driver.getCurrentUrl());	
			return new AdverseDrugEventInformation(driver);
				}
			
			/**
			 * This method is used to verify the alert for leaving AAP
			 */
			
			public AdverseDrugEventInformation verifyExternalPage() throws Exception {
				driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				//driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
			    driver.findElement(By.id("aapLeave")).click();
			    Thread.sleep(3000);
				return new AdverseDrugEventInformation(driver); 
			}
			
				public AdverseDrugEventInformation verifyExternalPagetitle() throws Exception {
					    //driver.switchTo().alert().accept();
					    assertEquals("Drug Interactions Checker - For Drugs, Food & Alcohol", driver.getTitle());
				return new AdverseDrugEventInformation(driver);   
			}

				public AdverseDrugEventInformation verifyDrugInteractionurl() throws Exception{
					assertEquals("http://www.drugs.com/drug_interactions.html", driver.getCurrentUrl());	
					return new AdverseDrugEventInformation(driver);
				}
				
			private String closeAlertAndGetItsText() {
			    try {
			      Alert alert = driver.switchTo().alert();
			      String alertText = alert.getText();
			      if (acceptNextAlert) {
			        alert.accept();
			      } else {
			        alert.dismiss();
			      }
			      return alertText;
			    } finally {
			      acceptNextAlert = true;
			    }
			  }
			
			 private boolean isAlertPresent() {
				    try {
				      driver.switchTo().alert();
				      return true;
				    } catch (NoAlertPresentException e) {
				      return false;
				    }
		
			 }
			}

