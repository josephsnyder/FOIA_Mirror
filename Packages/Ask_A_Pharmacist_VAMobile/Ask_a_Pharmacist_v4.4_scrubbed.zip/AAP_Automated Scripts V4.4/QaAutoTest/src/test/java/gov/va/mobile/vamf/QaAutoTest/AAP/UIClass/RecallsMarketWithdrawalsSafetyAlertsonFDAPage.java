package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RecallsMarketWithdrawalsSafetyAlertsonFDAPage {
	public static WebDriver driver;
    //Web Elements on USFoodAndDrugAdministration/RecallsMarketWithdrawalsSafetyAlertsonFDAPage Page
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[11]/a/span[1]")
	public WebElement click_USFoodAndDrugAdministration;
	
	 //Web Elements on USFoodAndDrugAdministration/RecallsMarketWithdrawalsSafetyAlertsonFDAPage Page
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[13]/a/span[1]")
		public WebElement click_RecallMarketWithdrawalSafety;
	
	 /**
	 * This method is used to Click on US Food and Drug Administration.
	 */
    public USFoodAndDrugAdministrationPage click_USFoodAndDrugAdministration() throws Exception{
    	click_USFoodAndDrugAdministration.click();
    	Thread.sleep(3000);
    	return new USFoodAndDrugAdministrationPage();
    }
    
    /**
	 * This method is used to Click on US Food and Drug Administration.
	 */
    public USFoodAndDrugAdministrationPage click_RecallMarketWithdrawalSafety() throws Exception{
    	click_USFoodAndDrugAdministration.click();
    	Thread.sleep(3000);
    	return new USFoodAndDrugAdministrationPage();
    }

public void clickContinuepPopup() {

	}
}
