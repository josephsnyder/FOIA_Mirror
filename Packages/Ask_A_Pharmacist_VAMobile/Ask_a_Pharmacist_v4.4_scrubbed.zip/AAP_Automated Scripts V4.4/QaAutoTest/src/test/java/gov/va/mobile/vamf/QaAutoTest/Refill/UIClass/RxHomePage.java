package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class RxHomePage {
	public static WebDriver driver;
	
	public RxHomePage(WebDriver driver){
		RxHomePage.driver = driver;
	}
	
	/**
	 * This method is used to Click Refillable VA Medication
	 * 
	 */
	public RefillableVAMedicationPage clicRefillableVAMedications() throws Exception{
		driver.findElement(By.xpath(".//*[@id='rxr-link']/div/div[1]/a")).click();
		Thread.sleep(3000);
		
		return new RefillableVAMedicationPage(driver);
	}
	
	public PrescriptionHistoryPage clickPrescriptionHistory() throws Exception{
		driver.findElement(By.xpath(".//*[@id='rxr-link']/div/div[3]/a")).click();
		Thread.sleep(3000);
		
		return new PrescriptionHistoryPage(driver);
	}
	
	public TrackDeliveryPage clickTrackDelivery() throws Exception{
		driver.findElement(By.xpath(".//*[@id='rxr-link']/div/div[2]/a")).click();
		Thread.sleep(3000);
		
		return new TrackDeliveryPage(driver);
	}
	
	public LinkModulePage clickLinkModule() throws Exception{
		driver.findElement(By.xpath(".//*[@id='rxr-link']/div/div[4]/a")).click();
		Thread.sleep(3000);
		
		return new LinkModulePage(driver);
	}
	
	public RxHomePage clickApplicationIcon() throws Exception{
		driver.findElement(By.linkText("Rx Refill")).click();
		Thread.sleep(3000);
		
		return new RxHomePage(driver);
	}
	
	public RxHomePage verifyHomePage() throws Exception {
	    assertEquals("Home", driver.findElement(By.cssSelector("h1.page-heading")).getText());
		Thread.sleep(3000);
		
		return new RxHomePage(driver);
	}
	
	public RxHomePage verifyFooterInformation() throws Exception {
		try {
		      assertEquals("U.S. Department of Veterans Affairs |\n 810 Vermont Avenue, NW Washington DC 20420 | Last reviewed/Updated 5/14/15\n App Version: 2.0", 
		    		  driver.findElement(By.cssSelector("footer")).getText());
		    } catch (Error e) {
		      System.out.println("Footer is incorrect");
		    }
		
		return new RxHomePage(driver);
	}
	
	public FeatureMenuPage clickFeaturesMenu() throws Exception {
		driver.findElement(By.cssSelector("span.caret")).click();
		Thread.sleep(5000);
		return new FeatureMenuPage(driver);
	}
}
