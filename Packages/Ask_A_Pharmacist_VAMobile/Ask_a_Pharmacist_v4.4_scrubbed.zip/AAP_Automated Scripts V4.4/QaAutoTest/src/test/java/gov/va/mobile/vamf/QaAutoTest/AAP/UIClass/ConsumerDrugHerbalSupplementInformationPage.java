package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ConsumerDrugHerbalSupplementInformationPage {
		public static WebDriver driver;
		private boolean acceptNextAlert = true;
		private boolean isAlertPresent = true;
		public StringBuffer verificationErrors = new StringBuffer();
	
		//Web Elements on Consumer Drug, Herbal & Supplement Information page
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
		public WebElement click_FoodAndDrugAdministration;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[6]/a/span[1]/span[1]")
		public WebElement click_MedlinePlus;	
		
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
		public WebElement click_Medication;
		
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
		public WebElement click_MedicationAndHealth;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[11]/a/span[1]/span[1]")
		public WebElement click_VeteransHealthLibrary;
	
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[5]/a/span[1]/span[1]")
		public WebElement click_MedicineSafetyAToolkitforFamilies;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
		public WebElement click_MedicationTipsToolsonSafemedication;

		@FindBy(how = How.XPATH, using = ".//*[@id='aap-link']/div/div[9]/a/span[1]/span[1]")
		public WebElement click_SafeDisposalofMedicinesonFDA;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[10]/a/span[1]/span[1]")
		public WebElement click_VACenterforMedicationSafety;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
		public WebElement click_FDAMedWatch;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[8]/a/span[1]/span[1]")
		public WebElement click_ReportAMedicationError;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
		public WebElement click_FreeMedicationAlerts;

	    @FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[7]/a/span[1]/span[1]")
	    public WebElement click_RecallsMarketWithdrawalsSafetyAlertsonFDA;
	    
	    @FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
	    public WebElement click_SafetyPractice;
	    
	    @FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
	    public WebElement click_ReportingMedicationErrors;
	    
	    @FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
	    public WebElement click_GetTheLatestSafetyArticlesOnMedicationsPage;
	    
		public ConsumerDrugHerbalSupplementInformationPage(WebDriver driver){
			ConsumerDrugHerbalSupplementInformationPage.driver = driver;
		}
	    

		 /**
	     * This method is used to Click on Cancel button.
	     */
	
	    public ConsumerDrugHerbalSupplementInformationPage click_Cancel() throws Exception{
	    	driver.findElement(By.id("aapStay")).click();
	    	assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#consumer-drug-herbal-supplement-information", driver.getCurrentUrl());
	    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
	    }
		
		public ConsumerDrugHerbalSupplementInformationPage GoBackBrowserButton() throws Exception{
			Thread.sleep(3000);
			driver.navigate().back();
			Thread.sleep(3000);
			assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#consumer-drug-herbal-supplement-information", driver.getCurrentUrl());
		    Thread.sleep(3000);
	    return new ConsumerDrugHerbalSupplementInformationPage(driver);
		}
		 /**
	     * This method is used to Click on FDA MedWatch
	     */
	
	    public ConsumerDrugHerbalSupplementInformationPage click_FDAMedWatch() throws Exception{
	    	click_FDAMedWatch.click();
	    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
	    }
	    
		 /**
	     * This method is used to Click on Medication
	     */
	
	    public ConsumerDrugHerbalSupplementInformationPage click_Medication() throws Exception{
	    	click_Medication.click();
	    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
	    }
	    
		 /**
	     * This method is used to Click on Medication and Health link
	     */
	
	    public ConsumerDrugHerbalSupplementInformationPage click_MedicationAndHealth() throws Exception{
	    	click_MedicationAndHealth.click();
	    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
	    }
	    
		 /**
	     * This method is used to Click on Medication and Health link
	     */
	
	    public ConsumerDrugHerbalSupplementInformationPage click_GetTheLatestSafetyArticlesOnMedicationsPage() throws Exception{
	    	click_GetTheLatestSafetyArticlesOnMedicationsPage.click();
	    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
	    }
	    
	    
		/**
		* This method is used to verify link url for USFDA MedWatch - The FDA Safety Information and Adverse Event Reporting Program
		*/
		public ConsumerDrugHerbalSupplementInformationPage verifyUSFDAMedWatchurl() throws Exception{
			Thread.sleep(5000);
			assertEquals("http://www.fda.gov/Safety/MedWatch/default.htm", driver.getCurrentUrl());//The link in the test case is wrong.
			return new ConsumerDrugHerbalSupplementInformationPage(driver);
		}
		
	    /**
	     * This method is used to Click on RecallsMarketWithdrawalsSafetyAlertsonFDA
	     */
	
	    public ConsumerDrugHerbalSupplementInformationPage click_RecallsMarketWithdrawalsSafetyAlertsonFDA() throws Exception{
	    	click_RecallsMarketWithdrawalsSafetyAlertsonFDA.click();
	    	Thread.sleep(3000);
	    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
	    }
	    
	    /*
		* This method is used to verify link url for USFDA RecallsMarketWithdrawalsSafetyAlertsonFDA
		*/
		public ConsumerDrugHerbalSupplementInformationPage verifyUSFDARecallsMarketWithdrawalsSafetyAlertsonFDAurl() throws Exception{
			Thread.sleep(5000);
			assertEquals("http://www.fda.gov/Safety/Recalls/default.htm", driver.getCurrentUrl());//The link in the test case is wrong.
			return new ConsumerDrugHerbalSupplementInformationPage(driver);
		}   
	    	
	    	/**
			 * This method is used to Click on Food and Drug Administration
			 */
	    	
			public  ConsumerDrugHerbalSupplementInformationPage click_FoodAndDrugAdministration() throws Exception{
				click_FoodAndDrugAdministration.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for US Food and Drug Administraion - Information for Consumers.
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyFoodAndDrugAdministrationLinkurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.fda.gov/Drugs/ResourcesForYou/Consumers/default.htm", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			 /**
		     * This method is used to Click on Free Medication Alerts
		     */
		
		    public ConsumerDrugHerbalSupplementInformationPage click_FreeMedicationAlerts() throws Exception{
		    	click_FreeMedicationAlerts.click();
		    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
		    }
		    
			/**
			* This method is used to verify link url for Consumer Med Safety - Free Medication Alerts
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyConsumerMedSafetyFreeMedicationAlertsurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.consumermedsafety.org/tools-and-resources/medication-safety-tools-and-resources/know-your-medicine/get-free-personalized-drug-updates", driver.getCurrentUrl());//The link in the test case is wrong.
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			
	    	/**
			 * This method is used to Click on Medline Plus
			 */
	    	
			public  ConsumerDrugHerbalSupplementInformationPage click_MedlinePlus() throws Exception{
				click_MedlinePlus.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for Medline Plus Drug Supplements and Herbal Information.
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyMedlinePluDrugSupplementsAndHerbalInformationsurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.nlm.nih.gov/medlineplus/druginformation.html", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
	    	
			
	    	/**
			 * This method is used to Click on Veterans Health Library page.
			 */
	    	
			public  ConsumerDrugHerbalSupplementInformationPage click_VeteransHealthLibrary() throws Exception{
				Thread.sleep(3000);
				click_VeteransHealthLibrary.click();
				Thread.sleep(3000);
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			 * This method is used to Click on Reporting Medication Errors page.
			 */
	    	
			public  ConsumerDrugHerbalSupplementInformationPage click_ReportingMedicationErrors() throws Exception{
				Thread.sleep(3000);
				click_ReportingMedicationErrors.click();
				Thread.sleep(3000);
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for DVA Veterans Health Library.
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyVeteransHealthLibrarysurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.veteranshealthlibrary.org/MedicationsVA/", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}	
			
		 	/**
			 * This method is used to Click on Medicine Safety: A Toolkit for Families
			 */
	    	
			public  ConsumerDrugHerbalSupplementInformationPage click_MedicineSafetyAToolkitforFamilies() throws Exception{
				click_MedicineSafetyAToolkitforFamilies.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for Learn About Rx Safety Medicine Safety: A Toolkit for Families
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyMedicineSafetyAToolkitforFamiliesurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.learnaboutrxsafety.org/", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}	
			
			
		 	/**
			 * This method is used to Click on Medication Tips & Tools on Safemedication.com
			 */
	    	
			public  ConsumerDrugHerbalSupplementInformationPage click_MedicationTipsToolsOnSafemedication() throws Exception{
				click_MedicationTipsToolsonSafemedication.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for Safe Medication - Medication Tips & Tools
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyMedicationTipsToolsOnSafemedicationurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.safemedication.com/safemed/MedicationTipsTools/", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}	
			
			/**
			* This method is used to verify link url for Safe Disposal of Medicines on FDA
			*/
			
			public  ConsumerDrugHerbalSupplementInformationPage click_SafeDisposalofMedicinesonFDA() throws Exception{
				click_SafeDisposalofMedicinesonFDA.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for US Food And Drug Administration - Safe Disposal of Medicines on FDA
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyUSFDASafeDisposalofMedicinesonFDAurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.fda.gov/Drugs/ResourcesForYou/Consumers/BuyingUsingMedicineSafely/EnsuringSafeUseofMedicine/SafeDisposalofMedicines/default.htm", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to verify link url for VA Center for Medication Safety
			*/
			
			public  ConsumerDrugHerbalSupplementInformationPage click_VACenterforMedicationSafety() throws Exception{
				click_VACenterforMedicationSafety.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			/**
			* This method is used to click on Safety Practice link
			*/
			
			public  ConsumerDrugHerbalSupplementInformationPage click_SafetyPractice() throws Exception{
				click_SafetyPractice.click();
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			
			/**
			* This method is used to verify link url for Pharmacy Benefits Management Services - VA Center for Medication Safety A Patient Safety Center for Inquiry
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyPBMSVACenterforMedicationSafetyurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.pbm.domain/PBM/vacenterformedicationsafety/vacenterformedicationsafetyprescriptionsafety.asp", driver.getCurrentUrl());
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			 /**
		     * This method is used to Click on Report A Medication Error
		     */
		
		    public ConsumerDrugHerbalSupplementInformationPage click_ReportAMedicationError() throws Exception{
		    	click_ReportAMedicationError.click();
		    	return new ConsumerDrugHerbalSupplementInformationPage(driver);
		    }
		    
			/**
			* This method is used to verify link url for Consumer MedSafety.org - Report A Medication Error
			*/
			public ConsumerDrugHerbalSupplementInformationPage verifyConsumerMedSafetyReportAMedicationErrorurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.consumermedsafety.org/report-a-medication-error", driver.getCurrentUrl());//The link in the test case is wrong.
				return new ConsumerDrugHerbalSupplementInformationPage(driver);
			}
			
			
			public ConsumerDrugHerbalSupplementInformationPage verifyExternalPage() throws Exception {
				driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
			    driver.findElement(By.id("aapLeave")).click();
			    Thread.sleep(5000);
				return new  ConsumerDrugHerbalSupplementInformationPage(driver); 
			}
			
	    	
}
