package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MedicationArticlesOnMyHealtheVetPage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
		
		//Web Elements on Medication Articles On My Healthe Vet Page
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
			public WebElement click_CheckYourMedicationsAPrescriptionForBetterHealth;	
	
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
			public WebElement click_MedicationsKeepTrackAndPlayItSafe;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
			public WebElement click_MedicationDisposalSafetyTips;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[7]/a/span[1]/span[1]")
			public WebElement click_NavigatingYourWayToGoodHealthFindingReliableInformationOnline;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[9]/a/span[1]/span[1]")
			public WebElement click_ThinkingAboutQuittingSmokingMedicationsCanHelp;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[5]/a/span[1]/span[1]")
			public WebElement click_MedicationsPlayingItSafeAtHome;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
			public WebElement click_MedicationCheckUp;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[8]/a/span[1]/span[1]")
			public WebElement click_SharingYourHealthInformation;	
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[6]/a/span[1]/span[1]")
			public WebElement click_MedicineCabinetFullTooManyPills;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[10]/a/span[1]/span[1]")
			public WebElement click_VAMailOrderPharmacyProgramRecognized2011;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[11]/a/span[1]/span[1]")
			public WebElement click_ViewingYourVAMedicationNames;	
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[12]/a/span[1]/span[1]")
			public WebElement click_WhatVaccinesDoYouNeed;
			

		public MedicationArticlesOnMyHealtheVetPage(WebDriver driver){
			MedicationArticlesOnMyHealtheVetPage.driver = driver;
		}
		
		/**
		 * This method is used to Click on Check Your Medications: A Prescription for Better Health
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_CheckYourMedicationsAPrescriptionForBetterHealth() throws Exception{
			click_CheckYourMedicationsAPrescriptionForBetterHealth.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		/**
		 * This method is used to verify link URL for  My Health eVet Check Your Medications: A Prescription for Better Health
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyCheckYourMedicationsAPrescriptionForBetterHealthurl() throws Exception{
		    Thread.sleep(4000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/December%202010/spotlight_dec2010_caregiver.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}		

		/**
		 * This method is used to Click on Medications Keep Track And Play It Safe
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_MedicationsKeepTrackAndPlayItSafe() throws Exception{
			click_MedicationsKeepTrackAndPlayItSafe.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		/**
		 * This method is used to verify link URL for  My Health eVet Medications Keep Track And Play It Safe
		 */
		public MedicationArticlesOnMyHealtheVetPage MyHealtheVetMedicationsKeepTrackAndPlayItSafeurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/May2012/spotlight_may2012_medication_management.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		
		/**
		 * This method is used to Click on Medication Disposal Safety Tips
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_MedicationDisposalSafetyTips() throws Exception{
			click_MedicationDisposalSafetyTips.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		/**
		 * This method is used to verify link URL for  My Health eVet Medication Disposal Safety Tips
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyMedicationDisposalSafetyTipsurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/October%202010/spotlight_prescription_safety.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}	
		
		
		/**
		 * This method is used to Click on Navigating Your Way To Good Health Finding Reliable Information On line
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_NavigatingYourWayToGoodHealthFindingReliableInformationOnline() throws Exception{
			click_NavigatingYourWayToGoodHealthFindingReliableInformationOnline.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		
		/**
		 * This method is used to verify link URL for  My Health eVet Medications Keep Track And Play It Safe
		 */
		public MedicationArticlesOnMyHealtheVetPage MyHealtheVetNavigatingYourWayToGoodHealthFindingReliableInformationOnlineurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/March2012/spotlight_mar2012_navigate_health.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
				
		/**
		* This method is used to Click on Thinking about Quitting Smoking? - Medications Can Help
		*/
		public  MedicationArticlesOnMyHealtheVetPage click_ThinkingAboutQuittingSmokingMedicationsCanHelp() throws Exception{
			click_ThinkingAboutQuittingSmokingMedicationsCanHelp.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
			}	
		
				/**
		 * This method is used to verify link URL for  My Health eVet Thinking about Quitting Smoking? - Medications Can Help
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyThinkingAboutQuittingSmokingMedicationsCanHelpurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/November%202011/spotlight_nov2011_smoking.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		
		/**
		* This method is used to Click on Medications: Playing it Safe at Home
		*/
		public  MedicationArticlesOnMyHealtheVetPage click_MedicationsPlayingItSafeAtHome() throws Exception{
			click_MedicationsPlayingItSafeAtHome.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
			}	
		
		/**
		 * This method is used to verify link URL for My Health eVet Medications: Playing it Safe at Home
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyMedicationsPlayingItSafeAtHomeurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/August%202009/spotlight_medications.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
	
		/**
		* This method is used to Click on Medications: Playing it Safe at Home
		*/
		public  MedicationArticlesOnMyHealtheVetPage click_MedicationCheckUp() throws Exception{
			click_MedicationCheckUp.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
			}	
		
		/**
		 * This method is used to verify link URL for My Health eVet Medications: Playing it Safe at Home
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyMedicationCheckUpurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/December%202010/spotlight_dec2010_med_checkup.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}

	/**
	 * This method is used to Click on Check Sharing Your Health Information
	 */
	public  MedicationArticlesOnMyHealtheVetPage click_SharingYourHealthInformation() throws Exception{
		click_SharingYourHealthInformation.click();
		return new MedicationArticlesOnMyHealtheVetPage(driver);
	}
	/**
	 * This method is used to verify link URL for  My Health eVet Sharing Your Health Information
	 */
	public MedicationArticlesOnMyHealtheVetPage verifySharingYourHealthInformationrl() throws Exception{
	    Thread.sleep(5000);
		assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/September%202010/spotlight_share.html", driver.getCurrentUrl());
		return new MedicationArticlesOnMyHealtheVetPage(driver);
	}		
	
	
		/**
		* This method is used to Click on Medicine Cabinet Full? Too Many Pills
		*/
		
		public  MedicationArticlesOnMyHealtheVetPage click_MedicineCabinetFullTooManyPills() throws Exception{
			click_MedicineCabinetFullTooManyPills.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
			}	
		
		/**
		 * This method is used to verify link URL My Health eVet Medicine Cabinet Full? Too Many Pills
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyMedicineCabinetFullTooManyPillsurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=news/May%202011/news.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		
		
		/**
		 * This method is used to Click on VA's Mail-Order Pharmacy Program Recognized 2011
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_VAMailOrderPharmacyProgramRecognized2011() throws Exception{
			click_VAMailOrderPharmacyProgramRecognized2011.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		/**
		 * This method is used to verify link URL for My Health eVet VA's Mail-Order Pharmacy Program Recognized 2011
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyVAMailOrderPharmacyProgramRecognized2011url() throws Exception{
		    Thread.sleep(5000);
			assertEquals("http://www1.domain/opa/pressrel/pressrelease.cfm?id=2119", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}		

		/**
		 * This method is used to Click on What Vaccines do you need?
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_WhatVaccinesDoYouNeed() throws Exception{
		click_WhatVaccinesDoYouNeed.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		/**
		 * This method is used to verify link URL for My Health eVet What Vaccines do you need?
		 */
		public MedicationArticlesOnMyHealtheVetPage verifyUpdatedImmunizationRecommendationurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/May%202011/spotlight_may2011_pertussis.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}	
	
		/**
		 * This method is used to Click on Viewing your VA Medication Names
		 */
		public  MedicationArticlesOnMyHealtheVetPage click_ViewingYourVAMedicationNames() throws Exception{
			click_ViewingYourVAMedicationNames.click();
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		/**
		 * This method is used to verify link URL for My Health eVet Viewing your VA Medication Names
		 */
		public MedicationArticlesOnMyHealtheVetPage verify_ViewingYourVAMedicationNamesurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=spotlightArchive&contentPage=spotlight/November%202009/spotlight_view-medications.html", driver.getCurrentUrl());
			return new MedicationArticlesOnMyHealtheVetPage(driver);
		}		
		
		public MedicationArticlesOnMyHealtheVetPage GoBackBrowserButton() throws Exception{
			Thread.sleep(3000);
			driver.navigate().back();
			assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#medication-articles", driver.getCurrentUrl());
		    Thread.sleep(3000);
	    return new MedicationArticlesOnMyHealtheVetPage(driver);
		}
		
		public  MedicationArticlesOnMyHealtheVetPage verifyExternalPage() throws Exception {
			driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
			//assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
		    driver.findElement(By.id("aapLeave")).click();
		    Thread.sleep(5000);
			return new  MedicationArticlesOnMyHealtheVetPage(driver); 
		}
		
		
}