package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverResourceCenterPage {
	private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
	public WebElement click_VAhealthlogo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']")
	public WebElement click_SignInButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
	public WebElement click_VABannerHeader; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_ResourceCenterButtonLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement click_ResourceCenterTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p")
	public WebElement click_ResouceCenterBodyText; 
	
	
	
	public CaregiverResourceCenterPage(WebDriver driver){
		CaregiverResourceCenterPage.driver = driver;
	}

	 /**
     * This method is used to verify Resource Center title
     */
    public CaregiverResourceCenterPage verifyResourceCenterTitle() throws Exception{
    	assertEquals("Resource Center", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
    	//Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).getText(), false);
    	return new CaregiverResourceCenterPage(driver);
    }
    
	 /**
     * This method is used to verify Home text
     */
    public CaregiverResourceCenterPage verifyResouceCenterText() throws Exception{
    	assertEquals("Welcome to the Dementia Care Resource Center. Please select one of the well-being categories below to view its related educational materials such as videos and tips in Veteran care.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p")).getText());
    	//Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).getText(), false);
    	return new CaregiverResourceCenterPage(driver);
    }
}
