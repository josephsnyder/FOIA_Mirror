package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import org.openqa.selenium.WebDriver;

public class USFoodAndDrugAdministrationPage {
	public static WebDriver driver;
}
