package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverHomePage {
		private static WebDriver driver; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
		public WebElement click_VAhealthlogo; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='login']")
		public WebElement click_SignInButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='login-off']")
		public WebElement click_LogoutArrow; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='logout']")
		public WebElement click_LogoutLink;
		
		@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
		public WebElement click_VABannerHeader; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='home']")
		public WebElement click_HomeButtonLink; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
		public WebElement click_ResourceCenterButtonLink; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='nav-dropdown']")
		public WebElement click_AssessmentDropdown; 
		
		@FindBy(how = How.XPATH, using = ".//*[@id='menu-list']/ul/li[1]/a")
		public WebElement click_CompleteStatusUpdateUnderAssessmentDropdown; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[1]/a")
		public WebElement click_viewStatusHistoryUnderAssessmentDropdown; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[4]")
		public WebElement click_AboutButtonLink; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='help']")
		public WebElement click_HelpButtonLink; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
		public WebElement click_WelcomeTitle; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p")
		public WebElement click_WelcomeBodyTet; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='login']/img[1]")
		public WebElement click_CaregiverSignInIcon; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='login']/h3")
		public WebElement click_CaregiverSignInLink; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='login']/img[2]")
		public WebElement click_CaregiverSignInArrow; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='statusUpdate']/img[1]")
		public WebElement click_CompleteStatusUpdateIcon; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='statusUpdate']/h3")
		public WebElement click_CompleteStatusUpdateLink; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='statusUpdate']/img[2]")
		public WebElement click_CompleteStatusUpdateArrow; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[1]/div[2]/div/a/img[1]")
		public WebElement click_ViewStatusHistoryIcon; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[1]/div[2]/div/a/h3")
		public WebElement click_ViewStatusHistoryLink; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[1]/div[2]/div/a/img[2]")
		public WebElement click_ViewStatusHistoryArrow; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/div/div/a/img[1]")
		public WebElement click_ResouceCenterBookIcon; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/div/div/a/h3")
		public WebElement click_ResourceCenterLink; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/div/div/a/img[2]")
		public WebElement click_ResourceCenterArrow; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[4]/img")
		public WebElement click_TipOfTheWeekBulbIcon; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[4]/h3")
		public WebElement click_TipOfTheWeekHeading; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[4]/p")
		public WebElement click_TipOfTheWeekTextbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[5]/p")
		public WebElement click_GetAppLabel; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[5]/a[1]/img")
		public WebElement click_DownloadAppStoreLink; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[5]/a[2]/img")
		public WebElement click_DownloadGooglePlayLink; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[1]")
		public WebElement click_FooterOne; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[2]")
		public WebElement click_FooterTwo; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[3]")
		public WebElement click_FooterThree; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[3]/button")
		public WebElement click_AboutCloseButton;
		
		@FindBy(how = How.XPATH, using = "//*[@id='help-modal']/div/div/div[3]/button")
		public WebElement click_HelpCloseButton;
		
		
		public CaregiverHomePage(WebDriver driver){
			CaregiverHomePage.driver = driver;
		}
		
		public void OpenURL (String URL){
			driver.navigate().to(URL);
		}

		 /**
	     * This method is used to click on SignIn link
	     */
	    public CaregiverHomePage click_SignInButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='login']")).isDisplayed());
	    	click_SignInButton.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Sign out link
	     */
	    public CaregiverHomePage click_SignoutLink() throws Exception{
	    	Thread.sleep(1000);
	    	click_LogoutArrow.click();
			Thread.sleep(2000);
			click_LogoutLink.click();
			Thread.sleep(2000);
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify chicklet icon
	     */
	    public CaregiverHomePage verifyChickleticon() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify App Name
	     */
	    public CaregiverHomePage click_DementiCareName() throws Exception{
	    	//assertEquals("Dementia Care", driver.findElement(By.xpath("//img[@class= 'dc-app-icon']")).getText());
	    	assertEquals("Dementia Care", driver.findElement(By.className("dc-app-icon")).getText());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to Select on VABanner Header link
	     */
	    public CaregiverHomePage verifyVABannerHeader() throws Exception{
	  	    Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify Home link is present
	     */
	    public CaregiverHomePage verifyHomeLinkPresent() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='home']")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
	    
		 /**
	     * This method is used to verify Assessment link is present
	     */
	    public CaregiverHomePage verifyAssessmentsLinkPresent() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='nav-dropdown']")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify Resource Center link is present
	     */
	    public CaregiverHomePage verifyResouceCenterLinkPresent() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='nav-dropdown']")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify About link is present
	     */
	    public CaregiverHomePage verifyAboutLinkPresent() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']/a[4]")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify Help link is present
	     */
	    public CaregiverHomePage verifyHelpLinkPresent() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='help']")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
	    
	    
	    
	    
		 /**
	     * This method is used to click on Home link
	     */
	    public CaregiverHomePage click_HomeButtonLink() throws Exception{
	    	click_HomeButtonLink.click();
	    	//assertEquals("http://vetadmin.mobilehealth.domain:8080/grecc-web-2.0-veteran/#home", driver.getCurrentUrl());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify on Home link url
	     */
	    public CaregiverHomePage verify_HomeButtonLinkurl() throws Exception{
	    	assertEquals("http://vetadmin.mobilehealth.domain:8080/grecc-web-2.0-veteran/#home", driver.getCurrentUrl());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Assessment Drop down link
	     */
	    public CaregiverHomePage click_AssessmentDropdownLink() throws Exception{
	    	click_AssessmentDropdown.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify values under Assessment Drop down link
	     */
	    public CaregiverHomePage verifyAssessmentDropdownLinkvalues() throws Exception{
	    	//click_AssessmentDropdown.click();
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']/ul/li[1]/a")).isDisplayed());
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']/ul/li[2]/a")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Complete Status Update link under Assessment Drop down link
	     */
	    public CaregiverHomePage click_CompleteStatusUpdateUnderAssessmentDropdownLink() throws Exception{
	    	click_CompleteStatusUpdateUnderAssessmentDropdown.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on View Status History link under Assessment Drop down link
	     */
	    public CaregiverHomePage click_viewStatusHistoryUnderAssessmentDropdownLink() throws Exception{
	    	click_viewStatusHistoryUnderAssessmentDropdown.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Resource Center link
	     */
	    public CaregiverHomePage click_ResourceCenterButtonLink() throws Exception{
	    	click_ResourceCenterButtonLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	 
		 /**
	     * This method is used to click on About link
	     */
	    public CaregiverHomePage click_AboutButtonLink() throws Exception{
	    	click_AboutButtonLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to close on About screen
	     */
	    public CaregiverHomePage click_AboutCloseButton() throws Exception{
	    	click_AboutCloseButton.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Help link
	     */
	    public CaregiverHomePage click_HelpButtonLink() throws Exception{
	    	click_HelpButtonLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to close on Help screen
	     */
	    public CaregiverHomePage click_HelpCloseButton() throws Exception{
	    	click_HelpCloseButton.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify Home title
	     */
	    public CaregiverHomePage verifyHomeTitle() throws Exception{
	    	Thread.sleep(1000);
	    	assertEquals("Home", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());

	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify Home text
	     */
	    public CaregiverHomePage verifyHomeText() throws Exception{
	    	assertEquals("Welcome to Dementia Care. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p")).getText());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Complete Status Update Icon.
	     */
	    public CaregiverHomePage click_CompleteStatusUpdateIcon() throws Exception{
	    	click_CompleteStatusUpdateIcon.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
	    
		 /**
	     * This method is used to click on Complete Status Update Link in the middle of the page.
	     */
	    public CaregiverHomePage click_CompleteStatusUpdateLink() throws Exception{
	    	click_CompleteStatusUpdateLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Complete Status Update Arrow in the middle of the page.
	     */
	    public CaregiverHomePage click_CompleteStatusUpdateArrow() throws Exception{
	    	click_CompleteStatusUpdateArrow.click();
	    	return new CaregiverHomePage(driver);
	    }
	    

   		 /**
    	     * This method is used to click on View Status History Icon.
    	     */
    	    public CaregiverHomePage click_ViewStatusHistoryIcon() throws Exception{
	    		click_ViewStatusHistoryIcon.click();
    	    	return new CaregiverHomePage(driver);
    	    }
    	    
    	    
    		 /**
    	     * This method is used to click on View Status History Link in the middle of the page.
    	     */
    	    public CaregiverHomePage click_ViewStatusHistoryLink() throws Exception{
    	    	click_ViewStatusHistoryLink.click();
    	    	return new CaregiverHomePage(driver);
    	    }
    	    
    		 /**
    	     * This method is used to click on View Status History in the middle of the page.
    	     */
    	    public CaregiverHomePage click_ViewStatusHistoryArrow() throws Exception{
    	    	click_ViewStatusHistoryArrow.click();
    	    	return new CaregiverHomePage(driver);
    	    }
	    		
	    		
		 /**
	     * This method is used to click on Caregiver Sign In Button arrow in the middle of the page.
	     */
	    public CaregiverHomePage click_CaregiverSignInArrow() throws Exception{
	    	click_CaregiverSignInArrow.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
	    /**
	     * This method is used to click on Resource Center Icon.
	     */
	    public CaregiverHomePage click_ResouceCenterBookIcon() throws Exception{
	    	click_ResouceCenterBookIcon.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Resource Center Link in the middle of the page.
	     */
	    public CaregiverHomePage click_ResourceCenterLink() throws Exception{
	    	click_ResourceCenterLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Resource Center arrow in the middle of the page.
	     */
	    public CaregiverHomePage click_ResourceCenterArrow() throws Exception{
	    	click_ResourceCenterArrow.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to Select Tip Of the Week
	     */
	    public CaregiverHomePage click_TipOfTheWeekBulbIcon() throws Exception{
	    	//click_TipOfTheWeekBulbIcon.click();
	    	Assert.assertTrue(driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[2]/img")).isDisplayed());
	    	assertEquals("Tip of the Week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[2]/h3")).getText());
	    	assertEquals("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[2]/p")).getText());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to Select Get the Dementia Care App label
	     */
	    public CaregiverHomePage verifyGetAppLabel() throws Exception{
	    	click_GetAppLabel.click();
	    	assertEquals("Get the Dementia Care App", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[3]/p")).getText());
	    	return new CaregiverHomePage(driver);
	    }
	    
	    
		 /**
	     * This method is used to click on AppStole lInk
	     */
	    public CaregiverHomePage click_DownloadAppStoreLink() throws Exception{
	    	click_DownloadAppStoreLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify AppleStore lInk
	     */
	    public CaregiverHomePage verifyDownloadAppleStoreLink() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[3]/a[1]/img")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on GoogleStore lInk
	     */
	    public CaregiverHomePage click_DownloadGooglePlayLink() throws Exception{
	    	click_DownloadGooglePlayLink.click();
	    	return new CaregiverHomePage(driver);
	    }
	    
		 /**
	     * This method is used to verify GoogleStore lInk
	     */
	    public CaregiverHomePage verifyDownloadGooglePlayLink() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[3]/a[2]/img")).isDisplayed());
	    	return new CaregiverHomePage(driver);
	    }
	    
	    
		 /**
	     * This method is used to select on Footer
	     */
	    public CaregiverHomePage verifyFooter() throws Exception{
	    	assertEquals("U.S. Department of Veterans Affairs", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[1]")).getText());
	    	assertEquals("810 Vermont Avenue, NW Washington DC 20420", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[2]")).getText());
	    	assertEquals("Last reviewed/updated 6/3/15", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[3]")).getText());
	    	assertEquals("App Version: 15.0", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[4]")).getText());
	    	Thread.sleep(2000);
	    	return new CaregiverHomePage(driver);
	    }
}
