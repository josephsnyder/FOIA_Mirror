package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;


import org.openqa.selenium.WebDriver;


public class RxRefillLoginPage {
private static WebDriver driver;
	
		
	public RxRefillLoginPage(WebDriver driver){
		RxRefillLoginPage.driver = driver;
	}
	
	public void OpenURL (String URL){
		driver.navigate().to(URL);
		
	}
}
