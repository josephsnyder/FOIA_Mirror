package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {
	
	private static WebDriver driver;
	
	//Find WebElements 
	@FindBy(how = How.NAME,using ="userName")
	public WebElement userName;
	
	@FindBy(how = How.NAME,using ="password")
	public WebElement password;
	
	@FindBy(how = How.NAME,using ="submit")
	public WebElement submitButton;
	
	public LoginPage(WebDriver driver){
		LoginPage.driver = driver;
	}
	
	public void OpenURL (String URL){
		driver.navigate().to(URL);
		
	}
}
