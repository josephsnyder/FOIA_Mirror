package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ReportingMedicationErrorPage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Reporting Medication Error Page
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
	public WebElement click_FDAMedWatch;
	
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
	public WebElement click_ReportAMedicationError;
	
	public ReportingMedicationErrorPage(WebDriver driver){
		ReportingMedicationErrorPage.driver = driver;
	}
    
    /**
     * This method is used to click on FDA MedWatch link
     */
    public ReportingMedicationErrorPage click_FDAMedWatch() throws Exception{
    	click_FDAMedWatch.click();
    	return new ReportingMedicationErrorPage(driver);
    }
    
	
    /**
     * This method is used to click on Report A Medication Error link
     */
    public ReportingMedicationErrorPage click_ReportAMedicationError() throws Exception{
    	click_ReportAMedicationError.click();
    	return new ReportingMedicationErrorPage(driver);
    }
    
	public ReportingMedicationErrorPage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(5000);
		return new ReportingMedicationErrorPage(driver); 
	}
	
	public ReportingMedicationErrorPage verifyFDAMedWatchurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.fda.gov/Safety/MedWatch/default.htm", driver.getCurrentUrl());
		return new ReportingMedicationErrorPage(driver);
	}

	public ReportingMedicationErrorPage verifyReportAMedicationErrorurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.consumermedsafety.org/report-a-medication-error", driver.getCurrentUrl());
		return new ReportingMedicationErrorPage(driver);
	}
	

}
