package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverPainDetailsPage {
private static WebDriver driver; 
	
	
//Labored breathing Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "//*[@id='pain-dropdown-1']")
		public WebElement click_LaboredBreathingDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[1]/a")
		public WebElement click_LaboredBreathingDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")
		public WebElement click_LaboredBreathingDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")
		public WebElement click_LaboredBreathingDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[4]/a")
		public WebElement click_LaboredBreathingDropdown2Value; 
		
		
//Verbal expressions Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='pain-dropdown-2']")
		public WebElement click_VerbalExpressionsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[1]/a")
		public WebElement click_VerbalExpressionsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")
		public WebElement click_VerbalExpressionsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")
		public WebElement click_VerbalExpressionsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")
		public WebElement click_VerbalExpressionsDropdown2Value; 
		

//Facial expressions Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='pain-dropdown-3']")
		public WebElement click_FacialExpressionsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[1]/a")
		public WebElement click_FacialExpressionsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")
		public WebElement click_FacialExpressionsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")
		public WebElement click_FacialExpressionsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")
		public WebElement click_FacialExpressionsDropdown2Value; 
				
				
//Body language Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='pain-dropdown-4']")
		public WebElement click_BodyLanguageDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[1]/a")
		public WebElement click_BodyLanguageDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")
		public WebElement click_BodyLanguageDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")
		public WebElement click_BodyLanguageDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")
		public WebElement click_BodyLanguageDropdown2Value; 
					
//NOT consolable Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='pain-dropdown-5']")
		public WebElement click_NOTConsolableDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[1]/a")
		public WebElement click_NOTConsolableDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")
		public WebElement click_NOTConsolableDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")
		public WebElement click_NOTConsolableDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")
		public WebElement click_NOTConsolableDropdown2Value; 
				
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverPainDetailsPage(WebDriver driver){
			CaregiverPainDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Pain Title
	     */
	    public CaregiverPainDetailsPage verifyPainDetailsTitle() throws Exception{
	    	Thread.sleep(4000);
	    	assertEquals("Pain Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverPainDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Pain Text
	     */
	    public CaregiverPainDetailsPage verifyPainDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Pain.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverPainDetailsPage(driver);
	    }
	    
//Labored breathing Section Methods ======================================================================================================
		 /**
		 * This method is used to verify LaboredBreathing Label
		 */
		public CaregiverPainDetailsPage verifyLaboredBreathingLabel() throws Exception{
			assertEquals("Labored breathing", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[1]/label")).getText());
			return new CaregiverPainDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on LaboredBreathing drop down.
		 */
		public CaregiverPainDetailsPage click_LaboredBreathingDropdown() throws Exception{
			Thread.sleep(1000);
			click_LaboredBreathingDropdown.click();
			Thread.sleep(1000);
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify LaboredBreathing category Select an option drop down value
	    */
		public CaregiverPainDetailsPage verifyLaboredBreathingSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='pain-dropdown-1']")).getText());
			return new CaregiverPainDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on LaboredBreathing Select an option drop value
		 */
		public CaregiverPainDetailsPage click_LaboredBreathingDropdownSelectAnOptionValue() throws Exception{
			click_LaboredBreathingDropdownSelectAnOptionValue.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify LaboredBreathing category 0 value
		*/
		public CaregiverPainDetailsPage verifyLaboredBreathingSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on LaboredBreathing 0 value
		 */
		public CaregiverPainDetailsPage click_LaboredBreathingDropdown0Value() throws Exception{
			click_LaboredBreathingDropdown0Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify LaboredBreathing category 1 value
		*/
		public CaregiverPainDetailsPage verifyLaboredBreathingSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on LaboredBreathing 1 value
		 */
		public CaregiverPainDetailsPage click_LaboredBreathingDropdown1Value() throws Exception{
			click_LaboredBreathingDropdown1Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify LaboredBreathing category 2 value
		*/
		public CaregiverPainDetailsPage verifyLaboredBreathingSelection2() throws Exception{
			assertEquals("2 - Severe", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on LaboredBreathing 2 value
		 */
		public CaregiverPainDetailsPage click_LaboredBreathingDropdown2Value() throws Exception{
			click_LaboredBreathingDropdown2Value.click();
			return new CaregiverPainDetailsPage(driver);
		}

//Verbal expressions Section Methods ======================================================================================================
		 /**
		 * This method is used to verify VerbalExpressions Label
		 */
		public CaregiverPainDetailsPage verifyVerbalExpressionsLabel() throws Exception{
			assertEquals("Verbal expressions", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[1]/label")).getText());
			return new CaregiverPainDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on VerbalExpressions drop down.
		 */
		public CaregiverPainDetailsPage click_VerbalExpressionsDropdown() throws Exception{
			Thread.sleep(1000);
			click_VerbalExpressionsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify VerbalExpressions category Select an option drop down value
	    */
		public CaregiverPainDetailsPage verifyVerbalExpressionsSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='pain-dropdown-2']")).getText());
			return new CaregiverPainDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on VerbalExpressions Select an option drop value
		 */
		public CaregiverPainDetailsPage click_VerbalExpressionsDropdownSelectAnOptionValue() throws Exception{
			click_VerbalExpressionsDropdownSelectAnOptionValue.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify VerbalExpressions category 0 value
		*/
		public CaregiverPainDetailsPage verifyVerbalExpressionsSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on VerbalExpressions 0 value
		 */
		public CaregiverPainDetailsPage click_VerbalExpressionsDropdown0Value() throws Exception{
			click_VerbalExpressionsDropdown0Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify VerbalExpressions category 1 value
		*/
		public CaregiverPainDetailsPage verifyVerbalExpressionsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on VerbalExpressions 1 value
		 */
		public CaregiverPainDetailsPage click_VerbalExpressionsDropdown1Value() throws Exception{
			click_VerbalExpressionsDropdown1Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify VerbalExpressions category 2 value
		*/
		public CaregiverPainDetailsPage verifyVerbalExpressionsSelection2() throws Exception{
			assertEquals("2 - Severe", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on VerbalExpressions 2 value
		 */
		public CaregiverPainDetailsPage click_VerbalExpressionsDropdown2Value() throws Exception{
			click_VerbalExpressionsDropdown2Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
//Facial expressions Section Methods ======================================================================================================
		 /**
		 * This method is used to verify FacialExpressions Label
		 */
		public CaregiverPainDetailsPage verifyFacialExpressionsLabel() throws Exception{
			assertEquals("Facial expressions", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[1]/label")).getText());
			return new CaregiverPainDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on FacialExpressions drop down.
		 */
		public CaregiverPainDetailsPage click_FacialExpressionsDropdown() throws Exception{
			Thread.sleep(1000);
			click_FacialExpressionsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify FacialExpressions category Select an option drop down value
	    */
		public CaregiverPainDetailsPage verifyFacialExpressionsSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='pain-dropdown-3']")).getText());
			return new CaregiverPainDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on FacialExpressions Select an option drop value
		 */
		public CaregiverPainDetailsPage click_FacialExpressionsDropdownSelectAnOptionValue() throws Exception{
			click_FacialExpressionsDropdownSelectAnOptionValue.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify FacialExpressions category 0 value
		*/
		public CaregiverPainDetailsPage verifyFacialExpressionsSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on FacialExpressions 0 value
		 */
		public CaregiverPainDetailsPage click_FacialExpressionsDropdown0Value() throws Exception{
			click_FacialExpressionsDropdown0Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify FacialExpressions category 1 value
		*/
		public CaregiverPainDetailsPage verifyFacialExpressionsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on FacialExpressions 1 value
		 */
		public CaregiverPainDetailsPage click_FacialExpressionsDropdown1Value() throws Exception{
			click_FacialExpressionsDropdown1Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify FacialExpressions category 2 value
		*/
		public CaregiverPainDetailsPage verifyFacialExpressionsSelection2() throws Exception{
			assertEquals("2 - Severe", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on FacialExpressions 2 value
		 */
		public CaregiverPainDetailsPage click_FacialExpressionsDropdown2Value() throws Exception{
			click_FacialExpressionsDropdown2Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
//Body language Section Methods ======================================================================================================
		 /**
		 * This method is used to verify BodyLanguage Label
		 */
		public CaregiverPainDetailsPage verifyBodyLanguageLabel() throws Exception{
			assertEquals("Body language", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[1]/label")).getText());
			return new CaregiverPainDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on BodyLanguage drop down.
		 */
		public CaregiverPainDetailsPage click_BodyLanguageDropdown() throws Exception{
			Thread.sleep(1000);
			click_BodyLanguageDropdown.click();
			Thread.sleep(1000);
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify BodyLanguage category Select an option drop down value
	    */
		public CaregiverPainDetailsPage verifyBodyLanguageSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='pain-dropdown-4']")).getText());
			return new CaregiverPainDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on BodyLanguage Select an option drop value
		 */
		public CaregiverPainDetailsPage click_BodyLanguageDropdownSelectAnOptionValue() throws Exception{
			click_BodyLanguageDropdownSelectAnOptionValue.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify BodyLanguage category 0 value
		*/
		public CaregiverPainDetailsPage verifyBodyLanguageSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on BodyLanguage 0 value
		 */
		public CaregiverPainDetailsPage click_BodyLanguageDropdown0Value() throws Exception{
			click_BodyLanguageDropdown0Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify BodyLanguage category 1 value
		*/
		public CaregiverPainDetailsPage verifyBodyLanguageSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on BodyLanguage 1 value
		 */
		public CaregiverPainDetailsPage click_BodyLanguageDropdown1Value() throws Exception{
			click_BodyLanguageDropdown1Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify BodyLanguage category 2 value
		*/
		public CaregiverPainDetailsPage verifyBodyLanguageSelection2() throws Exception{
			assertEquals("2 - Severe", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on BodyLanguage 2 value
		 */
		public CaregiverPainDetailsPage click_BodyLanguageDropdown2Value() throws Exception{
			click_BodyLanguageDropdown2Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
//NOT consolable Section Methods ======================================================================================================
		 /**
		 * This method is used to verify NOTConsolable Label
		 */
		public CaregiverPainDetailsPage verifyNOTConsolableLabel() throws Exception{
			assertEquals("NOT consolable", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[1]/label")).getText());
			return new CaregiverPainDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on NOTConsolable drop down.
		 */
		public CaregiverPainDetailsPage click_NOTConsolableDropdown() throws Exception{
			Thread.sleep(1000);
			click_NOTConsolableDropdown.click();
			Thread.sleep(1000);
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify NOTConsolable category Select an option drop down value
	    */
		public CaregiverPainDetailsPage verifyNOTConsolableSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='pain-dropdown-5']")).getText());
			return new CaregiverPainDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on NOTConsolable Select an option drop value
		 */
		public CaregiverPainDetailsPage click_NOTConsolableDropdownSelectAnOptionValue() throws Exception{
			click_NOTConsolableDropdownSelectAnOptionValue.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify NOTConsolable category 0 value
		*/
		public CaregiverPainDetailsPage verifyNOTConsolableSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on NOTConsolable 0 value
		 */
		public CaregiverPainDetailsPage click_NOTConsolableDropdown0Value() throws Exception{
			click_NOTConsolableDropdown0Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify NOTConsolable category 1 value
		*/
		public CaregiverPainDetailsPage verifyNOTConsolableSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on NOTConsolable 1 value
		 */
		public CaregiverPainDetailsPage click_NOTConsolableDropdown1Value() throws Exception{
			click_NOTConsolableDropdown1Value.click();
			return new CaregiverPainDetailsPage(driver);
		}
		
		/**
		* This method is used to verify NOTConsolable category 2 value
		*/
		public CaregiverPainDetailsPage verifyNOTConsolableSelection2() throws Exception{
			assertEquals("2 - Severe", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverPainDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on NOTConsolable 2 value
		 */
		public CaregiverPainDetailsPage click_NOTConsolableDropdown2Value() throws Exception{
			click_NOTConsolableDropdown2Value.click();
			return new CaregiverPainDetailsPage(driver);
		}

//Buttons Section ===================================================================================================================
		
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverPainDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverPainDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverPainDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverPainDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverPainDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverPainDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverPainDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverPainDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverPainDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverPainDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverPainDetailsPage click_ContinueButton() throws Exception{
	    	click_ContinueButton.click();
	    	return new CaregiverPainDetailsPage(driver);
	    }
	    
 //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverPainDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverPainDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverPainDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverPainDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverPainDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverPainDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverPainDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverPainDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverPainDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverPainDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverPainDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverPainDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverPainDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverPainDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverPainDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverPainDetailsPage(driver);
  		}
  			    
	    
}
