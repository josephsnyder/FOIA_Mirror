package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;


import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class RefillableVAMedicationPage {
	public static WebDriver driver;
	
	public RefillableVAMedicationPage(WebDriver driver){
		RefillableVAMedicationPage.driver = driver;
	}
	
	
	
	public RefillableVAMedicationPage verifyRefillableVAMedicationPage() throws Exception{
		Thread.sleep(5000);
		String titleRefillable = driver.findElement(By.cssSelector("h1.page-heading")).getText();
		assertTrue(titleRefillable.contains("Refillable VA Medications"));
		Thread.sleep(3000);
		
		return new RefillableVAMedicationPage(driver);
	}
}
