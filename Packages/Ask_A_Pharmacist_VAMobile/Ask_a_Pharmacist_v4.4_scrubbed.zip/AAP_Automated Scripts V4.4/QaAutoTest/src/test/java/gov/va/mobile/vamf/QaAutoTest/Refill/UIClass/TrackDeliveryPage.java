package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;


import static org.junit.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class TrackDeliveryPage {
	public static WebDriver driver;
	
	public TrackDeliveryPage(WebDriver driver){
		TrackDeliveryPage.driver = driver;
	}
	
	
	
	public TrackDeliveryPage verifyTrackDeliveryPage() throws Exception{
		Thread.sleep(5000);
		String titleRefillable =  driver.findElement(By.cssSelector("h1.page-heading")).getText();
		assertTrue(titleRefillable.contains("Track Delivery"));
		Thread.sleep(3000);
		
		return new TrackDeliveryPage(driver);
	}
}
