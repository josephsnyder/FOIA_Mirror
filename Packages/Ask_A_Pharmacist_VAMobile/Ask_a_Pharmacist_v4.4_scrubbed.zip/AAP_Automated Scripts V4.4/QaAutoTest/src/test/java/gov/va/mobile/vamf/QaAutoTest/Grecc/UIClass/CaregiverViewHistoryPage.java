package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverViewHistoryPage {

private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
	public WebElement click_VAhealthlogo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']")
	public WebElement click_SignInButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
	public WebElement click_VABannerHeader; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_ResourceCenterButtonLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement click_HistoryForTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p")
	public WebElement click_HistoryForBodyText; 
	
	
	
	public CaregiverViewHistoryPage(WebDriver driver){
		CaregiverViewHistoryPage.driver = driver;
	}

	 /**
     * This method is used to verify History title
     */
    public CaregiverViewHistoryPage verifyHistoryTitle() throws Exception{
    	assertEquals("History for", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
    	//Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).getText(), false);
    	return new CaregiverViewHistoryPage(driver);
    }
    
	 /**
     * This method is used to verify Home text
     */
    public CaregiverViewHistoryPage verifyHistoryText() throws Exception{
    	assertEquals("Placeholder for Status Update History", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p")).getText());
    	return new CaregiverViewHistoryPage(driver);
    }
}
