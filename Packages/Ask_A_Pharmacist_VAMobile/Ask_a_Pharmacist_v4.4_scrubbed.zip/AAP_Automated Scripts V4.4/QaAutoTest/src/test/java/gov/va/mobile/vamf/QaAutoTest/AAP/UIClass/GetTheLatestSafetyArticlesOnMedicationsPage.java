package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GetTheLatestSafetyArticlesOnMedicationsPage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Get the latest Safety Articles on Medications Page
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
	public WebElement click_FreeMedicationAlerts;
	
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
	public WebElement click_RecallsMarketWithdrawalsAndSafetyAlertsOnFDA;
	
	public GetTheLatestSafetyArticlesOnMedicationsPage(WebDriver driver){
		GetTheLatestSafetyArticlesOnMedicationsPage.driver = driver;
	}
    
    /**
     * This method is used to click on Free Medication Alerts link
     */
    public GetTheLatestSafetyArticlesOnMedicationsPage click_FreeMedicationAlerts() throws Exception{
    	click_FreeMedicationAlerts.click();
    	return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
    }
    
    /**
     * This method is used to click on Recalls Market Withdrawals And Safety Alerts On FDA link
     */
    public GetTheLatestSafetyArticlesOnMedicationsPage click_RecallsMarketWithdrawalsAndSafetyAlertsOnFDA() throws Exception{
    	click_RecallsMarketWithdrawalsAndSafetyAlertsOnFDA.click();
    	return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
    }
    	
 
	public GetTheLatestSafetyArticlesOnMedicationsPage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		//assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(3000);
		return new GetTheLatestSafetyArticlesOnMedicationsPage(driver); 
	}
	
	public GetTheLatestSafetyArticlesOnMedicationsPage verifyFreeMedicationAlertsurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.consumermedsafety.org/tools-and-resources/medication-safety-tools-and-resources/know-your-medicine/get-free-personalized-drug-updates", driver.getCurrentUrl());
		return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
	}
	
	public GetTheLatestSafetyArticlesOnMedicationsPage verifyRecallsMarketWithdrawalsAndSafetyAlertsOnFDAurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.fda.gov/Safety/Recalls/default.htm", driver.getCurrentUrl());
		return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
	}
	
	 /**
     * This method is used to Click on Cancel button.
     */

    public GetTheLatestSafetyArticlesOnMedicationsPage click_Cancel() throws Exception{
    	driver.findElement(By.id("aapStay")).click();
    	assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#safety-articles", driver.getCurrentUrl());
    	return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
    }
    
	public GetTheLatestSafetyArticlesOnMedicationsPage GoBackBrowserButton() throws Exception{
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(4000);
		assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#safety-articles", driver.getCurrentUrl());
	    Thread.sleep(3000);
    return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
	}
}
