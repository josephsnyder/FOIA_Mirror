package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class AAPFooter {
	  private WebDriver driver;
	  //private String baseUrl;
	  private boolean acceptNextAlert = true;
	  private StringBuffer verificationErrors = new StringBuffer();
	  private String temp;

	  @Before
	  public void setUp() throws Exception {
	    driver = new FirefoxDriver();
	    //baseUrl = "www.google.com";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }

	  @Test
	  public void testAAPFooter() throws Exception {
		  try {
		  driver.get("http://localhost:8080/AAPSprint3_war4/");
		  //WindowHelper.windowMaximize();
		  System.out.println("Title : " + driver.getTitle());
		  //Assert.assertEquals(driver.getTitle(), "CCCC");
		  Assert.assertTrue(driver.getTitle().contains("Enter"));
		  //System.out.println("Displayed : " + driver.findElement(By.linkText("Home")).isDisplayed())
		  //driver.navigate().back();
		} catch (Exception e) {
			e.printStackTrace();
		}
		  /*
			public static void back() {
				driver.navigate().back();
			}
			
			public static void forward() {
				driver.navigate().forward();
				
			}
			
			public static void refresh() {
				driver.navigate().refresh();
				
			}
			
			public static void navigateToPage(String url) {
				driver.navigate().to(url);
				
			}*/ 
		  /*System.out.println("Selected : " + driver.findElement(By.id("Bugzilla_restrictlogin")).isSelected());
			driver.findElement(By.id("Bugzilla_restrictlogin")).click();
			System.out.println("Selected : " + driver.findElement(By.id("Bugzilla_restrictlogin")).isSelected());*/
		  
		  
	  //} catch (NoSuchElementException e) {
		//	e.printStackTrace();
		//}
	  }
}
	    /*System.out.println("Title check = " + driver.getTitle());
	    if
	    (driver.equals(getTitle(), "AAP")
	    //Assert.assertEquals(driver.getTitle(), "AAP")
	    //if(driver.getTitle() == "AAP")
	    System.out.println("Title verfied =" + driver.getTitle());
	    else
	    System.out.println("Title not verified");
	    //assertEquals("AAP", driver.getTitle());
	    try {
	     // assertTrue(isElementPresent(By.cssSelector("footer")));
	     //System.out.println("Footer =" +driver.get(assertTrue(isElementPresent(By.cssSelector("footer")))));
	      //System.out.println("Title =" + driver.getTitle());
	      //System.out.println("Url : " + driver.getCurrentUrl());
	      //if(driver.getTitle() == "AAP")
	    	  //System.out.println("Title =" + driver.getTitle());
	    	  //driver.quit():
	    	  //else.assertFalse("Wrong Title");
	      //String alertText = alert.getText();
	      //System.out.println("Url : " + driver.getText());
	      //assertTrue(driver.getTitle().equalsIgnoreCase("AAC"));
	      } catch (Error e) {
	      verificationErrors.append(e.toString());
	    }
	    assertEquals("3/12/16", driver.findElement(By.cssSelector("footer > span")).getText());
	    System.out.println("test Passed");
	  }

	  private Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}

	@After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }

	  private boolean isElementPresent(By by) {
	    try {
	      driver.findElement(by);
	      return true;
	    } catch (NoSuchElementException e) {
	      return false;
	    }
	  }

	  private boolean isAlertPresent() {
	    try {
	      driver.switchTo().alert();
	      return true;
	    } catch (NoAlertPresentException e) {
	      return false;
	    }
	  }

	  private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }


	  }*/
	
