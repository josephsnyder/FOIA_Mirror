package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class DrugInteractionsAdverseDrugPage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Trusted Medication Resouce Page
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]")
		public WebElement click_KnowYourMedicationLabe;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]")
		public WebElement click_PillIdentification;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]")
		public WebElement click_DrugInteractions;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]")
		public WebElement click_MedicationAdministration;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[5]/a/span[1]")
		public WebElement click_MedicationDisposal;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[6]/a/span")
		public WebElement click_ConsumerDrugHerbalSupplementInformation;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[7]/a/span[1]")
		public WebElement click_FAQAskAPharmacist;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[8]/a/span[1]")
		public WebElement click_FAQVANationalMedicationFormulary;
		
		
		public DrugInteractionsAdverseDrugPage(WebDriver driver){
			DrugInteractionsAdverseDrugPage.driver = driver;
		}
		/**
		 * This method is used to Click on ConsumerDrugHerbalSupplementInformation
		 */
		public ConsumerDrugHerbalSupplementInformationPage click_ConsumerDrugHerbalSupplementInformation() throws Exception{
			click_ConsumerDrugHerbalSupplementInformation.click();
			Thread.sleep(3000);
			return new ConsumerDrugHerbalSupplementInformationPage(driver);
		}
		
		public  DrugInteractionsAdverseDrugPage clickDrugInteractionsAdverseDrugEvents() throws Exception{
			click_DrugInteractions.click();
			return new DrugInteractionsAdverseDrugPage(driver);
		}
	
}
