package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverDailyFunctionDetailsPage {
private static WebDriver driver; 
	
	
//Write checks, pay bills, balance checkbook Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-1']")
		public WebElement click_WriteChecksPayBillsBalanceCheckbookDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[1]/a")
		public WebElement click_WriteChecksPayBillsBalanceCheckbookDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")
		public WebElement click_WriteChecksPayBillsBalanceCheckbookDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")
		public WebElement click_WriteChecksPayBillsBalanceCheckbookDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[4]/a")
		public WebElement click_WriteChecksPayBillsBalanceCheckbookDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[5]/a")
		public WebElement click_WriteChecksPayBillsBalanceCheckbookDropdown3Value; 
		
//Assemble tax records, business affairs, or paper Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-2']")
		public WebElement click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[1]/a")
		public WebElement click_AssembleTaxRecordsBusinessAffairsOrPaperDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")
		public WebElement click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")
		public WebElement click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")
		public WebElement click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[5]/a")
		public WebElement click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown3Value; 
		

//Shop alone for clothes, household necessities, or groceries Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-3']")
		public WebElement click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[1]/a")
		public WebElement click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")
		public WebElement click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")
		public WebElement click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")
		public WebElement click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[5]/a")
		public WebElement click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown3Value; 
				
				
//Play a game of skill, work on a hobby Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-4']")
		public WebElement click_PlayAGameOfSkillWorkOnAHobbyDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[1]/a")
		public WebElement click_PlayAGameOfSkillWorkOnAHobbyDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")
		public WebElement click_PlayAGameOfSkillWorkOnAHobbyDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")
		public WebElement click_PlayAGameOfSkillWorkOnAHobbyDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")
		public WebElement click_PlayAGameOfSkillWorkOnAHobbyDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[5]/a")
		public WebElement click_PlayAGameOfSkillWorkOnAHobbyDropdown3Value; 
				
				
//Heat water, make coffee, turn off stove Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-5']")
		public WebElement click_HeatWaterMakeCoffeeTurnOffStoveDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[1]/a")
		public WebElement click_HeatWaterMakeCoffeeTurnOffStoveDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")
		public WebElement click_HeatWaterMakeCoffeeTurnOffStoveDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")
		public WebElement click_HeatWaterMakeCoffeeTurnOffStoveDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")
		public WebElement click_HeatWaterMakeCoffeeTurnOffStoveDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[5]/a")
		public WebElement click_HeatWaterMakeCoffeeTurnOffStoveDropdown3Value; 
		
		
//Prepare a balanced meal Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-6']")
		public WebElement click_PrepareABalancedMealDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[1]/a")
		public WebElement click_PrepareABalancedMealDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[2]/a")
		public WebElement click_PrepareABalancedMealDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[3]/a")
		public WebElement click_PrepareABalancedMealDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[4]/a")
		public WebElement click_PrepareABalancedMealDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[5]/a")
		public WebElement click_PrepareABalancedMealDropdown3Value; 
		
//Keep track of current events Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-7']")
		public WebElement click_KeepTrackOfCurrentEventsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[1]/a")
		public WebElement click_KeepTrackOfCurrentEventsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[2]/a")
		public WebElement click_KeepTrackOfCurrentEventsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[3]/a")
		public WebElement click_KeepTrackOfCurrentEventsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[4]/a")
		public WebElement click_KeepTrackOfCurrentEventsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[5]/a")
		public WebElement click_KeepTrackOfCurrentEventsDropdown3Value; 				
	
//Pay attention to, understand, discuss a TV show or book Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-8']")
		public WebElement click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[1]/a")
		public WebElement click_PayAttentionToUnderstandDiscussATVShowOrBookDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[2]/a")
		public WebElement click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[3]/a")
		public WebElement click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[4]/a")
		public WebElement click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[5]/a")
		public WebElement click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown3Value; 	

//Remember appointments, family occasions, holidays, medications Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-9']")
		public WebElement click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[1]/a")
		public WebElement click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[2]/a")
		public WebElement click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[3]/a")
		public WebElement click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[4]/a")
		public WebElement click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[5]/a")
		public WebElement click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown3Value; 	
		
//Travel out of neighborhood, driving, arranging to take bus Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-10']")
		public WebElement click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[1]/a")
		public WebElement click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[2]/a")
		public WebElement click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[3]/a")
		public WebElement click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[4]/a")
		public WebElement click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[5]/a")
		public WebElement click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown3Value; 
		
//Getting dressed Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-11']")
		public WebElement click_GettingDressedDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[1]/a")
		public WebElement click_GettingDressedDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[2]/a")
		public WebElement click_GettingDressedDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[3]/a")
		public WebElement click_GettingDressedDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[4]/a")
		public WebElement click_GettingDressedDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[5]/a")
		public WebElement click_GettingDressedDropdown3Value; 
		
//Using toilet Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-12']")
		public WebElement click_UsingToiletDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[1]/a")
		public WebElement click_UsingToiletDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[2]/a")
		public WebElement click_UsingToiletDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[3]/a")
		public WebElement click_UsingToiletDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[4]/a")
		public WebElement click_UsingToiletDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[5]/a")
		public WebElement click_UsingToiletDropdown3Value; 
		
//Bathing/showering Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-13']")
		public WebElement click_BathingShoweringDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[1]/a")
		public WebElement click_BathingShoweringDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[2]/a")
		public WebElement click_BathingShoweringDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[3]/a")
		public WebElement click_BathingShoweringDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[4]/a")
		public WebElement click_BathingShoweringDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[5]/a")
		public WebElement click_BathingShoweringDropdown3Value; 
		
//Planning activities Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-14']")
		public WebElement click_PlanningActivitiesDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[1]/a")
		public WebElement click_PlanningActivitiesDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[2]/a")
		public WebElement click_PlanningActivitiesDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[3]/a")
		public WebElement click_PlanningActivitiesDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[4]/a")
		public WebElement click_PlanningActivitiesDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[5]/a")
		public WebElement click_PlanningActivitiesDropdown3Value; 
		
//Using Telephone Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-15']")
		public WebElement click_UsingTelephoneDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[1]/a")
		public WebElement click_UsingTelephoneDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[2]/a")
		public WebElement click_UsingTelephoneDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[3]/a")
		public WebElement click_UsingTelephoneDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[4]/a")
		public WebElement click_UsingTelephoneDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[5]/a")
		public WebElement click_UsingTelephoneDropdown3Value; 
		
//Managing Medications ===========================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-16']")
		public WebElement click_ManagingMedicationsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[1]/a")
		public WebElement click_ManagingMedicationsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[2]/a")
		public WebElement click_ManagingMedicationsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[3]/a")
		public WebElement click_ManagingMedicationsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[4]/a")
		public WebElement click_ManagingMedicationsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[5]/a")
		public WebElement click_ManagingMedicationsDropdown3Value; 
		
//Housekeeping ===========================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-17']")
		public WebElement click_HousekeepingDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[17]div[2]/div/ul/li[1]/a")
		public WebElement click_HousekeepingDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[2]/a")
		public WebElement click_HousekeepingDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[3]/a")
		public WebElement click_HousekeepingDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[4]/a")
		public WebElement click_HousekeepingDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[5]/a")
		public WebElement click_HousekeepingDropdown3Value; 
		
//Laundry ===========================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='daily-dropdown-18']")
		public WebElement click_LaundryDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[1]/a")
		public WebElement click_LaundryDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[2]/a")
		public WebElement click_LaundryDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[3]/a")
		public WebElement click_LaundryDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[4]/a")
		public WebElement click_LaundryDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[5]/a")
		public WebElement click_LaundryDropdown3Value;

		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
		
//==========================================================================================================================
		public CaregiverDailyFunctionDetailsPage(WebDriver driver){
			CaregiverDailyFunctionDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Daily Function Details Title
	     */
	    public CaregiverDailyFunctionDetailsPage verifyDailyFunctionDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Daily Function Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Daily Function Details Text
	     */
	    public CaregiverDailyFunctionDetailsPage verifyDailyFunctionDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Daily Function.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }
	    
//Write checks, pay bills, balance checkbook Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Write checks, pay bills, balance checkbook Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyWriteChecksPayBillsBalanceCheckbookLabel() throws Exception{
			assertEquals("Write checks, pay bills, balance checkbook", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on WriteChecksPayBillsBalanceCheckbook drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_WriteChecksPayBillsBalanceCheckbookDropdown() throws Exception{
			Thread.sleep(1000);
			click_WriteChecksPayBillsBalanceCheckbookDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify WriteChecksPayBillsBalanceCheckbook category Select an option drop down value
	    */
		public CaregiverDailyFunctionDetailsPage verifyWriteChecksPayBillsBalanceCheckbookSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-1']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on WriteChecksPayBillsBalanceCheckbook Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_WriteChecksPayBillsBalanceCheckbookDropdownSelectAnOptionValue() throws Exception{
			click_WriteChecksPayBillsBalanceCheckbookDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify WriteChecksPayBillsBalanceCheckbook category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyWriteChecksPayBillsBalanceCheckbookSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on WriteChecksPayBillsBalanceCheckbook 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_WriteChecksPayBillsBalanceCheckbookDropdown0Value() throws Exception{
			click_WriteChecksPayBillsBalanceCheckbookDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify WriteChecksPayBillsBalanceCheckbook category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyWriteChecksPayBillsBalanceCheckbookSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on WriteChecksPayBillsBalanceCheckbook 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_WriteChecksPayBillsBalanceCheckbookDropdown1Value() throws Exception{
			click_WriteChecksPayBillsBalanceCheckbookDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify WriteChecksPayBillsBalanceCheckbook category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyWriteChecksPayBillsBalanceCheckbookSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on WriteChecksPayBillsBalanceCheckbook 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_WriteChecksPayBillsBalanceCheckbookDropdown2Value() throws Exception{
			click_WriteChecksPayBillsBalanceCheckbookDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify WriteChecksPayBillsBalanceCheckbook category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyWriteChecksPayBillsBalanceCheckbookSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on WriteChecksPayBillsBalanceCheckbook 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_WriteChecksPayBillsBalanceCheckbookDropdown3Value() throws Exception{
			click_WriteChecksPayBillsBalanceCheckbookDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
	    
//Assemble tax records, business affairs, or paper  Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Assemble tax records, business affairs, or paper Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyAssembleTaxRecordsBusinessAffairsOrPaperLabel() throws Exception{
			assertEquals("Assemble tax records, business affairs, or paper", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on AssembleTaxRecordsBusinessAffairsOrPaper drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown() throws Exception{
			Thread.sleep(1000);
			click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Assemble tax records, business affairs, or paper category Select an option drop down value for AssembleTaxRecordsBusinessAffairsOrPaper
	    */
		public CaregiverDailyFunctionDetailsPage verifyAssembleTaxRecordsBusinessAffairsOrPaperSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-2']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on AssembleTaxRecordsBusinessAffairsOrPaper Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_AssembleTaxRecordsBusinessAffairsOrPaperDropdownSelectAnOptionValue() throws Exception{
			click_AssembleTaxRecordsBusinessAffairsOrPaperDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Assemble tax records, business affairs, or paper category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyAssembleTaxRecordsBusinessAffairsOrPaperSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AssembleTaxRecordsBusinessAffairsOrPaper 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown0Value() throws Exception{
			click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Assemble tax records, business affairs, or paper category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyAssembleTaxRecordsBusinessAffairsOrPaperSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AssembleTaxRecordsBusinessAffairsOrPaper 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown1Value() throws Exception{
			click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Assemble tax records, business affairs, or paper category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyAssembleTaxRecordsBusinessAffairsOrPaperSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AssembleTaxRecordsBusinessAffairsOrPaper 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown2Value() throws Exception{
			click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Assemble tax records, business affairs, or paper category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyAssembleTaxRecordsBusinessAffairsOrPaperSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AssembleTaxRecordsBusinessAffairsOrPaper 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown3Value() throws Exception{
			click_AssembleTaxRecordsBusinessAffairsOrPaperDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
//Shop alone for clothes, household necessities, or groceries Section Methods ======================================================================================================
		 /**
		 * This method is used to verify ShopAloneForClothesHouseholdNecessitiesOrGroceries Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyShopAloneForClothesHouseholdNecessitiesOrGroceriesLabel() throws Exception{
			assertEquals("Shop alone for clothes, household necessities, or groceries", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on ShopAloneForClothesHouseholdNecessitiesOrGroceries drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown() throws Exception{
			Thread.sleep(1000);
			click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify ShopAloneForClothesHouseholdNecessitiesOrGroceries category Select an option drop down value for ShopAloneForClothesHouseholdNecessitiesOrGroceries
	    */
		public CaregiverDailyFunctionDetailsPage verifyShopAloneForClothesHouseholdNecessitiesOrGroceriesSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-3']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on ShopAloneForClothesHouseholdNecessitiesOrGroceries Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdownSelectAnOptionValue() throws Exception{
			click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ShopAloneForClothesHouseholdNecessitiesOrGroceries category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyShopAloneForClothesHouseholdNecessitiesOrGroceriesSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ShopAloneForClothesHouseholdNecessitiesOrGroceries 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown0Value() throws Exception{
			click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ShopAloneForClothesHouseholdNecessitiesOrGroceries category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyShopAloneForClothesHouseholdNecessitiesOrGroceriesSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ShopAloneForClothesHouseholdNecessitiesOrGroceries 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown1Value() throws Exception{
			click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ShopAloneForClothesHouseholdNecessitiesOrGroceries category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyShopAloneForClothesHouseholdNecessitiesOrGroceriesSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ShopAloneForClothesHouseholdNecessitiesOrGroceries 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown2Value() throws Exception{
			click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ShopAloneForClothesHouseholdNecessitiesOrGroceries category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyShopAloneForClothesHouseholdNecessitiesOrGroceriesSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ShopAloneForClothesHouseholdNecessitiesOrGroceries 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown3Value() throws Exception{
			click_ShopAloneForClothesHouseholdNecessitiesOrGroceriesDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
			
//Play a game of skill, work on a hobby Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Play a game of skill, work on a hobby Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyPlayAGameOfSkillWorkOnAHobbyLabel() throws Exception{
			assertEquals("Play a game of skill, work on a hobby", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Play a game of skill, work on a hobby drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_PlayAGameOfSkillWorkOnAHobbyDropdown() throws Exception{
			Thread.sleep(1000);
			click_PlayAGameOfSkillWorkOnAHobbyDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Play a game of skill, work on a hobby category Select an option drop down value for PlayAGameOfSkillWorkOnAHobby
	    */
		public CaregiverDailyFunctionDetailsPage verifyPlayAGameOfSkillWorkOnAHobbySelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-4']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Play a game of skill, work on a hobby Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlayAGameOfSkillWorkOnAHobbyDropdownSelectAnOptionValue() throws Exception{
			click_PlayAGameOfSkillWorkOnAHobbyDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Play a game of skill, work on a hobby category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlayAGameOfSkillWorkOnAHobbySelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Play a game of skill, work on a hobby 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlayAGameOfSkillWorkOnAHobbyDropdown0Value() throws Exception{
			click_PlayAGameOfSkillWorkOnAHobbyDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PlayAGameOfSkillWorkOnAHobby category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlayAGameOfSkillWorkOnAHobbySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PlayAGameOfSkillWorkOnAHobby 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlayAGameOfSkillWorkOnAHobbyDropdown1Value() throws Exception{
			click_PlayAGameOfSkillWorkOnAHobbyDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PlayAGameOfSkillWorkOnAHobby category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlayAGameOfSkillWorkOnAHobbySelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PlayAGameOfSkillWorkOnAHobby 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlayAGameOfSkillWorkOnAHobbyDropdown2Value() throws Exception{
			click_PlayAGameOfSkillWorkOnAHobbyDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PlayAGameOfSkillWorkOnAHobby category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlayAGameOfSkillWorkOnAHobbySelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on PlayAGameOfSkillWorkOnAHobby 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlayAGameOfSkillWorkOnAHobbyDropdown3Value() throws Exception{
			click_PlayAGameOfSkillWorkOnAHobbyDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
			

//Heat water, make coffee, turn off stove Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Heat water, make coffee, turn off stove Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyHeatWaterMakeCoffeeTurnOffStoveLabel() throws Exception{
			assertEquals("Heat water, make coffee, turn off stove", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Heat water, make coffee, turn off stove drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_HeatWaterMakeCoffeeTurnOffStoveDropdown() throws Exception{
			Thread.sleep(1000);
			click_HeatWaterMakeCoffeeTurnOffStoveDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Heat water, make coffee, turn off stove category Select an option drop down value
	    */
		public CaregiverDailyFunctionDetailsPage verifyHeatWaterMakeCoffeeTurnOffStoveSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-5']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Heat water, make coffee, turn off stove Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_HeatWaterMakeCoffeeTurnOffStoveDropdownSelectAnOptionValue() throws Exception{
			click_HeatWaterMakeCoffeeTurnOffStoveDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Heat water, make coffee, turn off stove category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHeatWaterMakeCoffeeTurnOffStoveSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Heat water, make coffee, turn off stove 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HeatWaterMakeCoffeeTurnOffStoveDropdown0Value() throws Exception{
			click_HeatWaterMakeCoffeeTurnOffStoveDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HeatWaterMakeCoffeeTurnOffStove category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHeatWaterMakeCoffeeTurnOffStoveSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HeatWaterMakeCoffeeTurnOffStove 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HeatWaterMakeCoffeeTurnOffStoveDropdown1Value() throws Exception{
			click_HeatWaterMakeCoffeeTurnOffStoveDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HeatWaterMakeCoffeeTurnOffStove category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHeatWaterMakeCoffeeTurnOffStoveSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HeatWaterMakeCoffeeTurnOffStove 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HeatWaterMakeCoffeeTurnOffStoveDropdown2Value() throws Exception{
			click_HeatWaterMakeCoffeeTurnOffStoveDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HeatWaterMakeCoffeeTurnOffStove category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHeatWaterMakeCoffeeTurnOffStoveSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on HeatWaterMakeCoffeeTurnOffStove 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HeatWaterMakeCoffeeTurnOffStoveDropdown3Value() throws Exception{
			click_HeatWaterMakeCoffeeTurnOffStoveDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
			
//Prepare a balanced meal Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Prepare a balanced meal Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyPrepareABalancedMealLabel() throws Exception{
			assertEquals("Prepare a balanced meal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Prepare a balanced meal drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_PrepareABalancedMealDropdown() throws Exception{
			Thread.sleep(1000);
			click_PrepareABalancedMealDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Prepare a balanced meal category Select an option drop down value for PrepareABalancedMeal
	    */
		public CaregiverDailyFunctionDetailsPage verifyPrepareABalancedMealSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-6']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Prepare a balanced meal Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_PrepareABalancedMealDropdownSelectAnOptionValue() throws Exception{
			click_PrepareABalancedMealDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Prepare a balanced meal category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPrepareABalancedMealSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Prepare a balanced meal 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PrepareABalancedMealDropdown0Value() throws Exception{
			click_PrepareABalancedMealDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify PrepareABalancedMeal category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPrepareABalancedMealSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PrepareABalancedMeal 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PrepareABalancedMealDropdown1Value() throws Exception{
			click_PrepareABalancedMealDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PrepareABalancedMeal category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPrepareABalancedMealSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PrepareABalancedMeal 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PrepareABalancedMealDropdown2Value() throws Exception{
			click_PrepareABalancedMealDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PrepareABalancedMeal category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPrepareABalancedMealSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on PrepareABalancedMeal 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PrepareABalancedMealDropdown3Value() throws Exception{
			click_PrepareABalancedMealDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
//Keep track of current events Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Keep track of current events Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyKeepTrackOfCurrentEventsLabel() throws Exception{
			assertEquals("Keep track of current events", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Keep track of current events drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_KeepTrackOfCurrentEventsDropdown() throws Exception{
			Thread.sleep(1000);
			click_KeepTrackOfCurrentEventsDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Keep track of current events category Select an option drop down value for KeepTrackOfCurrentEvents
	    */
		public CaregiverDailyFunctionDetailsPage verifyKeepTrackOfCurrentEventsSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-7']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Keep track of current events Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_KeepTrackOfCurrentEventsDropdownSelectAnOptionValue() throws Exception{
			click_KeepTrackOfCurrentEventsDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Keep track of current events category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyKeepTrackOfCurrentEventsSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Keep track of current events 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_KeepTrackOfCurrentEventsDropdown0Value() throws Exception{
			click_KeepTrackOfCurrentEventsDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify KeepTrackOfCurrentEvents category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyKeepTrackOfCurrentEventsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on KeepTrackOfCurrentEvents 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_KeepTrackOfCurrentEventsDropdown1Value() throws Exception{
			click_KeepTrackOfCurrentEventsDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify KeepTrackOfCurrentEvents category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyKeepTrackOfCurrentEventsSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on KeepTrackOfCurrentEvents 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_KeepTrackOfCurrentEventsDropdown2Value() throws Exception{
			click_KeepTrackOfCurrentEventsDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify KeepTrackOfCurrentEvents category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyKeepTrackOfCurrentEventsSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on KeepTrackOfCurrentEvents 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_KeepTrackOfCurrentEventsDropdown3Value() throws Exception{
			click_KeepTrackOfCurrentEventsDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
//Pay attention to, understand, discuss a TV show or book Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Pay attention to, understand, discuss a TV show or books Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyPayAttentionToUnderstandDiscussATVShowOrBookLabel() throws Exception{
			assertEquals("Pay attention to, understand, discuss a TV show or book", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Pay attention to, understand, discuss a TV show or books drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown() throws Exception{
			Thread.sleep(1000);
			click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Pay attention to, understand, discuss a TV show or books category Select an option drop down value for PayAttentionToUnderstandDiscussATVShowOrBook
	    */
		public CaregiverDailyFunctionDetailsPage verifyPayAttentionToUnderstandDiscussATVShowOrBookSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-8']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Pay attention to, understand, discuss a TV show or books Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_PayAttentionToUnderstandDiscussATVShowOrBookDropdownSelectAnOptionValue() throws Exception{
			click_PayAttentionToUnderstandDiscussATVShowOrBookDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Pay attention to, understand, discuss a TV show or books category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPayAttentionToUnderstandDiscussATVShowOrBookSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Pay attention to, understand, discuss a TV show or books 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown0Value() throws Exception{
			click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify PayAttentionToUnderstandDiscussATVShowOrBook category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPayAttentionToUnderstandDiscussATVShowOrBookSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PayAttentionToUnderstandDiscussATVShowOrBook 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown1Value() throws Exception{
			click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PayAttentionToUnderstandDiscussATVShowOrBook category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPayAttentionToUnderstandDiscussATVShowOrBookSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PayAttentionToUnderstandDiscussATVShowOrBook 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown2Value() throws Exception{
			click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PayAttentionToUnderstandDiscussATVShowOrBook category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPayAttentionToUnderstandDiscussATVShowOrBookSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on PayAttentionToUnderstandDiscussATVShowOrBook 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown3Value() throws Exception{
			click_PayAttentionToUnderstandDiscussATVShowOrBookDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
			
		}
		
//Remember appointments, family occasions, holidays, medications Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Remember appointments, family occasions, holidays, medications Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyRememberAppointmentsFamilyOccasionsHolidaysMedicationsLabel() throws Exception{
			assertEquals("Remember appointments, family occasions, holidays, medications", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Remember appointments, family occasions, holidays, medications drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown() throws Exception{
			Thread.sleep(1000);
			click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Remember appointments, family occasions, holidays, medications category Select an option drop down value for RememberAppointmentsFamilyOccasionsHolidaysMedications
	    */
		public CaregiverDailyFunctionDetailsPage verifyRememberAppointmentsFamilyOccasionsHolidaysMedicationsSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-9']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Remember appointments, family occasions, holidays, medications Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdownSelectAnOptionValue() throws Exception{
			click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Remember appointments, family occasions, holidays, medications category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyRememberAppointmentsFamilyOccasionsHolidaysMedicationsSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Remember appointments, family occasions, holidays, medications 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown0Value() throws Exception{
			click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify RememberAppointmentsFamilyOccasionsHolidaysMedications category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyRememberAppointmentsFamilyOccasionsHolidaysMedicationsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on RememberAppointmentsFamilyOccasionsHolidaysMedications 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown1Value() throws Exception{
			click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify RememberAppointmentsFamilyOccasionsHolidaysMedications category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyRememberAppointmentsFamilyOccasionsHolidaysMedicationsSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on RememberAppointmentsFamilyOccasionsHolidaysMedications 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown2Value() throws Exception{
			click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify RememberAppointmentsFamilyOccasionsHolidaysMedications category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyRememberAppointmentsFamilyOccasionsHolidaysMedicationsSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on RememberAppointmentsFamilyOccasionsHolidaysMedications 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown3Value() throws Exception{
			click_RememberAppointmentsFamilyOccasionsHolidaysMedicationsDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
			
		}
		
//Travel out of neighborhood, driving, arranging to take bus Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Travel out of neighborhood, driving, arranging to take bus Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyTravelOutOfNeighborhoodDrivingArrangingToTakeBusLabel() throws Exception{
			assertEquals("Travel out of neighborhood, driving, arranging to take bus", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Travel out of neighborhood, driving, arranging to take bus drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown() throws Exception{
			Thread.sleep(1000);
			click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Travel out of neighborhood, driving, arranging to take bus category Select an option drop down value for TravelOutOfNeighborhoodDrivingArrangingToTakeBus
	    */
		public CaregiverDailyFunctionDetailsPage verifyTravelOutOfNeighborhoodDrivingArrangingToTakeBusSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-10']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Travel out of neighborhood, driving, arranging to take bus Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdownSelectAnOptionValue() throws Exception{
			click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Travel out of neighborhood, driving, arranging to take bus category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyTravelOutOfNeighborhoodDrivingArrangingToTakeBusSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Travel out of neighborhood, driving, arranging to take bus 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown0Value() throws Exception{
			click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify TravelOutOfNeighborhoodDrivingArrangingToTakeBus category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyTravelOutOfNeighborhoodDrivingArrangingToTakeBusSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on TravelOutOfNeighborhoodDrivingArrangingToTakeBus 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown1Value() throws Exception{
			click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify TravelOutOfNeighborhoodDrivingArrangingToTakeBus category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyTravelOutOfNeighborhoodDrivingArrangingToTakeBusSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on TravelOutOfNeighborhoodDrivingArrangingToTakeBus 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown2Value() throws Exception{
			click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify TravelOutOfNeighborhoodDrivingArrangingToTakeBus category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyTravelOutOfNeighborhoodDrivingArrangingToTakeBusSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on TravelOutOfNeighborhoodDrivingArrangingToTakeBus 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown3Value() throws Exception{
			click_TravelOutOfNeighborhoodDrivingArrangingToTakeBusDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
			
		}
		
//Getting dressed Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Getting dressed Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyGettingDressedLabel() throws Exception{
			assertEquals("Getting dressed", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Getting dressed drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_GettingDressedDropdown() throws Exception{
			Thread.sleep(1000);
			click_GettingDressedDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Getting dressed category Select an option drop down value for GettingDressed
	    */
		public CaregiverDailyFunctionDetailsPage verifyGettingDressedSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-11']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Getting dressed Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_GettingDressedDropdownSelectAnOptionValue() throws Exception{
			click_GettingDressedDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Getting dressed category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyGettingDressedSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Getting dressed 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_GettingDressedDropdown0Value() throws Exception{
			click_GettingDressedDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify GettingDressed category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyGettingDressedSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on GettingDressed 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_GettingDressedDropdown1Value() throws Exception{
			click_GettingDressedDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify GettingDressed category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyGettingDressedSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on GettingDressed 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_GettingDressedDropdown2Value() throws Exception{
			click_GettingDressedDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify GettingDressed category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyGettingDressedSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on GettingDressed 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_GettingDressedDropdown3Value() throws Exception{
			click_GettingDressedDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
			
		}
	    
//Using toilet Section Methods ======================================================================================================

		 /**
		 * This method is used to verify  Using toilet Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyUsingToiletLabel() throws Exception{
			assertEquals("Using toilet", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Using toilet drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingToiletDropdown() throws Exception{
			Thread.sleep(1000);
			click_UsingToiletDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Using toilet category Select an option drop down value for UsingToilet
	    */
		public CaregiverDailyFunctionDetailsPage verifyUsingToiletSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-12']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Using toilet Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingToiletDropdownSelectAnOptionValue() throws Exception{
			click_UsingToiletDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Using toilet category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingToiletSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on  Using toilet 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingToiletDropdown0Value() throws Exception{
			click_UsingToiletDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify UsingToilet category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingToiletSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on UsingToilet 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingToiletDropdown1Value() throws Exception{
			click_UsingToiletDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify UsingToilet category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingToiletSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on UsingToilet 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingToiletDropdown2Value() throws Exception{
			click_UsingToiletDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify UsingToilet category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingToiletSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on UsingToilet 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingToiletDropdown3Value() throws Exception{
			click_UsingToiletDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}

//Bathing/showering Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Bathing/showering Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyBathingShoweringLabel() throws Exception{
			assertEquals("Bathing/showering", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Bathing/showering drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_BathingShoweringDropdown() throws Exception{
			Thread.sleep(1000);
			click_BathingShoweringDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Bathing/showering category Select an option drop down value for BathingShowering
	    */
		public CaregiverDailyFunctionDetailsPage verifyBathingShoweringSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-13']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Bathing/showering Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_BathingShoweringDropdownSelectAnOptionValue() throws Exception{
			click_BathingShoweringDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Bathing/showering category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyBathingShoweringSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Bathing/showering 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_BathingShoweringDropdown0Value() throws Exception{
			click_BathingShoweringDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify BathingShowering category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyBathingShoweringSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on BathingShowering 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_BathingShoweringDropdown1Value() throws Exception{
			click_BathingShoweringDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify BathingShowering category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyBathingShoweringSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on BathingShowering 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_BathingShoweringDropdown2Value() throws Exception{
			click_BathingShoweringDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify BathingShowering category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyBathingShoweringSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on BathingShowering 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_BathingShoweringDropdown3Value() throws Exception{
			click_BathingShoweringDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}

//Planning activities Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Bathing/showering Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyPlanningActivitiesLabel() throws Exception{
			assertEquals("Planning activities", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[14]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Bathing/showering drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_PlanningActivitiesDropdown() throws Exception{
			Thread.sleep(1000);
			click_PlanningActivitiesDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Bathing/showering category Select an option drop down value for PlanningActivities
	    */
		public CaregiverDailyFunctionDetailsPage verifyPlanningActivitiesSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-14']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Bathing/showering Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlanningActivitiesDropdownSelectAnOptionValue() throws Exception{
			click_PlanningActivitiesDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Bathing/showering category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlanningActivitiesSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Bathing/showering 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlanningActivitiesDropdown0Value() throws Exception{
			click_PlanningActivitiesDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify PlanningActivities category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlanningActivitiesSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PlanningActivities 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlanningActivitiesDropdown1Value() throws Exception{
			click_PlanningActivitiesDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PlanningActivities category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlanningActivitiesSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PlanningActivities 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlanningActivitiesDropdown2Value() throws Exception{
			click_PlanningActivitiesDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PlanningActivities category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyPlanningActivitiesSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[14]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on PlanningActivities 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_PlanningActivitiesDropdown3Value() throws Exception{
			click_PlanningActivitiesDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}

//Using Telephone Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Using Telephone Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyUsingTelephoneLabel() throws Exception{
			assertEquals("Using telephone", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[15]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Using Telephone drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingTelephoneDropdown() throws Exception{
			Thread.sleep(1000);
			click_UsingTelephoneDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Using Telephone category Select an option drop down value for UsingTelephone
	    */
		public CaregiverDailyFunctionDetailsPage verifyUsingTelephoneSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-15']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Using Telephone Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingTelephoneDropdownSelectAnOptionValue() throws Exception{
			click_UsingTelephoneDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Using Telephone category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingTelephoneSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Using Telephone 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingTelephoneDropdown0Value() throws Exception{
			click_UsingTelephoneDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify UsingTelephone category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingTelephoneSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on UsingTelephone 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingTelephoneDropdown1Value() throws Exception{
			click_UsingTelephoneDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify UsingTelephone category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingTelephoneSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on UsingTelephone 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingTelephoneDropdown2Value() throws Exception{
			click_UsingTelephoneDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify UsingTelephone category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyUsingTelephoneSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[15]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on UsingTelephone 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_UsingTelephoneDropdown3Value() throws Exception{
			click_UsingTelephoneDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}

//Managing Medications Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Managing Medications Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyManagingMedicationsLabel() throws Exception{
			assertEquals("Managing medications", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[16]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Managing Medications drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_ManagingMedicationsDropdown() throws Exception{
			Thread.sleep(1000);
			click_ManagingMedicationsDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Managing Medications category Select an option drop down value for ManagingMedications
	    */
		public CaregiverDailyFunctionDetailsPage verifyManagingMedicationsSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-16']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Managing Medications Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_ManagingMedicationsDropdownSelectAnOptionValue() throws Exception{
			click_ManagingMedicationsDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Managing Medications category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyManagingMedicationsSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Managing Medications 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ManagingMedicationsDropdown0Value() throws Exception{
			click_ManagingMedicationsDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify ManagingMedications category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyManagingMedicationsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ManagingMedications 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ManagingMedicationsDropdown1Value() throws Exception{
			click_ManagingMedicationsDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ManagingMedications category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyManagingMedicationsSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ManagingMedications 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ManagingMedicationsDropdown2Value() throws Exception{
			click_ManagingMedicationsDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ManagingMedications category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyManagingMedicationsSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[16]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ManagingMedications 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_ManagingMedicationsDropdown3Value() throws Exception{
			click_ManagingMedicationsDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}

//Housekeeping Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Housekeeping Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyHousekeepingLabel() throws Exception{
			assertEquals("Housekeeping", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[17]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Housekeeping drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_HousekeepingDropdown() throws Exception{
			Thread.sleep(1000);
			click_HousekeepingDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Housekeeping category Select an option drop down value for Housekeeping
	    */
		public CaregiverDailyFunctionDetailsPage verifyHousekeepingSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-17']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Housekeeping Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_HousekeepingDropdownSelectAnOptionValue() throws Exception{
			click_HousekeepingDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Housekeeping category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHousekeepingSelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Housekeeping 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HousekeepingDropdown0Value() throws Exception{
			click_HousekeepingDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Housekeeping category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHousekeepingSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Housekeeping 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HousekeepingDropdown1Value() throws Exception{
			click_HousekeepingDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Housekeeping category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHousekeepingSelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Housekeeping 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HousekeepingDropdown2Value() throws Exception{
			click_HousekeepingDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Housekeeping category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyHousekeepingSelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[17]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Housekeeping 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_HousekeepingDropdown3Value() throws Exception{
			click_HousekeepingDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
//Laundry Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Laundry Label
		 */
		public CaregiverDailyFunctionDetailsPage verifyLaundryLabel() throws Exception{
			assertEquals("Laundry", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[18]/div[1]/label")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on  Laundry drop down.
		 */
		public CaregiverDailyFunctionDetailsPage click_LaundryDropdown() throws Exception{
			Thread.sleep(1000);
			click_LaundryDropdown.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify  Laundry category Select an option drop down value for Laundry
	    */
		public CaregiverDailyFunctionDetailsPage verifyLaundrySelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='daily-dropdown-18']")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on  Laundry Select an option drop value
		 */
		public CaregiverDailyFunctionDetailsPage click_LaundryDropdownSelectAnOptionValue() throws Exception{
			click_LaundryDropdownSelectAnOptionValue.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify  Laundry category 0 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyLaundrySelection0() throws Exception{
			assertEquals("0 - Normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Laundry 0 value
		 */
		public CaregiverDailyFunctionDetailsPage click_LaundryDropdown0Value() throws Exception{
			click_LaundryDropdown0Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Laundry category 1 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyLaundrySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Difficult but independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Laundry 1 value
		 */
		public CaregiverDailyFunctionDetailsPage click_LaundryDropdown1Value() throws Exception{
			click_LaundryDropdown1Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Laundry category 2 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyLaundrySelection2() throws Exception{
			assertEquals("2 - Requires assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Laundry 2 value
		 */
		public CaregiverDailyFunctionDetailsPage click_LaundryDropdown2Value() throws Exception{
			click_LaundryDropdown2Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Laundry category 3 value
		*/
		public CaregiverDailyFunctionDetailsPage verifyLaundrySelection3() throws Exception{
			assertEquals("3 - Dependent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[18]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDailyFunctionDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Laundry 3 value
		 */
		public CaregiverDailyFunctionDetailsPage click_LaundryDropdown3Value() throws Exception{
			click_LaundryDropdown3Value.click();
			return new CaregiverDailyFunctionDetailsPage(driver);
		}

//Buttons Section ===================================================================================================================
		
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverDailyFunctionDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverDailyFunctionDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverDailyFunctionDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverDailyFunctionDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverDailyFunctionDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverDailyFunctionDetailsPage click_ContinueButton() throws Exception{
	    	click_ContinueButton.click();
	    	return new CaregiverDailyFunctionDetailsPage(driver);
	    }
	    
	  //Popup section.
	  		/**
	  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
	  		 */
	  		public CaregiverDailyFunctionDetailsPage verifyCancelPopupMessage() throws Exception{
	  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
	  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
	  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
	  			return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
	  		
	  		 /**
	  		 * This method is used to click on No button on popup message on Cancel
	  		 */
	  		public CaregiverDailyFunctionDetailsPage click_NoButtonOnCancelPopup() throws Exception{
	  			click_NoButtonOnPopup.click();
	  			return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
	  		
	  		/**
	  		* This method is used to click on Yes button on popup message on Cancel
	  		*/
	  		public CaregiverDailyFunctionDetailsPage click_YesButtonOnCancelPopup() throws Exception{
	  		click_YesButtonOnPopup.click();
	  		return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
	  			    
	  		/**
	  		 * This method is used to verify Continue Popup message and No and yes buttons button.
	  		 */
	  		public CaregiverDailyFunctionDetailsPage verifyContinuePopupMessage() throws Exception{
	  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
	  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
	  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
	  			return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
	  		
	  		 /**
	  		 * This method is used to click on No button on popup message on Cancel
	  		 */
	  		public CaregiverDailyFunctionDetailsPage click_NoButtonOnContinuePopup() throws Exception{
	  			click_NoButtonOnPopup.click();
	  			return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
	  		
	  		/**
	  		* This method is used to click on Yes button on popup message on Cancel
	  		*/
	  		public CaregiverDailyFunctionDetailsPage click_YesButtonOnContinuePopup() throws Exception{
	  		click_YesButtonOnPopup.click();
	  		return new CaregiverDailyFunctionDetailsPage(driver);
	  		}

	  		    /**
	  		 * This method is used to verify Reset Popup message for Reset button.
	  		 */
	  		public CaregiverDailyFunctionDetailsPage verifyResetPopupMessage() throws Exception{
	  			driver.switchTo().alert();
	  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
	  			return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
	  		 /**
	  		 * This method is used to close Reset Popup message for Reset button.
	  		 */
	  		public CaregiverDailyFunctionDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
	  		driver.switchTo().alert();
	  		click_ResetPopupMessageCloseIcon.click();
	  		return new CaregiverDailyFunctionDetailsPage(driver);
	  		}
}


