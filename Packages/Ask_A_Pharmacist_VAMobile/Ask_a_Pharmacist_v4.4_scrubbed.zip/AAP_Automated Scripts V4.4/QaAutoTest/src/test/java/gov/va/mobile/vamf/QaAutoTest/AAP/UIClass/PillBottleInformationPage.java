	package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

	import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

	public class PillBottleInformationPage {

	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
		
		//Web Elements on Pill and Bottle Information Page
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
			public WebElement click_PillIdentification;

			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
			public WebElement click_PillBottleInformation;
		
			//@FindBy(how = How.XPATH, using = "//*[@id='aap-modal']/div/div/p]")
			//public WebElement click_PillIdentificationLeaveMessage;
			
			//@FindBy(how = How.XPATH, using = "//*[@id='aapLeave']")
			//public WebElement click_PillIdentificationContinueButton;
			
			public PillBottleInformationPage(WebDriver driver){
				PillBottleInformationPage.driver = driver;
				//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			}
			
			public PillBottleInformationPage clickPillIdentification() throws Exception{
				click_PillIdentification.click();
				
				return new PillBottleInformationPage(driver);
			}
			
			
			public PillBottleInformationPage clickPillBottleInformation() throws Exception{
				click_PillBottleInformation.click();
				
				return new PillBottleInformationPage(driver);
			}
			
			public PillBottleInformationPage verifyPillBottleInformationurl() throws Exception{
				assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#PillBottle", driver.getCurrentUrl());	
				return new PillBottleInformationPage(driver);
			}
			
			public PillBottleInformationPage verifyExternalPage() throws Exception {
				driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
			    driver.findElement(By.id("aapLeave")).click();
			    Thread.sleep(5000);	
					    driver.switchTo().alert().accept();
					    assertEquals("Pillbox - National Library of Medicine", driver.getTitle());
			    /*
			    try {	 
				    driver.switchTo().alert();	
			        assertEquals("If this is an emergency, call 911 or the national Poison Help hotline at "
			    		+ "1-800-222-1222.\n\nMost images in Pillbox are not part of the drug labels "
		    		    + "and have not been verified by the labeler.\n\nAlways consult your "
			    		+ "physician or pharmacist with any medication-related questions.", driver.switchTo().alert().getText());
			    }
				catch (Error e) {
				       e.printStackTrace();
				       verificationErrors.append(e.toString());
				       }
			    driver.switchTo().alert().dismiss();
			  */
			    return new PillBottleInformationPage(driver);
			}
			   
			   // assertEquals("I this is an emergency, call 911 or the national Poison Help hotline at "
			    //		+ "1-800-222-1222.\n\nMost images in Pillbox are not part of the drug labels "
		    	//	    + "and have not been verified by the labeler.\n\nAlways consult your "
			    //		+ "physician or pharmacist with any medication-related questions.", closeAlertAndGetItsText());
			    //
			
			private String closeAlertAndGetItsText() {
			    try {
			      Alert alert = driver.switchTo().alert();
			      String alertText = alert.getText();
			      if (acceptNextAlert) {
			        alert.accept();
			      } else {
			        alert.dismiss();
			      }
			      return alertText;
			    } finally {
			      acceptNextAlert = true;
			    }
			  }
			
			 private boolean isAlertPresent() {
				    try {
				      driver.switchTo().alert();
				      return true;
				    } catch (NoAlertPresentException e) {
				      return false;
				    }
				  }
	}
