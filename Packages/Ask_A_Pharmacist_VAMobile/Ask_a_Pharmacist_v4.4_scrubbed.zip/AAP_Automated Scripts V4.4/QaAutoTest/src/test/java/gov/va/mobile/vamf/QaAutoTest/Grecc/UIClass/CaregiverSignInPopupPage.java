package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverSignInPopupPage {
	private static WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//*[@id='loginSection']/div[1]/h4")
	public WebElement click_CaregiverSignInPopup; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='userID']")
	public WebElement click_CaregiverSignInPopupUserID; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='password']")
	public WebElement click_CaregiverSignInPopupPassword;
	
	@FindBy(how = How.XPATH, using = "//*[@id='showPassword']")
	public WebElement click_CaregiverSignInPopupShowLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='user-login']")
	public WebElement click_CaregiverSignInPopupButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']/a")
	public WebElement click_Caregivernamedropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='logout']")
	public WebElement click_Logout;
	
	public CaregiverSignInPopupPage(WebDriver driver){
		CaregiverSignInPopupPage.driver = driver;
	}

	 /**
     * This method is used to verify Caregiver Sign In Popup.
     */
    public CaregiverSignInPopupPage verifyCaregiverSignInPopuptitle() throws Exception{
    	//click_CaregiverSignInPopup.click();
    	//assertEquals("Caregiver Sign In", driver.findElement(By.xpath("//*[@id='loginSection']/div[1]/h4")).getText());
    	return new CaregiverSignInPopupPage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver Sign In Popup UserID field.
     */
    public CaregiverSignInPopupPage clickCaregiverSignInPopupUserID() throws Exception{
    	//driver.findElement(By.id("userID")).sendKeys("a"); // Commented it out because on 5/26 they introduce a Fake Log in option
    	return new CaregiverSignInPopupPage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver Sign In Popup Password field.
     */
    public CaregiverSignInPopupPage clickCaregiverSignInPopupPassword() throws Exception{
    	//driver.findElement(By.id("password")).sendKeys("b"); // Commented it out because on 5/26 they introduce a Fake Log in option
    	return new CaregiverSignInPopupPage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver Sign In Popup button.
     */
    public CaregiverSignInPopupPage click_CaregiverSignInPopupButton() throws Exception{
    	//click_CaregiverSignInPopupButton.click(); // Commented it out because on 5/26 they introduce a Fake Log in option
    	return new CaregiverSignInPopupPage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver Name drop down link.
     */
    public CaregiverSignInPopupPage click_Caregivernamedropdown() throws Exception{
    	click_Caregivernamedropdown.click();
    	return new CaregiverSignInPopupPage(driver);
    }
    
	 /**
     * This method is used to click on Log out link.
     */
    public CaregiverSignInPopupPage click_Logout() throws Exception{
    	click_Logout.click();
    	return new CaregiverSignInPopupPage(driver);
    }
    
    
}
