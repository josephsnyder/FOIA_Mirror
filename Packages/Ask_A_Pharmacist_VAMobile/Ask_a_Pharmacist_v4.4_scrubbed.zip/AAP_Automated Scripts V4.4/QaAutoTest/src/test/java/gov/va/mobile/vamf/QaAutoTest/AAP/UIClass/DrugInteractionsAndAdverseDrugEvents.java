package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;
import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class DrugInteractionsAndAdverseDrugEvents {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Drug Interactions And Adverse Drug Events Page.
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
			public WebElement click_AdverseDrugEventInformation;

			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
			public WebElement click_DrugInteractionArticles;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
			public WebElement click_ReportadversedrugeventstoFDAMedWatch;
			
			public DrugInteractionsAndAdverseDrugEvents(WebDriver driver){
				DrugInteractionsAndAdverseDrugEvents.driver = driver;
			}
			
			
			/**
			 * This method is used to Click on Adverse Drug Event Information
			 */
			public  DrugInteractionsAndAdverseDrugEvents click_AdverseDrugEventInformation() throws Exception{
				click_AdverseDrugEventInformation.click();
				return new DrugInteractionsAndAdverseDrugEvents(driver);
			}
			/**
			 * This method is used to Click on Drug Interaction Article
			 */
			public  DrugInteractionsAndAdverseDrugEvents click_DrugInteractionArticles() throws Exception{
				click_DrugInteractionArticles.click();
				return new DrugInteractionsAndAdverseDrugEvents(driver);
			}
			
			/**
			 * This method is used to Click on Report adverse drug events to FDA Med Watch
			 */
			public  DrugInteractionsAndAdverseDrugEvents click_ReportadversedrugeventstoFDAMedWatch() throws Exception{
				click_ReportadversedrugeventstoFDAMedWatch.click();
				return new DrugInteractionsAndAdverseDrugEvents(driver);
			}
			
			/**
			* This method is used to verify link url for Med Watch
			*/
			public DrugInteractionsAndAdverseDrugEvents verifyMedWatcheLink() throws Exception{
				Thread.sleep(5000);
				assertEquals("https://www.accessdata.fda.gov/scripts/medwatch/index.cfm?action=reporting.home", driver.getCurrentUrl());
				return new DrugInteractionsAndAdverseDrugEvents(driver);
			}
			
			public DrugInteractionsAndAdverseDrugEvents verifyExternalPage() throws Exception {
				driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
				assertEquals("This link reports an adverse drug event to the U.S. Food and Drug Administration. In addition to submitting the MedWatch Online Voluntary Reporting Form, please contact your Veterans Affairs healthcare provider for immediate attention.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p[2]")).getText());
				driver.findElement(By.id("aapLeave")).click();
			    Thread.sleep(5000);
				return new  DrugInteractionsAndAdverseDrugEvents(driver); 
			}
			
}
