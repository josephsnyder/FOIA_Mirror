package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverSafetyDetailsPage {
private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement verifySafetyDetailsTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[1]")
	public WebElement verifySafetyDetailsText;
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[2]/em")
	public WebElement verifySafetyDetailsText2;

//Safety Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")
		public WebElement click_DrivingCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")
		public WebElement click_WanderingCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")
		public WebElement click_MedicationsCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")
		public WebElement click_AggressionCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")
		public WebElement click_ChokingOnFoodOrMedicationsCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")
		public WebElement click_FallingCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label/input")
		public WebElement click_FinancialManagementCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[8]/div/label/input")
		public WebElement click_MachinesAppliancesCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[9]/div/label/input")
		public WebElement click_GunsWeaponsCheckbox; 
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverSafetyDetailsPage(WebDriver driver){
			CaregiverSafetyDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Safety Details Title
	     */
	    public CaregiverSafetyDetailsPage verifySafetyDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Safety Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Safety Details Text
	     */
	    public CaregiverSafetyDetailsPage verifySafetyDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Safety. Check all that apply.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
	    
//Safety Methods ======================================================================================================
		 
	    /**
		 * This method is used to verify Driving Label
		 */
		public CaregiverSafetyDetailsPage verifyDrivingLabel() throws Exception{
			assertEquals("Driving", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Driving Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_DrivingCheckbox() throws Exception{
			click_DrivingCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Driving Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyDrivingCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify Wandering Label
		 */
		public CaregiverSafetyDetailsPage verifyWanderingLabel() throws Exception{
			assertEquals("Wandering", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Wandering Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_WanderingCheckbox() throws Exception{
			click_WanderingCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Wandering Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyWanderingCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Medications Label
		 */
		public CaregiverSafetyDetailsPage verifyMedicationsLabel() throws Exception{
			assertEquals("Medications", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Medications Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_MedicationsCheckbox() throws Exception{
			click_MedicationsCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Medications Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyMedicationsCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify Aggression Label
		 */
		public CaregiverSafetyDetailsPage verifyAggressionLabel() throws Exception{
			assertEquals("Aggression", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Aggression Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_AggressionCheckbox() throws Exception{
			click_AggressionCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Aggression Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyAggressionCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
			
	    /**
		 * This method is used to verify ChokingOnFoodOrMedications Label
		 */
		public CaregiverSafetyDetailsPage verifyChokingOnFoodOrMedicationsLabel() throws Exception{
			assertEquals("Choking on food or medications", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on ChokingOnFoodOrMedications Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_ChokingOnFoodOrMedicationsCheckbox() throws Exception{
			click_ChokingOnFoodOrMedicationsCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Choking On Food O rMedications Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyChokingOnFoodOrMedicationsCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Falling Label
		 */
		public CaregiverSafetyDetailsPage verifyFallingLabel() throws Exception{
			assertEquals("Falling", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Falling Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_FallingCheckbox() throws Exception{
			click_FallingCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
			
	    /**
		 * This method is used to verify Falling Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyFallingCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify FinancialManagement Label
		 */
		public CaregiverSafetyDetailsPage verifyFinancialManagementLabel() throws Exception{
			assertEquals("Financial management", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on FinancialManagement Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_FinancialManagementCheckbox() throws Exception{
			click_FinancialManagementCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Financial Management Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyFinancialManagementCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}

	    /**
		 * This method is used to verify MachinesAppliances  Label
		 */
		public CaregiverSafetyDetailsPage verifyMachinesAppliancesLabel() throws Exception{
			assertEquals("Machines/appliances", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[8]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on MachinesAppliances Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_MachinesAppliancesCheckbox() throws Exception{
			click_MachinesAppliancesCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Machines Appliances Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyMachinesAppliancesCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[8]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		/*
		 * This method is used to verify GunsWeapons Label
		 */
		public CaregiverSafetyDetailsPage verifyGunsWeaponsLabel() throws Exception{
			assertEquals("Guns/weapons", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[9]/div/label")).getText());
			return new CaregiverSafetyDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on GunsWeapons Checkbox.
		 */
		public CaregiverSafetyDetailsPage click_GunsWeaponsCheckbox() throws Exception{
			click_GunsWeaponsCheckbox.click();
			return new CaregiverSafetyDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Machines Appliances Checkbox is unchcked.
		 */
		public CaregiverSafetyDetailsPage verifyGunsWeaponsCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[9]/div/label/input")).getAttribute("value"));
			return new CaregiverSafetyDetailsPage(driver);
		}
		
//Buttons Section ===================================================================================================================
		
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverSafetyDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverSafetyDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverSafetyDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverSafetyDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverSafetyDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverSafetyDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverSafetyDetailsPage click_ContinueButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverSafetyDetailsPage(driver);
	    }
	    
	    
 //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverSafetyDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverSafetyDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverSafetyDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverSafetyDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverSafetyDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverSafetyDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverSafetyDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverSafetyDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverSafetyDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverSafetyDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverSafetyDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverSafetyDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverSafetyDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverSafetyDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverSafetyDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverSafetyDetailsPage(driver);
  		}
  		
}
