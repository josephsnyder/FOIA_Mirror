package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class MedicalAdministrationPage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Trusted Medical Administration Page
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div/a/span[1]")
			public WebElement click_HowToProperlyAdministerAMedication;

			public MedicalAdministrationPage(WebDriver driver){
				MedicalAdministrationPage.driver = driver;
			}
			
		/**
		 * This method is used to Click on FAQ-MYHealthVet
		 */

			public  MedicalAdministrationPage click_HowToProperlyAdministerAMedication() throws Exception{
				click_HowToProperlyAdministerAMedication.click();
				return new MedicalAdministrationPage(driver);
			}
		
				
		 /**
		 * This method is used to verify How to Administer link url.
		 */
				   public MedicalAdministrationPage verifyHowToAdministerurl() throws Exception{
					 Thread.sleep(5000);
					assertEquals("http://www.safemedication.com/safemed/MedicationTipsTools/HowtoAdminister.aspx", driver.getCurrentUrl());
					return new MedicalAdministrationPage(driver);
				}
			
			public  MedicalAdministrationPage verifyExternalPage() throws Exception {
				driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
			    driver.findElement(By.id("aapLeave")).click();
			    Thread.sleep(5000);
				return new MedicalAdministrationPage(driver); 
			}
}