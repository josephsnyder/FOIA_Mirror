package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MedicationPage {
	
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	
	//Web Elements on MedicationPage page
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
			public WebElement click_FoodAndDrugAdministration;
			
			@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
			public WebElement click_MedlinePlus;
			
			public MedicationPage(WebDriver driver){
				MedicationPage.driver = driver;
			}
			
			 /**
		     * This method is used to Click on Food and Drug Administration link
		     */
		
		    public MedicationPage click_FoodAndDrugAdministration() throws Exception{
		    	click_FoodAndDrugAdministration.click();
		    	return new MedicationPage(driver);
		    }
		    
		    /**
		     * This method is used to Click on Medline Plus link
		     */
		
		    public MedicationPage click_MedlinePlus() throws Exception{
		    	click_MedlinePlus.click();
		    	return new MedicationPage(driver);
		    }
		    
		    
			public MedicationPage verifyExternalPage() throws Exception {
				driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
				assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
			    driver.findElement(By.id("aapLeave")).click();
			    Thread.sleep(3000);
				return new MedicationPage(driver); 
			}
			
			public MedicationPage verifyUSFDAInforamtionForCustomerurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.fda.gov/Drugs/ResourcesForYou/Consumers/default.htm", driver.getCurrentUrl());
				return new MedicationPage(driver);
			}
			
			public MedicationPage verifyMedlinePlusurl() throws Exception{
				Thread.sleep(5000);
				assertEquals("http://www.nlm.nih.gov/medlineplus/druginformation.html", driver.getCurrentUrl());
				return new MedicationPage(driver);
			}
			
}
