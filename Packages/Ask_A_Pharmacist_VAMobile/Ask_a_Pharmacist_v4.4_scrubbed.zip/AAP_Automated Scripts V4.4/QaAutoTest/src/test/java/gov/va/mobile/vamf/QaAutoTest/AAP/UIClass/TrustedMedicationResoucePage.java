package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TrustedMedicationResoucePage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Trusted Medication Resouce Page
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
		public WebElement click_KnowYourMedicationLabe;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[7]/a/span[1]/span[1]")
		public WebElement click_PillIdentification;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
		public WebElement click_DrugInteractions;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[5]/a/span[1]/span[1]")
		public WebElement click_MedicationAdministration;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[6]/a/span[1]/span[1]")
		public WebElement click_MedicationDisposal;

		@FindBy(how = How.XPATH, using = ".//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
		public WebElement click_ConsumerDrugHerbalSupplementInformation;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[7]/a/span[1]")
		public WebElement click_FAQAskAPharmacist;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
		public WebElement click_FAQVANationalMedicationFormulary;
		
		
		public TrustedMedicationResoucePage(WebDriver driver){
			TrustedMedicationResoucePage.driver = driver;
		}
		
		/**
		 * This method is used to Click on ConsumerDrugHerbalSupplementInformation
		 */
		public TrustedMedicationResoucePage click_ConsumerDrugHerbalSupplementInformation() throws Exception{
			click_ConsumerDrugHerbalSupplementInformation.click();
			Thread.sleep(3000);
			return new TrustedMedicationResoucePage(driver);
		}
		
		public  TrustedMedicationResoucePage clickDrugInteractionsAdverseDrugEvents() throws Exception{
			click_DrugInteractions.click();
			return new TrustedMedicationResoucePage(driver);
		}
	
		public  TrustedMedicationResoucePage click_FAQVANationalMedicationFormulary() throws Exception{
			click_FAQVANationalMedicationFormulary.click();
			Thread.sleep(3000);
			return new TrustedMedicationResoucePage(driver);
		}
		
		public TrustedMedicationResoucePage verifyVANationalFormularyurl() throws Exception{
		    Thread.sleep(4000);
			assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#VANationalFormulary", driver.getCurrentUrl());
			return new TrustedMedicationResoucePage(driver);
		}
	
		
		public  TrustedMedicationResoucePage click_MedicationDisposal() throws Exception{
			click_MedicationDisposal.click();
			Thread.sleep(3000);
			return new TrustedMedicationResoucePage(driver);
		}
		
		public TrustedMedicationResoucePage verifyVACenterForMedicationSafetyPrescriptionsurl() throws Exception{
		    Thread.sleep(5000);
			assertEquals("http://www.pbm.domain/PBM/vacenterformedicationsafety/vacenterformedicationsafetyprescriptionsafety.asp", driver.getCurrentUrl());
			return new TrustedMedicationResoucePage(driver);
		}
		
		public  TrustedMedicationResoucePage click_DrugInteractions() throws Exception{
			click_DrugInteractions.click();
			Thread.sleep(3000);
			return new TrustedMedicationResoucePage(driver);
		}
		
		public  TrustedMedicationResoucePage click_MedicationAdministration() throws Exception{
			click_MedicationAdministration.click();
			Thread.sleep(3000);
			return new TrustedMedicationResoucePage(driver);
		}
			
		
	//	public TrustedMedicationResoucePage verifyVACenterForMedicationSafetyPrescriptionsurl() throws Exception{
		//    Thread.sleep(5000);
			//assertEquals("http://www.pbm.domain/PBM/vacenterformedicationsafety/vacenterformedicationsafetyprescriptionsafety.asp", driver.getCurrentUrl());
			//return new TrustedMedicationResoucePage(driver);
	//	}
		
		
}
