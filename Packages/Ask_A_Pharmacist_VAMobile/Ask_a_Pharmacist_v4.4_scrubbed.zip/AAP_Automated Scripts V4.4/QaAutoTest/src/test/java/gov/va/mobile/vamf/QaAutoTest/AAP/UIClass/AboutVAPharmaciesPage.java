package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class AboutVAPharmaciesPage {
public static WebDriver driver;
private boolean acceptNextAlert = true;
private boolean isAlertPresent = true;
public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on About VAPharmacies Page
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]")
		public WebElement click_HowVAPharmacistsHelpVeterans;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]")
		public WebElement click_HowVAPharmaciesOperate;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]")
		public WebElement click_FindMyFacility;
	
		public AboutVAPharmaciesPage(WebDriver driver){
			AboutVAPharmaciesPage.driver = driver;
		}
		
		
		/**
		 * This method is used to Click on Find My Facility
		 */
		public  AboutVAPharmaciesPage click_FindMyFacility() throws Exception{
			click_FindMyFacility.click();
			return new AboutVAPharmaciesPage(driver);
		}

		/**
		 * This method is used to Click on How VA Pharmacies Operate
		 */
		public  AboutVAPharmaciesPage click_HowVAPharmaciesOperate() throws Exception{
			click_HowVAPharmaciesOperate.click();
			return new AboutVAPharmaciesPage(driver);
		}
		
		/**
		 * This method is used to verify link for How Do VA Pharmacies Operate
		 */
		public  AboutVAPharmaciesPage verifyHowDoVAPharmaciesOperateLink() throws Exception{
			assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#HowVAPharmaciesOperate", driver.getCurrentUrl());
			return new AboutVAPharmaciesPage(driver);
		}
		
		
		/**
		 * This method is used to Click on How VA Pharmacies Help Veterans
		 */
		public  AboutVAPharmaciesPage click_HowVAPharmacistsHelpVeterans() throws Exception{
			click_HowVAPharmacistsHelpVeterans.click();
			return new AboutVAPharmaciesPage(driver);
		}
		
		/**
		 * This method is used to verify link for How VA Pharmacists Help Veterans Operate
		 */
		public  AboutVAPharmaciesPage verifyHowVAPharmacistsHelpVeteransLink() throws Exception{
			assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#HowVAHelpsVeterans", driver.getCurrentUrl());
			return new AboutVAPharmaciesPage(driver);
		}
		
		
		
		public AboutVAPharmaciesPage verifyExternalPage() throws Exception {
			try {
			driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
			assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
		    driver.findElement(By.id("aapLeave")).click();
		    Thread.sleep(5000);
			}
			catch (Error e) {		
				     e.printStackTrace();
				      verificationErrors.append(e.toString());
				 }
			return new AboutVAPharmaciesPage(driver); 
		}
		
		public AboutVAPharmaciesPage ZipCodeSearch() throws Exception{
		driver.findElement(By.id("inputaddress")).sendKeys("32308");
		driver.findElement(By.xpath("//*[@id='tbllocatorForm']/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(5000);
		//driver.findElement(By.xpath("//*[@id='searchlist']/strong")).isDisplayed();
		//Thread.sleep(3000);
	    return new AboutVAPharmaciesPage(driver);
		}
		
		public AboutVAPharmaciesPage ByStateSearch() throws Exception{
		//driver.findElement(By.xpath("//*[@id='tier4innerContent']/div[4]/map/area[36]")).click();
		Thread.sleep(3000);
		//driver.findElement(By.xpath("//*[@id='fac']/tbody/tr[1]/td/a")).isDisplayed();
		//Thread.sleep(3000);
	    return new AboutVAPharmaciesPage(driver);
		}
		
		public AboutVAPharmaciesPage ByDirectorySearch() throws Exception{
		driver.findElement(By.xpath("//*[@id='QTLabel']")).sendKeys("FL");
		driver.findElement(By.xpath("//*[@id='keywordSearchForm']/table/tbody/tr[2]/td/form/input[2]")).click();
		assertEquals("http://www1.domain/directory/guide/searchResults.cfm", driver.getCurrentUrl());
		Thread.sleep(3000);
	    return new AboutVAPharmaciesPage(driver);
		}
		
		public AboutVAPharmaciesPage GoBackBrowserButton() throws Exception{
			Thread.sleep(3000);
			driver.navigate().back();
		    Thread.sleep(4000);
	    return new AboutVAPharmaciesPage(driver);
		}
		
}
