package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HelpPage {
	private static WebDriver driver;
	
	//Find WebElements 
	@FindBy(how = How.XPATH,using =".//*[@id='aap-modal-content']/div/div/div[3]/button")
	public WebElement btn_closeButton;
	
	
	
	
	public HelpPage(WebDriver driver){
		HelpPage.driver = driver;
	}
	
	
	public void clickCloseButton () throws IOException{
		//driver.switchTo().frame(0);
        //WebElement webelement= driver.switchTo().activeElement();
        //((JavascriptExecutor) driver).executeScript("document.body.innerHTML = '<br>'");
        //do whatever with weblement in here
       // driver.switchTo().defaultContent(); //switches focus out of iFrame
		//btn_closeButton.click();
		
		//load data from resource file
		Properties properties = new Properties();
		String path = System.getProperty("user.dir")+ "//src//test//resources//datafile//data.properties";
		
		FileInputStream fs = new FileInputStream(path);
		properties.load(fs);
			
		
		String	vURL = properties.getProperty("URL");
		
		driver.navigate().to(vURL);
		
		 
	}
}



