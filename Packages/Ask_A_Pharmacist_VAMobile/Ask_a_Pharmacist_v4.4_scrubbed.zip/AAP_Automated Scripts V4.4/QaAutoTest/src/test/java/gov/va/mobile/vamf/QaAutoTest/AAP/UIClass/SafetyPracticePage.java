package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SafetyPracticePage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Safety Practice Page Page
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
	public WebElement click_MedicineSafetyAToolkitForFamilies;
	
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
	public WebElement click_MedicationTipsToolsOnSafemedicationCom;
	
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
	public WebElement click_SafeDisposalOfMedicinesOnFDA;
	
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
	public WebElement click_VACenterForMedicationSafety;
	
	
	public SafetyPracticePage(WebDriver driver){
		SafetyPracticePage.driver = driver;
	}
	
    /**
     * This method is used to click on MedicinecSafety A Toolkit For Families link
     */
    public SafetyPracticePage click_MedicineSafetyAToolkitForFamilies() throws Exception{
    	click_MedicineSafetyAToolkitForFamilies.click();
    	return new SafetyPracticePage(driver);
    }
    
    /**
     * This method is used to click on Medication Tips Tools On Safemedication.Com link
     */
    public SafetyPracticePage click_MedicationTipsToolsOnSafemedicationCom() throws Exception{
    	click_MedicationTipsToolsOnSafemedicationCom.click();
    	return new SafetyPracticePage(driver);
    }
    
    /**
     * This method is used to click on Safe Disposal Of Medicines On FDA link
     */
    public SafetyPracticePage click_SafeDisposalOfMedicinesOnFDA() throws Exception{
    	click_SafeDisposalOfMedicinesOnFDA.click();
    	return new SafetyPracticePage(driver);
    }
    
    /**
     * This method is used to click on VA Center For Medication Safety link
     */
    public SafetyPracticePage click_VACenterForMedicationSafety() throws Exception{
    	click_VACenterForMedicationSafety.click();
    	return new SafetyPracticePage(driver);
    }
	
	public SafetyPracticePage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(3000);
		return new SafetyPracticePage(driver); 
	}
	
	public SafetyPracticePage verifyMedicineSafetyAToolkitForFamiliesurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.learnaboutrxsafety.org/", driver.getCurrentUrl());
		return new SafetyPracticePage(driver);
	}
	
	public SafetyPracticePage verifyMedicationTipsToolsOnSafemedicationComurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.safemedication.com/safemed/MedicationTipsTools/", driver.getCurrentUrl());
		return new SafetyPracticePage(driver);
	}
	
	public SafetyPracticePage verifySafeDisposalOfMedicinesOnFDAurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.fda.gov/Drugs/ResourcesForYou/Consumers/BuyingUsingMedicineSafely/EnsuringSafeUseofMedicine/SafeDisposalofMedicines/default.htm", driver.getCurrentUrl());
		return new SafetyPracticePage(driver);
	}
	
	public SafetyPracticePage verifyVACenterForMedicationSafetyurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.pbm.domain/PBM/vacenterformedicationsafety/vacenterformedicationsafetyprescriptionsafety.asp", driver.getCurrentUrl());
		return new SafetyPracticePage(driver);
	}
	
}
