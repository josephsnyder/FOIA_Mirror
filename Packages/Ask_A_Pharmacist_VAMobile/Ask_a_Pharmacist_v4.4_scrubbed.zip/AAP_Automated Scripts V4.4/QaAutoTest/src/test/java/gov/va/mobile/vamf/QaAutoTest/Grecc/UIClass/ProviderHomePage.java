package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ProviderHomePage {
	private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
	public WebElement click_VAhealthlogo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']/a")
	public WebElement click_SignInButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login-off']")
	public WebElement click_LogoutArrow; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login-off']")
	public WebElement click_LogoutLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
	public WebElement click_VABannerHeader; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_PendingAssessmentsNoteBookButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='nav-dropdown']")
	public WebElement click_ServicesDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[1]/a")
	public WebElement click_PatientAssessmentsUnderServicesDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[2]/a")
	public WebElement click_CaregiverPatientLinkageUnderServicesDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_AboutButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='help']")
	public WebElement click_HelpButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/h2")
	public WebElement click_HomeTitle; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/h2")
	public WebElement click_HomeBodyText; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[1]/a/img[1]")
	public WebElement click_PatientAssessmentsIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[1]/a/h3")
	public WebElement click_PatientAssessmentsLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[1]/a/img[2]")
	public WebElement click_PatientAssessmentsArrow; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[2]/div/a/img[1]")
	public WebElement click_CaregiverPatientLinkageIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[2]/div/a/h3")
	public WebElement click_CaregiverPatientLinkageLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[2]/div/a/img[2]")
	public WebElement click_CaregiverPatientLinkageArrow; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[1]/img")
	public WebElement click_PendingAssessmentsNoteBookIcon; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/div/div/a/h3")
	public WebElement click_PendingAssessmentsNoteBookLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[2]/img")
	public WebElement click_WaitingToBeContactedPhoneIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[2]/span")
	public WebElement click_WaitingToBeContactedPhoneLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[4]/img")
	public WebElement click_TipOfTheWeekBulbIcon; 
	

	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/footer/div/span[1]")
	public WebElement click_FooterOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/footer/div/span[2]")
	public WebElement click_FooterTwo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/footer/div/span[3]")
	public WebElement click_FooterThree; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='dc-provider']/div[1]/footer/div/span[4]")
	public WebElement click_FooterFour; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']/ul/li[1]/a")
	public WebElement click_ReturnToLaunchpadButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='logout']")
	public WebElement click_LogoutButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[3]/button")
	public WebElement click_AboutCloseButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='help-modal']/div/div/div[3]/button")
	public WebElement click_HelpCloseButton;
	
	
	public ProviderHomePage(WebDriver driver){
		ProviderHomePage.driver = driver;
	}
	
	public void OpenURL (String URL){
		driver.navigate().to(URL);
	}

	 /**
     * This method is used to click on SignIn link
     */
    public ProviderHomePage click_SignInButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='header-login']/a")).isDisplayed());
    	click_SignInButton.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Sign out link
     */
    public ProviderHomePage click_SignoutLink() throws Exception{
    	Thread.sleep(1000);
    	click_LogoutArrow.click();
		Thread.sleep(2000);
		click_LogoutLink.click();
		Thread.sleep(2000);
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify chicklet icon
     */
    public ProviderHomePage verifyChickleticon() throws Exception{
    	Assert.assertTrue(driver.findElement(By.id("logo-va")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify App Name
     */
    public ProviderHomePage click_DementiCareName() throws Exception{
    	assertEquals("Dementia Care", driver.findElement(By.className("dc-app-icon")).getText());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to Select on VABanner Header link
     */
    public ProviderHomePage verifyVABannerHeader() throws Exception{
  	    Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify Home link is present
     */
    public ProviderHomePage verifyHomeLinkPresent() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='home']")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
    
	 /**
     * This method is used to verify Services link is present
     */
    public ProviderHomePage verifyServicessLinkPresent() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='nav-dropdown']")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
    
	 /**
     * This method is used to verify About link is present
     */
    public ProviderHomePage verifyAboutLinkPresent() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']/a[3]")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify Help link is present
     */
    public ProviderHomePage verifyHelpLinkPresent() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='help']")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Home link
     */
    public ProviderHomePage click_HomeButtonLink() throws Exception{
    	click_HomeButtonLink.click();
    	assertEquals("http://vetadmin.mobilehealth.domain:8080/grecc-web-2.0-provider/#home", driver.getCurrentUrl());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify on Home link url
     */
    public ProviderHomePage verify_HomeButtonLinkurl() throws Exception{
    	assertEquals("http://vetadmin.mobilehealth.domain:8080/grecc-web-2.0-provider/#home", driver.getCurrentUrl());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Services Drop down link
     */
    public ProviderHomePage click_ServicesDropdownLink() throws Exception{
    	click_ServicesDropdown.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify values under Services Drop down link
     */
    public ProviderHomePage verifyServicesDropdownLinkvalues() throws Exception{
    	//click_ServicesDropdown.click();
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']/ul/li[1]/a")).isDisplayed());
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']/ul/li[2]/a")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Patient Assessments link under Services Drop down link
     */
    public ProviderHomePage click_PatientAssessmentsUnderServicesDropdownLink() throws Exception{
    	Thread.sleep(1000);
    	click_PatientAssessmentsUnderServicesDropdown.click();
    	Thread.sleep(1000);
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver-Patient Linkage link under Services Drop down link
     */
    public ProviderHomePage click_CaregiverPatientLinkageUnderServicesDropdownLink() throws Exception{
    	click_CaregiverPatientLinkageUnderServicesDropdown.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Patient Assessment Note Book Icon link
     */
    public ProviderHomePage click_PendingAssessmentsNoteBookButtonLink() throws Exception{
    	click_PendingAssessmentsNoteBookButtonLink.click();
    	return new ProviderHomePage(driver);
    }
 
	 /**
     * This method is used to click on About link
     */
    public ProviderHomePage click_AboutButtonLink() throws Exception{
    	click_AboutButtonLink.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to close on About screen
     */
    public ProviderHomePage click_AboutCloseButton() throws Exception{
    	click_AboutCloseButton.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Help link
     */
    public ProviderHomePage click_HelpButtonLink() throws Exception{
    	click_HelpButtonLink.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to close on Help screen
     */
    public ProviderHomePage click_HelpCloseButton() throws Exception{
    	click_HelpCloseButton.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify Home title
     */
    public ProviderHomePage verifyHomeTitle() throws Exception{
    	assertEquals("Home", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/h2")).getText());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to verify Home text
     */
    public ProviderHomePage verifyHomeText() throws Exception{
    	assertEquals("Home", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/h2")).getText());
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Patient Assessments Icon.
     */
    public ProviderHomePage click_PatientAssessmentsIcon() throws Exception{
    	click_PatientAssessmentsIcon.click();
    	return new ProviderHomePage(driver);
    }
    
    
	 /**
     * This method is used to click on Patient Assessments Link in the middle of the page.
     */
    public ProviderHomePage click_PatientAssessmentsLink() throws Exception{
    	click_PatientAssessmentsLink.click();
    	return new ProviderHomePage(driver);
    }
    
	 /**
     * This method is used to click on Patient Assessments Arrow in the middle of the page.
     */
    public ProviderHomePage click_PatientAssessmentsArrow() throws Exception{
    	click_PatientAssessmentsArrow.click();
    	return new ProviderHomePage(driver);
    }
    

		 /**
	     * This method is used to click on Caregiver-Patient Linkage Icon.
	     */
	    public ProviderHomePage click_CaregiverPatientLinkageIcon() throws Exception{
    		click_CaregiverPatientLinkageIcon.click();
	    	return new ProviderHomePage(driver);
	    }
	    
	    
		 /**
	     * This method is used to click on Caregiver-Patient Linkage Link in the middle of the page.
	     */
	    public ProviderHomePage click_CaregiverPatientLinkageLink() throws Exception{
	    	click_CaregiverPatientLinkageLink.click();
	    	return new ProviderHomePage(driver);
	    }
	    
		 /**
	     * This method is used to click on Caregiver-Patient Linkage arrow in the middle of the page.
	     */
	    public ProviderHomePage click_CaregiverPatientLinkageArrow() throws Exception{
	    	click_CaregiverPatientLinkageArrow.click();
	    	return new ProviderHomePage(driver);
	    }
    		
    		

    /**
     * This method is used to click on Pending Assessments Note Book Icon.
     */
    public ProviderHomePage click_PendingAssessmentsNoteBookIcon() throws Exception{
    	click_PendingAssessmentsNoteBookIcon.click();
    	return new ProviderHomePage(driver);
    }
    
    /**
     * This method is used to verify Pending Assessments Note Book Icon is present 
     */
    	public ProviderHomePage verifyPendingAssessmentsNoteBookIcon() throws Exception{
    	assertEquals(true, driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[1]/img")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
   /**
 * This method is used to verify Pending Assessments text is present 
 */
	public ProviderHomePage verifyPendingAssessmentsText() throws Exception{
	assertEquals("72 assessments pending for review", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[1]/span")).getText());
	return new ProviderHomePage(driver);
}
	
	
    /**
     * This method is used to verify Caregiver waiting Telephone Icon is present 
     */
    	public ProviderHomePage verifyCaregiverWaitingTelephoneIcon() throws Exception{
    	assertEquals(true, driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[2]/img")).isDisplayed());
    	return new ProviderHomePage(driver);
    }
    
   /**
 * This method is used to verify Caregiver waiting text is present 
 */
	public ProviderHomePage verifyCaregiverWaitingText() throws Exception{
	assertEquals("19 caregivers waiting to be contacted", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/div/div/div[1]/div[2]/ul/li[2]/span")).getText());
	return new ProviderHomePage(driver);
}
	
    	
	 /**
     * This method is used to click on Pending Assessments Note Book Link in the middle of the page.
     */
    public ProviderHomePage click_PendingAssessmentsNoteBookLink() throws Exception{
    	click_PendingAssessmentsNoteBookLink.click();
    	return new ProviderHomePage(driver);
    }
    

    
	 /**
     * This method is used to select on Footer
     */
    public ProviderHomePage verifyFooter() throws Exception{
    	assertEquals("U.S. Department of Veterans Affairs", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/footer/div/span[1]")).getText());
    	assertEquals("810 Vermont Avenue, NW Washington DC 20420", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/footer/div/span[2]")).getText());
    	assertEquals("Last reviewed/updated 6/3/15", driver.findElement(By.xpath(".//*[@id='dc-provider']/div[1]/footer/div/span[3]")).getText());
    	assertEquals("App Version: 15.0", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/footer/div/span[4]")).getText());
    	return new ProviderHomePage(driver);
    }
}
