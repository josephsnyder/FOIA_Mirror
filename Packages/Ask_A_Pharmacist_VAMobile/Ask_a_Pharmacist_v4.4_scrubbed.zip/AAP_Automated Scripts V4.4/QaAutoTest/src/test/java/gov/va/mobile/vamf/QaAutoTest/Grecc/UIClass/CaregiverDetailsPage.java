package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverDetailsPage {
private static WebDriver driver; 
	
	
	
//I felt that my physical health was worse than before Section ======================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='wellbeing-dropdown-1']")
		public WebElement click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[1]/a")
		public WebElement click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")
		public WebElement click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")
		public WebElement click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown05Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[4]/a")
		public WebElement click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[5]/a")
		public WebElement click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown2Value; 

		
//I felt downhearted, blue, or sad more often. (knowing correct time and place) Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='wellbeing-dropdown-2']")
		public WebElement click_IfeltDownheartedBlueOrSadMoreOftenDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[1]/a")
		public WebElement click_IfeltDownheartedBlueOrSadMoreOftenDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")
		public WebElement click_IfeltDownheartedBlueOrSadMoreOftenDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")
		public WebElement click_IfeltDownheartedBlueOrSadMoreOftenDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")
		public WebElement click_IfeltDownheartedBlueOrSadMoreOftenDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[5]/a")
		public WebElement click_IfeltDownheartedBlueOrSadMoreOftenDropdown3Value; 
		
		
//I felt more nervous or bothered by nerves than before Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='wellbeing-dropdown-3']")
		public WebElement click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[1]/a")
		public WebElement click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")
		public WebElement click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")
		public WebElement click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")
		public WebElement click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[5]/a")
		public WebElement click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown3Value; 
		
		
// I felt that I had less pep or energy. Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='wellbeing-dropdown-4']")
		public WebElement click_IFeltThatIHadLessPepOrEnergyDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[1]/a")
		public WebElement click_IFeltThatIHadLessPepOrEnergyDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")
		public WebElement click_IFeltThatIHadLessPepOrEnergyDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")
		public WebElement click_IFeltThatIHadLessPepOrEnergyDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")
		public WebElement click_IFeltThatIHadLessPepOrEnergyDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[5]/a")
		public WebElement click_IFeltThatIHadLessPepOrEnergyDropdown3Value;
		
		
//I felt bothered more by aches and pains Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='wellbeing-dropdown-5']")
		public WebElement click_IFeltBotheredMoreByAchesAndPainsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[1]/a")
		public WebElement click_IFeltBotheredMoreByAchesAndPainsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")
		public WebElement click_IFeltBotheredMoreByAchesAndPainsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")
		public WebElement click_IFeltBotheredMoreByAchesAndPainsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")
		public WebElement click_IFeltBotheredMoreByAchesAndPainsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[5]/a")
		public WebElement click_IFeltBotheredMoreByAchesAndPainsDropdown3Value; 
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverDetailsPage(WebDriver driver){
			CaregiverDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Caregiver Details Title
	     */
	    public CaregiverDetailsPage verifyCaregiverDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Caregiver Well-Being Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Caregiver Details Text
	     */
	    public CaregiverDetailsPage verifyCaregiverDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your current Well-Being.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverDetailsPage(driver);
	    }
	    
//IFeltThatMyPhysicalHealthWasWorseThanBefore Section Methods ======================================================================================================
		 /**
		 * This method is used to verify I felt that my physical health was worse than before Label
		 */
		public CaregiverDetailsPage verifyIFeltThatMyPhysicalHealthWasWorseThanBeforeLabel() throws Exception{
			assertEquals("I felt that my physical health was worse than before.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[1]/label")).getText());
			return new CaregiverDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on I felt that my physical health was worse than before drop down.
		 */
		public CaregiverDetailsPage click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown() throws Exception{
			Thread.sleep(1000);
			click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown.click();
			Thread.sleep(2000);
			return new CaregiverDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify I felt that my physical health was worse than before category Select an option drop down value
	    */
		public CaregiverDetailsPage verifyIFeltThatMyPhysicalHealthWasWorseThanBeforeSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='wellbeing-dropdown-1']")).getText());
			return new CaregiverDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on I felt that my physical health was worse than before Select an option drop value
		 */
		public CaregiverDetailsPage click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdownSelectAnOptionValue() throws Exception{
			click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdownSelectAnOptionValue.click();
			return new CaregiverDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify I felt that my physical health was worse than before category 0 value
		*/
		public CaregiverDetailsPage verifyIFeltThatMyPhysicalHealthWasWorseThanBeforeSelection0() throws Exception{
			assertEquals("0 - Strongly agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt that my physical health was worse than before 0 value
		 */
		public CaregiverDetailsPage click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown0Value() throws Exception{
			click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown0Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify I felt that my physical health was worse than before category 1 value
		*/
		public CaregiverDetailsPage verifyIFeltThatMyPhysicalHealthWasWorseThanBeforeSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt that my physical health was worse than before 1 value
		 */
		public CaregiverDetailsPage click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown1Value() throws Exception{
			click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown1Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify I felt that my physical health was worse than before category 2 value
		*/
		public CaregiverDetailsPage verifyIFeltThatMyPhysicalHealthWasWorseThanBeforeSelection2() throws Exception{
			assertEquals("2 - Disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt that my physical health was worse than before 2 value
		 */
		public CaregiverDetailsPage click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown2Value() throws Exception{
			click_IFeltThatMyPhysicalHealthWasWorseThanBeforeDropdown2Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify I felt that my physical health was worse than before category 3 value
		*/
		public CaregiverDetailsPage verifyIFeltThatMyPhysicalHealthWasWorseThanBeforeSelection3() throws Exception{
			assertEquals("3 - Storngly disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	
//I felt downhearted, blue, or sad more often. Section Methods ======================================================================================================
		 /**
		 * This method is used to verify IfeltDownheartedBlueOrSadMoreOften Label
		 */
		public CaregiverDetailsPage verifyIfeltDownheartedBlueOrSadMoreOftenLabel() throws Exception{
			assertEquals("I felt downhearted, blue, or sad more often.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[1]/label")).getText());
			return new CaregiverDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on IfeltDownheartedBlueOrSadMoreOften drop down.
		 */
		public CaregiverDetailsPage click_IfeltDownheartedBlueOrSadMoreOftenDropdown() throws Exception{
			click_IfeltDownheartedBlueOrSadMoreOftenDropdown.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify IfeltDownheartedBlueOrSadMoreOften category Select an option drop down value for IfeltDownheartedBlueOrSadMoreOften
	    */
		public CaregiverDetailsPage verifyIfeltDownheartedBlueOrSadMoreOftenSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='wellbeing-dropdown-2']")).getText());
			return new CaregiverDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on IfeltDownheartedBlueOrSadMoreOften Select an option drop value
		 */
		public CaregiverDetailsPage click_IfeltDownheartedBlueOrSadMoreOftenDropdownSelectAnOptionValue() throws Exception{
			click_IfeltDownheartedBlueOrSadMoreOftenDropdownSelectAnOptionValue.click();
			return new CaregiverDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify IfeltDownheartedBlueOrSadMoreOften category 0 value
		*/
		public CaregiverDetailsPage verifyIfeltDownheartedBlueOrSadMoreOftenSelection0() throws Exception{
			assertEquals("0 - Strongly Agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IfeltDownheartedBlueOrSadMoreOften 0 value
		 */
		public CaregiverDetailsPage click_IfeltDownheartedBlueOrSadMoreOftenDropdown0Value() throws Exception{
			click_IfeltDownheartedBlueOrSadMoreOftenDropdown0Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IfeltDownheartedBlueOrSadMoreOften category 1 value
		*/
		public CaregiverDetailsPage verifyIfeltDownheartedBlueOrSadMoreOftenSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IfeltDownheartedBlueOrSadMoreOften 1 value
		 */
		public CaregiverDetailsPage click_IfeltDownheartedBlueOrSadMoreOftenDropdown1Value() throws Exception{
			click_IfeltDownheartedBlueOrSadMoreOftenDropdown1Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IfeltDownheartedBlueOrSadMoreOften category 2 value
		*/
		public CaregiverDetailsPage verifyIfeltDownheartedBlueOrSadMoreOftenSelection2() throws Exception{
			assertEquals("2 - Disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IfeltDownheartedBlueOrSadMoreOften 2 value
		 */
		public CaregiverDetailsPage click_IfeltDownheartedBlueOrSadMoreOftenDropdown2Value() throws Exception{
			click_IfeltDownheartedBlueOrSadMoreOftenDropdown2Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IfeltDownheartedBlueOrSadMoreOften category 3 value
		*/
		public CaregiverDetailsPage verifyIfeltDownheartedBlueOrSadMoreOftenSelection3() throws Exception{
			assertEquals("3 - Strongly disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on IfeltDownheartedBlueOrSadMoreOften 3 value
		 */
		public CaregiverDetailsPage click_IfeltDownheartedBlueOrSadMoreOftenDropdown3Value() throws Exception{
			click_IfeltDownheartedBlueOrSadMoreOftenDropdown3Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
//I felt more nervous or bothered by nerves than before Section Methods ======================================================================================================
		 /**
		 * This method is used to verify IfeltMoreNervousOrBotheredByNervesThanBefore Label
		 */
		public CaregiverDetailsPage verifyIfeltMoreNervousOrBotheredByNervesThanBeforeLabel() throws Exception{
			assertEquals("I felt more nervous or bothered by nerves than before.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[1]/label")).getText());
			return new CaregiverDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on IfeltMoreNervousOrBotheredByNervesThanBefore drop down.
		 */
		public CaregiverDetailsPage click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown() throws Exception{
			click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify IfeltMoreNervousOrBotheredByNervesThanBefore category Select an option drop down value
	    */
		public CaregiverDetailsPage verifyIfeltMoreNervousOrBotheredByNervesThanBeforeSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='wellbeing-dropdown-3']")).getText());
			return new CaregiverDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on IfeltMoreNervousOrBotheredByNervesThanBefore Select an option drop value
		 */
		public CaregiverDetailsPage click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdownSelectAnOptionValue() throws Exception{
			click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdownSelectAnOptionValue.click();
			return new CaregiverDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify IfeltMoreNervousOrBotheredByNervesThanBefore category 0 value
		*/
		public CaregiverDetailsPage verifyIfeltMoreNervousOrBotheredByNervesThanBeforeSelection0() throws Exception{
			assertEquals("0 - Strongly agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IfeltMoreNervousOrBotheredByNervesThanBefore 0 value
		 */
		public CaregiverDetailsPage click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown0Value() throws Exception{
			click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown0Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IfeltMoreNervousOrBotheredByNervesThanBefore category 1 value
		*/
		public CaregiverDetailsPage verifyIfeltMoreNervousOrBotheredByNervesThanBeforeSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IfeltMoreNervousOrBotheredByNervesThanBefore 1 value
		 */
		public CaregiverDetailsPage click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown1Value() throws Exception{
			click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown1Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IfeltMoreNervousOrBotheredByNervesThanBefore category 2 value
		*/
		public CaregiverDetailsPage verifyIfeltMoreNervousOrBotheredByNervesThanBeforeSelection2() throws Exception{
			assertEquals("2 - Disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IfeltMoreNervousOrBotheredByNervesThanBefore 2 value
		 */
		public CaregiverDetailsPage click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown2Value() throws Exception{
			click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown2Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IfeltMoreNervousOrBotheredByNervesThanBefore category 3 value
		*/
		public CaregiverDetailsPage verifyIfeltMoreNervousOrBotheredByNervesThanBeforeSelection3() throws Exception{
			assertEquals("3 - Strongly disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on IfeltMoreNervousOrBotheredByNervesThanBefore 3 value
		 */
		public CaregiverDetailsPage click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown3Value() throws Exception{
			click_IfeltMoreNervousOrBotheredByNervesThanBeforeDropdown3Value.click();
			return new CaregiverDetailsPage(driver);
		}
			
//I felt that I had less pep or energy Section Methods ======================================================================================================

		 /**
		 * This method is used to verify I felt that I had less pep or energy. Label
		 */
		public CaregiverDetailsPage verifyIFeltThatIHadLessPepOrEnergyLabel() throws Exception{
			assertEquals("I felt that I had less pep or energy.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[1]/label")).getText());
			return new CaregiverDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on I felt that I had less pep or energy. drop down.
		 */
		public CaregiverDetailsPage click_IFeltThatIHadLessPepOrEnergyDropdown() throws Exception{
			click_IFeltThatIHadLessPepOrEnergyDropdown.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify I felt that I had less pep or energy. category Select an option drop down value
	    */
		public CaregiverDetailsPage verifyIFeltThatIHadLessPepOrEnergySelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='wellbeing-dropdown-4']")).getText());
			return new CaregiverDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on I felt that I had less pep or energy. Select an option drop value
		 */
		public CaregiverDetailsPage click_IFeltThatIHadLessPepOrEnergyDropdownSelectAnOptionValue() throws Exception{
			click_IFeltThatIHadLessPepOrEnergyDropdownSelectAnOptionValue.click();
			return new CaregiverDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify I felt that I had less pep or energy. category 0 value
		*/
		public CaregiverDetailsPage verifyIFeltThatIHadLessPepOrEnergySelection0() throws Exception{
			assertEquals("0 - Strongly agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt that I had less pep or energy. 0 value
		 */
		public CaregiverDetailsPage click_IFeltThatIHadLessPepOrEnergyDropdown0Value() throws Exception{
			click_IFeltThatIHadLessPepOrEnergyDropdown0Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IFeltThatIHadLessPepOrEnergy category 1 value
		*/
		public CaregiverDetailsPage verifyIFeltThatIHadLessPepOrEnergySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IFeltThatIHadLessPepOrEnergy 1 value
		 */
		public CaregiverDetailsPage click_IFeltThatIHadLessPepOrEnergyDropdown1Value() throws Exception{
			click_IFeltThatIHadLessPepOrEnergyDropdown1Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IFeltThatIHadLessPepOrEnergy category 2 value
		*/
		public CaregiverDetailsPage verifyIFeltThatIHadLessPepOrEnergySelection2() throws Exception{
			assertEquals("2 - Disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IFeltThatIHadLessPepOrEnergy 2 value
		 */
		public CaregiverDetailsPage click_IFeltThatIHadLessPepOrEnergyDropdown2Value() throws Exception{
			click_IFeltThatIHadLessPepOrEnergyDropdown2Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IFeltThatIHadLessPepOrEnergy category 3 value
		*/
		public CaregiverDetailsPage verifyIFeltThatIHadLessPepOrEnergySelection3() throws Exception{
			assertEquals("3 - Strongly disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on IFeltThatIHadLessPepOrEnergy 3 value
		 */
		public CaregiverDetailsPage click_IFeltThatIHadLessPepOrEnergyDropdown3Value() throws Exception{
			click_IFeltThatIHadLessPepOrEnergyDropdown3Value.click();
			return new CaregiverDetailsPage(driver);
		}
			

//I felt bothered more by aches and pains Section Methods ======================================================================================================

		 /**
		 * This method is used to verify I felt bothered more by aches and pains Label
		 */
		public CaregiverDetailsPage verifyIFeltBotheredMoreByAchesAndPainsLabel() throws Exception{
			assertEquals("I felt bothered more by aches and pains.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[1]")).getText());
			return new CaregiverDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on I felt bothered more by aches and pains  drop down.
		 */
		public CaregiverDetailsPage click_IFeltBotheredMoreByAchesAndPainsDropdown() throws Exception{
			click_IFeltBotheredMoreByAchesAndPainsDropdown.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify I felt bothered more by aches and pains category Select an option drop down value
	    */
		public CaregiverDetailsPage verifyIFeltBotheredMoreByAchesAndPainsSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath(".//*[@id='wellbeing-dropdown-5']")).getText());
			return new CaregiverDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on I felt bothered more by aches and pains Select an option drop value
		 */
		public CaregiverDetailsPage click_IFeltBotheredMoreByAchesAndPainsDropdownSelectAnOptionValue() throws Exception{
			click_IFeltBotheredMoreByAchesAndPainsDropdownSelectAnOptionValue.click();
			return new CaregiverDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify I felt bothered more by aches and pains category 0 value
		*/
		public CaregiverDetailsPage verifyIFeltBotheredMoreByAchesAndPainsSelection0() throws Exception{
			assertEquals("0 - Strongy agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt bothered more by aches and pains 0 value
		 */
		public CaregiverDetailsPage click_IFeltBotheredMoreByAchesAndPainsDropdown0Value() throws Exception{
			click_IFeltBotheredMoreByAchesAndPainsDropdown0Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify I felt bothered more by aches and pains category 1 value
		*/
		public CaregiverDetailsPage verifyIFeltBotheredMoreByAchesAndPainsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Agree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt bothered more by aches and pains 1 value
		 */
		public CaregiverDetailsPage click_IFeltBotheredMoreByAchesAndPainsDropdown1Value() throws Exception{
			click_IFeltBotheredMoreByAchesAndPainsDropdown1Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify I felt bothered more by aches and pains  category 2 value
		*/
		public CaregiverDetailsPage verifyIFeltBotheredMoreByAchesAndPainsSelection2() throws Exception{
			assertEquals("2 - Disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on I felt bothered more by aches and pains  2 value
		 */
		public CaregiverDetailsPage click_IFeltBotheredMoreByAchesAndPainsDropdown2Value() throws Exception{
			click_IFeltBotheredMoreByAchesAndPainsDropdown2Value.click();
			return new CaregiverDetailsPage(driver);
		}
		
		/**
		* This method is used to verify I felt bothered more by aches and pains  category 3 value
		*/
		public CaregiverDetailsPage verifyIFeltBotheredMoreByAchesAndPainsSelection3() throws Exception{
			assertEquals("3 - Strongly disagree", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on I felt bothered more by aches and pains  3 value
		 */
		public CaregiverDetailsPage click_IFeltBotheredMoreByAchesAndPainsDropdown3Value() throws Exception{
			click_IFeltBotheredMoreByAchesAndPainsDropdown3Value.click();
			return new CaregiverDetailsPage(driver);
		}
	    
//Buttons Section ===================================================================================================================
		
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverDetailsPage click_ContinueButton() throws Exception{
	    	click_ContinueButton.click();
	    	return new CaregiverDetailsPage(driver);
	    }
	    
 //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverDetailsPage(driver);
  		}
}
