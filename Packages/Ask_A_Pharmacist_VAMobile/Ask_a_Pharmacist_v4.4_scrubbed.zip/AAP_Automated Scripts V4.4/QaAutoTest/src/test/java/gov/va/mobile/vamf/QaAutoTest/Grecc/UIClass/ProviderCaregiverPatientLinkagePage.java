package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ProviderCaregiverPatientLinkagePage {

private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']")
	public WebElement click_SignInButton; 

	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-off2']")
	public WebElement click_ServicesDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[1]/a")
	public WebElement click_PatientAssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[2]/a")
	public WebElement click_CaregiverPatientLinkagetDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_AboutButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='help']")
	public WebElement click_HelpButtonLink; 

	@FindBy(how = How.XPATH, using = "//*[@id='search']/img")
	public WebElement click_SearchAssessmentsIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='search']/span")
	public WebElement click_SearchAssessmentsLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-reviews']")
	public WebElement click_PendingForReviewsCheckbox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-worsen']")
	public WebElement click_WorseningSymptomsCheckbox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='link-worsen']/img")
	public WebElement click_WorseningSymptomsInfoIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-patient']")
	public WebElement click_PatientCheckbox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-patient-input']")
	public WebElement click_PatientTextBox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-callbacks']")
	public WebElement click_PendingCaregiverContactRequestsCheckbox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-last20']")
	public WebElement click_Last20ViewedPatientsCheckbox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-last20']")
	public WebElement click_Last20ViewedPatientsInfoIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-dates']")
	public WebElement click_FromCheckBox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-dates-from']")
	public WebElement click_FromTextBox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='cbx-dates-to']")
	public WebElement click_ToTextBox; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[1]")
	public WebElement click_SerialNumberLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[2]")
	public WebElement click_PatientLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[3]")
	public WebElement click_SubmittedOnLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[4]")
	public WebElement click_ReviewedLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[5]")
	public WebElement click_WorseningSymptomsLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[5]/a/img")
	public WebElement clickWorseningSymptomsInfoIconLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[6]")
	public WebElement click_ContactRequestedLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[7]")
	public WebElement click_ContactProvidedLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='tbl-patient-assessments']/thead/tr/th[8]")
	public WebElement click_ActionLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn-cancel']")
	public WebElement click_CancelButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn-reset']")
	public WebElement click_ResetButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn-search']")
	public WebElement click_SearchButton;
	
// Methods========================================
	
	public ProviderCaregiverPatientLinkagePage(WebDriver driver){
			ProviderCaregiverPatientLinkagePage.driver = driver;
	}
	
	 /**
     * This method is used to verify Caregiver Patient Linkage Title
     */
    public ProviderCaregiverPatientLinkagePage verifyCaregiverPatientLinkageForTitle() throws Exception{
    	Thread.sleep(4000);
    	assertEquals("Caregiver Patient Linkage", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/div[1]/h2")).getText());
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
	
	 /**
     * This method is used to verify Caregiver Patient Linkage Text
     */
    public ProviderCaregiverPatientLinkagePage verifyCaregiverPatientLinkageForText() throws Exception{
    	Thread.sleep(4000);
    	assertEquals("Search Caregiver Patient Linkage that are Pending for Reviews or with Pending Caregiver Contact Requests.", driver.findElement(By.xpath("//*[@id='dc-provider']/div[1]/section[1]/div/p")).getText());
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	 /**
	 * This method is used to verify Total assessments found Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifyTotalAssessmentsFoundHeading() throws Exception{
		assertEquals("Total assessments found:", driver.findElement(By.xpath("//*[@id='results']/p/strong")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
    
	 /**
	 * This method is used to verify Submitted On Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifySubmittedHeading() throws Exception{
		assertEquals("Submitted On", driver.findElement(By.xpath("//*[@id='tbl-patient-assessments']/thead/tr/th[3]")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
	
	 /**
	 * This method is used to verify Reviewed Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifyReviewedHeading() throws Exception{
		assertEquals("Reviewed", driver.findElement(By.xpath("//*[@id='tbl-patient-assessments']/thead/tr/th[4]")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
    
	 /**
	 * This method is used to verify Worsening Symptoms Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifyWorseningSymptomsHeading() throws Exception{
		assertEquals("Worsening Symptoms ", driver.findElement(By.xpath("//*[@id='tbl-patient-assessments']/thead/tr/th[5]")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
	
	 /**
	    * This method is used to click on Worsening Symptoms Info Icon Link
	    */
	 public ProviderCaregiverPatientLinkagePage clickWorseningSymptomsInfoIconLink() throws Exception{
		clickWorseningSymptomsInfoIconLink.click();
	    return new ProviderCaregiverPatientLinkagePage(driver);
	 }
	 

	 /**
	 * This method is used to verify Contact Requested Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifyContactRequestedHeading() throws Exception{
		assertEquals("Minimally Improved", driver.findElement(By.xpath(".//*[@id='tbl-patient-assessments']/thead/tr/th[6]")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
    
	 /**
	 * This method is used to verify Contact Provided Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifyContactProvidedHeading() throws Exception{
		assertEquals("Contact Provided", driver.findElement(By.xpath("//*[@id='tbl-patient-assessments']/thead/tr/th[7]")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
    
	 /**
	 * This method is used to verify Action Heading
	 */
	public ProviderCaregiverPatientLinkagePage verifyActionHeading() throws Exception{
		assertEquals("Action", driver.findElement(By.xpath("//*[@id='tbl-patient-assessments']/thead/tr/th[8]")).getText());
		return new ProviderCaregiverPatientLinkagePage(driver);
	}
	
	/**
     * This method is used to click on Pending for Reviews Checkbox
     */
    public ProviderCaregiverPatientLinkagePage click_PendingForReviewsCheckbox() throws Exception{
    	click_PendingForReviewsCheckbox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
	
	/**
     * This method is used to click on Worsening Symptoms Checkbox
     */
    public ProviderCaregiverPatientLinkagePage click_WorseningSymptomsCheckbox() throws Exception{
    	click_WorseningSymptomsCheckbox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on Worsening Symptoms Info Icon
     */
    public ProviderCaregiverPatientLinkagePage click_WorseningSymptomsInfoIcon() throws Exception{
    	click_WorseningSymptomsInfoIcon.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on Pending Caregiver Contact Requests Checkbox
     */
    public ProviderCaregiverPatientLinkagePage click_PendingCaregiverContactRequestsCheckbox() throws Exception{
    	click_PendingCaregiverContactRequestsCheckbox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on  Last 20 Viewed Patients Checkbox
     */
    public ProviderCaregiverPatientLinkagePage click_Last20ViewedPatientsCheckbox() throws Exception{
    	click_Last20ViewedPatientsCheckbox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on Last 20 Viewed Patient Info Icon
     */
    public ProviderCaregiverPatientLinkagePage click_Last20ViewedPatientsInfoIcon() throws Exception{
    	click_Last20ViewedPatientsInfoIcon.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on From Checkbox
     */
    public ProviderCaregiverPatientLinkagePage click_FromCheckbox() throws Exception{
    	click_FromCheckBox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on From Textbox
     */
    public ProviderCaregiverPatientLinkagePage click_FromTextBox() throws Exception{
    	click_FromTextBox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on To Textbox
     */
    public ProviderCaregiverPatientLinkagePage click_ToTextBox() throws Exception{
    	click_ToTextBox.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
    
    
//===============================================================================================================================
//Buttons Section
	
	 /**
     * This method is used to verify Cancel button.
     */
    public ProviderCaregiverPatientLinkagePage verifyCancelButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn-cancel']")) !=null);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on Cancel button.
     */
    public ProviderCaregiverPatientLinkagePage click_CancelButton() throws Exception{
    	click_CancelButton.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	 /**
     * This method is used to verify Search Assessments Icon
     */
    public ProviderCaregiverPatientLinkagePage verifySeachAssessmentsIcon() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='search']/img")) !=null);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	 /**
     * This method is used to verify Search Assessments Link
     */
    public ProviderCaregiverPatientLinkagePage verifySeachAssessmentsLink() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='search']/span")) !=null);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on Search Assessments Info Icon
     */
    public ProviderCaregiverPatientLinkagePage click_SearchAssessmentsIcon() throws Exception{
    	Thread.sleep(1000);
    	click_SearchAssessmentsIcon.click();
    	Thread.sleep(1000);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	/**
     * This method is used to click on Search Assessments link Icon
     */
    public ProviderCaregiverPatientLinkagePage click_SearchAssessmentsLink() throws Exception{
    	Thread.sleep(1000);
    	click_SearchAssessmentsLink.click();
    	Thread.sleep(1000);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	 /**
     * This method is used to verify Reset button.
     */
    public ProviderCaregiverPatientLinkagePage verifyResetButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn-reset']")) !=null);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	 /**
     * This method is used to click on Reset button.
     */
    public ProviderCaregiverPatientLinkagePage click_ResetButton() throws Exception{
    	click_ResetButton.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }

	 /**
     * This method is used to verify Search button.
     */
    public ProviderCaregiverPatientLinkagePage verifySearchButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn-search']")) !=null);
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
	 /**
     * This method is used to click on Search button.
     */
    public ProviderCaregiverPatientLinkagePage click_SearchButton() throws Exception{
    	click_SearchButton.click();
    	return new ProviderCaregiverPatientLinkagePage(driver);
    }
    
    
}