package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class LinkModulePage {
	public static WebDriver driver;
	
	public LinkModulePage(WebDriver driver){
		LinkModulePage.driver = driver;
	}
	
	
	
	public LinkModulePage verifyLinkModulePage() throws Exception{
		Thread.sleep(5000);
		assertEquals("Refillable VA Medications", 
				driver.findElement(By.xpath("//section[@id='rxr-link']/div/div[2]/a/div/strong")).getText());
    
		Thread.sleep(3000);
		
		return new LinkModulePage(driver);
	}
}
