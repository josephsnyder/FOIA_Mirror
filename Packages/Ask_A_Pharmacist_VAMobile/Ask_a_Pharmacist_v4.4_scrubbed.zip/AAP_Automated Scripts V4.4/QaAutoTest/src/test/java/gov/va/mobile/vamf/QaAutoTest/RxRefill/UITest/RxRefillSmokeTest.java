package gov.va.mobile.vamf.QaAutoTest.RxRefill.UITest;

import static org.junit.Assert.*;

import org.junit.*;

import gov.va.mobile.vamf.QaAutoTest.Refill.UIClass.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;



/*
 *  Smoke Test for RxRefill Application
 *  
 */

public class RxRefillSmokeTest {
	//declare Objects - Webdriver, LoginPage Object & variables
	static WebDriver driver;
	RxRefillLoginPage newRxRefillLoginPage;
	
	String vURL, UserName, Password, Browser;
	
	private boolean acceptNextAlert = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	@Before
	
	public void SetUP()throws Exception{
		//initialize Objects
		
		//driver = new FirefoxDriver();
		
		//driver = new SafariDriver();
		
		File file = new File(System.getProperty("user.dir")+ "//ExtDependencies//IEDriverServer.exe");
		
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		driver = new InternetExplorerDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//load data from resource file
		Properties properties = new Properties();
		String path = System.getProperty("user.dir")+ "//src//test//resources//datafile//data.properties";
		
		FileInputStream fs = new FileInputStream(path);
		properties.load(fs);
			
			UserName = properties.getProperty("RxUserName");
			Password = properties.getProperty("RxPassword");
			vURL = properties.getProperty("RxURL");
			Browser = properties.getProperty("Browser");		
			
		System.out.println("Test started");
		
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		}
	

	@Test
	public void LaunchRxRAppTest() throws Exception{
		
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		driver.manage().window().maximize();
	    
		}
	

	@Test
	public void RefillableVAMedTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clicRefillableVAMedications().verifyRefillableVAMedicationPage();	
		
	}	
	
	@Test
	public void PresctiptionHistoryTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickPrescriptionHistory().verifyPrescriptionHistoryPage();
			
	}
	
	@Test
	public void TrackDeliveryTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickTrackDelivery().verifyTrackDeliveryPage();
			
	}	
	
	@Test
	public void LinksModuleTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickLinkModule().verifyLinkModulePage();
			
	}
	
	@Test
	public void ApplicationIconTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickApplicationIcon().verifyHomePage();
			
	}
	
	@Test
	public void VerifyFooterInformationTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.verifyFooterInformation();
			
	}
	
	@Test
	public void ClickFeatureRefillableVAMedicationsTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickFeaturesMenu()
		.clickRefillableVAMedications()
		.verifyRefillableVAMedicationPage();
			
	}
	
	@Test
	public void ClickFeatureTrackDeliveryTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickFeaturesMenu()
		.clickTrackDelivery()
		.verifyTrackDeliveryPage();
			
	}
	
	@Test
	public void ClickFeaturePrescriptionHistoryTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickFeaturesMenu()
		.clickPrescriptionHistory()
		.verifyPrescriptionHistoryPage();
			
	}
	
	@Test
	public void ClickFeatureLinksModuleTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickFeaturesMenu()
		.clickLinks()
		.verifyLinkModulePage();
			
	}
	
	@Test
	public void ClickFeatureAboutPageTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickFeaturesMenu()
		.clickAbout();
		
			
	}
	
	@Test
	public void ClickFeatureHelpPageTest() throws Exception{
		RxRefillLoginPage rxRefillLoginPage = new RxRefillLoginPage(driver);
		rxRefillLoginPage.OpenURL(vURL);
		RxHomePage rxHomePage = new RxHomePage(driver);
		rxHomePage.clickFeaturesMenu()
		.clickHelp();
			
	}


	@After
	public void tearDown() throws Exception {
		driver.quit();
	String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

 
  
  

}

