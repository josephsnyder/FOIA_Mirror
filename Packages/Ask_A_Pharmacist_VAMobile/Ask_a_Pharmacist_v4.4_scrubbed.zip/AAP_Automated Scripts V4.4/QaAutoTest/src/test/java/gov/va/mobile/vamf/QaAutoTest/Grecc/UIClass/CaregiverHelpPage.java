package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import java.awt.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverHelpPage {
private static WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-label']")
	public WebElement verifyHelpTitle; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[1]/div[1]/label")
	public WebElement verifyBrowserLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[2]/div[1]/label")
	public WebElement verifyDevelopedByLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[3]/div[1]/label")
	public WebElement verifyUserManualVideosAndFrequentlyAskedQuestionsLabelLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[4]/div[1]/label")
	public WebElement verifyTollFreeHelpDeskLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-last']/div[1]/label")
	public WebElement verifyGeneralFeedbackToVALabel;
	
	@FindBy(how = How.XPATH, using = "//*[@id='help-manual']/a")
	public WebElement click_UserManualVideosAndFrequentlyAskedQuestionsLink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='help-feedback']/a")
	public WebElement click_GeneralFeedbackToVALink;
	
	@FindBy(how = How.XPATH, using = "//*[@id='help-modal']/div/div/div[3]/button")
	public WebElement click_CaretiverHelpCloseButton;
	
	public CaregiverHelpPage(WebDriver driver){
		CaregiverHelpPage.driver = driver;
	}
	
	 /**
     * This method is used to verify Help Label.
     */
    public CaregiverHelpPage verifyHelpLabel() throws Exception{
    	assertEquals("Help", driver.findElement(By.xpath("//*[@id='help-label']")).getText());
    	return new CaregiverHelpPage(driver);
    }
	
	 /**
     * This method is used to verify Browser Label.
     */
    public CaregiverHelpPage verifyApplicationBrowserLabel() throws Exception{
    	assertEquals("Browsers", driver.findElement(By.xpath("//*[@id='help-modal']/div/div/div[2]/div[1]/div[1]/label")).getText());
    	//assertEquals("This application can be used on the following supported browsers: Internet Explorer 9, 11 and higher Safari 7 and higher (Mac OS X and iOS only) ", driver.findElement(By.xpath("//*[@id='help-browsers']")).getText());
    	//assertEquals("This application can be used on the following supported browsers: Internet Explorer 9, 11 and higher Safari 7 and higher (Mac OS X and iOS only)", driver.findElement(By.id("help-browsers")).getText());
    	//assertEquals("This application can be used on the following supported browsers: Internet Explorer 9, 11 and higher Safari 7 and higher (Mac OS X and iOS only)", driver.findElement(By.xpath("//div[@id='help-modal']/div/div/div[2]/div/div[2]")).getText());
    	//assertEquals("This application can be used on the following supported browsers: Internet Explorer 9, 11 and higher Safari 7 and higher (Mac OS X and iOS only)", driver.findElement(By.xpath("//div[4]/div/div/div[2]/div/div[2]")).getText());
    	//assertEquals("This application can be used on the following supported browsers: Internet Explorer 9, 11 and higher Safari 7 and higher (Mac OS X and iOS only)", driver.findElement(By.cssSelector("css=#help-browsers")).getText());
    	return new CaregiverHelpPage(driver);
    }
 
	 /**
     * This method is used to verify User Manual, Videos and Frequently Asked Questions Label.
     */
    public CaregiverHelpPage verifyUserManualVideosAndFrequentlyAskedQuestionsLabelLabel() throws Exception{
    	assertEquals("User Manual, Videos and Frequently Asked Questions", driver.findElement(By.xpath("//*[@id='help-modal']/div/div/div[2]/div[2]/div[1]/label")).getText());
    	assertEquals("User Manual, Videos and Frequently Asked Questions", driver.findElement(By.xpath("//*[@id='help-manual']/a")).getText());
    	return new CaregiverHelpPage(driver);
    }
    
	 /**
     * This method is used to click on User Manual, Videos and Frequently Asked Questions links.
     */
    
    public CaregiverSignInPopupPage click_UserManualVideosAndFrequentlyAskedQuestionsLink() throws Exception{
    	click_UserManualVideosAndFrequentlyAskedQuestionsLink.click();
    	return new CaregiverSignInPopupPage(driver);
    }
    
    
	 /**
     * This method is used to verify User Manual, Videos and Frequently Asked Questions Label.
     */
    public CaregiverHelpPage verifyDevelopedByLabel() throws Exception{
    	assertEquals("Developed By", driver.findElement(By.xpath("//*[@id='about-modal']/div/div/div[2]/div[4]/div[1]/label")).getText());
    	assertEquals("2015", driver.findElement(By.xpath("//*[@id='about-date']")).getText());
    	return new CaregiverHelpPage(driver);
    }
    
	 /**
     * This method is used to verify Toll Free Help Desk Label.
     */
    public CaregiverHelpPage verifyTollFreeHelpDeskLabel() throws Exception{
    	assertEquals("Toll Free Help Desk", driver.findElement(By.xpath("//*[@id='help-modal']/div/div/div[2]/div[3]/div[1]/label")).getText());
    	assertEquals("For help with this application contact the VA Mobile App Help Desk at For DS Logon related questions contact the eBenefits help line at 1-800-983-0937.", driver.findElement(By.xpath("//*[@id='help-desk']")).getText());
    	return new CaregiverHelpPage(driver);
    }
    
	 /**
     * This method is used to verify General Feedback to VA ALabel.
     */
    public CaregiverHelpPage verifyGeneralFeedbackToVALabel() throws Exception{
    	assertEquals("General Feedback to VA", driver.findElement(By.xpath("//*[@id='help-last']/div[1]/label")).getText());
    	assertEquals("General Feedback to VA", driver.findElement(By.xpath("//*[@id='help-feedback']/a")).getText());
    	return new CaregiverHelpPage(driver);
    }
    
    
	 /**
     * This method is used to click on General Feedback to VA ALabel links.
     */
    public CaregiverSignInPopupPage click_GeneralFeedbackToVALink() throws Exception{
    	click_GeneralFeedbackToVALink.click();
    	Thread.sleep(5000);
    	//driver.switchTo();
    	//driver.switchTo().window("VA Mobile Health App Feedback | VA Mobile");
    	//driver.switchTo().window("https://mobile.domain/feedback?appname=DC");
    	//driver.switchTo().window(nameOrHandle);
    	assertEquals("https://mobile.domain/feedback?appname=DC", driver.getWindowHandle());
    	
    	String parentWindow = driver.getWindowHandle();
    	
    	Set<String> availableWindow = driver.getWindowHandles();

    	for  (String w : availableWindow)
    	{
    	if(w != parentWindow)
    	{
    	driver.switchTo().window(w);
    	}
    	}
    	return new CaregiverSignInPopupPage(driver);
    }
    
	 /**
     * This method is used to click on Close button.
     */
    public CaregiverSignInPopupPage click_CaretiverHelpCloseButton() throws Exception{
    	click_CaretiverHelpCloseButton.click();
    	return new CaregiverSignInPopupPage(driver);
    }
    


}
