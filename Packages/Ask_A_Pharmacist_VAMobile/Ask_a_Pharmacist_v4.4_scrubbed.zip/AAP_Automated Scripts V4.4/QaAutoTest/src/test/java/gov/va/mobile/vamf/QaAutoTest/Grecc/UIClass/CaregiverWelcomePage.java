package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverWelcomePage {
	private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
	public WebElement click_VAhealthlogo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']")
	public WebElement click_SignInButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='fakeLogin']")
	public WebElement click_FakeButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
	public WebElement click_VABannerHeader; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[2]")
	public WebElement click_ResourceCenterButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_AboutButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='help']")
	public WebElement click_HelpButtonLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement click_WelcomeTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p")
	public WebElement click_WelcomeBodyTet; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']/img[1]")
	public WebElement click_CaregiverSignInIcon; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']/h3")
	public WebElement click_CaregiverSignInLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']/img[2]")
	public WebElement click_CaregiverSignInArrow; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[1]/div/div[2]/div/a/img[1]")
	public WebElement click_ResouceCenterBookIcon; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[1]/div/div[2]/div/a/h3")
	public WebElement click_ResourceCenterLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[1]/div/div[2]/div/a/img[2]")
	public WebElement click_ResourceCenterArrow; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/img")
	public WebElement click_TipOfTheWeekBulbIcon; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/h3")
	public WebElement click_TipOfTheWeekHeading; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[2]/p")
	public WebElement click_TipOfTheWeekTextbox; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[3]/p")
	public WebElement click_GetAppLabel; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[3]/a[1]/img")
	public WebElement click_DownloadAppStoreLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/div/div[3]/a[2]/img")
	public WebElement click_DownloadGooglePlayLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[1]")
	public WebElement click_FooterOne; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[2]")
	public WebElement click_FooterTwo; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[3]")
	public WebElement click_FooterThree; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[3]/button")
	public WebElement click_AboutCloseButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='help-modal']/div/div/div[3]/button")
	public WebElement click_HelpCloseButton;
	
	
	
	public CaregiverWelcomePage(WebDriver driver){
		CaregiverWelcomePage.driver = driver;
	}
	
	public void OpenURL (String URL){
		driver.navigate().to(URL);
	}

	 /**
     * This method is used to verify on SignIn link
     */
	
    public CaregiverWelcomePage verifySignInButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='login']")).isDisplayed());
    	return new CaregiverWelcomePage(driver);
    }
    	
   	 /**
         * This method is used to click on SignIn link
         */
    	
        public CaregiverWelcomePage click_SignInButton() throws Exception{
        	click_SignInButton.click();
        	Thread.sleep(3000);
        	click_FakeButton.click();        	
        	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify chicklet icon
     */
    public CaregiverWelcomePage click_Chickleticon() throws Exception{
    	Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).isDisplayed());
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify App Name
     */
    public CaregiverWelcomePage click_DementiCareName() throws Exception{
    	assertEquals("Dementia Care", driver.findElement(By.className("dc-app-icon")).getText());
    	//Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).getText(), false);
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to Select on VABanner Header link
     */
    public CaregiverWelcomePage verifyVABannerHeader() throws Exception{
    	click_VABannerHeader.click();
    	//assertTrue(isElementPresent(By.cssSelector("footer")));
  	    Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']")).isDisplayed());
  	    //Assert.assertTrue(driver.findElement(By.xpath("//*[@id='menu-list']").contains);
	  	//driver.findElement(By.xpath("//*[@id='menu-list']")).isDisplayed();
		//assertEquals("You.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    //driver.findElement(By.id("aapLeave")).click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Home link
     */
    public CaregiverWelcomePage click_HomeButtonLink() throws Exception{
    	click_HomeButtonLink.click();
    	assertEquals("http://vetadmin.mobilehealth.domain:8080/grecc-web-2.0-veteran/#home", driver.getCurrentUrl());
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify on Home link url
     */
    public CaregiverWelcomePage verify_HomeButtonLinkurl() throws Exception{
    	assertEquals("http://vetadmin.mobilehealth.domain:8080/grecc-web-2.0-veteran/#home", driver.getCurrentUrl());
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Resource Center link
     */
    public CaregiverWelcomePage click_ResourceCenterButtonLink() throws Exception{
    	click_ResourceCenterButtonLink.click();
    	return new CaregiverWelcomePage(driver);
    }
 
	 /**
     * This method is used to click on About link
     */
    public CaregiverWelcomePage click_AboutButtonLink() throws Exception{
    	click_AboutButtonLink.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to close on About screen
     */
    public CaregiverWelcomePage click_AboutCloseButton() throws Exception{
    	click_AboutCloseButton.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Help link
     */
    public CaregiverWelcomePage click_HelpButtonLink() throws Exception{
    	click_HelpButtonLink.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to close on Help screen
     */
    public CaregiverWelcomePage click_HelpCloseButton() throws Exception{
    	click_HelpCloseButton.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify Welcome title
     */
    public CaregiverWelcomePage verifyWelcomeTitle() throws Exception{
    	assertEquals("Welcome", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
    	//Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).getText(), false);
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify Welcome text
     */
    public CaregiverWelcomePage verifyWelcomeText() throws Exception{
    	assertEquals("Welcome to Dementia Care. Please sign in if you are a caregiver or request for an account if you would like to care for a Veteran patient.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p")).getText());
    	//Assert.assertTrue(driver.findElement(By.className("dc-app-icon")).getText(), false);
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver Sign In Icon.
     */
    public CaregiverWelcomePage click_CaregiverSignInIcon() throws Exception{
    	click_CaregiverSignInIcon.click();
    	return new CaregiverWelcomePage(driver);
    }
    
    
	 /**
     * This method is used to click on Caregiver Sign In Button Link in the middle of the page.
     */
    public CaregiverWelcomePage click_CaregiverSignInLink() throws Exception{
    	click_CaregiverSignInLink.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Caregiver Sign In Button arrow in the middle of the page.
     */
    public CaregiverWelcomePage click_CaregiverSignInArrow() throws Exception{
    	click_CaregiverSignInArrow.click();
    	return new CaregiverWelcomePage(driver);
    }
    
    /**
     * This method is used to click on Resource Center Icon.
     */
    public CaregiverWelcomePage click_ResouceCenterBookIcon() throws Exception{
    	click_ResouceCenterBookIcon.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Resource Center Link in the middle of the page.
     */
    public CaregiverWelcomePage click_ResourceCenterLink() throws Exception{
    	click_ResourceCenterLink.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on Resource Center arrow in the middle of the page.
     */
    public CaregiverWelcomePage click_ResourceCenterArrow() throws Exception{
    	click_ResourceCenterArrow.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to Select Tip Of the Week
     */
    public CaregiverWelcomePage click_TipOfTheWeekBulbIcon() throws Exception{
    	//click_TipOfTheWeekBulbIcon.click();
    	Assert.assertTrue(driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[2]/img")).isDisplayed());
    	assertEquals("Tip of the Week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[2]/h3")).getText());
    	assertEquals("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[2]/p")).getText());
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to Select Get the Dementia Care App label
     */
    public CaregiverWelcomePage verifyGetAppLabel() throws Exception{
    	click_GetAppLabel.click();
    	assertEquals("Get the Dementia Care App", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[3]/p")).getText());
    	return new CaregiverWelcomePage(driver);
    }
    
    
	 /**
     * This method is used to click on AppStole lInk
     */
    public CaregiverWelcomePage click_DownloadAppStoreLink() throws Exception{
    	click_DownloadAppStoreLink.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify AppleStore lInk
     */
    public CaregiverWelcomePage verifyDownloadAppleStoreLink() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[3]/a[1]/img")).isDisplayed());
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to click on GoogleStore lInk
     */
    public CaregiverWelcomePage click_DownloadGooglePlayLink() throws Exception{
    	click_DownloadGooglePlayLink.click();
    	return new CaregiverWelcomePage(driver);
    }
    
	 /**
     * This method is used to verify GoogleStore lInk
     */
    public CaregiverWelcomePage verifyDownloadGooglePlayLink() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("html/body/div[1]/section[1]/div/div/div[3]/a[2]/img")).isDisplayed());
    	return new CaregiverWelcomePage(driver);
    }
    
    
	 /**
     * This method is used to select on Footer
     */
    public CaregiverWelcomePage verifyFooter() throws Exception{
    	assertEquals("U.S. Department of Veterans Affairs", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[1]")).getText());
    	assertEquals("810 Vermont Avenue, NW Washington DC 20420", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[2]")).getText());
    	assertEquals("Last reviewed/updated 5/26/15", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[3]")).getText());
    	assertEquals("App Version: 13.0", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[4]")).getText());
    	return new CaregiverWelcomePage(driver);
    }
    
    /*
	public GetTheLatestSafetyArticlesOnMedicationsPage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		assertEquals("U.S. Department of Veterans Affairs", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[1]")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(3000);
		return new GetTheLatestSafetyArticlesOnMedicationsPage(driver); 
	}
	
	public GetTheLatestSafetyArticlesOnMedicationsPage verifyFreeMedicationAlertsurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.consumermedsafety.org/tools-and-resources/medication-safety-tools-and-resources/know-your-medicine/get-free-personalized-drug-updates", driver.getCurrentUrl());
		return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
	}
	
	public GetTheLatestSafetyArticlesOnMedicationsPage verifyRecallsMarketWithdrawalsAndSafetyAlertsOnFDAurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.fda.gov/Safety/Recalls/default.htm", driver.getCurrentUrl());
		return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
	}
	
	 /**
     * This method is used to Click on Cancel button.
     */
/*
    public GetTheLatestSafetyArticlesOnMedicationsPage click_Cancel() throws Exception{
    	driver.findElement(By.id("aapStay")).click();
    	assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#safety-articles", driver.getCurrentUrl());
    	return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
    }*/
    /*
	public GetTheLatestSafetyArticlesOnMedicationsPage GoBackBrowserButton() throws Exception{
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(4000);
		assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#safety-articles", driver.getCurrentUrl());
	    Thread.sleep(3000);
    return new GetTheLatestSafetyArticlesOnMedicationsPage(driver);
	}*/
}
