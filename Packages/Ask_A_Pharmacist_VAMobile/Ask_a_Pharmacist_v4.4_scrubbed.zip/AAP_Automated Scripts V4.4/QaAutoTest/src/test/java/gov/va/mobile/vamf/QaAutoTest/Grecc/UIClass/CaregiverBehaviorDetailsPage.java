package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverBehaviorDetailsPage {
private static WebDriver driver; 
	
	
//Delusions Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-1']")
		public WebElement click_DelusionsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[1]/a")
		public WebElement click_DelusionsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")
		public WebElement click_DelusionsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")
		public WebElement click_DelusionsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")
		public WebElement click_DelusionsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[5]/a")
		public WebElement click_DelusionsDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[6]/a")
		public WebElement click_DelusionsDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-1']")
		public WebElement click_DelusionsSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[1]/a")
		public WebElement click_DelusionsSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[2]/a")
		public WebElement click_DelusionsSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[3]/a")
		public WebElement click_DelusionsSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[4]/a")
		public WebElement click_DelusionsSeverityDropdown3Value; 
		
		
//Hallucinations Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-2']")
		public WebElement click_HallucinationsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[1]/a")
		public WebElement click_HallucinationsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")
		public WebElement click_HallucinationsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")
		public WebElement click_HallucinationsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")
		public WebElement click_HallucinationsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[5]/a")
		public WebElement click_HallucinationsDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[6]/a")
		public WebElement click_HallucinationsDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-2']")
		public WebElement click_HallucinationsSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[1]/a")
		public WebElement click_HallucinationsSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[2]/a")
		public WebElement click_HallucinationsSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[3]/a")
		public WebElement click_HallucinationsSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[4]/a")
		public WebElement click_HallucinationsSeverityDropdown3Value; 
		
	//Agitation/aggression Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-3']")
		public WebElement click_AgitationAggressionDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[1]/a")
		public WebElement click_AgitationAggressionDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")
		public WebElement click_AgitationAggressionDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")
		public WebElement click_AgitationAggressionDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")
		public WebElement click_AgitationAggressionDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[5]/a")
		public WebElement click_AgitationAggressionDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[6]/a")
		public WebElement click_AgitationAggressionDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-3']")
		public WebElement click_AgitationAggressionSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[1]/a")
		public WebElement click_AgitationAggressionSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[2]/a")
		public WebElement click_AgitationAggressionSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[3]/a")
		public WebElement click_AgitationAggressionSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[4]/a")
		public WebElement click_AgitationAggressionSeverityDropdown3Value; 
		
// Depression/dysphoria Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-4']")
		public WebElement click_DepressionDysphoriaDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[1]/a")
		public WebElement click_DepressionDysphoriaDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")
		public WebElement click_DepressionDysphoriaDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")
		public WebElement click_DepressionDysphoriaDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")
		public WebElement click_DepressionDysphoriaDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[5]/a")
		public WebElement click_DepressionDysphoriaDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[6]/a")
		public WebElement click_DepressionDysphoriaDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-4']")
		public WebElement click_DepressionDysphoriaSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[1]/a")
		public WebElement click_DepressionDysphoriaSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[2]/a")
		public WebElement click_DepressionDysphoriaSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[3]/a")
		public WebElement click_DepressionDysphoriaSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[4]/a")
		public WebElement click_DepressionDysphoriaSeverityDropdown3Value;
	
// Anxiety Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-5']")
		public WebElement click_AnxietyDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[1]/a")
		public WebElement click_AnxietyDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[2]/a")
		public WebElement click_AnxietyDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[3]/a")
		public WebElement click_AnxietyDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[4]/a")
		public WebElement click_AnxietyDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[5]/a")
		public WebElement click_AnxietyDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[6]/a")
		public WebElement click_AnxietyDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-5']")
		public WebElement click_AnxietySeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[1]/a")
		public WebElement click_AnxietySeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[2]/a")
		public WebElement click_AnxietySeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[3]/a")
		public WebElement click_AnxietySeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[4]/a")
		public WebElement click_AnxietySeverityDropdown3Value;
		
// Elation/euphoria Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-6']")
		public WebElement click_ElationEuphoriaDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[1]/a")
		public WebElement click_ElationEuphoriaDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[2]/a")
		public WebElement click_ElationEuphoriaDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[3]/a")
		public WebElement click_ElationEuphoriaDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[4]/a")
		public WebElement click_ElationEuphoriaDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[5]/a")
		public WebElement click_ElationEuphoriaDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[6]/a")
		public WebElement click_ElationEuphoriaDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-6']")
		public WebElement click_ElationEuphoriaSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[1]/a")
		public WebElement click_ElationEuphoriaSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[2]/a")
		public WebElement click_ElationEuphoriaSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[3]/a")
		public WebElement click_ElationEuphoriaSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[4]/a")
		public WebElement click_ElationEuphoriaSeverityDropdown3Value;
		
		
// Apathy/Indifference Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-7']")
		public WebElement click_ApathyIndifferenceDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[1]/a")
		public WebElement click_ApathyIndifferenceDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[2]/a")
		public WebElement click_ApathyIndifferenceDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[3]/a")
		public WebElement click_ApathyIndifferenceDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[4]/a")
		public WebElement click_ApathyIndifferenceDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[5]/a")
		public WebElement click_ApathyIndifferenceDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[6]/a")
		public WebElement click_ApathyIndifferenceDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-7']")
		public WebElement click_ApathyIndifferenceSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[1]/a")
		public WebElement click_ApathyIndifferenceSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[2]/a")
		public WebElement click_ApathyIndifferenceSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[3]/a")
		public WebElement click_ApathyIndifferenceSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[4]/a")
		public WebElement click_ApathyIndifferenceSeverityDropdown3Value;
		
//  Disinhibition Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-8']")
		public WebElement click_DisinhibitionDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[1]/a")
		public WebElement click_DisinhibitionDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[2]/a")
		public WebElement click_DisinhibitionDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[3]/a")
		public WebElement click_DisinhibitionDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[4]/a")
		public WebElement click_DisinhibitionDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[5]/a")
		public WebElement click_DisinhibitionDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[6]/a")
		public WebElement click_DisinhibitionDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-8']")
		public WebElement click_DisinhibitionSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[1]/a")
		public WebElement click_DisinhibitionSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[2]/a")
		public WebElement click_DisinhibitionSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[3]/a")
		public WebElement click_DisinhibitionSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[4]/a")
		public WebElement click_DisinhibitionSeverityDropdown3Value;

//  Irritability Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-9']")
		public WebElement click_IrritabilityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[1]/a")
		public WebElement click_IrritabilityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[2]/a")
		public WebElement click_IrritabilityDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[3]/a")
		public WebElement click_IrritabilityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[4]/a")
		public WebElement click_IrritabilityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[5]/a")
		public WebElement click_IrritabilityDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[6]/a")
		public WebElement click_IrritabilityDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-9']")
		public WebElement click_IrritabilitySeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[1]/a")
		public WebElement click_IrritabilitySeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[2]/a")
		public WebElement click_IrritabilitySeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[3]/a")
		public WebElement click_IrritabilitySeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[4]/a")
		public WebElement click_IrritabilitySeverityDropdown3Value;
		
//  Odd movements Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-10']")
		public WebElement click_OddMovementsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[1]/a")
		public WebElement click_OddMovementsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[2]/a")
		public WebElement click_OddMovementsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[3]/a")
		public WebElement click_OddMovementsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[4]/a")
		public WebElement click_OddMovementsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[5]/a")
		public WebElement click_OddMovementsDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[6]/a")
		public WebElement click_OddMovementsDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-10']")
		public WebElement click_OddMovementsSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[1]/a")
		public WebElement click_OddMovementsSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[2]/a")
		public WebElement click_OddMovementsSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[3]/a")
		public WebElement click_OddMovementsSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[4]/a")
		public WebElement click_OddMovementsSeverityDropdown3Value;

//  Sleep and nighttime behaviors Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-11']")
		public WebElement click_SleepAndNighttimeBehaviorsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[1]/a")
		public WebElement click_SleepAndNighttimeBehaviorsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[2]/a")
		public WebElement click_SleepAndNighttimeBehaviorsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[3]/a")
		public WebElement click_SleepAndNighttimeBehaviorsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[4]/a")
		public WebElement click_SleepAndNighttimeBehaviorsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[5]/a")
		public WebElement click_SleepAndNighttimeBehaviorsDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[6]/a")
		public WebElement click_SleepAndNighttimeBehaviorsDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-11']")
		public WebElement click_SleepAndNighttimeBehaviorsSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[1]/a")
		public WebElement click_SleepAndNighttimeBehaviorsSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[2]/a")
		public WebElement click_SleepAndNighttimeBehaviorsSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[3]/a")
		public WebElement click_SleepAndNighttimeBehaviorsSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[4]/a")
		public WebElement click_SleepAndNighttimeBehaviorsSeverityDropdown3Value;
		
// Appetite and eating disorders Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='frequency-dropdown-12']")
		public WebElement click_AppetiteAndEatingDisordersDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[1]/a")
		public WebElement click_AppetiteAndEatingDisordersDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[2]/a")
		public WebElement click_AppetiteAndEatingDisordersDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[3]/a")
		public WebElement click_AppetiteAndEatingDisordersDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[4]/a")
		public WebElement click_AppetiteAndEatingDisordersDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[5]/a")
		public WebElement click_AppetiteAndEatingDisordersDropdown3Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[6]/a")
		public WebElement click_AppetiteAndEatingDisordersDropdown4Value; 
		
		//Severity
		@FindBy(how = How.XPATH, using = "//*[@id='severity-dropdown-12']")
		public WebElement click_AppetiteAndEatingDisordersSeverityDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[1]/a")
		public WebElement click_AppetiteAndEatingDisordersSeverityDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[2]/a")
		public WebElement click_AppetiteAndEatingDisordersSeverityDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[3]/a")
		public WebElement click_AppetiteAndEatingDisordersSeverityDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[4]/a")
		public WebElement click_AppetiteAndEatingDisordersSeverityDropdown3Value;
		
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverBehaviorDetailsPage(WebDriver driver){
			CaregiverBehaviorDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Behavior Details Title
	     */
	    public CaregiverBehaviorDetailsPage verifyBehaviorDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Behavior Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Behavior Details Text
	     */
	    public CaregiverBehaviorDetailsPage verifyBehaviorDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Behavior.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }
	    
		 /**
		 * This method is used to verify Frequency Label
		 */
		public CaregiverBehaviorDetailsPage verifyFrequencyLabel() throws Exception{
			assertEquals("Frequency", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[2]/span")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		 /**
		 * This method is used to verify Severity Label
		 */
		public CaregiverBehaviorDetailsPage verifySeverityLabel() throws Exception{
			assertEquals("Severity", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div[3]/span")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
//Delusions Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Delusions Label
		 */
		public CaregiverBehaviorDetailsPage verifyDelusionsLabel() throws Exception{
			assertEquals("Delusions", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Delusions drop down.
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdown() throws Exception{
			Thread.sleep(1000);
			click_DelusionsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Delusions category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyDelusionsSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-1']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Delusions Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdownSelectAnOptionValue() throws Exception{
			click_DelusionsDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Delusions category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Delusions 0 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdown0Value() throws Exception{
			click_DelusionsDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Delusions category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Delusions 1 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdown1Value() throws Exception{
			click_DelusionsDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Delusions category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Delusions 2 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdown2Value() throws Exception{
			click_DelusionsDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Delusions category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Delusions 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdown3Value() throws Exception{
			click_DelusionsDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify Delusions category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Delusions 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsDropdown4Value() throws Exception{
			click_DelusionsDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}		
//Delusions Severity Section Methods ======================================================================================================

		 /**
		 * This method is used to click on DelusionsSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_DelusionsSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify DelusionsSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyDelusionsSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-1']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on DelusionsSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsSeverityDropdownSelectAnOptionValue() throws Exception{
			click_DelusionsSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DelusionsSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DelusionsSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsSeverityDropdown1Value() throws Exception{
			click_DelusionsSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DelusionsSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DelusionsSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsSeverityDropdown2Value() throws Exception{
			click_DelusionsSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DelusionsSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyDelusionsSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on DelusionsSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DelusionsSeverityDropdown3Value() throws Exception{
			click_DelusionsSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}

//Hallucinations Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Hallucinations Label
		 */
		public CaregiverBehaviorDetailsPage verifyHallucinationsLabel() throws Exception{
			assertEquals("Hallucinations", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Hallucinations drop down.
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdown() throws Exception{
			Thread.sleep(1000);
			click_HallucinationsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Hallucinations category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyHallucinationsSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-2']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Hallucinations Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdownSelectAnOptionValue() throws Exception{
			click_HallucinationsDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Hallucinations category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Hallucinations 0 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdown0Value() throws Exception{
			click_HallucinationsDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Hallucinations category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Hallucinations 1 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdown1Value() throws Exception{
			click_HallucinationsDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Hallucinations category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Hallucinations 2 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdown2Value() throws Exception{
			click_HallucinationsDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Hallucinations category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Hallucinations 3 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdown3Value() throws Exception{
			click_HallucinationsDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify Hallucinations category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Hallucinations 3 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsDropdown4Value() throws Exception{
			click_HallucinationsDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Hallucinations Severity Section Methods ======================================================================================================

		 /**
		 * This method is used to click on HallucinationsSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_HallucinationsSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify HallucinationsSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyHallucinationsSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-2']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on HallucinationsSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsSeverityDropdownSelectAnOptionValue() throws Exception{
			click_HallucinationsSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HallucinationsSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HallucinationsSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsSeverityDropdown1Value() throws Exception{
			click_HallucinationsSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HallucinationsSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HallucinationsSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsSeverityDropdown2Value() throws Exception{
			click_HallucinationsSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HallucinationsSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyHallucinationsSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on HallucinationsSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_HallucinationsSeverityDropdown3Value() throws Exception{
			click_HallucinationsSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}

//Agitation Aggression Section Methods ======================================================================================================
		 /**
		 * This method is used to verify AgitationAggression Label
		 */
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionLabel() throws Exception{
			assertEquals("Agitation/aggression", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on AgitationAggression drop down.
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdown() throws Exception{
			Thread.sleep(1000);
			click_AgitationAggressionDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify AgitationAggression category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-3']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on AgitationAggression Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdownSelectAnOptionValue() throws Exception{
			click_AgitationAggressionDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify AgitationAggression category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AgitationAggression 0 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdown0Value() throws Exception{
			click_AgitationAggressionDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AgitationAggression category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AgitationAggression 1 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdown1Value() throws Exception{
			click_AgitationAggressionDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AgitationAggression category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AgitationAggression 2 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdown2Value() throws Exception{
			click_AgitationAggressionDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AgitationAggression category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AgitationAggression 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdown3Value() throws Exception{
			click_AgitationAggressionDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify AgitationAggression category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AgitationAggression 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionDropdown4Value() throws Exception{
			click_AgitationAggressionDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Agitation Aggression Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on AgitationAggressionSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_AgitationAggressionSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify AgitationAggressionSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-3']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on AgitationAggressionSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionSeverityDropdownSelectAnOptionValue() throws Exception{
			click_AgitationAggressionSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AgitationAggressionSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AgitationAggressionSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionSeverityDropdown1Value() throws Exception{
			click_AgitationAggressionSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AgitationAggressionSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AgitationAggressionSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionSeverityDropdown2Value() throws Exception{
			click_AgitationAggressionSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AgitationAggressionSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyAgitationAggressionSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AgitationAggressionSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AgitationAggressionSeverityDropdown3Value() throws Exception{
			click_AgitationAggressionSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}		

//Depression Dysphoria Section Methods ======================================================================================================
		 /**
		 * This method is used to verify DepressionDysphoria Label
		 */
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaLabel() throws Exception{
			assertEquals("Depression/dysphoria", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on DepressionDysphoria drop down.
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdown() throws Exception{
			Thread.sleep(1000);
			click_DepressionDysphoriaDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify DepressionDysphoria category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-4']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on DepressionDysphoria Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdownSelectAnOptionValue() throws Exception{
			click_DepressionDysphoriaDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify DepressionDysphoria category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DepressionDysphoria 0 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdown0Value() throws Exception{
			click_DepressionDysphoriaDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DepressionDysphoria category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DepressionDysphoria 1 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdown1Value() throws Exception{
			click_DepressionDysphoriaDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DepressionDysphoria category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DepressionDysphoria 2 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdown2Value() throws Exception{
			click_DepressionDysphoriaDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DepressionDysphoria category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on DepressionDysphoria 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdown3Value() throws Exception{
			click_DepressionDysphoriaDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify DepressionDysphoria category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on DepressionDysphoria 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaDropdown4Value() throws Exception{
			click_DepressionDysphoriaDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Depression Dysphoria Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on DepressionDysphoriaSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_DepressionDysphoriaSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify DepressionDysphoriaSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-4']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on DepressionDysphoriaSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaSeverityDropdownSelectAnOptionValue() throws Exception{
			click_DepressionDysphoriaSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DepressionDysphoriaSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DepressionDysphoriaSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaSeverityDropdown1Value() throws Exception{
			click_DepressionDysphoriaSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DepressionDysphoriaSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DepressionDysphoriaSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaSeverityDropdown2Value() throws Exception{
			click_DepressionDysphoriaSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DepressionDysphoriaSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyDepressionDysphoriaSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on DepressionDysphoriaSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DepressionDysphoriaSeverityDropdown3Value() throws Exception{
			click_DepressionDysphoriaSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}		

//Anxiety Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Anxiety Label
		 */
		public CaregiverBehaviorDetailsPage verifyAnxietyLabel() throws Exception{
			assertEquals("Anxiety", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Anxiety drop down.
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdown() throws Exception{
			Thread.sleep(1000);
			click_AnxietyDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Anxiety category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyAnxietySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-5']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Anxiety Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdownSelectAnOptionValue() throws Exception{
			click_AnxietyDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Anxiety category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Anxiety 0 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdown0Value() throws Exception{
			click_AnxietyDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Anxiety category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Anxiety 1 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdown1Value() throws Exception{
			click_AnxietyDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Anxiety category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Anxiety 2 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdown2Value() throws Exception{
			click_AnxietyDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Anxiety category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Anxiety 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdown3Value() throws Exception{
			click_AnxietyDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify Anxiety category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Anxiety 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietyDropdown4Value() throws Exception{
			click_AnxietyDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Anxiety Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on AnxietySeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_AnxietySeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_AnxietySeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify AnxietySeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyAnxietySeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-5']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on AnxietySeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietySeverityDropdownSelectAnOptionValue() throws Exception{
			click_AnxietySeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AnxietySeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AnxietySeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietySeverityDropdown1Value() throws Exception{
			click_AnxietySeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AnxietySeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AnxietySeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietySeverityDropdown2Value() throws Exception{
			click_AnxietySeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AnxietySeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyAnxietySeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AnxietySeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AnxietySeverityDropdown3Value() throws Exception{
			click_AnxietySeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	

//Elation Euphoria Section Methods ======================================================================================================
		 /**
		 * This method is used to verify ElationEuphoria Label
		 */
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaLabel() throws Exception{
			assertEquals("Elation/euphoria", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on ElationEuphoria drop down.
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdown() throws Exception{
			Thread.sleep(1000);
			click_ElationEuphoriaDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify ElationEuphoria category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-6']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on ElationEuphoria Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdownSelectAnOptionValue() throws Exception{
			click_ElationEuphoriaDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify ElationEuphoria category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ElationEuphoria 0 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdown0Value() throws Exception{
			click_ElationEuphoriaDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ElationEuphoria category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ElationEuphoria 1 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdown1Value() throws Exception{
			click_ElationEuphoriaDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ElationEuphoria category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ElationEuphoria 2 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdown2Value() throws Exception{
			click_ElationEuphoriaDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ElationEuphoria category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ElationEuphoria 3 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdown3Value() throws Exception{
			click_ElationEuphoriaDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify ElationEuphoria category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ElationEuphoria 3 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaDropdown4Value() throws Exception{
			click_ElationEuphoriaDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Elation Euphoria Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on ElationEuphoriaSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_ElationEuphoriaSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify ElationEuphoriaSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-6']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on ElationEuphoriaSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaSeverityDropdownSelectAnOptionValue() throws Exception{
			click_ElationEuphoriaSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ElationEuphoriaSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ElationEuphoriaSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaSeverityDropdown1Value() throws Exception{
			click_ElationEuphoriaSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ElationEuphoriaSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ElationEuphoriaSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaSeverityDropdown2Value() throws Exception{
			click_ElationEuphoriaSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ElationEuphoriaSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyElationEuphoriaSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[7]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ElationEuphoriaSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_ElationEuphoriaSeverityDropdown3Value() throws Exception{
			click_ElationEuphoriaSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	

//Apathy/Indifference Section Methods ======================================================================================================
		 /**
		 * This method is used to verify ApathyIndifference Label
		 */
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceLabel() throws Exception{
			assertEquals("Apathy/indifference", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on ApathyIndifference drop down.
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdown() throws Exception{
			Thread.sleep(1000);
			click_ApathyIndifferenceDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify ApathyIndifference category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-7']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on ApathyIndifference Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdownSelectAnOptionValue() throws Exception{
			click_ApathyIndifferenceDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify ApathyIndifference category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ApathyIndifference 0 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdown0Value() throws Exception{
			click_ApathyIndifferenceDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ApathyIndifference category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ApathyIndifference 1 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdown1Value() throws Exception{
			click_ApathyIndifferenceDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ApathyIndifference category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ApathyIndifference 2 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdown2Value() throws Exception{
			click_ApathyIndifferenceDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ApathyIndifference category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ApathyIndifference 3 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdown3Value() throws Exception{
			click_ApathyIndifferenceDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify ApathyIndifference category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ApathyIndifference 3 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceDropdown4Value() throws Exception{
			click_ApathyIndifferenceDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Apathy/Indifference Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on ApathyIndifferenceSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_ApathyIndifferenceSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify ApathyIndifferenceSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-7']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on ApathyIndifferenceSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceSeverityDropdownSelectAnOptionValue() throws Exception{
			click_ApathyIndifferenceSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ApathyIndifferenceSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ApathyIndifferenceSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceSeverityDropdown1Value() throws Exception{
			click_ApathyIndifferenceSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ApathyIndifferenceSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on ApathyIndifferenceSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceSeverityDropdown2Value() throws Exception{
			click_ApathyIndifferenceSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ApathyIndifferenceSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyApathyIndifferenceSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[8]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on ApathyIndifferenceSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_ApathyIndifferenceSeverityDropdown3Value() throws Exception{
			click_ApathyIndifferenceSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
//Disinhibition Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Disinhibition Label
		 */
		public CaregiverBehaviorDetailsPage verifyDisinhibitionLabel() throws Exception{
			assertEquals("Disinhibition", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Disinhibition drop down.
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdown() throws Exception{
			Thread.sleep(1000);
			click_DisinhibitionDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Disinhibition category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-8']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Disinhibition Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdownSelectAnOptionValue() throws Exception{
			click_DisinhibitionDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Disinhibition category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Disinhibition 0 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdown0Value() throws Exception{
			click_DisinhibitionDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Disinhibition category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Disinhibition 1 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdown1Value() throws Exception{
			click_DisinhibitionDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Disinhibition category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Disinhibition 2 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdown2Value() throws Exception{
			click_DisinhibitionDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Disinhibition category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Disinhibition 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdown3Value() throws Exception{
			click_DisinhibitionDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify Disinhibition category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Disinhibition 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionDropdown4Value() throws Exception{
			click_DisinhibitionDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Disinhibition Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on DisinhibitionSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_DisinhibitionSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify DisinhibitionSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-8']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on DisinhibitionSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionSeverityDropdownSelectAnOptionValue() throws Exception{
			click_DisinhibitionSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DisinhibitionSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DisinhibitionSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionSeverityDropdown1Value() throws Exception{
			click_DisinhibitionSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DisinhibitionSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on DisinhibitionSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionSeverityDropdown2Value() throws Exception{
			click_DisinhibitionSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify DisinhibitionSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyDisinhibitionSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[9]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on DisinhibitionSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_DisinhibitionSeverityDropdown3Value() throws Exception{
			click_DisinhibitionSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Irritability Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Irritability Label
		 */
		public CaregiverBehaviorDetailsPage verifyIrritabilityLabel() throws Exception{
			assertEquals("Irritability", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Irritability drop down.
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdown() throws Exception{
			Thread.sleep(1000);
			click_IrritabilityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Irritability category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyIrritabilitySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-9']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Irritability Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdownSelectAnOptionValue() throws Exception{
			click_IrritabilityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Irritability category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Irritability 0 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdown0Value() throws Exception{
			click_IrritabilityDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Irritability category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Irritability 1 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdown1Value() throws Exception{
			click_IrritabilityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Irritability category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Irritability 2 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdown2Value() throws Exception{
			click_IrritabilityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Irritability category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Irritability 3 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdown3Value() throws Exception{
			click_IrritabilityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify Irritability category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Irritability 3 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilityDropdown4Value() throws Exception{
			click_IrritabilityDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//Irritability Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on IrritabilitySeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilitySeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_IrritabilitySeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify IrritabilitySeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyIrritabilitySeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-9']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on IrritabilitySeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilitySeverityDropdownSelectAnOptionValue() throws Exception{
			click_IrritabilitySeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IrritabilitySeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IrritabilitySeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilitySeverityDropdown1Value() throws Exception{
			click_IrritabilitySeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IrritabilitySeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on IrritabilitySeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilitySeverityDropdown2Value() throws Exception{
			click_IrritabilitySeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify IrritabilitySeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyIrritabilitySeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[10]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on IrritabilitySeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_IrritabilitySeverityDropdown3Value() throws Exception{
			click_IrritabilitySeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
//Odd movements Section Methods ======================================================================================================
		 /**
		 * This method is used to verify OddMovements Label
		 */
		public CaregiverBehaviorDetailsPage verifyOddMovementsLabel() throws Exception{
			assertEquals("Odd movements", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on OddMovements drop down.
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdown() throws Exception{
			Thread.sleep(1000);
			click_OddMovementsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify OddMovements category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyOddMovementsSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-10']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on OddMovements Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdownSelectAnOptionValue() throws Exception{
			click_OddMovementsDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify OddMovements category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on OddMovements 0 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdown0Value() throws Exception{
			click_OddMovementsDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify OddMovements category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on OddMovements 1 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdown1Value() throws Exception{
			click_OddMovementsDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify OddMovements category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on OddMovements 2 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdown2Value() throws Exception{
			click_OddMovementsDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify OddMovements category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on OddMovements 3 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdown3Value() throws Exception{
			click_OddMovementsDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify OddMovements category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on OddMovements 3 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsDropdown4Value() throws Exception{
			click_OddMovementsDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//OddMovements Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on OddMovementsSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_OddMovementsSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify OddMovementsSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyOddMovementsSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-10']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on OddMovementsSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsSeverityDropdownSelectAnOptionValue() throws Exception{
			click_OddMovementsSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify OddMovementsSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on OddMovementsSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsSeverityDropdown1Value() throws Exception{
			click_OddMovementsSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify OddMovementsSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on OddMovementsSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsSeverityDropdown2Value() throws Exception{
			click_OddMovementsSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify OddMovementsSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyOddMovementsSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[11]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on OddMovementsSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_OddMovementsSeverityDropdown3Value() throws Exception{
			click_OddMovementsSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}

//Sleep and nighttime behaviors Section Methods ======================================================================================================
		 /**
		 * This method is used to verify SleepAndNighttimeBehaviors Label
		 */
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsLabel() throws Exception{
			assertEquals("Sleep and nighttime behaviors", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors drop down.
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdown() throws Exception{
			Thread.sleep(1000);
			click_SleepAndNighttimeBehaviorsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify SleepAndNighttimeBehaviors category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-11']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdownSelectAnOptionValue() throws Exception{
			click_SleepAndNighttimeBehaviorsDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviors category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors 0 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdown0Value() throws Exception{
			click_SleepAndNighttimeBehaviorsDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviors category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors 1 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdown1Value() throws Exception{
			click_SleepAndNighttimeBehaviorsDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviors category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors 2 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdown2Value() throws Exception{
			click_SleepAndNighttimeBehaviorsDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviors category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors 3 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdown3Value() throws Exception{
			click_SleepAndNighttimeBehaviorsDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify SleepAndNighttimeBehaviors category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviors 3 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsDropdown4Value() throws Exception{
			click_SleepAndNighttimeBehaviorsDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//SleepAndNighttimeBehaviors Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviorsSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_SleepAndNighttimeBehaviorsSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify SleepAndNighttimeBehaviorsSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-11']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviorsSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsSeverityDropdownSelectAnOptionValue() throws Exception{
			click_SleepAndNighttimeBehaviorsSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviorsSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviorsSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsSeverityDropdown1Value() throws Exception{
			click_SleepAndNighttimeBehaviorsSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviorsSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviorsSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsSeverityDropdown2Value() throws Exception{
			click_SleepAndNighttimeBehaviorsSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SleepAndNighttimeBehaviorsSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifySleepAndNighttimeBehaviorsSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[12]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on SleepAndNighttimeBehaviorsSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_SleepAndNighttimeBehaviorsSeverityDropdown3Value() throws Exception{
			click_SleepAndNighttimeBehaviorsSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	

//Appetite and eating disorders Section Methods ======================================================================================================
		 /**
		 * This method is used to verify AppetiteAndEatingDisorders Label
		 */
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersLabel() throws Exception{
			assertEquals("Appetite and eating disorders", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[1]/label")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders drop down.
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdown() throws Exception{
			Thread.sleep(1000);
			click_AppetiteAndEatingDisordersDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify AppetiteAndEatingDisorders category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='frequency-dropdown-12']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdownSelectAnOptionValue() throws Exception{
			click_AppetiteAndEatingDisordersDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify AppetiteAndEatingDisorders category 0 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSelection0() throws Exception{
			assertEquals("0 - Never", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders 0 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdown0Value() throws Exception{
			click_AppetiteAndEatingDisordersDropdown0Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AppetiteAndEatingDisorders category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Less than once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders 1 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdown1Value() throws Exception{
			click_AppetiteAndEatingDisordersDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AppetiteAndEatingDisorders category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSelection2() throws Exception{
			assertEquals("2 - About once a week", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders 2 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdown2Value() throws Exception{
			click_AppetiteAndEatingDisordersDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AppetiteAndEatingDisorders category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSelection3() throws Exception{
			assertEquals("3 - More than once a week but not daily", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[5]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdown3Value() throws Exception{
			click_AppetiteAndEatingDisordersDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
	    
		/**
		* This method is used to verify AppetiteAndEatingDisorders category 4 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSelection4Value() throws Exception{
			assertEquals("4 - Daily/continuous", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[2]/div/ul/li[6]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AppetiteAndEatingDisorders 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersDropdown4Value() throws Exception{
			click_AppetiteAndEatingDisordersDropdown4Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
//AppetiteAndEatingDisorders Severity Section Methods ======================================================================================================
	
		 /**
		 * This method is used to click on AppetiteAndEatingDisordersSeverity drop down.
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersSeverityDropdown() throws Exception{
			Thread.sleep(1000);
			click_AppetiteAndEatingDisordersSeverityDropdown.click();
			Thread.sleep(1000);
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify AppetiteAndEatingDisordersSeverity category Select an option drop down value
	    */
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSeveritySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='severity-dropdown-12']")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on AppetiteAndEatingDisordersSeverity Select an option drop value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersSeverityDropdownSelectAnOptionValue() throws Exception{
			click_AppetiteAndEatingDisordersSeverityDropdownSelectAnOptionValue.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AppetiteAndEatingDisordersSeverity category 1 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSeveritySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: minimal stress", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[2]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AppetiteAndEatingDisordersSeverity 1 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersSeverityDropdown1Value() throws Exception{
			click_AppetiteAndEatingDisordersSeverityDropdown1Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AppetiteAndEatingDisordersSeverity category 2 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSeveritySelection2() throws Exception{
			assertEquals("2 - Moderate: disturbing but can redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[3]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on AppetiteAndEatingDisordersSeverity 2 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersSeverityDropdown2Value() throws Exception{
			click_AppetiteAndEatingDisordersSeverityDropdown2Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		/**
		* This method is used to verify AppetiteAndEatingDisordersSeverity category 3 value
		*/
		public CaregiverBehaviorDetailsPage verifyAppetiteAndEatingDisordersSeveritySelection3() throws Exception{
			assertEquals("3 - Severe: very disturbing/difficult to redirect", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[13]/div[3]/div/ul/li[4]/a")).getText());
			return new CaregiverBehaviorDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on AppetiteAndEatingDisordersSeverity 3 value
		 */
		public CaregiverBehaviorDetailsPage click_AppetiteAndEatingDisordersSeverityDropdown3Value() throws Exception{
			click_AppetiteAndEatingDisordersSeverityDropdown3Value.click();
			return new CaregiverBehaviorDetailsPage(driver);
		}
		
		
//Buttons Section ===================================================================================================================	
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverBehaviorDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverBehaviorDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverBehaviorDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverBehaviorDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverBehaviorDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverBehaviorDetailsPage click_ContinueButton() throws Exception{
	    	click_ContinueButton.click();
	    	return new CaregiverBehaviorDetailsPage(driver);
	    }
	    
  //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverBehaviorDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverBehaviorDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverBehaviorDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverBehaviorDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverBehaviorDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverBehaviorDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverBehaviorDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverBehaviorDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverBehaviorDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverBehaviorDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverBehaviorDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverBehaviorDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverBehaviorDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverBehaviorDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverBehaviorDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverBehaviorDetailsPage(driver);
  		}
}

