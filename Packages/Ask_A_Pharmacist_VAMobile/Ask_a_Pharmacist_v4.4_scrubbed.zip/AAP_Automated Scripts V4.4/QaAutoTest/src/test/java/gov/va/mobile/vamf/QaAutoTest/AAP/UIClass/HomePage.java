package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;
import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Verify;

public class HomePage {
	
	public static WebDriver driver;
	
	// WebElements on Home Page
	
	@FindBy(how = How.LINK_TEXT, using = "Home")
	public WebElement tabHome;
	
	// WebElements for My Health Vet Pharmacy Services
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
	public WebElement click_myHealthVetPharmacyServices;
	
	// WebElements for My Health Vet Pharmacy Services Under Feature
	@FindBy(how = How.XPATH, using = "//*[@id='aap-navbar']/ul[2]/li[2]/ul/li[1]/a")
	public WebElement click_myHealthVetPharmacyServicesUnderFeature;

	// WebElements for My Health Vet Pharmacy Services icon
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a")
	public WebElement click_myHealthVetPharmacyServicesicon;
	
	// WebElement for VA Trusted Medication Resources icon
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-link']/div/div[3]/a/img")
	public WebElement click_trustedMedicationResourcesicon;
	
	// WebElement for VA Trusted Medication Resources
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
	public WebElement click_trustedMedicationResources;

	// WebElement for VA Trusted Medication Resources under Feature
	@FindBy(how = How.XPATH, using  = ".//*[@id='aap-navbar']/ul[2]/li[2]/ul/li[3]/a")
	public WebElement click_trustedMedicationResourcesUnderFeature;
	
	// WebElement for Send a Secure Message icon
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-link']/div/div[5]/a/img")
	public WebElement click_secureMessageicon;
	
	// WebElement for Send a Secure Message 
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-link']/div/div[5]/a/span/span[1]")
	public WebElement click_secureMessage;
	
	// WebElement for Send a Secure Message Under Feature 
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-navbar']/ul[2]/li[2]/ul/li[5]/a")
	public WebElement click_secureMessageUnderFeature;
	
	// WebElements for pill Bottle Information 
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
	public WebElement click_pillBottleInformation;
	
	// WebElements for pill Bottle Information Under Feature
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-navbar']/ul[2]/li[2]/ul/li[2]/a")
	public WebElement click_pillBottleInformationUnderFeature;
	
	// WebElements for pill Bottle Information icon
	@FindBy(how = How.XPATH, using  = "//*[@id='aap-link']/div/div[2]/a/img")
	public WebElement click_pillBottleInformationicon;
	
	// WebElements for about VA Pharmacies 
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
	public WebElement click_aboutVAPharmacies;
	
	// WebElements for about VA Pharmacies Under Feature
	@FindBy(how = How.XPATH, using = "//*[@id='aap-navbar']/ul[2]/li[2]/ul/li[4]/a")
	public WebElement click_aboutVAPharmaciesUnderFeature;
	
	// WebElements for about VA Pharmacies Under icon
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/img")
	public WebElement click_aboutVAPharmaciesicon;
	
	// WebElements for VA Health Logo 
	@FindBy(how = How.XPATH, using = "//*[@id='bannerContainer']/div/div/div/img")
	public WebElement click_VAHealthLogo;
	
	// WebElements Ask a Pharmacist Heading
	@FindBy(how = How.XPATH, using = "//*[@id='aap-nav']/nav/div/div[1]/a")
	public WebElement click_AskAPharmacistHeading;
	
	// WebElements for Home link.
	@FindBy(how = How.XPATH, using = "//*[@id='aap-navbar']/ul[2]/li[1]/a")
	public WebElement click_HomeLink;
	
	// WebElements for Feature link.
	@FindBy(how = How.XPATH, using = "//*[@id='aap-navbar']/ul[2]/li[2]/a")
	public WebElement click_FeatureLink;

	// WebElements for About link.
	@FindBy(how = How.XPATH, using = "//*[@id='aap-navbar']/ul[2]/li[3]/a")
	public WebElement click_AboutLink;
	
	// WebElements for Help link.
	@FindBy(how = How.XPATH, using = "//*[@id='aap-navbar']/ul[2]/li[4]/a")
	public WebElement click_HelpLink;
	
	public HomePage(WebDriver driver){
		HomePage.driver = driver;
	}
	
	/**
	 * This method is used to Click on Home Tab
	 * @author MBabalola
	 */
	public HomePage clickHomeTab() throws Exception{
		Thread.sleep(3000);
		tabHome.click();
		return new HomePage(driver);
	}
	/**
	 * This method is used to Click on My Health Vet Pharmacy Services
	 * @author MBabalola
	 */
	public MyHealthVetPharmacyServicesPage myHealthVetPharmacyServices() throws Exception{
		Thread.sleep(10000);
		//WebDriverWait wait = new WebDriverWait(driver, 20);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='aap-link']/div/div[1]/a/span[1]")));
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='aap-link']/div/div[1]/a/span[1]")));
		click_myHealthVetPharmacyServices.click();
		Thread.sleep(4000);
		return new MyHealthVetPharmacyServicesPage(driver);
	}
		
	/**
	 * This method is used to Click on My Health Vet Pharmacy Services under Feature
	 */
	public LandingPage myHealthVetPharmacyServicesUnderFeature() throws Exception{
		click_myHealthVetPharmacyServicesUnderFeature.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on My Health Vet Pharmacy icon
	 */
	public LandingPage click_myHealthVetPharmacyServicesicon() throws Exception{
		click_myHealthVetPharmacyServicesicon.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on Trusted Medication Resources icon

	 */
	public LandingPage trustedMedicationResourcesicon() throws Exception{
		click_trustedMedicationResourcesicon.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on Trusted Medication Resources
	 * @author MBabalola
	 */
	public LandingPage trustedMedicationResources() throws Exception{
		click_trustedMedicationResources.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
		
	}
	
	/**
	 * This method is used to Click on Trusted Medication Resources Under Feature
	 */
	public LandingPage trustedMedicationResourcesUnderFeature() throws Exception{
		click_trustedMedicationResourcesUnderFeature.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
		
	}

	/**
	 * This method is used to Click on Send Secure Message
	 * @author MBabalola
	 */
	public LandingPage sendSecureMessage() throws Exception{
		click_secureMessage.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on Send Secure Message Under Feature
	 */
	public LandingPage sendSecureMessageUnderFeature() throws Exception{
		click_secureMessageUnderFeature.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on Send Secure Message icon
	 */
	public HomePage sendsecureMessageicon() throws Exception{
		click_secureMessageicon.click();
		Thread.sleep(4000);
		return new HomePage(driver);
	}
	/**
	 * This method is used to verify link URL for Send Secure Message icon - mhvHome
	 */
	public HomePage verify_ViewingYourVAMedicationNamesurl() throws Exception{
	    Thread.sleep(5000);
		assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_pageLabel=mhvHome", driver.getCurrentUrl());
		return new HomePage(driver);
	}	
	
	/**
	 * This method is used to verify link URL for Send Secure Message icon - mhvHome
	 */
	public HomePage verify_MHVHomeurl() throws Exception{
	    Thread.sleep(5000);
		//assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_pageLabel=mhvHome", driver.getCurrentUrl());
		return new HomePage(driver);
	}	
	
	
	/**
	 * This method is used to Click on Pill Bottle Information
	 * @author MBabalola
	 */
	public PillBottleInformationPage clickPillBottleInformation() throws Exception{
		Thread.sleep(3000);
		click_pillBottleInformation.click();
		Thread.sleep(3000);
		return new PillBottleInformationPage(driver);
	}
	
	/**
	 * This method is used to Click on Pill Bottle Information icon
	 */
	public PillBottleInformationPage clickPillBottleInformationicon() throws Exception{
		Thread.sleep(3000);
		click_pillBottleInformationicon.click();
		Thread.sleep(3000);
		return new PillBottleInformationPage(driver);
	}
	
	/**
	 * This method is used to Click on Pill Bottle Information Under Feature
	 */
	public LandingPage pillBottleInformationUnderFeature() throws Exception{
		click_pillBottleInformationUnderFeature.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on About VA Pharmacies
	 * @author MBabalola
	 */
	public LandingPage aboutVAPharmacies() throws Exception{
		click_aboutVAPharmacies.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on About VA Pharmacies Under Feature
	 */
	public LandingPage aboutVAPharmaciesUnderFeature() throws Exception{
		click_aboutVAPharmaciesUnderFeature.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}	
	
	/**
	 * This method is used to Click on About VA Pharmacies icon
	 */
	public LandingPage aboutVAPharmaciesicon() throws Exception{
		click_aboutVAPharmaciesicon.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}	
	
	
	/**
	 * This method is used to verify Continue button.
	 */
	public HomePage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(5000);
		return new HomePage(driver); 
	}
	
	/**
	 * This method is used to verify Accept button on Eula
	 */
	public HomePage verifyEULAAcceptButton() throws Exception {
		//driver.findElement(By.xpath("//*[@id='eula-modal']/div/div/div[3]/button")).getText();
		//assertEquals("Accept", driver.findElement(By.xpath("//*[@id='eula-modal']/div/div/div[3]/button")).getText());
	    //driver.findElement(By.id("aapLeave")).click();
		driver.findElement(By.xpath("//*[@id='eula-modal']/div/div/div[3]/button")).click();
	    Thread.sleep(5000);
		return new HomePage(driver); 
	}
	
	/**
	 * This method is used to verify VA Logo on Landing Page.
	 */
	public LandingPage verifyHomeElements() throws Exception{
		System.out.println("Checking verify VALogo class");
		WebDriver driver = null;
		WebElement element;
		click_VAHealthLogo.click();
		click_AskAPharmacistHeading.click();
		click_AskAPharmacistHeading.isDisplayed();
		click_AskAPharmacistHeading.getText();
		//Assert.assertTrue((("click_AskAPharmacistHeading") driver).getText());
		//System.out.println("Heading text is: " + driver.;);
		WebElement element1 = driver.findElement(By.className("img-responsive"));
		Assert.assertTrue(driver.getTitle().contains("s"));
		element1.isDisplayed();
        element1.getLocation();
        driver.getTitle();
        System.out.println("Page title is: " + driver.getTitle());
        //System.out.println("Page Location is: " + ((WebElement) driver).getLocation());
		return new LandingPage(driver);
	}

	public HelpPage click_HelpLink() throws InterruptedException {
		click_HelpLink.click();
		Thread.sleep(5000);
		tabHome.click();
		return new HelpPage(driver);
		
	}

	public AboutPage click_AboutLink() throws InterruptedException {
		click_AboutLink.click();
		Thread.sleep(3000);
		tabHome.click();
		return new AboutPage(driver);
		
	}
	
	public HomePage verifyHomePage() throws InterruptedException{
		 Assert.assertEquals("AAP", driver.getTitle());
		 return new HomePage(driver);
	}
	
	public HomePage verifyPillBottleInformationLink() throws InterruptedException{
		 	driver.findElement(By.linkText("Features")).click();
		    driver.findElement(By.xpath("(//a[contains(text(),'Pill and Bottle Information')])[2]")).click();
		    driver.findElement(By.cssSelector("body")).click();
		    driver.findElement(By.xpath("//section[@id='aap-link']/div/div[2]/a/span")).click();
		 Assert.assertEquals("Pill Bottle Information", driver.findElement(By.cssSelector("h1.page-heading")).getText());
		 return new HomePage(driver);
	}
	
	public PillBottleInformationPage clickFeatures() throws InterruptedException{
		driver.findElement(By.linkText("Features")).click();
		
		return new PillBottleInformationPage(driver);
	}
	
	
	
}