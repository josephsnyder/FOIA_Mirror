package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverCognitionDetailsPage {
private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
	public WebElement click_VAhealthlogo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']")
	public WebElement click_SignInButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
	public WebElement click_VABannerHeader; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_ResourceCenterButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='nav-dropdown']")
	public WebElement click_AssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = ".//*[@id='menu-list']/ul/li[1]/a")
	public WebElement click_CompleteStatusUpdateUnderAssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[1]/a")
	public WebElement click_viewStatusHistoryUnderAssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[4]")
	public WebElement click_AboutButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='help']")
	public WebElement click_HelpButtonLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement verifyStatusUpdateForTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p")
	public WebElement verifyStatusUpdateForBodyTet; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[1]")
	public WebElement verifyCategoryLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[3]")
	public WebElement verifyMarkedlyImprovedLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[4]")
	public WebElement verifyMuchImprovedLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[5]")
	public WebElement verifyMinimallyImprovedLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[6]")
	public WebElement verifyNoChangeLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[7]")
	public WebElement verifyMinimallyWorseLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[8]")
	public WebElement verifyMuchWorseLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[9]")
	public WebElement verifyMarkedlyWorseLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='secondaryAssessment']")
	public WebElement clickContinueButtonForSecondaryAssessment; 
	
	
	//=========================================================================================================================
	//Short-term memory Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Short-term memory']")
	public WebElement clickShortTermMemoryAnswerButtonSeven; 
	
	//=========================================================================================================================
	//Knows place and date Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Knows place and date']")
	public WebElement clickKnowsPlaceAndDateAnswerButtonSeven; 
	
//Speaking and comprehension Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Markedly Improved for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Much Improved for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Minimally Improved for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='No Change for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Minimally Worse for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Much Worse for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Markedly Worse for Speaking and comprehension']")
	public WebElement clickSpeakingAndComprehensionAnswerButtonSeven; 
	
	
	//Multitasking Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Multitasking']")
	public WebElement clickMultitaskingAnswerButtonSeven; 
	
	
	//Understanding where things are Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Understanding where things are']")
	public WebElement clickUnderstandingWhereThingsAreAnswerButtonSeven; 
	
	//Planning and execution of tasks Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Planning and execution of tasks']")
	public WebElement clickPlanningAndExecutionOfTasksAnswerButtonSeven;
	
	
	//Recognizing familiar people Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Recognizing familiar people']")
	public WebElement clickRecognizingFamiliarPeopleAnswerButtonSeven;
	
	// Buttons Sections
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']']")
	public WebElement click_CancelButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
	public WebElement click_ResetButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
	public WebElement click_ContinueButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='cancelModalMessage']/p")
	public WebElement click_CancelButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='secondaryAssessment']")
	public WebElement click_ResetButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='secondaryAssessment']")
	public WebElement click_ContinueButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='no']")
	public WebElement click_NoButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='yes']")
	public WebElement click_YesButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
	public WebElement click_ResetPopupMessageCloseIcon;
	
//=============================================================================================
	public CaregiverCognitionDetailsPage(WebDriver driver){
		CaregiverCognitionDetailsPage.driver = driver;
	}
	

// General Methods
	 /**
     * This method is used to verify Cognition Details Title
     */
    public CaregiverCognitionDetailsPage verifyCognitionDetailsTitle() throws Exception{
    	Thread.sleep(5000);
    	assertEquals("Cognition Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
    	return new CaregiverCognitionDetailsPage(driver);
    }
	
	 /**
     * This method is used to verify Cognition Details Text
     */
    public CaregiverCognitionDetailsPage verifyCognitionDetailsText() throws Exception{
    	Thread.sleep(3000);
    	assertEquals("The details provided here will help us to understand your father's current Cognition.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
    	return new CaregiverCognitionDetailsPage(driver);
    }

	 /**
	 * This method is used to verify Category Heading
	 */
	public CaregiverCognitionDetailsPage verifyCategoryHeading() throws Exception{
		assertEquals("Category", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[1]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
   
	 /**
	 * This method is used to verify Markedly Improved Heading
	 */
	public CaregiverCognitionDetailsPage verifyMarkedlyImprovedHeading() throws Exception{
		assertEquals("Markedly Improved", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[2]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
    
	 /**
	 * This method is used to verify Much Improved Heading
	 */
	public CaregiverCognitionDetailsPage verifyMuchImprovedHeading() throws Exception{
		assertEquals("Much Improved", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[3]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
	
	 /**
	 * This method is used to verify Minimally Improved Heading
	 */
	public CaregiverCognitionDetailsPage verifyMinimallyImprovedHeading() throws Exception{
		assertEquals("Minimally Improved", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[4]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
    
	 /**
	 * This method is used to verify No Change Heading
	 */
	public CaregiverCognitionDetailsPage verifyNoChangeHeading() throws Exception{
		assertEquals("No Change", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[5]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
    
	 /**
	 * This method is used to verify Minimally Worse Heading
	 */
	public CaregiverCognitionDetailsPage verifyMinimallyWorseHeading() throws Exception{
		assertEquals("Minimally Worse", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[6]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
    
	 /**
	 * This method is used to verify Much Worse Heading
	 */
	public CaregiverCognitionDetailsPage verifyMuchWorseHeading() throws Exception{
		assertEquals("Much Worse", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[7]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
    
	 /**
	 * This method is used to verify Markedly Worse Heading
	 */
	public CaregiverCognitionDetailsPage verifyMarkedlyWorseHeading() throws Exception{
		assertEquals("Markedly Worse", driver.findElement(By.xpath("//*[@id='cognitionTable']/thead/tr/th[8]")).getText());
		return new CaregiverCognitionDetailsPage(driver);
	}
	
// Short-term memory Section for selection==================================================================================================
	
		/**
		 * This method is used to verify ShortTermMemory Heading Label
		 */
		public CaregiverCognitionDetailsPage verifyShortTermMemoryLabel() throws Exception{
			assertEquals("Short-term memory", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[1]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on ShortTermMemory Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonOne() throws Exception{
			clickShortTermMemoryAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on ShortTermMemory Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonTwo() throws Exception{
		clickShortTermMemoryAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on ShortTermMemory Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonThree() throws Exception{
		clickShortTermMemoryAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on ShortTermMemory Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonFour() throws Exception{
		clickShortTermMemoryAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify ShortTermMemory Answer Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifyShortTermMemoryAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Short-term memory']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on ShortTermMemory Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonFive() throws Exception{
		clickShortTermMemoryAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on ShortTermMemory Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonSix() throws Exception{
		clickShortTermMemoryAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on ShortTermMemory Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickShortTermMemoryAnswerButtonSeven() throws Exception{
		clickShortTermMemoryAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}

// Knows place and date Section for selection==================================================================================================
	
		/**
		 * This method is used to verify KnowsPlaceAndDate Heading Label
		 */
		public CaregiverCognitionDetailsPage verifyKnowsPlaceAndDateLabel() throws Exception{
			assertEquals("Knows place and date", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[2]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on KnowsPlaceAndDate Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonOne() throws Exception{
			clickKnowsPlaceAndDateAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on KnowsPlaceAndDate Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonTwo() throws Exception{
		clickKnowsPlaceAndDateAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on KnowsPlaceAndDate Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonThree() throws Exception{
		clickKnowsPlaceAndDateAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on KnowsPlaceAndDate Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonFour() throws Exception{
		clickKnowsPlaceAndDateAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify KnowsPlaceAndDate Answer Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifyKnowsPlaceAndDateAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Knows place and date']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on KnowsPlaceAndDate Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonFive() throws Exception{
		clickKnowsPlaceAndDateAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on KnowsPlaceAndDate Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonSix() throws Exception{
		clickKnowsPlaceAndDateAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on KnowsPlaceAndDate Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickKnowsPlaceAndDateAnswerButtonSeven() throws Exception{
		clickKnowsPlaceAndDateAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
    
// Speaking and comprehension Section for selection==================================================================================================
	
		/**
		 * This method is used to verify SpeakingAndComprehension Heading Label
		 */
		public CaregiverCognitionDetailsPage verifySpeakingAndComprehensionLabel() throws Exception{
			assertEquals("Speaking and comprehension", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[3]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on SpeakingAndComprehension Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonOne() throws Exception{
			clickSpeakingAndComprehensionAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on SpeakingAndComprehension Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonTwo() throws Exception{
		clickSpeakingAndComprehensionAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on SpeakingAndComprehension Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonThree() throws Exception{
		clickSpeakingAndComprehensionAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on SpeakingAndComprehension Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonFour() throws Exception{
		clickSpeakingAndComprehensionAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify SpeakingAndComprehensionAnswer Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifySpeakingAndComprehensionAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Speaking and comprehension']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on SpeakingAndComprehension Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonFive() throws Exception{
		clickSpeakingAndComprehensionAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on SpeakingAndComprehension Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonSix() throws Exception{
		clickSpeakingAndComprehensionAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on SpeakingAndComprehension Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickSpeakingAndComprehensionAnswerButtonSeven() throws Exception{
		clickSpeakingAndComprehensionAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
// Multitasking Section for selection==================================================================================================
	
		/**
		 * This method is used to verify Multitasking Heading Label
		 */
		public CaregiverCognitionDetailsPage verifyMultitaskingLabel() throws Exception{
			assertEquals("Multitasking", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[4]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on Multitasking Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonOne() throws Exception{
			clickMultitaskingAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on Multitasking Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonTwo() throws Exception{
		clickMultitaskingAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on Multitasking Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonThree() throws Exception{
		clickMultitaskingAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on Multitasking Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonFour() throws Exception{
		clickMultitaskingAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Multitasking Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifyMultitaskingAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Multitasking']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on Multitasking Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonFive() throws Exception{
		clickMultitaskingAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on Multitasking Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonSix() throws Exception{
		clickMultitaskingAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on Multitasking Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickMultitaskingAnswerButtonSeven() throws Exception{
		clickMultitaskingAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
//Understanding where things are for selection==================================================================================================
	
		/**
		 * This method is used to verify UnderstandingWhereThingsAre Heading Label
		 */
		public CaregiverCognitionDetailsPage verifyUnderstandingWhereThingsAreLabel() throws Exception{
			assertEquals("Understanding where things are", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[5]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonOne() throws Exception{
			clickUnderstandingWhereThingsAreAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonTwo() throws Exception{
		clickUnderstandingWhereThingsAreAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonThree() throws Exception{
		clickUnderstandingWhereThingsAreAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonFour() throws Exception{
		clickUnderstandingWhereThingsAreAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify UnderstandingWhereThingsAre Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifyUnderstandingWhereThingsAreAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Understanding where things are']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonFive() throws Exception{
		clickUnderstandingWhereThingsAreAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonSix() throws Exception{
		clickUnderstandingWhereThingsAreAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on UnderstandingWhereThingsAre Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickUnderstandingWhereThingsAreAnswerButtonSeven() throws Exception{
		clickUnderstandingWhereThingsAreAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}

//Planning and execution of tasks for selection==================================================================================================
	
		/**
		 * This method is used to verify PlanningAndExecutionOfTasks Heading Label
		 */
		public CaregiverCognitionDetailsPage verifyPlanningAndExecutionOfTasksLabel() throws Exception{
			assertEquals("Planning and execution of tasks", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[6]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonOne() throws Exception{
			clickPlanningAndExecutionOfTasksAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonTwo() throws Exception{
		clickPlanningAndExecutionOfTasksAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonThree() throws Exception{
		clickPlanningAndExecutionOfTasksAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonFour() throws Exception{
		clickPlanningAndExecutionOfTasksAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PlanningAndExecutionOfTasks Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifyPlanningAndExecutionOfTasksAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Planning and execution of tasks']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonFive() throws Exception{
		clickPlanningAndExecutionOfTasksAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonSix() throws Exception{
		clickPlanningAndExecutionOfTasksAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on PlanningAndExecutionOfTasks Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickPlanningAndExecutionOfTasksAnswerButtonSeven() throws Exception{
		clickPlanningAndExecutionOfTasksAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}

//Recognizing familiar people for selection==================================================================================================
	
		/**
		 * This method is used to verify RecognizingFamiliarPeople Heading Label
		 */
		public CaregiverCognitionDetailsPage verifyRecognizingFamiliarPeopleLabel() throws Exception{
			assertEquals("Planning and execution of tasks", driver.findElement(By.xpath("//*[@id='cognitionTable']/tbody/tr[6]/td[1]/span")).getText());
				return new CaregiverCognitionDetailsPage(driver);
			}
			    
		  /**
		* This method is used to click on RecognizingFamiliarPeople Answer Button One
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonOne() throws Exception{
			clickRecognizingFamiliarPeopleAnswerButtonOne.click();
			return new CaregiverCognitionDetailsPage(driver);
		}
		    
		/**
		* This method is used to click on RecognizingFamiliarPeople Answer Button Two
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonTwo() throws Exception{
		clickRecognizingFamiliarPeopleAnswerButtonTwo.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on RecognizingFamiliarPeople Answer Button Three
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonThree() throws Exception{
		clickRecognizingFamiliarPeopleAnswerButtonThree.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on RecognizingFamiliarPeople Answer Button Four
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonFour() throws Exception{
		clickRecognizingFamiliarPeopleAnswerButtonFour.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to verify RecognizingFamiliarPeople Button Four is selected by default
		*/
		public CaregiverCognitionDetailsPage verifyRecognizingFamiliarPeopleAnswerButtonFour() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='No Change for Recognizing familiar people']")).isSelected());
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on RecognizingFamiliarPeople Answer Button Five
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonFive() throws Exception{
		clickRecognizingFamiliarPeopleAnswerButtonFive.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		/**
		* This method is used to click on RecognizingFamiliarPeople Answer Button Six
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonSix() throws Exception{
		clickRecognizingFamiliarPeopleAnswerButtonSix.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
		
		/**
		* This method is used to click on RecognizingFamiliarPeople Answer Button Seven
		*/
		public CaregiverCognitionDetailsPage clickRecognizingFamiliarPeopleAnswerButtonSeven() throws Exception{
		clickRecognizingFamiliarPeopleAnswerButtonSeven.click();
		return new CaregiverCognitionDetailsPage(driver);
		}
		
//===============================================================================================================================
//Buttons Section
	
	 
	 /**
     * This method is used to verify Cancel button.
     */
    public CaregiverCognitionDetailsPage verifyCancelButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	/**
     * This method is used to click on Cancel button.
     */
    public CaregiverCognitionDetailsPage click_CancelButton() throws Exception{
    	click_CancelButton.click();
    	return new CaregiverCognitionDetailsPage(driver);
    }

	 /**
     * This method is used to verify Cancel button on Popup message.
     */
    public CaregiverCognitionDetailsPage verifyCancelButtonOnPopup() throws Exception{
    	Thread.sleep(1000);
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='assessment-modal']/div/div/div[2]/button[1]")) !=null);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	/**
     * This method is used to click on Cancel button on Popup message.
     */
    public CaregiverCognitionDetailsPage click_CancelButtonOnPopup() throws Exception{
    	Thread.sleep(1000);
    	click_CancelButtonOnPopup.click();
    	Thread.sleep(1000);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	 /**
     * This method is used to verify Continue button on Popup message.
     */
    public CaregiverCognitionDetailsPage verifyContinueButtonOnPopup() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='secondaryAssessment']")) !=null);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	/**
     * This method is used to click on Continue button on Popup message.
     */
    public CaregiverCognitionDetailsPage click_ContinueButtonOnPopup() throws Exception{
    	Thread.sleep(1000);
    	click_ContinueButtonOnPopup.click();
    	Thread.sleep(1000);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	 /**
     * This method is used to verify Reset button.
     */
    public CaregiverCognitionDetailsPage verifyResetButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	 /**
     * This method is used to click on Reset button.
     */
    public CaregiverCognitionDetailsPage click_ResetButton() throws Exception{
    	click_ResetButton.click();
    	return new CaregiverCognitionDetailsPage(driver);
    }

	 /**
     * This method is used to verify Reset Popup button.
     */
    public CaregiverCognitionDetailsPage verifyResetPopButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_statusSubmit']")) !=null);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	 /**
     * This method is used to verify Continue button.
     */
    public CaregiverCognitionDetailsPage verifyContinueButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
	 /**
     * This method is used to click on Continue button.
     */
    public CaregiverCognitionDetailsPage click_ContinueButton() throws Exception{
    	click_ContinueButton.click();
    	return new CaregiverCognitionDetailsPage(driver);
    }
    
  //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverCognitionDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverCognitionDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverCognitionDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverCognitionDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverCognitionDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverCognitionDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverCognitionDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverCognitionDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverCognitionDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverCognitionDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverCognitionDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverCognitionDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverCognitionDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverCognitionDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverCognitionDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverCognitionDetailsPage(driver);
  		}
    
}
