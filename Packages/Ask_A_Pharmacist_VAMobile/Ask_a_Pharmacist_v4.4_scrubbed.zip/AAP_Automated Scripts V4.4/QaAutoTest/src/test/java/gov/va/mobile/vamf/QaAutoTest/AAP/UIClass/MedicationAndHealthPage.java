package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MedicationAndHealthPage {
	
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Medication and Health Page
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div/a/span[1]/span[1]")
	public WebElement click_VeteranHealthLibrary;
	
	public MedicationAndHealthPage(WebDriver driver){
		MedicationAndHealthPage.driver = driver;
	}
	
    /**
     * This method is used to Click on Veteran Health Library link
     */
    public MedicationAndHealthPage click_VeteranHealthLibrary() throws Exception{
    	click_VeteranHealthLibrary.click();
    	return new MedicationAndHealthPage(driver);
    }
    
    
	public MedicationAndHealthPage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(3000);
		return new MedicationAndHealthPage(driver); 
	}
	
	public MedicationAndHealthPage verifyDVAVeteranHealthLibraryurl() throws Exception{
		Thread.sleep(5000);
		assertEquals("http://www.veteranshealthlibrary.org/MedicationsVA/", driver.getCurrentUrl());
		return new MedicationAndHealthPage(driver);
	}
    

}
