package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverAboutPage {
private static WebDriver driver;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-label']")
	public WebElement verifyAboutTitle; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[1]/div[1]/label")
	public WebElement verifyApplicationNameLable; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[2]/div[1]/label")
	public WebElement verifyVersionNumberLable;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[3]/div[1]/label")
	public WebElement verifyDevelopedBYLable;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[2]/div[4]/div[1]/label")
	public WebElement verifyNationalReleaseDateLable;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-last']/div[1]/label")
	public WebElement verifyAppDescriptionLable;
	
	@FindBy(how = How.XPATH, using = "//*[@id='about-modal']/div/div/div[3]/button")
	public WebElement click_CaretiverAboutCloseButton;
	
	public CaregiverAboutPage(WebDriver driver){
		CaregiverAboutPage.driver = driver;
	}

	 /**
     * This method is used to verify About Label.
     */
    public CaregiverAboutPage verifyAboutLable() throws Exception{
    	assertEquals("About", driver.findElement(By.xpath("//*[@id='about-label']")).getText());
    	return new CaregiverAboutPage(driver);
    }
	
	 /**
     * This method is used to verify Application Name Label.
     */
    public CaregiverAboutPage verifyApplicationNameLable() throws Exception{
    	assertEquals("Application Name", driver.findElement(By.xpath("//*[@id='about-modal']/div/div/div[2]/div[1]/div[1]/label")).getText());
    	assertEquals("Dementia Care", driver.findElement(By.xpath("//*[@id='about-app-name']")).getText());
    	return new CaregiverAboutPage(driver);
    }
 
	 /**
     * This method is used to verify Versioning Number Label.
     */
    public CaregiverAboutPage verifyVersionNumberLable() throws Exception{
    	assertEquals("Version Number", driver.findElement(By.xpath("//*[@id='about-modal']/div/div/div[2]/div[2]/div[1]/label")).getText());
    	//assertEquals("15.0", driver.findElement(By.xpath("//*[@id='about-version']")).getText());
    	return new CaregiverAboutPage(driver);
    }
    
    
	 /**
     * This method is used to verify Developed By Label.
     */
    public CaregiverAboutPage verifyDevelopedByLable() throws Exception{
    	assertEquals("Developed By", driver.findElement(By.xpath("//*[@id='about-modal']/div/div/div[2]/div[3]/div[1]/label")).getText());
    	return new CaregiverAboutPage(driver);
    }
    
	 /**
     * This method is used to verify National Release Date Label.
     */
    public CaregiverAboutPage verifyNationalReleaseDateLable() throws Exception{
    	assertEquals("National Release Date", driver.findElement(By.xpath("//*[@id='about-modal']/div/div/div[2]/div[4]/div[1]/label")).getText());
    	assertEquals("2015", driver.findElement(By.xpath("//*[@id='about-date']")).getText());
    	return new CaregiverAboutPage(driver);
    }
    
	 /**
     * This method is used to verify App Description Label.
     */
    public CaregiverAboutPage verifyAppDescriptionLable() throws Exception{
    	assertEquals("App Description", driver.findElement(By.xpath("//*[@id='about-last']/div[1]/label")).getText());
    	assertEquals("The Dementia Care application provides the functionality to connect caregivers and the families of Veterans suffering from dementias to providers, educational materials, and to one another.", driver.findElement(By.xpath("//*[@id='about-desc']")).getText());
    	return new CaregiverAboutPage(driver);
    }
    
   
	 /**
     * This method is used to click on Close button.
     */
    public CaregiverSignInPopupPage click_CaretiverAboutCloseButton() throws Exception{
    	click_CaretiverAboutCloseButton.click();
    	return new CaregiverSignInPopupPage(driver);
    }
    


}

