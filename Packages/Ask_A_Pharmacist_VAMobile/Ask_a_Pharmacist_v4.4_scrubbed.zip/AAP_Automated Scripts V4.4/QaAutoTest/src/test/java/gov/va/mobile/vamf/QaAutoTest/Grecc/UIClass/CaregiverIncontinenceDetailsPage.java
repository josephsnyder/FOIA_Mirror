package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverIncontinenceDetailsPage {
private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement verifyIncontinenceDetailsTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[1]")
	public WebElement verifyIncontinenceDetailsText;
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[2]/em")
	public WebElement verifyIncontinenceDetailsText2;
	
	@FindBy(how = How.XPATH, using = "//*[@id='no']")
	public WebElement click_NoButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='yes']")
	public WebElement click_YesButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
	public WebElement click_ResetPopupMessageCloseIcon;

//Incontinence Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")
		public WebElement click_FecalIncontinenceCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")
		public WebElement click_UrinaryIncontinenceCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")
		public WebElement click_ConstipationCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")
		public WebElement click_InappropriateUrinationCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")
		public WebElement click_PainDuringUrinationCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")
		public WebElement click_RemovesSoiledClothingCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label/input")
		public WebElement click_ResistsAssistanceCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[8]/div/label/input")
		public WebElement click_PoorToiletingHygieneCheckbox; 
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
//==========================================================================================================================
		public CaregiverIncontinenceDetailsPage(WebDriver driver){
			CaregiverIncontinenceDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Incontinence Details Title
	     */
	    public CaregiverIncontinenceDetailsPage verifyIncontinenceDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Incontinence Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Incontinence Details Text
	     */
	    public CaregiverIncontinenceDetailsPage verifyIncontinenceDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Incontinence. Check all that apply.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
	    
//Incontinence Methods ======================================================================================================
		 
	    /**
		 * This method is used to verify FecalIncontinence Label
		 */
		public CaregiverIncontinenceDetailsPage verifyFecalIncontinenceLabel() throws Exception{
			assertEquals("Fecal incontinence", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on FecalIncontinence Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_FecalIncontinenceCheckbox() throws Exception{
			click_FecalIncontinenceCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Fecal Incontinence Checkbox is unchcked.
		 */
		public CaregiverIncontinenceDetailsPage verifyFecalIncontinenceCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify UrinaryIncontinence Label
		 */
		public CaregiverIncontinenceDetailsPage verifyUrinaryIncontinenceLabel() throws Exception{
			assertEquals("Urinary incontinence", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on UrinaryIncontinence Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_UrinaryIncontinenceCheckbox() throws Exception{
			click_UrinaryIncontinenceCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify Urinary incontinence  Checkbox is unchcked.
		 */
		public CaregiverIncontinenceDetailsPage verifyUrinaryIncontinenceCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify Constipation Label
		 */
		public CaregiverIncontinenceDetailsPage verifyConstipationLabel() throws Exception{
			assertEquals("Constipation", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Constipation Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_ConstipationCheckbox() throws Exception{
			click_ConstipationCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}

	    /**
		 * This method is used to verify Constipation  Checkbox is unchcked.
		 */
		public CaregiverIncontinenceDetailsPage verifyConstipationCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify InappropriateUrination Label
		 */
		public CaregiverIncontinenceDetailsPage verifyInappropriateUrinationLabel() throws Exception{
			assertEquals("Inappropriate urination", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on InappropriateUrination Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_InappropriateUrinationCheckbox() throws Exception{
			click_InappropriateUrinationCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Inappropriate Urination Checkbox is unchcked.
		 */
		public CaregiverIncontinenceDetailsPage verifyInappropriateUrinationCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
			
	    /**
		 * This method is used to verify PainDuringUrination Label
		 */
		public CaregiverIncontinenceDetailsPage verifyPainDuringUrinationLabel() throws Exception{
			assertEquals("Pain during urination", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on PainDuringUrination Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_PainDuringUrinationCheckbox() throws Exception{
			click_PainDuringUrinationCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Pain During Urination Checkbox is unchcked.
		 */
		public CaregiverIncontinenceDetailsPage verifyPainDuringUrinationCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify RemovesSoiledClothing Label
		 */
		public CaregiverIncontinenceDetailsPage verifyRemovesSoiledClothingLabel() throws Exception{
			assertEquals("Removes soiled clothing", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on RemovesSoiledClothing Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_RemovesSoiledClothingCheckbox() throws Exception{
			click_RemovesSoiledClothingCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Pain Removes Soiled Clothing Checkbox is unchcked.
		 */
		public CaregiverIncontinenceDetailsPage verifyRemovesSoiledClothingCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
			
	    /**
		 * This method is used to verify ResistsAssistance Label
		 */
		public CaregiverIncontinenceDetailsPage verifyResistsAssistanceLabel() throws Exception{
			assertEquals("Resists assistance", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on ResistsAssistance Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_ResistsAssistanceCheckbox() throws Exception{
			click_ResistsAssistanceCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
			 * This method is used to verify Resists Assistance Checkbox is unchcked.
			 */
		public CaregiverIncontinenceDetailsPage verifyResistsAssistanceCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}

	    /**
		 * This method is used to verify PoorToiletingHygiene  Label
		 */
		public CaregiverIncontinenceDetailsPage verifyPoorToiletingHygieneLabel() throws Exception{
			assertEquals("Poor toileting/hygiene", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[8]/div/label")).getText());
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on PoorToiletingHygiene Checkbox.
		 */
		public CaregiverIncontinenceDetailsPage click_PoorToiletingHygieneCheckbox() throws Exception{
			click_PoorToiletingHygieneCheckbox.click();
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
	    /**
			 * This method is used to verify Poor Toileting Hygienee Checkbox is unchcked.
			 */
		public CaregiverIncontinenceDetailsPage verifyPoorToiletingHygieneCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[8]/div/label/input")).getAttribute("value"));
			return new CaregiverIncontinenceDetailsPage(driver);
		}
		
//Buttons Section ===================================================================================================================
		
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverIncontinenceDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverIncontinenceDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverIncontinenceDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverIncontinenceDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverIncontinenceDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverIncontinenceDetailsPage click_ContinueButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverIncontinenceDetailsPage(driver);
	    }
	    
  //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverIncontinenceDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverIncontinenceDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverIncontinenceDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverIncontinenceDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverIncontinenceDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  			click_YesButtonOnPopup.click();
  		return new CaregiverIncontinenceDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverIncontinenceDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverIncontinenceDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverIncontinenceDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverIncontinenceDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverIncontinenceDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  			click_YesButtonOnPopup.click();
  		return new CaregiverIncontinenceDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverIncontinenceDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverIncontinenceDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverIncontinenceDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  			driver.switchTo().alert();
  			click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverIncontinenceDetailsPage(driver);
  		}
  		
	    
}
