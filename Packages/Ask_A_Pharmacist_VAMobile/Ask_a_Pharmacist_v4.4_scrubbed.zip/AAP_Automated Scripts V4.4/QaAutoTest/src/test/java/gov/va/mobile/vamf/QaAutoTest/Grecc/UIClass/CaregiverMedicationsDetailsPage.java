package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverMedicationsDetailsPage {
private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement verifyMedicationsDetailsTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[1]")
	public WebElement verifyMedicationsDetailsText;
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[2]/em")
	public WebElement verifyMedicationsDetailsText2;

//Medication Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")
		public WebElement click_RefusesCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")
		public WebElement click_ChokesCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")
		public WebElement click_ResistiveCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")
		public WebElement click_SideEffectsCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")
		public WebElement click_ConfusesMedicationsCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")
		public WebElement click_ParanoidAboutMedicationsCheckbox; 
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverMedicationsDetailsPage(WebDriver driver){
			CaregiverMedicationsDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Medications Details Title
	     */
	    public CaregiverMedicationsDetailsPage verifyMedicationsDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Medications Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Medications Details Text
	     */
	    public CaregiverMedicationsDetailsPage verifyMedicationsDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Medications. Check all that apply.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }
	    
//Medications Methods ======================================================================================================
		 
	    /**
		 * This method is used to verify Refuses Label
		 */
		public CaregiverMedicationsDetailsPage verifyRefusesLabel() throws Exception{
			assertEquals("Refuses", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label")).getText());
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Refuses Checkbox.
		 */
		public CaregiverMedicationsDetailsPage click_RefusesCheckbox() throws Exception{
			click_RefusesCheckbox.click();
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Refuses Checkbox is unchcked.
		 */
		public CaregiverMedicationsDetailsPage verifyRefusesCheckboxUnchecked() throws Exception{
			//assertEquals("Refuses", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")).getText());
			//assertEquals("Refuses", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")).isSelected());
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")).getAttribute("value"));
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify Chokes Label
		 */
		public CaregiverMedicationsDetailsPage verifyChokesLabel() throws Exception{
			assertEquals("Chokes", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label")).getText());
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Chokes Checkbox.
		 */
		public CaregiverMedicationsDetailsPage click_ChokesCheckbox() throws Exception{
			click_ChokesCheckbox.click();
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Chokes Checkbox is unchcked.
		 */
		public CaregiverMedicationsDetailsPage verifyChokesCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")).getAttribute("value"));
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Resistive Label
		 */
		public CaregiverMedicationsDetailsPage verifyResistiveLabel() throws Exception{
			assertEquals("Resistive", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label")).getText());
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Resistive Checkbox.
		 */
		public CaregiverMedicationsDetailsPage click_ResistiveCheckbox() throws Exception{
			click_ResistiveCheckbox.click();
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Resistive Checkbox is unchcked.
		 */
		public CaregiverMedicationsDetailsPage verifyResistiveCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")).getAttribute("value"));
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify SideEffects Label
		 */
		public CaregiverMedicationsDetailsPage verifySideEffectsLabel() throws Exception{
			assertEquals("Side effects", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label")).getText());
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on SideEffects Checkbox.
		 */
		public CaregiverMedicationsDetailsPage click_SideEffectsCheckbox() throws Exception{
			click_SideEffectsCheckbox.click();
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Side Effects Checkbox is unchcked.
		 */
		public CaregiverMedicationsDetailsPage verifySideEffectsCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")).getAttribute("value"));
			return new CaregiverMedicationsDetailsPage(driver);
		}
			
	    /**
		 * This method is used to verify ConfusesMedications Label
		 */
		public CaregiverMedicationsDetailsPage verifyConfusesMedicationsLabel() throws Exception{
			assertEquals("Confuses medications", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label")).getText());
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Confuses Medications Checkbox.
		 */
		public CaregiverMedicationsDetailsPage click_ConfusesMedicationsCheckbox() throws Exception{
			click_ConfusesMedicationsCheckbox.click();
			return new CaregiverMedicationsDetailsPage(driver);
	}
		
	    /**
		 * This method is used to verify Confuses medications Checkbox is unchcked.
		 */
		public CaregiverMedicationsDetailsPage verifyConfusesMedicationsCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")).getAttribute("value"));
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify ParanoidAboutMedications Label
		 */
		public CaregiverMedicationsDetailsPage verifyParanoidAboutMedicationsLabel() throws Exception{
			assertEquals("Paranoid about medications", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label")).getText());
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on ParanoidAboutMedications Checkbox.
		 */
		public CaregiverMedicationsDetailsPage click_ParanoidAboutMedicationsCheckbox() throws Exception{
			click_ParanoidAboutMedicationsCheckbox.click();
			return new CaregiverMedicationsDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Paranoid About Medications Checkbox is unchcked.
		 */
		public CaregiverMedicationsDetailsPage verifyParanoidAboutMedicationsCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")).getAttribute("value"));
			return new CaregiverMedicationsDetailsPage(driver);
		}

//Buttons Section Methods ===================================================================================================================
		
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverMedicationsDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverMedicationsDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverMedicationsDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverMedicationsDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverMedicationsDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverMedicationsDetailsPage click_ContinueButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverMedicationsDetailsPage(driver);
	    }
	    
//Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverMedicationsDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverMedicationsDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverMedicationsDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverMedicationsDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverMedicationsDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverMedicationsDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverMedicationsDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverMedicationsDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverMedicationsDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverMedicationsDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverMedicationsDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverMedicationsDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverMedicationsDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverMedicationsDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverMedicationsDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverMedicationsDetailsPage(driver);
  		}
}
