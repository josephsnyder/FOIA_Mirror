package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.ConsumerDrugHerbalSupplementInformationPage;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverStatusUpdatePage {
	
private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-login']")
	public WebElement click_VAhealthlogo; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='login']")
	public WebElement click_SignInButton; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']")
	public WebElement click_VABannerHeader; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='home']")
	public WebElement click_HomeButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[3]")
	public WebElement click_ResourceCenterButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='nav-dropdown']")
	public WebElement click_AssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = ".//*[@id='menu-list']/ul/li[1]/a")
	public WebElement click_CompleteStatusUpdateUnderAssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/ul/li[1]/a")
	public WebElement click_viewStatusHistoryUnderAssessmentDropdown; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='menu-list']/a[4]")
	public WebElement click_AboutButtonLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='help']")
	public WebElement click_HelpButtonLink; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement verifyStatusUpdateForTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p")
	public WebElement verifyStatusUpdateForBodyTet; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[1]")
	public WebElement verifyCategoryLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[3]")
	public WebElement verifyMarkedlyImprovedLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[4]")
	public WebElement verifyMuchImprovedLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[5]")
	public WebElement verifyMinimallyImprovedLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[6]")
	public WebElement verifyNoChangeLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[7]")
	public WebElement verifyMinimallyWorseLabel; 
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[8]")
	public WebElement verifyMuchWorseLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/thead/tr/th[9]")
	public WebElement verifyMarkedlyWorseLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='secondaryAssessment']")
	public WebElement clickContinueButtonForSecondaryAssessment; 
	
	
	//=========================================================================================================================
	//Overall Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[1]/td[1]/span/span")
	public WebElement verifyOverallLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[1]/td[1]/span/a/img") //*[@id='statusUpdateTable']/tbody/tr[1]/td[1]/span/a/img
	public WebElement clickOverallInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[1]/td[2]/a/img")
	public WebElement clickOverallHistoryIconLink;  
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Overall Category']")
	public WebElement clickOverallAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Overall Category']")
	public WebElement clickOverallAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Overall Category']")
	public WebElement clickOverallAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Overall Category']")
	public WebElement clickOverallAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Overall Category']")
	public WebElement clickOverallAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Overall Category']")
	public WebElement clickOverallAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Overall Category']")
	public WebElement clickOverallAnswerButtonSeven; 
	
	//=========================================================================================================================
	//Cognition Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[2]/td[1]/span/span")
	public WebElement verifyCognitionLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[2]/td[1]/span/a/img")
	public WebElement clickCognitionInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[2]/td[2]/a/img")
	public WebElement clickCognitionHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Cognition Category']")
	public WebElement clickCognitionAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Cognition Category']")
	public WebElement clickCognitionAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Cognition Category']")
	public WebElement clickCognitionAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Cognition Category']")
	public WebElement clickCognitionAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Cognition Category']")
	public WebElement clickCognitionAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Cognition Category']")
	public WebElement clickCognitionAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Cognition Category']")
	public WebElement clickCognitionAnswerButtonSeven; 
	
	
	//Daily Function Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[3]/td[1]/span/span")
	public WebElement verifyDailyFunctionLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[3]/td[1]/span/a/img")
	public WebElement clickDailyFunctionInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[3]/td[2]/a/img")
	public WebElement clickDailyFunctionHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Markedly Improved for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Much Improved for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Minimally Improved for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='No Change for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Minimally Worse for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Much Worse for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons'and @aria-label='Markedly Worse for Daily Function Category']")
	public WebElement clickDailyFunctionAnswerButtonSeven; 
	
	
	//Behavior Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[4]/td[1]/span/span")
	public WebElement verifyBehaviorLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[4]/td[1]/span/a/img")
	public WebElement clickBehaviorInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[3]/td[2]/a/img")
	public WebElement clickBehaviorHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Behavior Category']")
	public WebElement clickBehaviorAnswerButtonSeven; 
	
	
	//Falls Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[5]/td[1]/span/span")
	public WebElement verifyFallsLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[5]/td[1]/span/a/img")
	public WebElement clickFallsInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[5]/td[2]/a/img")
	public WebElement clickFallsHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Falls Category']")
	public WebElement clickFallsAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Falls Category']")
	public WebElement clickFallsAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Falls Category']")
	public WebElement clickFallsAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Falls Category']")
	public WebElement clickFallsAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Falls Category']")
	public WebElement clickFallsAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Falls Category']")
	public WebElement clickFallsAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Falls Category']")
	public WebElement clickFallsAnswerButtonSeven; 
	
	//Medications Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[6]/td[1]/span/span")
	public WebElement verifyMedicationsLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[6]/td[1]/span/a/img")
	public WebElement clickMedicationsInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[6]/td[2]/a/img")
	public WebElement clickMedicationsHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Medications Category']")
	public WebElement clickMedicationsAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Medications Category']")
	public WebElement clickMedicationsAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Medications Category']")
	public WebElement clickMedicationsAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Medications Category']")
	public WebElement clickMedicationsAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Medications Category']")
	public WebElement clickMedicationsAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Medications Category']")
	public WebElement clickMedicationsAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Medications Category']")
	public WebElement clickMedicationsAnswerButtonSeven;
	
	
	//Sleep Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[6]/td[1]/span/span")
	public WebElement verifySleepLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[7]/td[1]/span/a/img")
	public WebElement clickSleepInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[6]/td[2]/a/img")
	public WebElement clickSleepHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Sleep Category']")
	public WebElement clickSleepAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Sleep Category']")
	public WebElement clickSleepAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Sleep Category']")
	public WebElement clickSleepAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Sleep Category']")
	public WebElement clickSleepAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Sleep Category']")
	public WebElement clickSleepAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Sleep Category']")
	public WebElement clickSleepAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Sleep Category']")
	public WebElement clickSleepAnswerButtonSeven;
	
	//Pain Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[8]/td[1]/span/span")
	public WebElement verifyPainLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[8]/td[1]/span/a/img")
	public WebElement clickPainInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[8]/td[2]/a/img")
	public WebElement clickPainHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Pain Category']")
	public WebElement clickPainAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Pain Category']")
	public WebElement clickPainAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Pain Category']")
	public WebElement clickPainAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Pain Category']")
	public WebElement clickPainAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Pain Category']")
	public WebElement clickPainAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Pain Category']")
	public WebElement clickPainAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Pain Category']")
	public WebElement clickPainAnswerButtonSeven;
	
	
	//Incontinence Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[9]/td[1]/span/span")
	public WebElement verifyIncontinenceLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[9]/td[1]/span/a/img")
	public WebElement clickIncontinenceInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[9]/td[2]/a/img")
	public WebElement clickIncontinenceHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Incontinence Category']")
	public WebElement clickIncontinenceAnswerButtonSeven;
	
	
	//Periods of Confusion Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[10]/td[1]/span/span")
	public WebElement verifyConfusionLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[10]/td[1]/span/a/img")
	public WebElement clickConfusionInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[10]/td[2]/a/img")
	public WebElement clickConfusionHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Confusion Category']")
	public WebElement clickConfusionAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Confusion Category']")
	public WebElement clickConfusionAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Confusion Category']")
	public WebElement clickConfusionAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Confusion Category']")
	public WebElement clickConfusionAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Confusion Category']")
	public WebElement clickConfusionAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Confusion Category']")
	public WebElement clickConfusionAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Confusion Category']")
	public WebElement clickConfusionAnswerButtonSeven;
	
	//Safety Section
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[11]/td[1]/span/span")
	public WebElement verifySafetyLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[11]/td[1]/span/a/img")
	public WebElement clickSafetyInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[11]/td[2]/a/img")
	public WebElement clickSafetyHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Safety Category']")
	public WebElement clickSafetyAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Safety Category']")
	public WebElement clickSafetyAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Safety Category']")
	public WebElement clickSafetyAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Safety Category']")
	public WebElement clickSafetyAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Safety Category']")
	public WebElement clickSafetyAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Safety Category']")
	public WebElement clickSafetyAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Safety Category']")
	public WebElement clickSafetyAnswerButtonSeven;
	
	//Caregiver Section
	
	@FindBy(how = How.XPATH, using = ".//*[@id='statusUpdateTable']/tbody/tr[12]/td[1]/span/span")
	public WebElement verifyCaregiverLabel; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='statusUpdateTable']/tbody/tr[12]/td[1]/span/a/img")
	public WebElement clickCaregiverInfoIconLink; 
	
	@FindBy(how = How.XPATH, using = ".//*[@id='statusUpdateTable']/tbody/tr[12]/td[2]/a/img")
	public WebElement clickCaregiverHistoryIconLink; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Improved for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonOne; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Improved for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Improved for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonThree;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='No Change for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonFour;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Minimally Worse for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonFive;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Much Worse for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonSix;
	
	@FindBy(how = How.XPATH, using = "//*[@id='answerButtons' and @aria-label='Markedly Worse for Caregiver Category']")
	public WebElement clickCaregiverAnswerButtonSeven;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn_statusCancel']")
	public WebElement click_CancelButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn_statusReset']")
	public WebElement click_ResetButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='btn_statusSubmit']")
	public WebElement click_SubmitButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/div/p")
	public WebElement click_ResetPopupCloseButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
	public WebElement click_SubmitPopupCloseButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='no']")
	public WebElement click_NoOnPopupFor67Button;
	
	@FindBy(how = How.XPATH, using = "//*[@id='yes']")
	public WebElement click_YesOnPopupFor67Button;
	
	@FindBy(how = How.XPATH, using = "//*[@id='no']")
	public WebElement click_NoOnPopupMessage;
	
	@FindBy(how = How.XPATH, using = "//*[@id='yes']")
	public WebElement click_YesOnPopupMessage;
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/footer/div/span[1]")
	public WebElement verifyfooter; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='assessment-modal']/div/div/div[2]/button[1]")
	public WebElement click_CancelButtonOnPopup;
	
	@FindBy(how = How.XPATH, using = "//*[@id='secondaryAssessment']")
	public WebElement click_ContinueButtonOnPopup;
	
	public CaregiverStatusUpdatePage(WebDriver driver){
		CaregiverStatusUpdatePage.driver = driver;
	}
	
	
	 /**
     * This method is used to verify Status Update Title
     */
    public CaregiverStatusUpdatePage verifyStatusUpdateForTitle() throws Exception{
    	Thread.sleep(4000);
    	assertEquals("Status Update for DCpatient, One", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
    	assertEquals("DCpatient, One", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2/span")).getText());
    	return new CaregiverStatusUpdatePage(driver);
    }
	
	 /**
     * This method is used to verify Status Update Text
     */
    public CaregiverStatusUpdatePage verifyStatusUpdateForText() throws Exception{
    	Thread.sleep(5000);
    	assertEquals("Please review and submit the Status Update for your father since March 21, 2015.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p")).getText());
    	return new CaregiverStatusUpdatePage(driver);
    }
    

	 /**
	 * This method is used to verify Category Heading
	 */
	public CaregiverStatusUpdatePage verifyCategoryHeading() throws Exception{
		assertEquals("Category", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[1]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Heading
	 */
	public CaregiverStatusUpdatePage verifyHistoryHeading() throws Exception{
		assertEquals("History", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
	 * This method is used to verify Markedly Improved Heading
	 */
	public CaregiverStatusUpdatePage verifyMarkedlyImprovedHeading() throws Exception{
		assertEquals("Markedly Improved", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[3]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify Much Improved Heading
	 */
	public CaregiverStatusUpdatePage verifyMuchImprovedHeading() throws Exception{
		assertEquals("Much Improved", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[4]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
	 * This method is used to verify Minimally Improved Heading
	 */
	public CaregiverStatusUpdatePage verifyMinimallyImprovedHeading() throws Exception{
		assertEquals("Minimally Improved", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[5]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify No Change Heading
	 */
	public CaregiverStatusUpdatePage verifyNoChangeHeading() throws Exception{
		assertEquals("No Change", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[6]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify Minimally Worse Heading
	 */
	public CaregiverStatusUpdatePage verifyMinimallyWorseHeading() throws Exception{
		assertEquals("Minimally Worse", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[7]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify Much Worse Heading
	 */
	public CaregiverStatusUpdatePage verifyMuchWorseHeading() throws Exception{
		assertEquals("Much Worse", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[8]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify Markedly Worse Heading
	 */
	public CaregiverStatusUpdatePage verifyMarkedlyWorseHeading() throws Exception{
		assertEquals("Markedly Worse", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/thead/tr/th[9]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
	
    //========================================================================================================================
	// Overall Section for selection 
	
	 /**
	 * This method is used to verify Overall Heading Label
	 */
	public CaregiverStatusUpdatePage verifyOverallLabel() throws Exception{
		assertEquals("Overall", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[1]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Overall Info Icon Link
    */
    public CaregiverStatusUpdatePage clickOverallInfoIconLink() throws Exception{
    	clickOverallInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Overall Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyOverallInfoIconText() throws Exception{
		Thread.sleep(1000);
		assertEquals("Estimate Veteran's overall well being since last assessment", driver.findElement(By.xpath("//*[@id='popover107754']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyOverallHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[1]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	    * This method is used to click on Overall History Icon Link
	    */
	    public CaregiverStatusUpdatePage clickOverallHistoryIconLink() throws Exception{
	    	clickOverallHistoryIconLink.click();
	    	return new CaregiverStatusUpdatePage(driver);
	    }
	    
	    /**
	    * This method is used to click on Overall Answer Button One
	    */
	    public CaregiverStatusUpdatePage clickOverallAnswerButtonOne() throws Exception{
	    	clickOverallAnswerButtonOne.click();
	    	return new CaregiverStatusUpdatePage(driver);
	    }
		    
		/**
		* This method is used to click on Overall Answer Button Two
		*/
		public CaregiverStatusUpdatePage clickOverallAnswerButtonTwo() throws Exception{
		clickOverallAnswerButtonTwo.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Overall Answer Button Three
		*/
		public CaregiverStatusUpdatePage clickOverallAnswerButtonThree() throws Exception{
		clickOverallAnswerButtonThree.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Overall Answer Button Four
		*/
		public CaregiverStatusUpdatePage clickOverallAnswerButtonFour() throws Exception{
		clickOverallAnswerButtonFour.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Overall Answer Button Five
		*/
		public CaregiverStatusUpdatePage clickOverallAnswerButtonFive() throws Exception{
		clickOverallAnswerButtonFive.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Overall Answer Button Six
		*/
		public CaregiverStatusUpdatePage clickOverallAnswerButtonSix() throws Exception{
		clickOverallAnswerButtonSix.click();
		return new CaregiverStatusUpdatePage(driver);
		}

    
		/**
		* This method is used to click on Overall Answer Button Seven
		*/
		public CaregiverStatusUpdatePage clickOverallAnswerButtonSeven() throws Exception{
		clickOverallAnswerButtonSeven.click();
		return new CaregiverStatusUpdatePage(driver);
		}

	    /**
	    * This method is used to verify Overall Answer Button One
	    */
		public CaregiverStatusUpdatePage verifyOverallAnswerButtonOne() throws Exception{
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='answerButtons' and @aria-label='Markedly Improved for Overall Category']")) !=null);
			return new CaregiverStatusUpdatePage(driver);
		}
		
		
	    /**
	    * This method is used to click on Continue button for secondary assessment.
	    */
	    public CaregiverStatusUpdatePage clickContinueButtonForSecondaryAssessment() throws Exception{
	    	clickContinueButtonForSecondaryAssessment.click();
	    	return new CaregiverStatusUpdatePage(driver);
	    }
		
		
		
		
		
		
		
		
		
	    //========================================================================================================================
		// Cognition Section for selection 
    
	 /**
	 * This method is used to verify Cognition Label Heading
	 */
	public CaregiverStatusUpdatePage verifyCognitionLabel() throws Exception{
		assertEquals("Cognition", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[2]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Cognition Info Icon Link
    */
    public CaregiverStatusUpdatePage clickCognitionInfoIconLink() throws Exception{
    	clickCognitionInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Cognition Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyCognitionInfoIconText() throws Exception{
		assertEquals("Estimate Veteran's overall thinking ability since last assessment.", driver.findElement(By.xpath("//*[@id='popover543684']/div[2]")).getText());
		//assertEquals("Estimate Veteran's overall thinking ability since last assessment.", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[2]/td[1]/span/a")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyCognitionHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[2]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
	    * This method is used to click on Cognition History Icon Link
	    */
	    public CaregiverStatusUpdatePage clickCognitionHistoryIconLink() throws Exception{
	    	clickCognitionHistoryIconLink.click();
	    	return new CaregiverStatusUpdatePage(driver);
	    }
	    
	    /**
	    * This method is used to click on Cognition Answer Button One
	    */
	    public CaregiverStatusUpdatePage clickCognitionAnswerButtonOne() throws Exception{
	    	clickCognitionAnswerButtonOne.click();
	    	return new CaregiverStatusUpdatePage(driver);
	    }
		    
		/**
		* This method is used to click on Cognition Answer Button Two
		*/
		public CaregiverStatusUpdatePage clickCognitionAnswerButtonTwo() throws Exception{
		clickCognitionAnswerButtonTwo.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Cognition Answer Button Three
		*/
		public CaregiverStatusUpdatePage clickCognitionAnswerButtonThree() throws Exception{
		clickCognitionAnswerButtonThree.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Cognition Answer Button Four
		*/
		public CaregiverStatusUpdatePage clickCognitionAnswerButtonFour() throws Exception{
		clickCognitionAnswerButtonFour.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Cognition Answer Button Five
		*/
		public CaregiverStatusUpdatePage clickCognitionAnswerButtonFive() throws Exception{
		clickCognitionAnswerButtonFive.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Cognition Answer Button Six
		*/
		public CaregiverStatusUpdatePage clickCognitionAnswerButtonSix() throws Exception{
		clickCognitionAnswerButtonSix.click();
		return new CaregiverStatusUpdatePage(driver);
		}

		/**
		* This method is used to click on Cognition Answer Button Seven
		*/
		public CaregiverStatusUpdatePage clickCognitionAnswerButtonSeven() throws Exception{
		clickCognitionAnswerButtonSeven.click();
		return new CaregiverStatusUpdatePage(driver);
		}
	
    //========================================================================================================================
	// Daily Function Section for selection 

    
	/**
	 * This method is used to verify Daily Function Label Heading
	 */
	public CaregiverStatusUpdatePage verifyDailyFunctionLabel() throws Exception{
		assertEquals("Daily Function", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[3]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Daily Function Info Icon Link
    */
    public CaregiverStatusUpdatePage clickDailyFunctionInfoIconLink() throws Exception{
    	clickDailyFunctionInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Daily Function Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyDailyFunctionInfoIconText() throws Exception{
		assertEquals("Estimate Veteran's overall performance on daily tasks since last assessment.", driver.findElement(By.xpath("//*[@id='popover536757']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyDailyFunctionHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[3]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Daily Function History Icon Link
    */
    public CaregiverStatusUpdatePage clickDailyFunctionHistoryIconLink() throws Exception{
    	clickDailyFunctionHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Daily Function Answer Button One
    */
    public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonOne() throws Exception{
    	clickDailyFunctionAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Daily Function Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonTwo() throws Exception{
	clickDailyFunctionAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Daily Function Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonThree() throws Exception{
	clickDailyFunctionAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Daily Function Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonFour() throws Exception{
	clickDailyFunctionAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Daily Function Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonFive() throws Exception{
	clickDailyFunctionAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Daily Function Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonSix() throws Exception{
	clickDailyFunctionAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Daily Function Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickDailyFunctionAnswerButtonSeven() throws Exception{
	clickDailyFunctionAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
    //========================================================================================================================
	// Behavior Section for selection 

	/**
	 * This method is used to verify Behavior Label Heading
	 */
	public CaregiverStatusUpdatePage verifyBehaviorLabel() throws Exception{
		assertEquals("Behavior", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[4]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Behavior Info Icon Link
    */
    public CaregiverStatusUpdatePage clickBehaviorInfoIconLink() throws Exception{
    	clickBehaviorInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Behavior Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyBehaviorInfoIconText() throws Exception{
		assertEquals("Assess Veteran's overall behavior since last assessment.", driver.findElement(By.xpath("//*[@id='popover124185']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyBehaviorHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[4]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Behavior History Icon Link
    */
    public CaregiverStatusUpdatePage clickBehaviorHistoryIconLink() throws Exception{
    	clickBehaviorHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Behavior Answer Button One
    */
    public CaregiverStatusUpdatePage clickBehaviorAnswerButtonOne() throws Exception{
    	clickBehaviorAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Behavior Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickBehaviorAnswerButtonTwo() throws Exception{
	clickBehaviorAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Behavior Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickBehaviorAnswerButtonThree() throws Exception{
	clickBehaviorAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Behavior Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickBehaviorAnswerButtonFour() throws Exception{
	clickBehaviorAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Behavior Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickBehaviorAnswerButtonFive() throws Exception{
	clickBehaviorAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Behavior Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickBehaviorAnswerButtonSix() throws Exception{
	clickBehaviorAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Behavior Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickBehaviorAnswerButtonSeven() throws Exception{
	clickBehaviorAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//========================================================================================================================
// Falls Section for selection 
	
	/**
	 * This method is used to verify Falls Label Heading
	 */
	public CaregiverStatusUpdatePage verifyFallsLabel() throws Exception{
		assertEquals("Falls", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[5]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Falls Info Icon Link
    */
    public CaregiverStatusUpdatePage clickFallsInfoIconLink() throws Exception{
    	clickFallsInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Falls Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyFallsInfoIconText() throws Exception{
		assertEquals("Estimate Veteran's risk of falling down since last assessment.", driver.findElement(By.xpath("//*[@id='popover928383']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyFallsHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[5]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Falls History Icon Link
    */
    public CaregiverStatusUpdatePage clickFallsHistoryIconLink() throws Exception{
    	clickFallsHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Falls Answer Button One
    */
    public CaregiverStatusUpdatePage clickFallsAnswerButtonOne() throws Exception{
    	clickFallsAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Falls Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickFallsAnswerButtonTwo() throws Exception{
	clickFallsAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Falls Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickFallsAnswerButtonThree() throws Exception{
	clickFallsAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Falls Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickFallsAnswerButtonFour() throws Exception{
	clickFallsAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Falls Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickFallsAnswerButtonFive() throws Exception{
	clickFallsAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Falls Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickFallsAnswerButtonSix() throws Exception{
	clickFallsAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Falls Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickFallsAnswerButtonSeven() throws Exception{
	clickFallsAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	


//========================================================================================================================
// Medications Section for selection 

	/**
	 * This method is used to verify Medications Label Heading
	 */
	public CaregiverStatusUpdatePage verifyMedicationsLabel() throws Exception{
		assertEquals("Medications", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[6]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Medications Info Icon Link
    */
    public CaregiverStatusUpdatePage clickMedicationsInfoIconLink() throws Exception{
    	clickMedicationsInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Medications Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyMedicationsInfoIconText() throws Exception{
		assertEquals("Estimate difficulty with Veteran's medications since last assessment.", driver.findElement(By.xpath("//*[@id='popover975623']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyMedicationsHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[6]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Medications History Icon Link
    */
    public CaregiverStatusUpdatePage clickMedicationsHistoryIconLink() throws Exception{
    	clickMedicationsHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Medications Answer Button One
    */
    public CaregiverStatusUpdatePage clickMedicationsAnswerButtonOne() throws Exception{
    	clickMedicationsAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Medications Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickMedicationsAnswerButtonTwo() throws Exception{
	clickMedicationsAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Medications Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickMedicationsAnswerButtonThree() throws Exception{
	clickMedicationsAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Medications Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickMedicationsAnswerButtonFour() throws Exception{
	clickMedicationsAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Medications Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickMedicationsAnswerButtonFive() throws Exception{
	clickMedicationsAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Medications Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickMedicationsAnswerButtonSix() throws Exception{
	clickMedicationsAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Medications Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickMedicationsAnswerButtonSeven() throws Exception{
	clickMedicationsAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//========================================================================================================================
// Sleep Section for selection 	
	
	/**
	 * This method is used to verify Sleep Label Heading
	 */
	public CaregiverStatusUpdatePage verifySleepLabel() throws Exception{
		assertEquals("Sleep", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[7]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Sleep Info Icon Link
    */
    public CaregiverStatusUpdatePage clickSleepInfoIconLink() throws Exception{
    	clickSleepInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Sleep Info Icon text
	 */
	public CaregiverStatusUpdatePage verifySleepInfoIconText() throws Exception{
		assertEquals("Estimate Veteran's overall sleep pattern since last assessment.", driver.findElement(By.xpath("//*[@id='popover80419']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifySleepHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[7]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Sleep History Icon Link
    */
    public CaregiverStatusUpdatePage clickSleepHistoryIconLink() throws Exception{
    	clickSleepHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Sleep Answer Button One
    */
    public CaregiverStatusUpdatePage clickSleepAnswerButtonOne() throws Exception{
    	clickSleepAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Sleep Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickSleepAnswerButtonTwo() throws Exception{
	clickSleepAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Sleep Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickSleepAnswerButtonThree() throws Exception{
	clickSleepAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Sleep Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickSleepAnswerButtonFour() throws Exception{
	clickSleepAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Sleep Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickSleepAnswerButtonFive() throws Exception{
	clickSleepAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Sleep Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickSleepAnswerButtonSix() throws Exception{
	clickSleepAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Sleep Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickSleepAnswerButtonSeven() throws Exception{
	clickSleepAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//========================================================================================================================
// Pain Section for selection 	
	/**
	 * This method is used to verify Pain Label Heading
	 */
	public CaregiverStatusUpdatePage verifyPainLabel() throws Exception{
		assertEquals("Pain AD", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[8]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Pain Info Icon Link
    */
    public CaregiverStatusUpdatePage clickPainInfoIconLink() throws Exception{
    	clickPainInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Pain Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyPainInfoIconText() throws Exception{
		assertEquals("Estimate Veteran's level of pain since last assessment.", driver.findElement(By.xpath("//*[@id='popover745966']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyPainHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[8]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Pain History Icon Link
    */
    public CaregiverStatusUpdatePage clickPainHistoryIconLink() throws Exception{
    	clickPainHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Pain Answer Button One
    */
    public CaregiverStatusUpdatePage clickPainAnswerButtonOne() throws Exception{
    	clickPainAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Pain Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickPainAnswerButtonTwo() throws Exception{
	clickPainAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Pain Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickPainAnswerButtonThree() throws Exception{
	clickPainAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Pain Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickPainAnswerButtonFour() throws Exception{
	clickPainAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Pain Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickPainAnswerButtonFive() throws Exception{
	clickPainAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Pain Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickPainAnswerButtonSix() throws Exception{
	clickPainAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Pain Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickPainAnswerButtonSeven() throws Exception{
	clickPainAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
	
//========================================================================================================================
// Incontinence Section for selection 	
	/**
	 * This method is used to verify Incontinence Label Heading
	 */
	public CaregiverStatusUpdatePage verifyIncontinenceLabel() throws Exception{
		assertEquals("Incontinence", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[9]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Incontinence Info Icon Link
    */
    public CaregiverStatusUpdatePage clickIncontinenceInfoIconLink() throws Exception{
    	clickIncontinenceInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Incontinence Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyIncontinenceInfoIconText() throws Exception{
		assertEquals("Estimate overall difficulty with urination and defecation since last assessment.", driver.findElement(By.xpath("//*[@id='popover114953']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyIncontinenceHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[9]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Incontinence History Icon Link
    */
    public CaregiverStatusUpdatePage clickIncontinenceHistoryIconLink() throws Exception{
    	clickIncontinenceHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Incontinence Answer Button One
    */
    public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonOne() throws Exception{
    	clickIncontinenceAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Incontinence Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonTwo() throws Exception{
	clickIncontinenceAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Incontinence Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonThree() throws Exception{
	clickIncontinenceAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Incontinence Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonFour() throws Exception{
	clickIncontinenceAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Incontinence Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonFive() throws Exception{
	clickIncontinenceAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Incontinence Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonSix() throws Exception{
	clickIncontinenceAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Incontinence Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickIncontinenceAnswerButtonSeven() throws Exception{
	clickIncontinenceAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//========================================================================================================================
// Confusion Section for selection 
	
	/**
	 * This method is used to verify Periods Of Confusion Label Heading
	 */
	public CaregiverStatusUpdatePage verifyConfusionLabel() throws Exception{
		assertEquals("Confusion", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[10]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Periods Of Confusion Info Icon Link
    */
    public CaregiverStatusUpdatePage clickConfusionInfoIconLink() throws Exception{
    	clickConfusionInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Periods Of Confusion Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyConfusionInfoIconText() throws Exception{
		assertEquals("Estimate the Veteran's tendency to get confused since last assessment.", driver.findElement(By.xpath("//*[@id='popover757205']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyConfusionHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[10]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Periods Of Confusion History Icon Link
    */
    public CaregiverStatusUpdatePage clickConfusionHistoryIconLink() throws Exception{
    	clickConfusionHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Periods Of Confusion Answer Button One
    */
    public CaregiverStatusUpdatePage clickConfusionAnswerButtonOne() throws Exception{
    	clickConfusionAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Periods Of Confusion Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickConfusionAnswerButtonTwo() throws Exception{
	clickConfusionAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Periods Of Confusion Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickConfusionAnswerButtonThree() throws Exception{
	clickConfusionAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Periods Of Confusion Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickConfusionAnswerButtonFour() throws Exception{
	clickConfusionAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Periods Of Confusion Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickConfusionAnswerButtonFive() throws Exception{
	clickConfusionAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Periods Of Confusion Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickConfusionAnswerButtonSix() throws Exception{
	clickConfusionAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Periods Of Confusion Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickConfusionAnswerButtonSeven() throws Exception{
	clickConfusionAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//========================================================================================================================
// Safety Section for selection 
	/**
	 * This method is used to verify Safety Label Heading
	 */
	public CaregiverStatusUpdatePage verifySafetyLabel() throws Exception{
		assertEquals("Safety", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[11]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Safety Info Icon Link
    */
    public CaregiverStatusUpdatePage clickSafetyInfoIconLink() throws Exception{
    	clickSafetyInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Safety Info Icon text
	 */
	public CaregiverStatusUpdatePage verifySafetyInfoIconText() throws Exception{
		assertEquals("Estimate the Veteran's overall personal safety since last assessment.", driver.findElement(By.xpath("//*[@id='popover756086']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifySafetyHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[11]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Safety History Icon Link
    */
    public CaregiverStatusUpdatePage clickSafetyHistoryIconLink() throws Exception{
    	clickSafetyHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Safety Answer Button One
    */
    public CaregiverStatusUpdatePage clickSafetyAnswerButtonOne() throws Exception{
    	clickSafetyAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Safety Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickSafetyAnswerButtonTwo() throws Exception{
	clickSafetyAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Safety Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickSafetyAnswerButtonThree() throws Exception{
	clickSafetyAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Safety Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickSafetyAnswerButtonFour() throws Exception{
	clickSafetyAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Safety Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickSafetyAnswerButtonFive() throws Exception{
	clickSafetyAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Safety Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickSafetyAnswerButtonSix() throws Exception{
	clickSafetyAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Safety Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickSafetyAnswerButtonSeven() throws Exception{
	clickSafetyAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//========================================================================================================================
// Caregiver Section for selection 
	/**
	 * This method is used to verify Caregiver Well-Being Label Heading
	 */
	public CaregiverStatusUpdatePage verifyCaregiverLabel() throws Exception{
		assertEquals("Caregiver Well-Being", driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[12]/td[1]/span/span")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	/**
    * This method is used to click on Caregiver Well-Being Info Icon Link
    */
    public CaregiverStatusUpdatePage clickCaregiverInfoIconLink() throws Exception{
    	clickCaregiverInfoIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Caregiver Well-Being Info Icon text
	 */
	public CaregiverStatusUpdatePage verifyCaregiverInfoIconText() throws Exception{
		assertEquals("Estimate the caregiver's overall physical and emotional status and stress level since last assessment.", driver.findElement(By.xpath("//*[@id='popover938195']/div[2]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
    
	 /**
	 * This method is used to verify History Icon
	 */
	public CaregiverStatusUpdatePage verifyCaregiverHistoryIcon() throws Exception{
		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='statusUpdateTable']/tbody/tr[12]/td[2]/a/img")) !=null);
		return new CaregiverStatusUpdatePage(driver);
	}
	
	 /**
    * This method is used to click on Caregiver Well-Being History Icon Link
    */
    public CaregiverStatusUpdatePage clickCaregiverHistoryIconLink() throws Exception{
    	clickCaregiverHistoryIconLink.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    /**
    * This method is used to click on Caregiver Well-Being Answer Button One
    */
    public CaregiverStatusUpdatePage clickCaregiverAnswerButtonOne() throws Exception{
    	clickCaregiverAnswerButtonOne.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
	    
	/**
	* This method is used to click on Caregiver Well-Being Answer Button Two
	*/
	public CaregiverStatusUpdatePage clickCaregiverAnswerButtonTwo() throws Exception{
	clickCaregiverAnswerButtonTwo.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Caregiver Well-Being Answer Button Three
	*/
	public CaregiverStatusUpdatePage clickCaregiverAnswerButtonThree() throws Exception{
	clickCaregiverAnswerButtonThree.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Caregiver Well-Being Answer Button Four
	*/
	public CaregiverStatusUpdatePage clickCaregiverAnswerButtonFour() throws Exception{
	clickCaregiverAnswerButtonFour.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Caregiver Well-Being Answer Button Five
	*/
	public CaregiverStatusUpdatePage clickCaregiverAnswerButtonFive() throws Exception{
	clickCaregiverAnswerButtonFive.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Caregiver Well-Being Answer Button Six
	*/
	public CaregiverStatusUpdatePage clickCaregiverAnswerButtonSix() throws Exception{
	clickCaregiverAnswerButtonSix.click();
	return new CaregiverStatusUpdatePage(driver);
	}

	/**
	* This method is used to click on Caregiver Well-Being Answer Button Seven
	*/
	public CaregiverStatusUpdatePage clickCaregiverAnswerButtonSeven() throws Exception{
	clickCaregiverAnswerButtonSeven.click();
	return new CaregiverStatusUpdatePage(driver);
	}
	
//===============================================================================================================================
//Buttons Section
	
	 
	 /**
     * This method is used to verify Cancel button.
     */
    public CaregiverStatusUpdatePage verifyCancelButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_statusCancel']")) !=null);
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	/**
     * This method is used to click on Cancel button.
     */
    public CaregiverStatusUpdatePage click_CancelButton() throws Exception{
    	click_CancelButton.click();
    	return new CaregiverStatusUpdatePage(driver);
    }

	 /**
     * This method is used to verify Cancel button on Popup message.
     */
    public CaregiverStatusUpdatePage verifyCancelButtonOnPopup() throws Exception{
    	Thread.sleep(1000);
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='assessment-modal']/div/div/div[2]/button[1]")) !=null);
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	/**
     * This method is used to click on Cancel button on Popup message.
     */
    public CaregiverStatusUpdatePage click_CancelButtonOnPopup() throws Exception{
    	Thread.sleep(1000);
    	click_CancelButtonOnPopup.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to verify Continue button on Popup message.
     */
    public CaregiverStatusUpdatePage verifyContinueButtonOnPopup() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='secondaryAssessment']")) !=null);
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	/**
     * This method is used to click on Continue button on Popup message.
     */
    public CaregiverStatusUpdatePage click_ContinueButtonOnPopup() throws Exception{
    	Thread.sleep(1000);
    	click_ContinueButtonOnPopup.click();
    	Thread.sleep(1000);
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to verify Reset button.
     */
    public CaregiverStatusUpdatePage verifyResetButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_statusReset']")) !=null);
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to click on Reset button.
     */
    public CaregiverStatusUpdatePage click_ResetButton() throws Exception{
    	click_ResetButton.click();
    	return new CaregiverStatusUpdatePage(driver);
    }

	 /**
     * This method is used to verify Submit button.
     */
    public CaregiverStatusUpdatePage verifySubmitButton() throws Exception{
    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_statusSubmit']")) !=null);
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to click on Submit button.
     */
    public CaregiverStatusUpdatePage click_SubmitButton() throws Exception{
    	click_SubmitButton.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
	 * This method is used to verify Footer
	 */
	public CaregiverStatusUpdatePage verifyFooter() throws Exception{
		assertEquals("U.S. Department of Veterans Affairs", driver.findElement(By.xpath("html/body/div[1]/footer/div/span[1]")).getText());
		return new CaregiverStatusUpdatePage(driver);
	}
	
// Popup alert message secion
	 /**
     * This method is used to verify Reset Popup message
     */
    public CaregiverStatusUpdatePage verifyResetPopupMessage() throws Exception{
    	assertEquals("All options in this Status Update have been reset to '4 - No Change.'", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to close Reset popup message.
     */
    public CaregiverStatusUpdatePage click_ResetPopupCloseButton() throws Exception{
    	click_ResetPopupCloseButton.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to verify Cancel Popup message
     */
    public CaregiverStatusUpdatePage verifyCancelPopupMessage() throws Exception{
    	assertEquals("This will discard your Status Update for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to click on No button on popup message.
     */
    public CaregiverStatusUpdatePage click_NoOnPopupMessage() throws Exception{
    	click_NoOnPopupMessage.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to click on Yes button on popup message.
     */
    public CaregiverStatusUpdatePage click_YesOnPopupMessage() throws Exception{
    	click_YesOnPopupMessage.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
    
	 /**
     * This method is used to verify Submit Popup message
     */
    public CaregiverStatusUpdatePage verifySubmitPopupMessage() throws Exception{
    	assertEquals("Success: The Status Update for DCpatient, One has been successfully submitted on May 11th, 2015.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to close Submit popup message.
     */
    public CaregiverStatusUpdatePage click_SubmitPopupCloseButton() throws Exception{
    	click_SubmitPopupCloseButton.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to verify Submit Popup message when selecting 6 or 7
     */
    public CaregiverStatusUpdatePage verifySubmitPopupMessageFor67() throws Exception{
    	assertEquals("The Status Update indicates worsening of symptoms. If this is an emergency please call 911 or Veterans Crisis line at 1-800-273-8255 FREE. If you want someone from the Clinic Team to contact you, select the Yes button below. Please note that this is not for emergencies, that the clinic team will contact you at their earliest convenience, usually within 3 business days. Would you like the Clinic Team to contact you?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to click on No for Submit popup message for 6 and 7.
     */
    public CaregiverStatusUpdatePage click_NoOnPopupFor67Button() throws Exception{
    	click_NoOnPopupFor67Button.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	 /**
     * This method is used to click on Yes for Submit popup message for 6 and 7.
     */
    public CaregiverStatusUpdatePage click_YesOnPopupFor67Button() throws Exception{
    	click_YesOnPopupFor67Button.click();
    	return new CaregiverStatusUpdatePage(driver);
    }
    
	public CaregiverStatusUpdatePage GoBackBrowserButton() throws Exception{
		Thread.sleep(1000);
		driver.navigate().back();
		Thread.sleep(1000);
		//assertEquals("http://vetadmin.mobilehealth.domain:8080/xx", driver.getCurrentUrl());
    return new CaregiverStatusUpdatePage(driver);
	}
    
    
}
