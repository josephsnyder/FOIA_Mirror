package gov.va.mobile.vamf.QaAutoTest.AAP.UITest;
//Summary: Total 87 test cases in Regression suite.
import static org.junit.Assert.*;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.AboutVAPharmaciesPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.AdverseDrugEventInformation;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.ConsumerDrugHerbalSupplementInformationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.DrugInteractionsAdverseDrugPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.DrugInteractionsAndAdverseDrugEvents;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.GetTheLatestSafetyArticlesOnMedicationsPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.HomePage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.LandingPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.LoginPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.MedicalAdministrationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.MedicationAndHealthPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.MedicationArticlesOnMyHealtheVetPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.MedicationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.MyHealthVetPharmacyServicesPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.PillBottleInformationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.RecallsMarketWithdrawalsSafetyAlertsonFDAPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.ReportingMedicationErrorPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.SafetyPracticePage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.TrackMyMedicationPage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.TrustedMedicationResoucePage;
import gov.va.mobile.vamf.QaAutoTest.AAP.UIClass.USFoodAndDrugAdministrationPage;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.runners.MethodSorters;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AAPRegressionTest {

	//declare Objects - Webdriver, LoginPage Object & variables
		static WebDriver driver;
		LandingPage newLandingPage;
		LoginPage newLoginPage;
		HomePage newHomePage;
		AboutVAPharmaciesPage newAboutVAPharmaciesPage;
		MyHealthVetPharmacyServicesPage newmyHealthVetPharmacyServicesPage;
		TrustedMedicationResoucePage newTrustedMedicationResoucePage;
		ConsumerDrugHerbalSupplementInformationPage newConsumerDrugHerbalSupplementInformationPage;
		RecallsMarketWithdrawalsSafetyAlertsonFDAPage newRecallsMarketWithdrawalsSafetyAlertsonFDAPage; //Please work on the pop up
		PillBottleInformationPage newPillBottleInformationPage;
		USFoodAndDrugAdministrationPage newUSFoodAndDrugAdministrationPage;
		DrugInteractionsAndAdverseDrugEvents newDrugInteractionsAndAdverseDrugEvents;
		AdverseDrugEventInformation newAdverseDrugEventInformation;
		TrackMyMedicationPage newTrackMyMedicationPage;
		MedicalAdministrationPage newMedicalAdministrationPage;
		MedicationArticlesOnMyHealtheVetPage newMedicationArticlesOnMyHealtheVetPage;
		MedicationPage newMedicationPage;
		MedicationAndHealthPage newMedicationAndHealthPage;
		SafetyPracticePage newSafetyPracticePage;
		ReportingMedicationErrorPage newReportingMedicationErrorPage;
		GetTheLatestSafetyArticlesOnMedicationsPage newGetTheLatestSafetyArticlesOnMedicationsPage;
		String vURL, UserName, Password, Browser;
		
		private boolean acceptNextAlert = true;
		public StringBuffer verificationErrors = new StringBuffer();
		
		@Before
		public void SetUP()throws Exception{
			//initialize Objects
			//driver = new FirefoxDriver();
			//driver = new SafariDriver();
			File file = new File(System.getProperty("user.dir")+ "//ExtDependencies//IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
			driver = new InternetExplorerDriver();
		    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			newLandingPage = PageFactory.initElements(driver, LandingPage.class);
			newHomePage = PageFactory.initElements(driver, HomePage.class);
			newLoginPage = PageFactory.initElements(driver, LoginPage.class);
			newAboutVAPharmaciesPage = PageFactory.initElements(driver, AboutVAPharmaciesPage.class);
			newmyHealthVetPharmacyServicesPage = PageFactory.initElements(driver, MyHealthVetPharmacyServicesPage.class);
			newTrustedMedicationResoucePage = PageFactory.initElements(driver, TrustedMedicationResoucePage.class);
			newConsumerDrugHerbalSupplementInformationPage = PageFactory.initElements(driver, ConsumerDrugHerbalSupplementInformationPage.class);
			newRecallsMarketWithdrawalsSafetyAlertsonFDAPage = PageFactory.initElements(driver, RecallsMarketWithdrawalsSafetyAlertsonFDAPage.class);
			newPillBottleInformationPage = PageFactory.initElements(driver, PillBottleInformationPage.class); 
			newUSFoodAndDrugAdministrationPage = PageFactory.initElements(driver, USFoodAndDrugAdministrationPage.class); 
			newDrugInteractionsAndAdverseDrugEvents = PageFactory.initElements(driver, DrugInteractionsAndAdverseDrugEvents.class); 
			newAdverseDrugEventInformation = PageFactory.initElements(driver, AdverseDrugEventInformation.class);
			newTrackMyMedicationPage = PageFactory.initElements(driver, TrackMyMedicationPage.class);
			newMedicalAdministrationPage = PageFactory.initElements(driver, MedicalAdministrationPage.class);
			newMedicationArticlesOnMyHealtheVetPage = PageFactory.initElements(driver, MedicationArticlesOnMyHealtheVetPage.class);
			newMedicationPage = PageFactory.initElements(driver, MedicationPage.class);
			newMedicationAndHealthPage = PageFactory.initElements(driver, MedicationAndHealthPage.class);
			newSafetyPracticePage = PageFactory.initElements(driver, SafetyPracticePage.class);
			newReportingMedicationErrorPage = PageFactory.initElements(driver, ReportingMedicationErrorPage.class);
			newGetTheLatestSafetyArticlesOnMedicationsPage = PageFactory.initElements(driver, GetTheLatestSafetyArticlesOnMedicationsPage.class);
			
			//load data from resource file
			Properties properties = new Properties();
			String path = System.getProperty("user.dir")+ "//src//test//resources//datafile//data.properties";
			
			FileInputStream fs = new FileInputStream(path);
			properties.load(fs);
				
				UserName = properties.getProperty("UserName");
				Password = properties.getProperty("Password");
				vURL = properties.getProperty("URL");
				Browser = properties.getProperty("Browser");		
			    System.out.println("Test started");
			    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			}
		
		@After
		public void tearDown() throws Exception {
			
			//driver.close();
			driver.quit();
		}
	
		/*
		 * Test Case Name: TS-AAP-001 Verify "RX Label" link
		 * Test Objective: As a User, I need to know what the information on my pill bottle  means so that I am knowledgeable about my medications.
		 */
		 
		@Test
	
		public void TSAAP001VerifyRXLabelLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			System.out.println("Test Case 1 Started: ");
			newHomePage.clickPillBottleInformationicon();
			newPillBottleInformationPage.clickPillBottleInformation();
			//newPillBottleInformationPage.verifyPillBottleInformationurl();
		}

		
		 //* Test Case Name: TS-AAP-002 Verify "RX Label" menu item
		 //* Test Objective: As a User, I need to know what the information on my pill bottle  means so that I am knowledgeable about my medications.
		 
		
		@Test
		public void TSAAP002VerifyRXLabelmenuitem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.pillBottleInformationUnderFeature();
			Thread.sleep(3000);
			newPillBottleInformationPage.clickPillBottleInformation();
			newPillBottleInformationPage.verifyPillBottleInformationurl();
		}
		
		 
		 //* Test Case Name: TS-AAP-003 Verify "Pill Identification" link
		 //* Test Objective: As a User, I need access to pill identification information so that I can identify my medication when needed.
		 

		@Test
		public void TSAAP003VerifyPillIdentificationlink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.clickPillBottleInformationicon();
			newPillBottleInformationPage.clickPillIdentification();
			//newPillBottleInformationPage.verifyExternalPage();
		}
		
		 
		// * Test Case Name: TS-AAP-013 Verify "Drug Interactions Checker" link
		 //* Test Objective: As a User, I need to access information on performing drug interactions so that I can educate myself on potential interactions
		 

		@Test
		public void TSAAP013VerifyDrugInteractionsCheckerlink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.clickDrugInteractionsAdverseDrugEvents();
			newDrugInteractionsAndAdverseDrugEvents.click_AdverseDrugEventInformation();
			newAdverseDrugEventInformation.click_DrugInteractionsChecker();
			newAdverseDrugEventInformation.verifyExternalPage();
			//newAdverseDrugEventInformation.verifyDrugInteractionurl();
			//newAdverseDrugEventInformation.verifyExternalPagetitle();
		}

		
		 //* Test Case Name: TS-AAP-014 Verify "Drug Interactions Checker" menu item
		 //* Test Objective: As a User, I need to access information on performing drug interactions so that I can educate myself on potential interactions
		 

		@Test
		@Ignore 
		public void TSAAP014VerifyDrugInteractionsCheckerMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.clickDrugInteractionsAdverseDrugEvents();
			newDrugInteractionsAndAdverseDrugEvents.click_AdverseDrugEventInformation();
			//newAdverseDrugEventInformation.click_DrugInteractionsChecker();
			//newAdverseDrugEventInformation.verifyExternalPage();
			//newAdverseDrugEventInformation.verifyDrugInteractionurl();
			//newAdverseDrugEventInformation.verifyExternalPagetitle();
		}

		
		 //* Test Case Name: TS-AAP-015 Verify "Find My Facility" link
		 //* Test Objective: As a User, I need the ability to utilize a "Facility Locator" to find  my preferred VA Healthcare facility or facilities so that I can choose a specific VA location.
		 

		@Test
		public void TSAAP015VerifyFindMyFacilityLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.aboutVAPharmaciesicon();
			newAboutVAPharmaciesPage.click_FindMyFacility();
			//newAboutVAPharmaciesPage.verifyExternalPage();
			//newAboutVAPharmaciesPage.ZipCodeSearch();
			newAboutVAPharmaciesPage.GoBackBrowserButton();
			newAboutVAPharmaciesPage.click_FindMyFacility();
			//newAboutVAPharmaciesPage.verifyExternalPage();
			//newAboutVAPharmaciesPage.ByStateSearch();
			//newAboutVAPharmaciesPage.GoBackBrowserButton();
			//newAboutVAPharmaciesPage.click_FindMyFacility();
			//newAboutVAPharmaciesPage.verifyExternalPage();
			//newAboutVAPharmaciesPage.ByDirectorySearch();
			//newAboutVAPharmaciesPage.GoBackBrowserButton();
			//newAboutVAPharmaciesPage.GoBackBrowserButton();
		}

		
		 //* Test Case Name: TS-AAP-016 Verify "Find My Facility" menu item
		// * Test Objective: As a User, I need the ability to utilize a "Facility Locator" to find  my preferred VA Healthcare facility or facilities so that I can choose a specific VA location.
		 
		
		@Test
		@Ignore 
		public void TSAAP016VerifyFindMyFacilityMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.aboutVAPharmaciesUnderFeature();	
			newAboutVAPharmaciesPage.click_FindMyFacility();
			//newAboutVAPharmaciesPage.verifyExternalPage();
			newAboutVAPharmaciesPage.ZipCodeSearch();
			newAboutVAPharmaciesPage.GoBackBrowserButton();
			newAboutVAPharmaciesPage.click_FindMyFacility();
			newAboutVAPharmaciesPage.verifyExternalPage();
			newAboutVAPharmaciesPage.ByStateSearch();
			newAboutVAPharmaciesPage.GoBackBrowserButton();
			newAboutVAPharmaciesPage.click_FindMyFacility();
			newAboutVAPharmaciesPage.verifyExternalPage();
			newAboutVAPharmaciesPage.ByDirectorySearch();
			newAboutVAPharmaciesPage.GoBackBrowserButton();
			newAboutVAPharmaciesPage.GoBackBrowserButton();
			}

		
		// * Test Case Name: TS-AAP-019 Verify "How VA Pharmacist Help Veterans" link
		// * Test Objective: As a User, I need access to information on the role of my VA pharmacists so that I can understand what my pharmacists do to help users with their medications.
		 
		
		@Test
		public void TSAAP019VerifyHowVAPharmacistHelpVeteransLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.aboutVAPharmaciesicon();
			newAboutVAPharmaciesPage.click_HowVAPharmacistsHelpVeterans();
			//newAboutVAPharmaciesPage.verifyHowVAPharmacistsHelpVeteransLink();
			}
	
		
		 //* Test Case Name: TS-AAP-020 Verify "How VA Pharmacist Help Veterans" menu item
		 //* Test Objective: As a User, I need access to information on the role of my VA pharmacists so that I can understand what my pharmacists do to help users with their medications.
		 
	
		@Test
		public void TSAAP020VerifyHowVAPharmacistHelpVeteransMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.aboutVAPharmaciesUnderFeature();
			Thread.sleep(3000);
			newAboutVAPharmaciesPage.click_HowVAPharmacistsHelpVeterans();
			newAboutVAPharmaciesPage.verifyHowVAPharmacistsHelpVeteransLink();				
			}

		
		// * Test Case Name: TS-AAP-022 Verify "How VA Pharmacies Operate" menu item
		 //* Test Objective: As a User, I need information on how my VA pharmacy operates so that I can understand how they work with the VA Consolidated Mail Order Pharmacies (CMOP) to get me my medications.
		 	
		
		@Test
		public void TSAAP022VerifyHowVAPharmaciesOperateMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.aboutVAPharmaciesUnderFeature();
			newAboutVAPharmaciesPage.click_HowVAPharmaciesOperate();
			//newAboutVAPharmaciesPage.verifyHowDoVAPharmaciesOperateLink();				
		}
		
		
		 //* Test Case Name: TS-AAP-023 Verify "UPS My Choice" link
		 //* Test Objective: As a user, I need to access third-party shipment websites (e.g., UPS My Choice) so that I can manage my prescription deliveries when they are shipped via a third-party service (e.g., UPS).
		 	

		@Test
		public void TSAAP023VerifyUPSMyChoicelink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_UPSMyChoice();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyUSPSMYChoiceurl();				
		}

		
		 //* Test Case Name: TS-AAP-024 Verify "UPS My Choice" menu item
		// * Test Objective: As a user, I need to access third-party shipment websites (e.g., UPS My Choice) so that I can manage my prescription deliveries when they are shipped via a third-party service (e.g., UPS).
		 	
		
		@Test
		public void TSAAP024VerifUPSMyChoiceMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_UPSMyChoice();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyUSPSMYChoiceurl();				
		}
		
		
		 //* Test Case Name: TS-AAP-025 Verify "USPS" link
		// * Test Objective: As a user, I need to access third-party shipment websites (e.g., USPS) so that I can manage my prescription deliveries when they are shipped via a third-party service (e.g., USPS).
		 	
		
		@Test
		public void TSAAP025VerifyUSPSink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_USPS();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyUSPSurl();	
		}
		
		
		// * Test Case Name: TS-AAP-026 Verify "USPS" menu item
		// * Test Objective: As a user, I need to access third-party shipment websites (e.g., USPS) so that I can manage my prescription deliveries when they are shipped via a third-party service (e.g., USPS).
		 	
		
		@Test
		public void TSAAP026VerifyUSPSMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_USPS();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyUSPSurl();	
		}
		
		
		 //* Test Case Name: TS-AAP-027 Verify "FAQ – MyHealtheVet" link
		 //* Test Objective: As a User, I need the ability to browse the Ask A Pharmacist Frequently Asked Questions by topic so that I am not forced to use the Search option to find content I am interested in.
		 	

		@Test
		public void TSAAP027VerifyFAQMyHealtheVetLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_FAQMyHealths();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newmyHealthVetPharmacyServicesPage.verifyFAQHomeurl();	
		}	

		
		 //* Test Case Name: TS-AAP-028 Verify "FAQ – MyHealtheVet" menu item
		 //* Test Objective: As a User, I need the ability to browse the Ask A Pharmacist Frequently Asked Questions by topic so that I am not forced to use the Search option to find content I am interested in.
		 	

		@Test
		public void TSAAP028VerifyFAQMyHealtheVetMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_FAQMyHealths();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newmyHealthVetPharmacyServicesPage.verifyFAQHomeurl();	
		}

		
		 //* Test Case Name: TS-AAP-029 Verify "Prescription Refill" link
		 //* Test Objective: As a user, I want to access FAQs related to prescription refills  in MHV so that I can learn more about what functionality is currently available.
		 //* As per email from Tester dated 5/12/2015 this test case is no longer applicable, hence commenting it out.
		
		@Test
		public void TSAAP029VerifyPrescriptionRefillLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_MYHealthVetPrescriptionRefill();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyFaqsHomePrescriptionRefillurl();	
		}
         
		
		 //* Test Case Name: TS-AAP-030 Verify "Prescription Refill" menu item
		 //* Test Objective: As a user, I want to access FAQs related to prescription refills  in MHV so that I can learn more about what functionality is currently available.
		 //* As per email from Tester dated 5/12/2015 this test case is no longer applicable, hence commenting it out.

		@Test
		public void TSAAP030VerifyPrescriptionRefillMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_MYHealthVetPrescriptionRefill();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyFaqsHomePrescriptionRefillurl();	
		} 

		
		 //* Test Case Name: TS-AAP-031 Verify "FAQ - VA National Medication Formulary" link
		 //* Test Objective: As a user, I want to access FAQs related to prescription refills  in MHV so that I can learn more about what functionality is currently available.
		 	
		
		@Test
		public void TSAAP031VerifyFAQVANationalMedicationFormularyLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_FAQVANationalMedicationFormulary();
			newTrustedMedicationResoucePage.verifyVANationalFormularyurl();
		}

		
		 //* Test Case Name: TS-AAP-032 Verify "FAQ - VA National Medication Formulary" menu item
		 //* Test Objective: As a User, I need access to FAQs related to the VA National Formulary for medications so that I will be able to view and share VA formulary information when I and/or my providers are determining the best available therapies for a treatment regiment.
		 	

		@Test
		public void TSAAP032VerifyFAQVANationalMedicationFormularyMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_FAQVANationalMedicationFormulary();
			//newTrustedMedicationResoucePage.verifyVANationalFormularyurl();
		}
		
		
		// * Test Case Name: TS-AAP-033 Verify "Presciption Tracking" link
		// * Test Objective: As a User, I want the ability to learn more about Rx Tracking through My HealtheVet so that I know what functionality is currently available.
		 	
	
		@Test
		public void TSAAP033VerifyPresciptionTrackingLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_PrescriptionTracker();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyPrescriptionTrackerurl();	
		}
	
		
		// * Test Case Name: TS-AAP-034 Verify "Prescription Tracking" menu item
		// * Test Objective: As a User, I want the ability to learn more about Rx Tracking through My HealtheVet so that I know what functionality is currently available.
		 	
	
		@Test
		public void TSAAP034VerifyPrescriptionTrackingMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);;
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_TrackMyMedications();
			newTrackMyMedicationPage.click_PrescriptionTracker();
			//newTrackMyMedicationPage.verifyExternalPage();
			//newTrackMyMedicationPage.verifyPrescriptionTrackerurl();	
		}	
	
		
		 //* Test Case Name: TS-AAP-035 Verify "RX Refill Guide" link
		 //* Test Objective: As a User, I need the ability to access general information on VA prescription refill so that I can learn more about the prescription refill tracking  process.
		 	
	
		@Test
		public void TSAAP035VerifyRXRefillGuideLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_RxRefillGuide();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newmyHealthVetPharmacyServicesPage.verifyRxRefillGuideLink();		
		}	
	
		
		// * Test Case Name: TS-AAP-036 Verify "RX Refill Guide" menu item
		// * Test Objective: As a User, I need the ability to access general information on VA prescription refill so that I can learn more about the prescription refill tracking  process.
		 	
	
		@Test
		public void TSAAP036VerifyRXRefillGuideMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_RxRefillGuide();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newmyHealthVetPharmacyServicesPage.verifyRxRefillGuideLink();		
		}		

		
		 //* Test Case Name: TS-AAP-037 Verify "Medication Disposal" link
		// * Test Objective: As a User, I need access to information on how to properly dispose of medications so that I can dispose of any medications safely.
		 	

		@Test
		public void TSAAP037VerifyMedicationDisposalLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_MedicationDisposal();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newTrustedMedicationResoucePage.verifyVACenterForMedicationSafetyPrescriptionsurl();	
		}

		
		 //* Test Case Name: TS-AAP-038 Verify "Medication Disposal" menu item
		 //* Test Objective: As a User, I need access to information on how to properly dispose of medications so that I can dispose of any medications safely.
		 	

		@Test
		public void TSAAP038VerifyMedicationDisposalMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_MedicationDisposal();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newTrustedMedicationResoucePage.verifyVACenterForMedicationSafetyPrescriptionsurl();	
		}	

		
		 //* Test Case Name: TS-AAP-039 Verify "How to properly administer a medication" link
		 //* Test Objective: As a User, I need access to information on how to properly administer a medication so that I can ensure I am taking my medication correctly.
		 	
		
		@Test
		@Ignore
		public void TSAAP039VerifyHowToProperlyAdministerAMedicationLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_MedicationAdministration();
			newMedicalAdministrationPage.click_HowToProperlyAdministerAMedication();
			//newMedicalAdministrationPage.verifyExternalPage();
			//newMedicalAdministrationPage.verifyHowToAdministerurl();	
		}	

		
		 //* Test Case Name: TS-AAP-040 Verify "How to properly administer a medication" menu item
		 //* Test Objective: As a User, I need access to information on how to properly administer a medication so that I can ensure I am taking my medication correctly.
		 	

		@Test
		public void TSAAP040VerifyHowToProperlyAdministerAMedicationMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_MedicationAdministration();
			//newMedicalAdministrationPage.click_HowToProperlyAdministerAMedication();
			//newMedicalAdministrationPage.verifyExternalPage();
			//newMedicalAdministrationPage.verifyHowToAdministerurl();	
		}		

		
		 //* Test Case Name: TS-AAP-041 Verify "Report adverse drug events to FDA MedWatch" link
		 //* Test Objective: As a User, I need the ability to report adverse drug events so that I can report and/or review events related to drugs I am taking. (FDA Medwatch)
		 	

		@Test
		public void TSAAP041VerifyReportAdverseDrugEventsToFDAMedWatchLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_DrugInteractions();
			Thread.sleep(3000);
			//newDrugInteractionsAndAdverseDrugEvents.click_ReportadversedrugeventstoFDAMedWatch();
			//newDrugInteractionsAndAdverseDrugEvents.verifyExternalPage();
			//newDrugInteractionsAndAdverseDrugEvents.verifyMedWatcheLink();	
		}	
	
		
		 //* Test Case Name: TS-AAP-042 Verify "Report adverse drug events to FDA MedWatch" menu item
		 //* Test Objective: As a User, I need the ability to report adverse drug events so that I can report and/or review events related to drugs I am taking. (FDA Medwatch)
		 	
	
		@Test
		public void TSAAP042VerifyReportAdverseDrugEventsToFDAMedWatchMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_DrugInteractions();
			//newDrugInteractionsAndAdverseDrugEvents.click_ReportadversedrugeventstoFDAMedWatch();
			//newDrugInteractionsAndAdverseDrugEvents.verifyExternalPage();
			//newDrugInteractionsAndAdverseDrugEvents.verifyMedWatcheLink();	
		}	

		
		 //* Test Case Name: TS-AAP-043 Verify " Track adverse drug events in FDA MedWatch" link
		 //* Test Objective: As a User, I need the ability to track adverse drug events so that I can report and/or review events related to drugs I am taking.
		 	
		
		@Test
		public void TSAAP043VerifyTrackAdverseDrugEventsInFDAMedWatchLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_DrugInteractions();
			newDrugInteractionsAndAdverseDrugEvents.click_AdverseDrugEventInformation();
			newAdverseDrugEventInformation.click_TrackadversedrugeventsinFDA();
			//newAdverseDrugEventInformation.verifyExternalPage(); 
			//newAdverseDrugEventInformation.verifyUSFoodAndDrugAdministrationLink();	
		    }

		
		 //* Test Case Name: TS-AAP-044 Verify " Track adverse drug events in FDA MedWatch" menu item
		 //* Test Objective: As a User, I need the ability to track adverse drug events so that I can report and/or review events related to drugs I am taking.
		 	
		
		@Test
		public void TSAAP044VerifyTrackAdverseDrugEventsInFDAMedWatchMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_DrugInteractions();
			newDrugInteractionsAndAdverseDrugEvents.click_AdverseDrugEventInformation();
			//newAdverseDrugEventInformation.click_TrackadversedrugeventsinFDA();
			//newAdverseDrugEventInformation.verifyExternalPage(); 
			//newAdverseDrugEventInformation.verifyUSFoodAndDrugAdministrationLink();	
		    }
	
		
		 //* Test Case Name: TS-AAP-045 Verify "Medications: Keep Track and Play It Safe" link
		 //* Test Objective: As a User, I want to access the medication article "Medications: Keep Track and Play It Safe" on MyHealtheVet so that I can educate myself on their use and other important information.
		 	
		
		@Test
		public void TSAAP045VerifyMedicationsKeepTrackAndPlayItSafeLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			Thread.sleep(3000);
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationsKeepTrackAndPlayItSafe();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//ewMedicationArticlesOnMyHealtheVetPage.MyHealtheVetMedicationsKeepTrackAndPlayItSafeurl();
		    }
		
		
		 //* Test Objective: As a User, I want to access the medication article "Medications: Keep Track and Play It Safe" on MyHealtheVet so that I can educate myself on their use and other important information..
		 	

		@Test
		public void TSAAP046VerifyMedicationsKeepTrackAndPlayItSafeMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationsKeepTrackAndPlayItSafe();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.MyHealtheVetMedicationsKeepTrackAndPlayItSafeurl();
		}

		
		// * Test Case Name: TS-AAP-047 Verify "Navigating Your Way to Good Health: Finding Reliable Information Online" link
		// * Test Objective: As a User, I want to access the medication article "Navigating Your Way to Good Health: Finding Reliable Information Online" on MyHealtheVet so that I can educate myself on their use and other important information.
		 	

		@Test
		public void TSAAP047VerifyNavigatingYourWayToGoodHealthFindingReliableInformationOnlinelink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			Thread.sleep(3000);
			newMedicationArticlesOnMyHealtheVetPage.click_NavigatingYourWayToGoodHealthFindingReliableInformationOnline();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.MyHealtheVetNavigatingYourWayToGoodHealthFindingReliableInformationOnlineurl();
		    }

		
		// * Test Case Name: TS-AAP-048 Verify "Navigating Your Way to Good Health: Finding Reliable Information Online" menu item
		// * Test Objective: As a User, I want to access the medication article "Navigating Your Way to Good Health: Finding Reliable Information Online" on MyHealtheVet so that I can educate myself on their use and other important information..
		 	

		@Test
		
		public void TSAAP048VerifyNavigatingYourWayToGoodHealthFindingReliableInformationOnlineMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_NavigatingYourWayToGoodHealthFindingReliableInformationOnline();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.MyHealtheVetNavigatingYourWayToGoodHealthFindingReliableInformationOnlineurl();
		    }	

		
		 //* Test Case Name: TS-AAP-049 Verify "Thinking about Quitting Smoking? - Medications Can Help" link
		 //* Test Objective: As a User, I want to access the medication article "Thinking about Quitting Smoking? - Medications Can Help" on MyHealtheVet so that I can educate myself on their use and other important information.
		 	
		
		@Test
		public void TSAAP049VerifyThinkingAboutQuittingSmokingMedicationsCanHelpLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			//newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			//newMedicationArticlesOnMyHealtheVetPage.click_ThinkingAboutQuittingSmokingMedicationsCanHelp();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyThinkingAboutQuittingSmokingMedicationsCanHelpurl();
		    }	
		
		/*
		 * Test Case Name: TS-AAP-050 Verify "Thinking about Quitting Smoking? - Medications Can Help" menu item
		 * Test Objective: As a User, I want to access the medication article "Thinking about Quitting Smoking? - Medications Can Help" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	

		@Test
		public void TSAAP050VerifyThinkingAboutQuittingSmokingMedicationsCanHelpMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			//newMedicationArticlesOnMyHealtheVetPage.click_ThinkingAboutQuittingSmokingMedicationsCanHelp();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyThinkingAboutQuittingSmokingMedicationsCanHelpurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-051 Verify "Medications: Playing it Safe at Home" link
		 * Test Objective: As a User, I want to access the medication article "Medications: Playing it Safe at Home" on MyHealtheVet so that I can educate myself on their use and other important information..
		 */	
		
		@Test
		public void TSAAP051VerifyMedicationsPlayingItSafeAtHomeLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			Thread.sleep(3000);
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationsPlayingItSafeAtHome();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicationsPlayingItSafeAtHomeurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-052 Verify "Medications: Playing it Safe at Home" menu item
		 * Test Objective: As a User, I want to access the medication article "Medications: Playing it Safe at Home" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP052VerifyMedicationsPlayingItSafeAtHomeMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationsPlayingItSafeAtHome();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicationsPlayingItSafeAtHomeurl();
		}	

		/*
		 * Test Case Name: TS-AAP-053 Verify "Medication Check Up" link
		 * Test Objective: As a User, I want to access the medication article "Medication Check Up" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP053VerifyMedicationCheckUpLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationCheckUp();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicationCheckUpurl();
		    }

		/*
		 * Test Case Name: TS-AAP-054 Verify "Medication Check Up" menu item
		 * Test Objective: As a User, I want to access the medication article "Medication Check Up" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP054VerifyMedicationCheckUpMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationCheckUp();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicationCheckUpurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-055 Verify "Medicine Cabinet Full? Too Many Pills?" link
		 * Test Objective: As a User, I want to access the medication article "Medicine Cabinet Full? Too Many Pills?" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	

		@Test
		public void TSAAP055VerifyMedicineCabinetFullTooManyPills() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicineCabinetFullTooManyPills();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicineCabinetFullTooManyPillsurl();
		    }

		/*
		 * Test Case Name: TS-AAP-056 Verify "Medicine Cabinet Full? Too Many Pills?" menu item
		 * Test Objective: As a User, I want to access the medication article "Medicine Cabinet Full? Too Many Pills?" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP056VerifyMedicineCabinetFullTooManyPillsMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			//Thread.sleep(3000);
			//newMedicationArticlesOnMyHealtheVetPage.click_MedicineCabinetFullTooManyPills();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicineCabinetFullTooManyPillsurl();
		    }

		/*
		 * Test Case Name: TS-AAP-057 Verify "Check Your Medications: A Prescription for Better Health" link
		 * Test Objective: As a User, I want to access the medication article "Check Your Medications: A Prescription for Better Health" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP057VerifyCheckYourMedicationsAPrescriptionForBetterHealthLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_CheckYourMedicationsAPrescriptionForBetterHealth();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyCheckYourMedicationsAPrescriptionForBetterHealthurl();
		    }
	
		/*
		 * Test Case Name: TS-AAP-058 Verify "Check Your Medications: A Prescription for Better Health" menu item
		 * Test Objective: As a User, I want to access the medication article "Check Your Medications: A Prescription for Better Health" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
	
		@Test
		public void TSAAP058VerifyCheckYourMedicationsAPrescriptionForBetterHealthMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_CheckYourMedicationsAPrescriptionForBetterHealth();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyCheckYourMedicationsAPrescriptionForBetterHealthurl();
		    }		
		
		/*
		 * Test Case Name: TS-AAP-059 Verify "Medication Disposal Safety Tips" link
		 * Test Objective: As a User, I want to access the medication article "Medication Disposal Safety Tips" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	

		@Test
		public void TSAAP059VerifyMedicationDisposalSafetyTipsLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationDisposalSafetyTips();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicationDisposalSafetyTipsurl();
		    }	
		
		/*
		 * Test Case Name: TS-AAP-060 Verify "Medication Disposal Safety Tips" menu item
		 * Test Objective: As a User, I want to access the medication article "Medication Disposal Safety Tips" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	

		@Test
		public void TSAAP060VerifyMedicationDisposalSafetyTipsMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_MedicationDisposalSafetyTips();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyMedicationDisposalSafetyTipsurl();
		    }		

		/*
		 * Test Case Name: TS-AAP-061 Verify "VA's Mail-Order Pharmacy Program Recognized 2011" link
		 * Test Objective: As a User, I want to access the medication article "VA's Mail-Order Pharmacy Program Recognized 2011" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP061VerifyVAMailOrderPharmacyProgramRecognized2011Link() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_VAMailOrderPharmacyProgramRecognized2011();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyVAMailOrderPharmacyProgramRecognized2011url();
		    }	
		
		/*
		 * Test Case Name: TS-AAP-062 Verify "VA's Mail-Order Pharmacy Program Recognized 2011" menu item
		 * Test Objective: As a User, I want to access the medication article "VA's Mail-Order Pharmacy Program Recognized 2011" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP062VerifyVAMailOrderPharmacyProgramRecognized2011MenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_VAMailOrderPharmacyProgramRecognized2011();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyVAMailOrderPharmacyProgramRecognized2011url();
		    }	

		/*
		 * Test Case Name: TS-AAP-063 Verify "Updated Immunization Recommendations" link
		 * Test Objective: As a User, I want to access the medication article "Updated Immunization Recommendations" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP063VerifyUpdatedImmunizationRecommendationsLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			//newMedicationArticlesOnMyHealtheVetPage.click_WhatVaccinesDoYouNeed();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyUpdatedImmunizationRecommendationurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-064 Verify "Updated Immunization Recommendations" menu item
		 * Test Objective: As a User, I want to access the medication article "Updated Immunization Recommendations" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		@Ignore
		public void TSAAP064VerifyUpdatedImmunizationRecommendationsMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(30000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_WhatVaccinesDoYouNeed();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifyUpdatedImmunizationRecommendationurl();
		    }		

		/*
		 * Test Case Name: TS-AAP-065 Verify "Sharing Your Health Information" link
		 * Test Objective: As a User, I want to access the medication article "Sharing Your Health Information" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP065VerifySharingYourHealthInformationLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_SharingYourHealthInformation();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifySharingYourHealthInformationrl();
		    }	
		
		/*
		 * Test Case Name: TS-AAP-066 Verify "Sharing Your Health Information" menu item
		 * Test Objective: As a User, I want to access the medication article "Sharing Your Health Information" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
	
		@Test
		@Ignore
		public void TSAAP066VerifySharingYourHealthInformationMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_SharingYourHealthInformation();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verifySharingYourHealthInformationrl();
		    }	

		/*
		 * Test Case Name: TS-AAP-067 Verify "Viewing your VA Medication Names" link
		 * Test Objective: As a User, I want to access the medication article "Viewing your VA Medication Names" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
	
		public void TSAAP067VerifyViewingYourVAMedicationNamesLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_ViewingYourVAMedicationNames();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verify_ViewingYourVAMedicationNamesurl();
		    }

		/*
		 * Test Case Name: TS-AAP-068 Verify "Viewing your VA Medication Names" menu item
		 * Test Objective: As a User, I want to access the medication article "Viewing your VA Medication Names" on MyHealtheVet so that I can educate myself on their use and other important information.
		 */	
		
		@Test
		public void TSAAP068VerifyViewingYourVAMedicationNamesMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			//newMedicationArticlesOnMyHealtheVetPage.click_ViewingYourVAMedicationNames();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.verify_ViewingYourVAMedicationNamesurl();
		    }
		
		/*
		 * Test Case Name: TS-AAP-069 Verify "Food and Drug Administration" link
		 * Test Objective: As a User, I want access to Food and Drug Administration drug information resources so that I can educate myself on drug information for consumers that may apply to me.
		 */	

		@Test
		public void TSAAP069VerifyFoodAndDrugAdministrationLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_Medication();
			newMedicationPage.click_FoodAndDrugAdministration();
			//newMedicationPage.verifyExternalPage();
			//newMedicationPage.verifyUSFDAInforamtionForCustomerurl();
		    }

		/*
		 * Test Case Name: TS-AAP-070 Verify "Food and Drug Administration" menu item
		 * Test Objective: As a User, I want access to Food and Drug Administration drug information resources so that I can educate myself on drug information for consumers that may apply to me.
		 */	
		
		@Test
		public void TSAAP070VerifyFoodAndDrugAdministrationMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_Medication();
			newMedicationPage.click_FoodAndDrugAdministration();
			//newMedicationPage.verifyExternalPage();
			//newMedicationPage.verifyUSFDAInforamtionForCustomerurl();
		    }

		/*
		 * Test Case Name: TS-AAP-071 Verify "Medline Plus"link
		 * Test Objective: As a User, I want access to Medline Plus drug information resources so that I can educate myself on drugs, supplements, and herbal information that may apply to me.
		 */	
		
		@Test
		public void TSAAP071VerifyMedlinePluslink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_Medication();
			newMedicationPage.click_MedlinePlus();
			//newMedicationPage.verifyExternalPage();
			//newMedicationPage.verifyMedlinePlusurl();
		    }

		/*
		 * Test Case Name: TS-AAP-072 Verify "Medline Plus" menu item
		 * Test Objective: As a User, I want access to Medline Plus drug information resources so that I can educate myself on drugs, supplements, and herbal information that may apply to me.
		 */	
		
		@Test
		public void TSAAP072VerifyMedlinePlusMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_Medication();
			newMedicationPage.click_MedlinePlus();
			//newMedicationPage.verifyExternalPage();
			//newMedicationPage.verifyMedlinePlusurl();
		    }

		/*
		 * Test Case Name: TS-AAP-073 Verify "MyHealtheVet" link
		 * Test Objective: As a User, I want access to MyHealtheVet drug information resources so that I can educate myself on medication information that may apply to me.
		 */	
		
		@Test
		public void TSAAP073VerifyMyHealtheVetLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_MedicationAndHealth();
			//newMedicationAndHealthPage.click_VeteranHealthLibrary();
			//newMedicationAndHealthPage.verifyExternalPage();
			//newMedicationAndHealthPage.verifyDVAVeteranHealthLibraryurl();
		    }

		/*
		 * Test Case Name: TS-AAP-074 Verify"MyHealtheVet" menu item
		 * Test Objective: As a User, I want access to MyHealtheVet drug information resources so that I can educate myself on medication information that may apply to me.
		 */	
		
		@Test
		public void TSAAP074VerifyMyHealtheVetMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_MedicationAndHealth();
			newMedicationAndHealthPage.click_VeteranHealthLibrary();
			//newMedicationAndHealthPage.verifyExternalPage();
			//newMedicationAndHealthPage.verifyDVAVeteranHealthLibraryurl();
		    }
	
		/*
		 * Test Case Name: TS-AAP-079 Verify "Medicine Safety: A Toolkit for Families" link
		 * Test Objective: As a User, I want access to A Toolkit for Families drug information resources so that I can educate myself on medicine safety information that may apply to me.
		 */	
		
		@Test
		public void TSAAP079VerifyMedicineSafetyAToolkitFoFamiliesLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_MedicineSafetyAToolkitForFamilies();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifyMedicineSafetyAToolkitForFamiliesurl();
		    }

		/*
		 * Test Case Name: TS-AAP-080 Verify "Medicine Safety: A Toolkit for Families" menu item
		 * Test Objective: As a User, I want access to A Toolkit for Families drug information resources so that I can educate myself on medicine safety information that may apply to me.
		 */	
		
		@Test
		public void TSAAP080VerifyMedicineSafetyAToolkitForFamiliesMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_MedicineSafetyAToolkitForFamilies();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifyMedicineSafetyAToolkitForFamiliesurl();
		    }

		/*
		 * Test Case Name: TS-AAP-081 Verify "Medication Tips & Tools on Safemedication.com" link
		 * Test Objective: As a User, I want access to Safemedication.com drug information resources so that I can educate myself on medication tips & tools information that may apply to me.
		 */	
		
		@Test
		public void TSAAP081VerifyMedicationTipsAndToolsOnSafemedicationlink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_MedicationTipsToolsOnSafemedicationCom();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifyMedicationTipsToolsOnSafemedicationComurl();
		    }
	
		/*
		 * Test Case Name: TS-AAP-082 Verify "Medication Tips & Tools on Safemedication.com" menu item
		 * Test Objective: As a User, I want access to Safemedication.com drug information resources so that I can educate myself on medication tips & tools information that may apply to me.
		 */	
		
		@Test
		public void TSAAP082VerifyMedicationTipsAndToolsOnSafemedicationMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_MedicationTipsToolsOnSafemedicationCom();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifyMedicationTipsToolsOnSafemedicationComurl();
		    }

		/*
		 * Test Case Name: TS-AAP-083 Verify "Safe Disposal of Medicines on FDA" link
		 * Test Objective: As a User, I want access to Food and Drug Administration drug information resources so that I can educate myself on safe disposal of medicines information that may apply to me.
		 */	
		
		@Test
		public void TSAAP083VerifySafeDisposalOfMedicinesOnFDALink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_SafeDisposalOfMedicinesOnFDA();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifySafeDisposalOfMedicinesOnFDAurl();
		    }

		/*
		 * Test Case Name: TS-AAP-084 Verify  "Safe Disposal of Medicines on FDA" menu item
		 * Test Objective: As a User, I want access to Food and Drug Administration drug information resources so that I can educate myself on safe disposal of medicines information that may apply to me.
		 */	
		
		@Test
		public void TSAAP084VerifySafeDisposalOfMedicinesOnFDAMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_SafeDisposalOfMedicinesOnFDA();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifySafeDisposalOfMedicinesOnFDAurl();
		    }

		/*
		 * Test Case Name: TS-AAP-085 Verify "VA Center for Medication Safety" link
		 * Test Objective: As a User, I want access to VA Center for Medication Safety drug information resources so that I can educate myself on drugs, supplements, and herbal information that may apply to me.
		 */	
		
		@Test
		public void TSAAP085VerifyVACenterForMedicationSafetyLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			newSafetyPracticePage.click_VACenterForMedicationSafety();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifyVACenterForMedicationSafetyurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-086 Verify "VA Center for Medication Safety" menu item
		 * Test Objective: As a User, I want access to VA Center for Medication Safety drug information resources so that I can educate myself on drugs, supplements, and herbal information that may apply to me.
		 */	
		
		@Test
		@Ignore
		public void TSAAP086VerifyVACenterForMedicationSafetyMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			//newConsumerDrugHerbalSupplementInformationPage.click_SafetyPractice();
			//newSafetyPracticePage.click_VACenterForMedicationSafety();
			//newSafetyPracticePage.verifyExternalPage();
			//newSafetyPracticePage.verifyVACenterForMedicationSafetyurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-087 Verify "FDA Medwatch" link
		 * Test Objective: As a User, I want access to FDA MedWatch drug information resources so that I can educate myself on adverse event reporting program provides information on how to report medication safety alerts information that may apply to me.
		 */	
		
		@Test
		public void TSAAP087VerifyFDAMedwatchLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_ReportingMedicationErrors();
			newReportingMedicationErrorPage.click_FDAMedWatch();
			//newReportingMedicationErrorPage.verifyExternalPage();
			//newReportingMedicationErrorPage.verifyFDAMedWatchurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-088 Verify "FDA Medwatch" menu item
		 * Test Objective: As a User, I want access to FDA MedWatch drug information resources so that I can educate myself on adverse event reporting program provides information on how to report medication safety alerts information that may apply to me.
		 */	
		
		@Test
		public void TSAAP088VerifyFDAMedwatchMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			newHomePage.trustedMedicationResourcesUnderFeature();
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			newConsumerDrugHerbalSupplementInformationPage.click_ReportingMedicationErrors();
			newReportingMedicationErrorPage.click_FDAMedWatch();
			//newReportingMedicationErrorPage.verifyExternalPage();
			//newReportingMedicationErrorPage.verifyFDAMedWatchurl();
		    }

		/*
		 * Test Case Name: TS-AAP-089 Verify "Report A Medication Error" link
		 * Test Objective: As a User, I want access to Institute for Safe Medication Practices drug information resources so that I can educate myself on reporting medication error information that may apply to me.
		 */	
		
		@Test
		public void TSAAP089VerifyReportAMedicationErrorLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_ReportingMedicationErrors();
			newReportingMedicationErrorPage.click_ReportAMedicationError();
			//newReportingMedicationErrorPage.verifyExternalPage();
			//newReportingMedicationErrorPage.verifyReportAMedicationErrorurl();
		    }

		/*
		 * Test Case Name: TS-AAP-090 Verify "Report A Medication Error" menu item
		 * Test Objective: As a User, I want access to Institute for Safe Medication Practices drug information resources so that I can educate myself on reporting medication error information that may apply to me.
		 */	
		
		@Test
		public void TSAAP090VerifyReportAMedicationErrorMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_ReportingMedicationErrors();
			newReportingMedicationErrorPage.click_ReportAMedicationError();
			//newReportingMedicationErrorPage.verifyExternalPage();
			//newReportingMedicationErrorPage.verifyReportAMedicationErrorurl();
		    }

		/*
		 * Test Case Name: TS-AAP-091 Verify "Free Medication Alerts" link
		 * Test Objective: As a User, I want access to Institute for Safe Medication Practices drug information resources so that I can educate myself on free medication alert information that may apply to me.
		 */	
		
		@Test
		public void TSAAP091VerifyFreeMedicationAlertsLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_GetTheLatestSafetyArticlesOnMedicationsPage();
			newGetTheLatestSafetyArticlesOnMedicationsPage.click_FreeMedicationAlerts();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyExternalPage();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyFreeMedicationAlertsurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-092 Verify "Free Medication Alerts" menu item
		 * Test Objective: As a User, I want access to Institute for Safe Medication Practices drug information resources so that I can educate myself on free medication alert information that may apply to me.
		 */	
		
		@Test
		public void TSAAP092VerifyFreeMedicationAlertsMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_GetTheLatestSafetyArticlesOnMedicationsPage();
			newGetTheLatestSafetyArticlesOnMedicationsPage.click_FreeMedicationAlerts();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyExternalPage();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyFreeMedicationAlertsurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-093 Verify "Recalls, Market Withdrawals, & Safety Alerts on FDA" link
		 * Test Objective: As a User, I want access to Food and Drug Administration drug information resources so that I can educate myself on recalls, market withdrawals, & safety alert information that may apply to me.
		 */	
		
		@Test
		public void TSAAP093VerifyRecallsMarketWithdrawalsAndSafetyAlertsOnFDALink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResourcesicon();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_GetTheLatestSafetyArticlesOnMedicationsPage();
			newGetTheLatestSafetyArticlesOnMedicationsPage.click_RecallsMarketWithdrawalsAndSafetyAlertsOnFDA();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyExternalPage();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyRecallsMarketWithdrawalsAndSafetyAlertsOnFDAurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-094 Verify "Recalls, Market Withdrawals, & Safety Alerts on FDA" menu item
		 * Test Objective: As a User, I want access to Food and Drug Administration drug information resources so that I can educate myself on recalls, market withdrawals, & safety alert information that may apply to me.
		 */	
		
		@Test
		@Ignore
		public void TSAAP094VerifyRecallsMarketWithdrawalsAndSafetyAlertsOnFDAMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.trustedMedicationResourcesUnderFeature();
			Thread.sleep(3000);
			newTrustedMedicationResoucePage.click_ConsumerDrugHerbalSupplementInformation();
			Thread.sleep(3000);
			newConsumerDrugHerbalSupplementInformationPage.click_GetTheLatestSafetyArticlesOnMedicationsPage();
			newGetTheLatestSafetyArticlesOnMedicationsPage.click_RecallsMarketWithdrawalsAndSafetyAlertsOnFDA();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyExternalPage();
			//newGetTheLatestSafetyArticlesOnMedicationsPage.verifyRecallsMarketWithdrawalsAndSafetyAlertsOnFDAurl();
		    }	

		/*
		 * Test Case Name: TS-AAP-095 Verify "Medical Library" link
		 * Test Objective: As a User, I want access to MyHealtheVet drug information resources so that I can educate myself on medical library information that may apply to me.
		 */	
		
		@Test
		public void TSAAP095VerifyMedicalLibraryLink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.click_myHealthVetPharmacyServicesicon();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicalLibrary();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newmyHealthVetPharmacyServicesPage.verifyMYHEVMedicalLibraryLinkurl();
		    }	
	
		/*
		 * Test Case Name: TS-AAP-096 Verify "Medical Library" menu item
		 * Test Objective: As a User, I want access to MyHealtheVet drug information resources so that I can educate myself on medical library information that may apply to me.
		 */	
	
		@Test
		public void TSAAP096VerifyMedicalLibraryMenuItem() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicalLibrary();
			//newmyHealthVetPharmacyServicesPage.verifyExternalPage();
			//newmyHealthVetPharmacyServicesPage.verifyMYHEVMedicalLibraryLinkurl();
		}

		
		/*
		 * Test Case Name: TS-AAP-099 Verify navigation upon return from external sites
		 * Test Objective: As a User, I want to be returned to the Ask A Pharmacist mobile application after I navigate to an external site so that I can seamlessly continue using the Ask A Pharmacist mobile application once I am finished with an external site.
		 */	
		
		@Test
		public void TSAAP099VerifyNavigationUponReturnFromExternalSites() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.myHealthVetPharmacyServicesUnderFeature();
			Thread.sleep(3000);
			newmyHealthVetPharmacyServicesPage.click_MedicationArticlesOnMyHealth();
			newMedicationArticlesOnMyHealtheVetPage.click_NavigatingYourWayToGoodHealthFindingReliableInformationOnline();
			//newMedicationArticlesOnMyHealtheVetPage.verifyExternalPage();
			//newMedicationArticlesOnMyHealtheVetPage.GoBackBrowserButton();
		}
        
		/*
		 * Test Case Name: TS-AAP-101 Verify  Secure Messaging link 
		 * Test Objective: As a User, I want the ability to log in to Secure Messaging (SM) from a mobile device so that I can communicate with my pharmacy staff.
		 */	
	
		@Test
		public void TSAAP101VerifySecureMessaginglink() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.sendsecureMessageicon();
			//newHomePage.verifyExternalPage();
			//newHomePage.verify_MHVHomeurl();
			//newHomePage.verify_ViewingYourVAMedicationNamesurl();
		}
		
		/*
		 * Test Case Name: TS-AAP-102 Verify  Secure Messaging link - menu
		 * Test Objective: As a User, I want the ability to log in to Secure Messaging (SM) from a mobile device so that I can communicate with my pharmacy staff.
		 */	
		
		@Test
		public void TSAAP102VerifySecureMessagingLinkMenu() throws Exception{
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newLandingPage.clickFeaturesTab();
			Thread.sleep(3000);
			newHomePage.sendSecureMessageUnderFeature();
			//newHomePage.verifyExternalPage();
			//newHomePage.verify_MHVHomeurl();
			//newHomePage.verify_ViewingYourVAMedicationNamesurl();
		}
		
		
		
		
		
		
	/*
	 * The following test is related to the Manual Test Case # TS-AAP-430 
	 * As a User, I need to know what the information on my pill bottle  
	 * means so that I am knowledgeable about my medications.
	 
		@Test
		public void TSAAP430VerifyPillBottleInformation() throws Exception{
			
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage()
			.verifyPillBottleInformationLink();
		
		    
		}
		*/
		/*
		 * The following test is related to the Manual Test Case # TS-AAP-430 
		 * As a User, I need access to pill identification information 
		 * so that I can identify my medication when needed..
		 
		@Test
		public void TSAAP430_1VerifyPillBottleInformation() throws Exception{
			
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.clickPillBottleInformation()
			.verifyExternalPage();
		
		    
		}
		*/
		
		/*
		 * As a User, I need access to pill identification information so that 
		 * I can identify my medication when needed.
		 
		@Test
		public void TSAAP004_VerifyPillIdentificationMenuItem() throws Exception{
			
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.clickFeatures();
			newPillBottleInformationPage.clickPillIdentification().verifyExternalPage();
			
		
		    
		}
		*/
		
		/*
		 * As a User, I need to access information on performing drug interactions 
		 * so that I can educate myself on potential interactions
		 
		@Test
		public void TSAAP013_VerifyDrugInteractionsCheckerlink() throws Exception{
			
			newLoginPage.OpenURL(vURL);
			driver.manage().window().maximize();
			newHomePage.verifyHomePage();
			newHomePage.trustedMedicationResources();
			newPillBottleInformationPage.clickPillIdentification().verifyExternalPage();
			
		
		    
		}
		*/
}