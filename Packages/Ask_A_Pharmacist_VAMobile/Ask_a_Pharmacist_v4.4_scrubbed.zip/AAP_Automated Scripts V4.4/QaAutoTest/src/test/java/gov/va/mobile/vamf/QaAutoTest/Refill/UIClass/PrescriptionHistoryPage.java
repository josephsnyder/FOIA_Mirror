package gov.va.mobile.vamf.QaAutoTest.Refill.UIClass;

import static org.junit.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class PrescriptionHistoryPage {
	public static WebDriver driver;
	
	public PrescriptionHistoryPage(WebDriver driver){
		PrescriptionHistoryPage.driver = driver;
	}
	
	
	
	public PrescriptionHistoryPage verifyPrescriptionHistoryPage() throws Exception{
		try {
		      assertEquals("Refillable VA Medications", driver.findElement(By.xpath("//section[@id='rxr-link']/div/div[2]/a/div/strong")).getText());
		    } catch (Error e) {
		    	System.out.println("Page is not Prescription History Page");
		    }
		Thread.sleep(3000);
		
		return new PrescriptionHistoryPage(driver);
	}
}
