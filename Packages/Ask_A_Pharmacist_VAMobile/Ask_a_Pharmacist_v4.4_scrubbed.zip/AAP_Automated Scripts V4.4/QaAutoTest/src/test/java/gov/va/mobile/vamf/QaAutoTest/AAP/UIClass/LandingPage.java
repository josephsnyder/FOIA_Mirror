package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LandingPage {
	
	public static WebDriver driver;
	
	// WebElements on Home Page
	
	@FindBy(how = How.LINK_TEXT, using = "Home")
	public WebElement tabHome;
	
	@FindBy(how = How.LINK_TEXT, using = "Features")
	public WebElement tabFeatures;
	
	@FindBy(how = How.LINK_TEXT, using = "About")
	public WebElement tabAbout;
	
	@FindBy(how = How.LINK_TEXT, using = "Help")
	public WebElement tabHelp;
	
	
	public LandingPage(WebDriver driver){
		LandingPage.driver = driver;
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	/**
	 * This method is used to Click on Home Tab
	 * @author MBabalola
	 */
	public HomePage clickHomeTab() throws Exception{
		
		//tabHome.click();
		
		//driver.findElement(By.xpath(".//*[@id='aap-navbar']/ul[2]/li[1]/a")).click();
		
		driver.findElement(By.linkText("Home")).click();
		
		Thread.sleep(5000);
		return new HomePage(driver);
	}
		
	/**
	 * This method is used to Click on Features Tab
	 * @author MBabalola
	 */
	public LandingPage clickFeaturesTab() throws Exception{
		
		tabFeatures.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
		
	}
	
	/**
	 * This method is used to Click on Feature Tab
	 * @author MBabalola
	 */
	public AboutPage clickAboutTab() throws Exception{
	
		tabAbout.click();
		Thread.sleep(3000);
		return new AboutPage(driver);
	}
	
	/**
	 * This method is used to Click on Features Tab
	 * @author MBabalola
	 */
	public LandingPage clickHelpTab() throws Exception{
	
		tabHelp.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
	/**
	 * This method is used to Click on My HealtheVet Pharmacy Services
	 * @author MBabalola
	 */
	public LandingPage clickMyHealtheVetPharmServices() throws Exception{
		
		tabHelp.click();
		Thread.sleep(3000);
		return new LandingPage(driver);
	}
	
}