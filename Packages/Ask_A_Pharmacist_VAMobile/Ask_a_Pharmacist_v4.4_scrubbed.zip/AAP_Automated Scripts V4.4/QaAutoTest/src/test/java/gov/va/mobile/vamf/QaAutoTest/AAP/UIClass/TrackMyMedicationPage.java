package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class TrackMyMedicationPage {
	public static WebDriver driver;
	private boolean acceptNextAlert = true;
	private boolean isAlertPresent = true;
	public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on Track My Medication Page
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]")
	public WebElement click_MYHealthVetPrescriptionRefill;

	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
	public WebElement click_PrescriptionTracker;

	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[2]/a/span[1]/span[1]")
	public WebElement click_UPSMyChoice;
	
	@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
	public WebElement click_USPS;

	public TrackMyMedicationPage(WebDriver driver) {
		TrackMyMedicationPage.driver = driver;
	}

	
	/**
	 * This method is used to Click on USPS My Choice link
	 */
	public  TrackMyMedicationPage click_UPSMyChoice() throws Exception{
		click_UPSMyChoice.click();
		return new TrackMyMedicationPage(driver);
	}
	
	/**
	 * This method is used to Click on USPS link
	 */
	public  TrackMyMedicationPage click_USPS() throws Exception{
		click_USPS.click();
		return new TrackMyMedicationPage(driver);
	}
	
	
	/**
	 * This method is used to verify USPS link url.
	 */
	public TrackMyMedicationPage verifyUSPSurl() throws Exception{
		assertEquals("https://my.usps.com/go/pages/intro/start.action", driver.getCurrentUrl());
		return new TrackMyMedicationPage(driver);
	}
		
	/**
	 * This method is used to Click on MyHealtheVet Prescription Refill link
	 */
	public  TrackMyMedicationPage click_MYHealthVetPrescriptionRefill() throws Exception{
		click_MYHealthVetPrescriptionRefill.click();
		return new TrackMyMedicationPage(driver);
	}
	
	
	/**
	 * This method is used to verify Faqs Home Prescription Refill link url.
	 */
	public TrackMyMedicationPage verifyFaqsHomePrescriptionRefillurl() throws Exception{
		 Thread.sleep(5000);
		assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=faqsHome#PrescriptionRefill", driver.getCurrentUrl());
		return new TrackMyMedicationPage(driver);
	}

	
	/**
	 * This method is used to Click on Prescription Tracker link
	 */
   public TrackMyMedicationPage click_PrescriptionTracker() throws Exception{
		click_PrescriptionTracker.click();
	return new TrackMyMedicationPage(driver);
   }
   
   /**
    * This method is used to verify Prescription Tracker link link url.
    */
   public TrackMyMedicationPage verifyPrescriptionTrackerurl() throws Exception{
	 Thread.sleep(5000);
	assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=faqsHome#PrescriptionTracker", driver.getCurrentUrl());
	return new TrackMyMedicationPage(driver);
}
	
	
	
	public  TrackMyMedicationPage verifyExternalPage() throws Exception {
		driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
		assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
	    driver.findElement(By.id("aapLeave")).click();
	    Thread.sleep(500);
		return new  TrackMyMedicationPage(driver); 
	}
	

		public TrackMyMedicationPage verifyUSPSMYChoiceurl() throws Exception{
			assertEquals("https://www.ups.com/one-to-one/login?returnto=https%3a//www.ups.com/pea/register%3fWT.mc_id%3dUPS_Con_NeedHelp_BAM&reasonCode=-1&appid=PEA_B", driver.getCurrentUrl());
			return new TrackMyMedicationPage(driver);
		}
			
	

	
	
}


