package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverSleepDetailsPage {
private static WebDriver driver; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/h2")
	public WebElement verifySleepDetailsTitle; 
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[1]")
	public WebElement verifySleepDetailsText;
	
	@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/p[2]/em")
	public WebElement verifySleepDetailsText2;
	
	

//Sleep Section ======================================================================================================

		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")
		public WebElement click_UpAtNightCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")
		public WebElement click_DifficultyFallingAsleepCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")
		public WebElement click_DifficultyStayingAsleepCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")
		public WebElement click_SleepsExcessivelyDuringTheDayCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")
		public WebElement click_MovesExcessivelyCriesOutInSleepCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")
		public WebElement click_SnoringBreathingProblemsInSleepCheckbox; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label/input")
		public WebElement click_GoesToBedTooEarlyCheckbox; 
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverSleepDetailsPage(WebDriver driver){
			CaregiverSleepDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Sleep Details Title
	     */
	    public CaregiverSleepDetailsPage verifySleepDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Sleep Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverSleepDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Sleep Details Text
	     */
	    public CaregiverSleepDetailsPage verifySleepDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Sleep. Check all that apply.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverSleepDetailsPage(driver);
	    }
	    
//Sleep Methods ======================================================================================================
		 
	    /**
		 * This method is used to verify UpAtNight Label
		 */
		public CaregiverSleepDetailsPage verifyUpAtNightLabel() throws Exception{
			assertEquals("Up at night", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on UpAtNight Checkbox.
		 */
		public CaregiverSleepDetailsPage click_UpAtNightCheckbox() throws Exception{
			click_UpAtNightCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Up at night  Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifyUpAtNightCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[1]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify DifficultyFallingAsleep Label
		 */
		public CaregiverSleepDetailsPage verifyDifficultyFallingAsleepLabel() throws Exception{
			assertEquals("Difficulty falling asleep", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on DifficultyFallingAsleep Checkbox.
		 */
		public CaregiverSleepDetailsPage click_DifficultyFallingAsleepCheckbox() throws Exception{
			click_DifficultyFallingAsleepCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify Difficulty Falling Asleep Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifyDifficultyFallingAsleepCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[2]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify DifficultyStayingAsleep Label
		 */
		public CaregiverSleepDetailsPage verifyDifficultyStayingAsleepLabel() throws Exception{
			assertEquals("Difficulty staying asleep", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on DifficultyStayingAsleep Checkbox.
		 */
		public CaregiverSleepDetailsPage click_DifficultyStayingAsleepCheckbox() throws Exception{
			click_DifficultyStayingAsleepCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Difficulty Staying Asleep Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifyDifficultyStayingAsleepCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[3]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify SleepsExcessivelyDuringTheDay Label
		 */
		public CaregiverSleepDetailsPage verifySleepsExcessivelyDuringTheDayLabel() throws Exception{
			assertEquals("Sleeps excessively during the day", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on SleepsExcessivelyDuringTheDay Checkbox.
		 */
		public CaregiverSleepDetailsPage click_SleepsExcessivelyDuringTheDayCheckbox() throws Exception{
			click_SleepsExcessivelyDuringTheDayCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}

	    /**
		 * This method is used to verify Difficulty Staying Asleep Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifySleepsExcessivelyDuringTheDayCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[4]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}
		
		
	    /**
		 * This method is used to verify MovesExcessivelyCriesOutInSleep Label
		 */
		public CaregiverSleepDetailsPage verifyMovesExcessivelyCriesOutInSleepLabel() throws Exception{
			assertEquals("Moves excessively/cries out in sleep", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on MovesExcessivelyCriesOutInSleep Checkbox.
		 */
		public CaregiverSleepDetailsPage click_MovesExcessivelyCriesOutInSleepCheckbox() throws Exception{
			click_MovesExcessivelyCriesOutInSleepCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Moves excessively/cries out in sleep Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifyMovesExcessivelyCriesOutInSleepCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[5]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify SnoringBreathingProblemsInSleep Label
		 */
		public CaregiverSleepDetailsPage verifySnoringBreathingProblemsInSleepLabel() throws Exception{
			assertEquals("Snoring/breathing problems in sleep", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on SnoringBreathingProblemsInSleep Checkbox.
		 */
		public CaregiverSleepDetailsPage click_SnoringBreathingProblemsInSleepCheckbox() throws Exception{
			click_SnoringBreathingProblemsInSleepCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Snoring Breathing Problems In Sleep Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifySnoringBreathingProblemsInSleepCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}
			
	    /**
		 * This method is used to verify Goes to bed too early  Label
		 */
		public CaregiverSleepDetailsPage verifyGoesToBedTooEarlyLabel() throws Exception{
			assertEquals("Snoring/breathing problems in sleep", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[6]/div/label")).getText());
			return new CaregiverSleepDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on GoesToBedTooEarly Checkbox.
		 */
		public CaregiverSleepDetailsPage click_GoesToBedTooEarlyCheckbox() throws Exception{
			click_GoesToBedTooEarlyCheckbox.click();
			return new CaregiverSleepDetailsPage(driver);
		}
		
	    /**
		 * This method is used to verify Goes To Bed Too Early In Sleep Checkbox is unchcked.
		 */
		public CaregiverSleepDetailsPage verifyGoesToBedTooEarlyCheckboxUnchecked() throws Exception{
			assertEquals("off", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/fieldset/div[7]/div/label/input")).getAttribute("value"));
			return new CaregiverSleepDetailsPage(driver);
		}

//Buttons Section ===================================================================================================================
		
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverSleepDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverSleepDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverSleepDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverSleepDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverSleepDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverSleepDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverSleepDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverSleepDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverSleepDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverSleepDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverSleepDetailsPage click_ContinueButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverSleepDetailsPage(driver);
	    }
	    
	    
  //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverSleepDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverSleepDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverSleepDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverSleepDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverSleepDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverSleepDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverSleepDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverSleepDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverSleepDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverSleepDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverSleepDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverSleepDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverSleepDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverSleepDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverSleepDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverSleepDetailsPage(driver);
  		}
  		

}
