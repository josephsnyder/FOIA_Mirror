package gov.va.mobile.vamf.QaAutoTest.AAP.UIClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import static org.junit.Assert.*;

public class MyHealthVetPharmacyServicesPage {

public static WebDriver driver;
private boolean acceptNextAlert = true;
private boolean isAlertPresent = true;
public StringBuffer verificationErrors = new StringBuffer();
	
	//Web Elements on My HealtheVet Pharmacy Services Page
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[6]/a/span[1]/span[1]")
		public WebElement click_RxRefillGuide;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[5]/a/span[1]/span[1]")
		public WebElement click_RxRefill;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[8]/a/span[1]/span[1]")
		public WebElement click_TrackMyMedications;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]")
		public WebElement click_MedicationAdministration;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[4]/a/span[1]/span[1]")
		public WebElement click_PrescriptionHistoryl;

		@FindBy(how = How.XPATH, using = ".//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
		public WebElement click_MedicationArticlesOnMyHealth;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[3]/a/span[1]/span[1]")
		public WebElement click_MedicalLibrary;

		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[1]/a/span[1]/span[1]")
		public WebElement click_FAQMyHealth;
		
		@FindBy(how = How.XPATH, using = "//*[@id='aap-link']/div/div[7]/a/span[1]/span[1]")
		public WebElement click_SendASecureMessage;
		
		
		public MyHealthVetPharmacyServicesPage(WebDriver driver){
			MyHealthVetPharmacyServicesPage.driver = driver;
		}
		
		
		public MyHealthVetPharmacyServicesPage verifyMyHealthVetPharmacyServicesPage () throws Exception {
			//assertEquals("AAP", driver.getTitle());
			String titleOfPage = driver.findElement(By.xpath(".//*[@id='aap-page-title']/h1")).getText();
			//assertEquals("My HealtheVet Pharmacy Services",  driver.findElement(By.xpath("//*[@id='aap-page-title']/h1")).getText());
			assertTrue(titleOfPage.contains("My Health"));
		    Thread.sleep(1000);
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to Click on Track My Medications
		 */
		public  MyHealthVetPharmacyServicesPage click_TrackMyMedications() throws Exception{
			click_TrackMyMedications.click();
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to verify link for Track My Medications.
		 */
		public  MyHealthVetPharmacyServicesPage verifyHowDoVAPharmaciesOperateLink() throws Exception{
			assertEquals("http://vetadmin.mobilehealth.domain:8080/aap/#HowVAPharmaciesOperate", driver.getCurrentUrl());
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to Click on Medical Library
		 */
		public  MyHealthVetPharmacyServicesPage click_MedicalLibrary() throws Exception{
			click_MedicalLibrary.click();
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to verify link for My Health eVet -Medical Library
		 */
		public  MyHealthVetPharmacyServicesPage verifyMYHEVMedicalLibraryLinkurl() throws Exception{
			assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=medicalLibraryHome", driver.getCurrentUrl());
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		
		/**
		 * This method is used to Click on Medication Articles on My HealtheVet
		 */
		public  MyHealthVetPharmacyServicesPage click_MedicationArticlesOnMyHealth() throws Exception{
			click_MedicationArticlesOnMyHealth.click();
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to Click on FAQ-MYHealthVet
		 */

		
		/**
		 * This method is used to Click on RxRefill Guide
		 */
		public MyHealthVetPharmacyServicesPage click_RxRefillGuide() throws Exception{
			Thread.sleep(5000);
			click_RxRefillGuide.click();
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to verify link url for Rx Refill Guide
		 */
		public  MyHealthVetPharmacyServicesPage verifyRxRefillGuideLink() throws Exception{
			Thread.sleep(5000);
			assertEquals("https://www.myhealth.domain/mhv-portal-web/resources/jsp/help.jsp?helpDirectRequest=rxrefill_training_vets/index.htm", driver.getCurrentUrl());
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		/**
		 * This method is used to Click on FAQ-MYHealthVet
		 */
		
		public  MyHealthVetPharmacyServicesPage click_FAQMyHealths() throws Exception{
			click_FAQMyHealth.click();
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
		public  MyHealthVetPharmacyServicesPage verifyExternalPage() throws Exception {
			driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText();
			assertEquals("You are leaving Ask a Pharmacist to go to an external website.", driver.findElement(By.xpath("//*[@id='aap-modal']/div/div/p")).getText());
		    driver.findElement(By.id("aapLeave")).click();
		    Thread.sleep(5000);
			return new  MyHealthVetPharmacyServicesPage(driver); 
		}
		
		public MyHealthVetPharmacyServicesPage verifyFAQHomeurl() throws Exception{
			    Thread.sleep(4000);
				assertEquals("https://www.myhealth.domain/mhv-portal-web/anonymous.portal?_nfpb=true&_nfto=false&_pageLabel=faqsHome", driver.getCurrentUrl());
				return new MyHealthVetPharmacyServicesPage(driver);
			}
		
		/**
		 * This method is used to verify the links sequence in Alphabetical orders 
		 */
		public MyHealthVetPharmacyServicesPage VerifyAlphabeticalSequence() throws Exception{
			java.util.List<WebElement> links = driver.findElements(By.tagName("a"));
			System.out.println(links.size());
			for (int i = 1; i<=links.size(); i=i+1)
			{
				System.out.println(links.get(i).getText());
			}
			return new MyHealthVetPharmacyServicesPage(driver);
		}
		
}
