package gov.va.mobile.vamf.QaAutoTest.Grecc.UIClass;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CaregiverOverallDetailsPage {
	
	private static WebDriver driver; 

//Memory Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='overall-dropdown-1']")
		public WebElement click_MemoryDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[1]/a")
		public WebElement click_MemoryDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[2]/a")
		public WebElement click_MemoryDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[3]/a")
		public WebElement click_MemoryDropdown05Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[4]/a")
		public WebElement click_MemoryDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[5]/a")
		public WebElement click_MemoryDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[6]/a")
		public WebElement click_MemoryDropdown3Value; 
		
//Orientation (knowing correct time and place) Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='overall-dropdown-2']")
		public WebElement click_OrientationDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[1]/a")
		public WebElement click_OrientationDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[2]/a")
		public WebElement click_OrientationDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[3]/a")
		public WebElement click_OrientationDropdown05Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[4]/a")
		public WebElement click_OrientationDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[5]/a")
		public WebElement click_OrientationDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[6]/a")
		public WebElement click_OrientationDropdown3Value; 
		
		
//Judgment and Overall Problem Solving Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='overall-dropdown-3']")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[1]/a")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[2]/a")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[3]/a")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdown05Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[4]/a")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[5]/a")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[6]/a")
		public WebElement click_JudgmentAndOverallProblemSolvingDropdown3Value; 
		
		
//Community Affairs Section =======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='overall-dropdown-4']")
		public WebElement click_CommunityAffairsDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[1]/a")
		public WebElement click_CommunityAffairsDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[2]/a")
		public WebElement click_CommunityAffairsDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[3]/a")
		public WebElement click_CommunityAffairsDropdown05Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[4]/a")
		public WebElement click_CommunityAffairsDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[5]/a")
		public WebElement click_CommunityAffairsDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[6]/a")
		public WebElement click_CommunityAffairsDropdown3Value; 
		
		
//Home & Hobbies Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='overall-dropdown-5']")
		public WebElement click_HomeAndHobbiesDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[1]/a")
		public WebElement click_HomeAndHobbiesDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[2]/a")
		public WebElement click_HomeAndHobbiesDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[3]/a")
		public WebElement click_HomeAndHobbiesDropdown05Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[4]/a")
		public WebElement click_HomeAndHobbiesDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[5]/a")
		public WebElement click_HomeAndHobbiesDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[6]/a")
		public WebElement click_HomeAndHobbiesDropdown3Value; 
		
		
//Personal Care Section ======================================================================================================

		@FindBy(how = How.XPATH, using = "//*[@id='overall-dropdown-6']")
		public WebElement click_PersonalCareDropdown; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[1]/a")
		public WebElement click_PersonalCareDropdownSelectAnOptionValue; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[2]/a")
		public WebElement click_PersonalCareDropdown0Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[3]/a")
		public WebElement click_PersonalCareDropdown1Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[4]/a")
		public WebElement click_PersonalCareDropdown2Value; 
		
		@FindBy(how = How.XPATH, using = "html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[5]/a")
		public WebElement click_PersonalCareDropdown3Value; 
		
// Button Section ================================================================================================
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_cancel']")
		public WebElement click_CancelButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_reset']")
		public WebElement click_ResetButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='btn_submit']")
		public WebElement click_ContinueButton; 
		
		@FindBy(how = How.XPATH, using = "//*[@id='no']")
		public WebElement click_NoButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='yes']")
		public WebElement click_YesButtonOnPopup;
		
		@FindBy(how = How.XPATH, using = "//*[@id='alertSuccess']/a/img")
		public WebElement click_ResetPopupMessageCloseIcon;
		
//==========================================================================================================================
		public CaregiverOverallDetailsPage(WebDriver driver){
			CaregiverOverallDetailsPage.driver = driver;
		} 
		
		/**
	     * This method is used to verify Overall Details Title
	     */
	    public CaregiverOverallDetailsPage verifyOverallDetailsTitle() throws Exception{
	    	Thread.sleep(5000);
	    	assertEquals("Overall Details", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/h2")).getText());
	    	return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
	     * This method is used to verify Overall Details Text
	     */
	    public CaregiverOverallDetailsPage verifyOverallDetailsText() throws Exception{
	    	Thread.sleep(3000);
	    	assertEquals("The details provided here will help us to understand your father's current Overall.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[1]")).getText());
	    	assertEquals("If this is an emergency, call 911 or the Veterans Crisis Line at 1-800-273-8255.", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/p[2]/em")).getText());
	    	return new CaregiverOverallDetailsPage(driver);
	    }
	    
//Memory Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Memory Label
		 */
		public CaregiverOverallDetailsPage verifyMemoryLabel() throws Exception{
			assertEquals("Memory", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div/label")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Memory drop down.
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdown() throws Exception{
			Thread.sleep(1000);
			click_MemoryDropdown.click();
			Thread.sleep(1000);
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Memory category Select an option drop down value for Memory
	    */
		public CaregiverOverallDetailsPage verifyMemorySelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='overall-dropdown-1']")).getText());
			return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Memory Select an option drop value
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdownSelectAnOptionValue() throws Exception{
			click_MemoryDropdownSelectAnOptionValue.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Memory category 0 value
		*/
		public CaregiverOverallDetailsPage verifyMemorySelection0() throws Exception{
			assertEquals("0 - Normal: No memory loss or slight inconsistent forgetfulness", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[2]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Memory 0 value
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdown0Value() throws Exception{
			click_MemoryDropdown0Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Memory category 0.5 value
		*/
		public CaregiverOverallDetailsPage verifyMemorySelection05() throws Exception{
			assertEquals("0.5 - Questionable: Consistent slight forgetfulness; partial recollection of events; 'benign forgetfulness", driver.findElement(By.xpath("//a[contains(@title, '0.5 - Questionable: Consistent slight forgetfulness; partial recollection of events;')]")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Memory 0.5 value
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdown05Value() throws Exception{
			click_MemoryDropdown05Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Memory category 1 value
		*/
		public CaregiverOverallDetailsPage verifyMemorySelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: Moderate memory loss; more marked for recent events; interferes with daily life", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[4]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Memory 1 value
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdown1Value() throws Exception{
			click_MemoryDropdown1Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Memory category 2 value
		*/
		public CaregiverOverallDetailsPage verifyMemorySelection2() throws Exception{
			assertEquals("2 - Moderate: Severe memory loss; retains highly learned material; new material lost", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[5]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Memory 2 value
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdown2Value() throws Exception{
			click_MemoryDropdown2Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Memory category 3 value
		*/
		public CaregiverOverallDetailsPage verifyMemorySelection3() throws Exception{
			assertEquals("3 - Severe: Severe memory loss; only fragments remain", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[1]/div/div/ul/li[6]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Memory 3 value
		 */
		public CaregiverOverallDetailsPage click_MemoryDropdown3Value() throws Exception{
			click_MemoryDropdown3Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
	    
//Orientation (knowing correct time and place) Section Methods ======================================================================================================
		 /**
		 * This method is used to verify Orientation Label
		 */
		public CaregiverOverallDetailsPage verifyOrientationLabel() throws Exception{
			assertEquals("Orientation (knowing correct time and place)", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div/label")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Orientation drop down.
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdown() throws Exception{
			Thread.sleep(1000);
			click_OrientationDropdown.click();
			Thread.sleep(1000);
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Orientation category Select an option drop down value for Orientation
	    */
		public CaregiverOverallDetailsPage verifyOrientationSelectAnOptionValue() throws Exception{
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='overall-dropdown-2']")).getText());
			return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Orientation Select an option drop value
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdownSelectAnOptionValue() throws Exception{
			click_OrientationDropdownSelectAnOptionValue.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Orientation category 0 value
		*/
		public CaregiverOverallDetailsPage verifyOrientationSelection0() throws Exception{
			assertEquals("0 - Normal: Fully oriented", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[2]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Orientation 0 value
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdown0Value() throws Exception{
			click_OrientationDropdown0Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Orientation category 0.5 value
		*/
		public CaregiverOverallDetailsPage verifyOrientationSelection05() throws Exception{
			assertEquals("0.5 - Questionable: Slight difficulty with time relationships", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[3]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Orientation 0.5 value
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdown05Value() throws Exception{
			click_OrientationDropdown05Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Orientation category 1 value
		*/
		public CaregiverOverallDetailsPage verifyOrientationSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: Moderate difficulty with time; mild disorientation to place", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[4]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Orientation 1 value
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdown1Value() throws Exception{
			click_OrientationDropdown1Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Orientation category 2 value
		*/
		public CaregiverOverallDetailsPage verifyOrientationSelection2() throws Exception{
			assertEquals("2 - Moderate: Severe difficulty with time; moderate disorientation to place", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[5]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Orientation 2 value
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdown2Value() throws Exception{
			click_OrientationDropdown2Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify Orientation category 3 value
		*/
		public CaregiverOverallDetailsPage verifyOrientationSelection3() throws Exception{
			assertEquals("3 - Severe: Oriented only to self", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[2]/div/div/ul/li[6]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on Orientation 3 value
		 */
		public CaregiverOverallDetailsPage click_OrientationDropdown3Value() throws Exception{
			click_OrientationDropdown3Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
//Judgment and Overall Problem Solving Section Methods ======================================================================================================
		 /**
		 * This method is used to verify JudgmentAndOverallProblemSolving Label
		 */
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingLabel() throws Exception{
			assertEquals("Judgment and Overall Problem Solving", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div/label")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving drop down.
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdown() throws Exception{
			Thread.sleep(1000);
			click_JudgmentAndOverallProblemSolvingDropdown.click();
			Thread.sleep(1000);
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify JudgmentAndOverallProblemSolving category Select an option drop down value for JudgmentAndOverallProblemSolving
	    */
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='overall-dropdown-3']")).getText());
			return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving Select an option drop value
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdownSelectAnOptionValue() throws Exception{
			click_JudgmentAndOverallProblemSolvingDropdownSelectAnOptionValue.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify JudgmentAndOverallProblemSolving category 0 value
		*/
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingSelection0() throws Exception{
			assertEquals("0 - Normal: No difficulties", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[2]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving 0 value
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdown0Value() throws Exception{
			click_JudgmentAndOverallProblemSolvingDropdown0Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify JudgmentAndOverallProblemSolving category 0.5 value
		*/
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingSelection05() throws Exception{
			assertEquals("0.5 - Questionable: Slight impairment solving problems, similarities, differences", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[3]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving 0.5 value
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdown05Value() throws Exception{
			click_JudgmentAndOverallProblemSolvingDropdown05Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify JudgmentAndOverallProblemSolving category 1 value
		*/
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: Moderate difficulty with problems, similarities, differences", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[4]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving 1 value
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdown1Value() throws Exception{
			click_JudgmentAndOverallProblemSolvingDropdown1Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify JudgmentAndOverallProblemSolving category 2 value
		*/
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingSelection2() throws Exception{
			assertEquals("2 - Moderate: Severe difficulty with problems; impaired social judgment", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[5]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving 2 value
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdown2Value() throws Exception{
			click_JudgmentAndOverallProblemSolvingDropdown2Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify JudgmentAndOverallProblemSolving category 3 value
		*/
		public CaregiverOverallDetailsPage verifyJudgmentAndOverallProblemSolvingSelection3() throws Exception{
			assertEquals("3 - Severe: Unable to solve problems; unable to make social judgment", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[3]/div/div/ul/li[6]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on JudgmentAndOverallProblemSolving 3 value
		 */
		public CaregiverOverallDetailsPage click_JudgmentAndOverallProblemSolvingDropdown3Value() throws Exception{
			click_JudgmentAndOverallProblemSolvingDropdown3Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
			
//Community Affairs Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Community Affairs Label
		 */
		public CaregiverOverallDetailsPage verifyCommunityAffairsLabel() throws Exception{
			assertEquals("Community Affairs", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div/label")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Community Affairs drop down.
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdown() throws Exception{
			Thread.sleep(1000);
			click_CommunityAffairsDropdown.click();
			Thread.sleep(1000);
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Community Affairs category Select an option drop down value for CommunityAffairs
	    */
		public CaregiverOverallDetailsPage verifyCommunityAffairsSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='overall-dropdown-4']")).getText());
			return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Community Affairs Select an option drop value
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdownSelectAnOptionValue() throws Exception{
			click_CommunityAffairsDropdownSelectAnOptionValue.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Community Affairs category 0 value
		*/
		public CaregiverOverallDetailsPage verifyCommunityAffairsSelection0() throws Exception{
			assertEquals("0 - Normal: Independent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[2]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Community Affairs 0 value
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdown0Value() throws Exception{
			click_CommunityAffairsDropdown0Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify CommunityAffairs category 0.5 value
		*/
		public CaregiverOverallDetailsPage verifyCommunityAffairsSelection05() throws Exception{
			assertEquals("0.5 - Questionable: Slight impairment in job, shopping volunteer, social groups", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[3]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on CommunityAffairs 0.5 value
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdown05Value() throws Exception{
			click_CommunityAffairsDropdown05Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify CommunityAffairs category 1 value
		*/
		public CaregiverOverallDetailsPage verifyCommunityAffairsSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: Unable to function independently; may appear normal", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[4]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on CommunityAffairs 1 value
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdown1Value() throws Exception{
			click_CommunityAffairsDropdown1Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify CommunityAffairs category 2 value
		*/
		public CaregiverOverallDetailsPage verifyCommunityAffairsSelection2() throws Exception{
			assertEquals("2 - Moderate: No pretense of independent; function outside home", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[5]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on CommunityAffairs 2 value
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdown2Value() throws Exception{
			click_CommunityAffairsDropdown2Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify CommunityAffairs category 3 value
		*/
		public CaregiverOverallDetailsPage verifyCommunityAffairsSelection3() throws Exception{
			assertEquals("3 - Severe: No independent function; appears to be too ill to be taken out of home", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[4]/div/div/ul/li[6]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on CommunityAffairs 3 value
		 */
		public CaregiverOverallDetailsPage click_CommunityAffairsDropdown3Value() throws Exception{
			click_CommunityAffairsDropdown3Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
			

//Home & Hobbies Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Home & Hobbies Label
		 */
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesLabel() throws Exception{
			assertEquals("Home & Hobbies", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div/label")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Home & Hobbies drop down.
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdown() throws Exception{
			Thread.sleep(1000);
			click_HomeAndHobbiesDropdown.click();
			Thread.sleep(1000);
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Home & Hobbies category Select an option drop down value for HomeAndHobbies
	    */
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='overall-dropdown-5']")).getText());
			return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Home & Hobbies Select an option drop value
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdownSelectAnOptionValue() throws Exception{
			click_HomeAndHobbiesDropdownSelectAnOptionValue.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Home & Hobbies category 0 value
		*/
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesSelection0() throws Exception{
			assertEquals("0 - Normal: Interest well-maintained", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[2]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Home & Hobbies 0 value
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdown0Value() throws Exception{
			click_HomeAndHobbiesDropdown0Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify HomeAndHobbies category 0.5 value
		*/
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesSelection05() throws Exception{
			assertEquals("0.5 - Questionable: Interests slightly impaired", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[3]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HomeAndHobbies 0.5 value
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdown05Value() throws Exception{
			click_HomeAndHobbiesDropdown05Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HomeAndHobbies category 1 value
		*/
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: Mild but definite impairment of function at home; difficult chores abandoned; complex hobbies abandoned", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[4]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HomeAndHobbies 1 value
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdown1Value() throws Exception{
			click_HomeAndHobbiesDropdown1Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HomeAndHobbies category 2 value
		*/
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesSelection2() throws Exception{
			assertEquals("2 - Moderate: Only simple chores preserved; very restricted interests", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[5]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on HomeAndHobbies 2 value
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdown2Value() throws Exception{
			click_HomeAndHobbiesDropdown2Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify HomeAndHobbies category 3 value
		*/
		public CaregiverOverallDetailsPage verifyHomeAndHobbiesSelection3() throws Exception{
			assertEquals("3 - Severe: No significant interests", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[5]/div/div/ul/li[6]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on HomeAndHobbies 3 value
		 */
		public CaregiverOverallDetailsPage click_HomeAndHobbiesDropdown3Value() throws Exception{
			click_HomeAndHobbiesDropdown3Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
			
//Personal Care Section Methods ======================================================================================================

		 /**
		 * This method is used to verify Personal Care Label
		 */
		public CaregiverOverallDetailsPage verifyPersonalCareLabel() throws Exception{
			assertEquals("Personal Care", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div/label")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}
		
		 /**
		 * This method is used to click on Personal Care drop down.
		 */
		public CaregiverOverallDetailsPage click_PersonalCareDropdown() throws Exception{
			Thread.sleep(1000);
			click_PersonalCareDropdown.click();
			Thread.sleep(1000);
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
	    * This method is used to verify Personal Care category Select an option drop down value for PersonalCare
	    */
		public CaregiverOverallDetailsPage verifyPersonalCareSelectAnOptionValue() throws Exception{
			Thread.sleep(1000);
			assertEquals("Select an option...", driver.findElement(By.xpath("//*[@id='overall-dropdown-6']")).getText());
			return new CaregiverOverallDetailsPage(driver);
	    }
		
		 /**
		 * This method is used to click on Personal Care Select an option drop value
		 */
		public CaregiverOverallDetailsPage click_PersonalCareDropdownSelectAnOptionValue() throws Exception{
			click_PersonalCareDropdownSelectAnOptionValue.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify Personal Care category 0 value
		*/
		public CaregiverOverallDetailsPage verifyPersonalCareSelection0() throws Exception{
			assertEquals("0 - Normal: Fully capable of self care", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[2]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on Personal Care 0 value
		 */
		public CaregiverOverallDetailsPage click_PersonalCareDropdown0Value() throws Exception{
			click_PersonalCareDropdown0Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		
		/**
		* This method is used to verify PersonalCare category 1 value
		*/
		public CaregiverOverallDetailsPage verifyPersonalCareSelection1() throws Exception{
			Thread.sleep(1000);
			assertEquals("1 - Mild: Needs prompting", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[3]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PersonalCare 1 value
		 */
		public CaregiverOverallDetailsPage click_PersonalCareDropdown1Value() throws Exception{
			click_PersonalCareDropdown1Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PersonalCare category 2 value
		*/
		public CaregiverOverallDetailsPage verifyPersonalCareSelection2() throws Exception{
			assertEquals("2 - Moderate: Requires assistance in dressing, hygiene, and keeping personal effects", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[4]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
	    
		 /**
		 * This method is used to click on PersonalCare 2 value
		 */
		public CaregiverOverallDetailsPage click_PersonalCareDropdown2Value() throws Exception{
			click_PersonalCareDropdown2Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
		
		/**
		* This method is used to verify PersonalCare category 3 value
		*/
		public CaregiverOverallDetailsPage verifyPersonalCareSelection3() throws Exception{
			assertEquals("3 - Severe: Requires much help with personal care; frequently incontinent", driver.findElement(By.xpath("html/body/div[1]/section[1]/div/form/div[6]/div/div/ul/li[5]/a")).getText());
			return new CaregiverOverallDetailsPage(driver);
		}	
		
		 /**
		 * This method is used to click on PersonalCare 3 value
		 */
		public CaregiverOverallDetailsPage click_PersonalCareDropdown3Value() throws Exception{
			click_PersonalCareDropdown3Value.click();
			return new CaregiverOverallDetailsPage(driver);
		}
	    
//Buttons Section ===================================================================================================================
		
		 
		 /**
	     * This method is used to verify Cancel button.
	     */
	    public CaregiverOverallDetailsPage verifyCancelButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_cancel']")) !=null);
	    	return new CaregiverOverallDetailsPage(driver);
	    }
	    
		/**
	     * This method is used to click on Cancel button.
	     */
	    public CaregiverOverallDetailsPage click_CancelButton() throws Exception{
	    	click_CancelButton.click();
	    	return new CaregiverOverallDetailsPage(driver);
	    }

	    
		 /**
	     * This method is used to verify Reset button.
	     */
	    public CaregiverOverallDetailsPage verifyResetButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_reset']")) !=null);
	    	return new CaregiverOverallDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Reset button.
	     */
	    public CaregiverOverallDetailsPage click_ResetButton() throws Exception{
	    	click_ResetButton.click();
	    	return new CaregiverOverallDetailsPage(driver);
	    }

		 /**
	     * This method is used to verify Continue button.
	     */
	    public CaregiverOverallDetailsPage verifyContinueButton() throws Exception{
	    	Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btn_submit']")) !=null);
	    	return new CaregiverOverallDetailsPage(driver);
	    }
	    
		 /**
	     * This method is used to click on Continue button.
	     */
	    public CaregiverOverallDetailsPage click_ContinueButton() throws Exception{
	    	click_ContinueButton.click();
	    	return new CaregiverOverallDetailsPage(driver);
	    }
	    
  //Popup section.
  		/**
  		 * This method is used to verify Cancel Popup message and No and yes buttons button.
  		 */
  		public CaregiverOverallDetailsPage verifyCancelPopupMessage() throws Exception{
  			assertEquals("This will discard your Secondary Assessment for this session. Do you still want to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  		Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverOverallDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverOverallDetailsPage click_NoButtonOnCancelPopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverOverallDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverOverallDetailsPage click_YesButtonOnCancelPopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverOverallDetailsPage(driver);
  		}
  			    
  		/**
  		 * This method is used to verify Continue Popup message and No and yes buttons button.
  		 */
  		public CaregiverOverallDetailsPage verifyContinuePopupMessage() throws Exception{
  			assertEquals("Not all questions have been answered. Do you wish to continue?", driver.findElement(By.xpath("//*[@id='cancelModalMessage']/p")).getText());
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='no']")) !=null);
  			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='yes']")) !=null);
  			return new CaregiverOverallDetailsPage(driver);
  		}
  		
  		 /**
  		 * This method is used to click on No button on popup message on Cancel
  		 */
  		public CaregiverOverallDetailsPage click_NoButtonOnContinuePopup() throws Exception{
  			click_NoButtonOnPopup.click();
  			return new CaregiverOverallDetailsPage(driver);
  		}
  		
  		/**
  		* This method is used to click on Yes button on popup message on Cancel
  		*/
  		public CaregiverOverallDetailsPage click_YesButtonOnContinuePopup() throws Exception{
  		click_YesButtonOnPopup.click();
  		return new CaregiverOverallDetailsPage(driver);
  		}

  		    /**
  		 * This method is used to verify Reset Popup message for Reset button.
  		 */
  		public CaregiverOverallDetailsPage verifyResetPopupMessage() throws Exception{
  			driver.switchTo().alert();
  			assertEquals("Success: All options in this assessment have been reset.", driver.findElement(By.xpath("//*[@id='alertSuccess']/div/p")).getText());
  			return new CaregiverOverallDetailsPage(driver);
  		}
  		 /**
  		 * This method is used to close Reset Popup message for Reset button.
  		 */
  		public CaregiverOverallDetailsPage click_ResetPopupMessageCloseIcon() throws Exception{
  		driver.switchTo().alert();
  		click_ResetPopupMessageCloseIcon.click();
  		return new CaregiverOverallDetailsPage(driver);
  		}	    
	    
	    
}
