drop table Principals;
drop table GroupMembers;

create table Principals ( name varchar2(32) not null, isuser varchar2(10) not null, password varchar2(32), CONSTRAINT Principals_pk PRIMARY KEY (name,isuser));

create table GroupMembers ( principal varchar2(32) not null, mygroup varchar2(32) not null, CONSTRAINT GroupMembers_pk PRIMARY KEY (principal, mygroup));

