
:: Department of Veterans Affairs
:: Office of Information and Technology (OI&T), Veterans Health Information Technology (VHIT)
:: Security and Other Common Services (S&OCS)
:: Product: Kaajee Security Provider

:: Current Version: 1.1.0.002
:: Target Final Release Version: 1.1

=============================================
       CONTENTS
=============================================

   I.  Introduction
  II.  Change History
 III.  Installation
  IV.  Known Issues and Limitations 

=============================================
I.     Introduction
=============================================

Kaajee Security Provider is a necessary component for KAAJEE as this implements BEA WebLogic's custom Security
Service Provider Interface (SSPI).

WLU KAAJEE provides a replacement plug-in Authentication Provider for BEA WebLogic J2EE servers, and a set of web forms for
web applications, that allow a web application to authenticate and authorize an end-user using a Kernel system
as the source of authentication and authorization.


=============================================
  II.   Change History
=============================================

1.1.0.002:
     :: The original Kaajee Security Provider was based on BEA WebLogic's
        AuthenticationProvider SSPI.  However, as of BEA WebLogic Server 9.2,
        this AuthenticationProvider SSPI has become deprecated.  Therefore,
        as of this build 002, The WLU Kaajee Security Provider implements
        BEA WebLogic's AuthenticationProviderV2 SSPI instead.
        
1.1.0.001:
     :: This version is the first 'AS-IS' Kaajee Security Provider for the WebLogic Upgrade (WLU) project.
        The 'AS-IS' represents bare minimum changes to get the Kaajee Security Provider
        to work on BEA WebLogic Server 9.2 environments.  This 'AS-IS' version will allow our
        stakeholders to continue to develop on a WLS 9.2 platform while we resolve deprecated classes
        and other issues pertaining to the KAAJEE SSPI.

=============================================
 III.   Installation
=============================================

Refer to the available installation documentation on either the VDL or FTP Anonymous directories.


=============================================
 IV.    Known Issues and Limitations 
=============================================

