drop table Principals;
drop table GroupMembers;

create table Principals ( name varchar(32) not null, isuser varchar(10) not null, password varchar(32), CONSTRAINT Principals_pk PRIMARY KEY (name,isuser));

create table GroupMembers ( principal varchar(32) not null, mygroup varchar(32) not null, CONSTRAINT GroupMembers_pk PRIMARY KEY (principal, mygroup));

