package EXT.DOMAIN.pharmacy.ct.query;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Clob;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.hql.QueryTranslator;
import org.hibernate.hql.classic.ClassicQueryTranslatorFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
/**
 * @author rick.bloyer
 * 
 */
public class QueryTextWriter
private static final Logger logger = Logger.getLogger(QueryTextWriter.class);
private static String DEFAULT_DELIMITER = ",";
private static String DEFAULT_FILE_NAME = "query";
private static String DEFAULT_FILE_EXTENSION = ".csv";
public final static String COLUMN = "Column";
public final static String OPERATOR = "Operator";
public final static String OPERAND = "Operand";
public final static String PREDICATE = "Predicate";
private Query query = null;
private String delimiter = null;
private String filePath = null;
private String fileName = null;
private String fileExtension = null;
private boolean includeColumnNames = true;
private HibernateTemplate stagingHibernateTemplate = null;
private HibernateTemplate fdbHibernateTemplate = null;
private SessionFactory stagingSessionFactory = null;
private SessionFactory fdbSessionFactory = null;
/**
 * Create an uninitialized QueryTextWriter object, using default values for:
 * <ul>
 * <li>record delimiter: "," (comma)</li>
 * <li>file name: "query"</li>
 * <li>file extension: ".csv"</li>
 * <li>include column names: true</li>
 * </ul>
 */
public QueryTextWriter()
fileName = DEFAULT_FILE_NAME;
fileExtension = DEFAULT_FILE_EXTENSION;
delimiter = DEFAULT_DELIMITER;
/**
 * Create an initialized QueryTextWriter object, using default values for:
 * <ul>
 * <li>record delimiter: "," (comma)</li>
 * <li>file name: "query"</li>
 * <li>file extension: ".csv"</li>
 * <li>include column names: true</li>
 * </ul>
 * 
 * @param query
 *            object to be executed.
 */
public QueryTextWriter(final Query query)
this.query = query;
fileName = DEFAULT_FILE_NAME;
fileExtension = DEFAULT_FILE_EXTENSION;
delimiter = DEFAULT_DELIMITER;
/**
 * Create an initialized QueryTextWriter object, assigning the file
 * extension given in the fileExtension parameter, and using default values
 * for:
 * <ul>
 * <li>file name: "query"</li>
 * <li>record delimiter: "," (comma)</li>
 * <li>include column names: true</li>
 * </ul>
 * 
 * @param query the HQL query to execute
 * @param fileExtension resulting file's extension
 */
public QueryTextWriter(final Query query, final String fileExtension)
this.query = query;
fileName = DEFAULT_FILE_NAME;
this.fileExtension = fileExtension;
delimiter = DEFAULT_DELIMITER;
/**
 * Create an initialized QueryTextWriter object, assigning the record
 * delimiter, file name, and file extension parameters, and using the
 * default value for:
 * <ul>
 * <li>include column names: true</li>
 * </ul>
 * 
 * @param query the HQL query to execute
 * @param fileExtension resulting file's extension
 * @param filePath the file path for the resulting file
 * @param fileName the file name for the resulting file
 */
public QueryTextWriter(final Query query, final String filePath, final String fileName, final String fileExtension)
this.query = query;
this.filePath = filePath;
this.fileName = fileName;
delimiter = DEFAULT_DELIMITER;
this.fileExtension = fileExtension;
/**
 * Retrieve a delimited file representing the result set of the executed
 * query given in the query parameter. The file format, including delimiter,
 * file name, file extension and the option to include column names in the
 * file depend on setting class field members, or accepting default values
 * when the class is instantiated. A null value will be returned if:
 * <ul>
 * <li>The HQL represented in the query parameter cannot be converted into
 * SQL</li>
 * <li>The result of SQL execution is null</li>
 * <li>Generating delimited content from query execution is null</li>
 * </ul>
 * 
 * @param query object encapsulating the HQL to be executed
 * @return File representing the result set of the executed query
 * @throws Exception
 */
public File getFile(final Query query) throws Exception
if (query == null)
throw new IllegalArgumentException("Required query parameter is null");
// Translate HQL to SQL
String sqlString = getSQLString(query.getHQLQuery(true), query);
if (logger.isDebugEnabled())
logger.debug("Attempting to execute sql query: " + sqlString);
// Execute query to obtain raw result set
List<Object[]> rawList = getQueryResult(sqlString, query);
if (rawList == null || rawList.size() == 0)
if (logger.isDebugEnabled())
logger.debug("Retrieved object list returned null for sql query: " + sqlString);
return null;
// Delimit records with the assigned delimiter
StringBuffer delimitedList = generateDelimitedList(rawList, sqlString);
if (delimitedList == null || delimitedList.length() == 0)
return null;
if (logger.isDebugEnabled())
logger.debug("Attempting to generate query file");
// Create delimited file
return generateFile(delimitedList);
/**
 * Retrieve a delimited file representing the result set of the executed
 * query given in the query parameter. The file format, including delimiter,
 * file name, file extension and the option to include column names in the
 * file depend on setting class field members, or accepting default values
 * when the class is instantiated. A null value will be returned if:
 * <ul>
 * <li>The HQL represented in the query parameter cannot be converted into SQL</li>
 * <li>The result of SQL execution is null</li>
 * <li>Generating delimited content from query execution is null</li>
 * </ul>
 * 
 * @param sqlString HQL to be executed
 * @return File representing the result set of the executed query
 * @throws Exception
 */
public File getFile(final String sqlString)
throws Exception
if (query == null)
throw new IllegalArgumentException("Required query parameter is null");
if (logger.isDebugEnabled())
logger.debug("Attempting to execute sql query: " + sqlString);
// Execute query to obtain raw result set
List<Object[]> rawList = getQueryResult(sqlString, query);
if (rawList == null || rawList.size() == 0)
if (logger.isDebugEnabled())
logger.debug("Retrieved object list returned null for sql query: " + sqlString);
return null;
// Delimit records with the assigned delimiter
StringBuffer delimitedList = generateDelimitedList(rawList, sqlString);
if (delimitedList == null || delimitedList.length() == 0)
return null;
if (logger.isDebugEnabled())
logger.debug("Attempting to generate query file");
// Create delimited file
return generateFile(delimitedList);
public File getFile(final Query query, final String filePath, final String fileName, final String fileExtension)
throws Exception
this.filePath = filePath;
this.fileName = fileName;
this.fileExtension = fileExtension;
return getFile(query);
public File getFile(final String hql, final String filePath, final String fileName, final String fileExtension)
throws Exception
this.filePath = filePath;
this.fileName = fileName;
this.fileExtension = fileExtension;
return getFile(hql);
/**
 * Create a delimited file having the file format, name, and delimiter as
 * given in class field values.
 * 
 * @param delimitedList StringBuffer containing the content to be returned in a file
 * @return File object representing the content as given in the delimitedList parameter
 * @throws Exception
 */
private File generateFile(final StringBuffer delimitedList)
throws Exception
File tmpFile = null;
FileWriter fw = null;
BufferedWriter bw = null;
PrintWriter pw = null;
try
if (logger.isInfoEnabled()) 
logger.info("Attempting to generate query file: " + fileName + "_" + System.currentTimeMillis() + fileExtension);
if (filePath != null)
File path = new File(filePath);
tmpFile = File.createTempFile(fileName + "_" + System.currentTimeMillis(), fileExtension, path);
else
tmpFile = File.createTempFile(fileName + "_" + System.currentTimeMillis(), fileExtension);
fw = new FileWriter(tmpFile);
bw = new BufferedWriter(fw);
pw = new PrintWriter(bw);
pw.print(delimitedList);
pw.flush();
if (logger.isInfoEnabled())
logger.info("Generated query file: " + fileName + "_" + System.currentTimeMillis() + fileExtension);
finally
try
if (pw != null) pw.close();
if (bw != null) bw.close();
if (fw != null) fw.close();
catch (Exception ex)
throw ex;
return tmpFile;
/**
 * Execute the SQL as given in the sqlString parameter using the Hibernate
 * native SQL API.
 * 
 * @param sqlString SQL formatted query to execute
 * @return List containing Object[], each representing individual records
 */
private List<Object[]> getQueryResult(final String sqlString, final Query query)
// Determine if the query is staging or fdb
Class clazz = query.getEntityReturnType();
String pack = clazz.getPackage().getName();
List<Object[]> modelList = null;
if (pack.endsWith("fdb"))
modelList = getFdbSession().createSQLQuery(sqlString).list();
else
modelList = getStagingSession().createSQLQuery(sqlString).list();
if (modelList == null || modelList.size() == 0)
return null;
if (logger.isDebugEnabled())
logger.debug("SQL query execution resulted in a model list of size: " + modelList.size());
return modelList;
/**
 * Convert HQL to SQL using the Hibernate query translator.
 * 
 * @param hqlString HQL formatted query string
 * @return SQL string converted from HQL
 * @throws Exception
 */
private String getSQLString(final String xmlString, final Query query)
throws Exception
if( logger.isDebugEnabled() )
logger.debug("Received for translation XML string: "+xmlString);
Class clazz = query.getEntityReturnType();
Query hqlQuery = createQueryFromXML(xmlString, clazz);
String hqlString = hqlQuery.getHQLQuery(true);
ClassicQueryTranslatorFactory cqtf = new ClassicQueryTranslatorFactory();
QueryTranslator translator = null;
// Determine if the query is staging or fdb
String pack = clazz.getPackage().getName();
if (pack.endsWith("fdb"))
translator = cqtf.createQueryTranslator(hqlString, hqlString, Collections.EMPTY_MAP, (SessionFactoryImplementor) fdbSessionFactory);
else
translator = cqtf.createQueryTranslator(hqlString, hqlString, Collections.EMPTY_MAP, (SessionFactoryImplementor) stagingSessionFactory);
translator.compile(Collections.EMPTY_MAP, false);
String sqlString = translator.getSQLString();
if( logger.isDebugEnabled() )
logger.debug("Generated SQL for XML string: "+sqlString);
return sqlString;
/**
 * Generate a delimited set of records from the modelList List content. If
 * the class member boolean variable "includeColumnNames" is set to true,
 * the column names are extracted from the sqlString parameter and appended
 * to the returned StringBuffer.
 * 
 * @param modelList List containing the content to delimit.
 * @param sqlString String containing the executed SQL that generated the content 
 * 
given in the modelList parameter
 * @return StringBuffer containing a delimited set of records
 * @throws Exception
 */
private StringBuffer generateDelimitedList(final List modelList, final String sqlString)
throws Exception
StringBuffer buf = new StringBuffer();
Iterator rawIter = modelList.iterator();
while (rawIter.hasNext())
Object[] record = (Object[]) rawIter.next();
for (int i = 0; i < record.length; i++)
if (record[i] == null)
buf.append("");
else
// Replace any carriage return new line with space
String rec = record[i].toString().replaceAll("\n", " ");
///.....Shahid ccr 3317 incre 2 build 198.
//this special block is for CLOB field for VA monograph line_text field which is CLOB in database.
if (rec.startsWith("org.hibernate.lob.SerializableClob")){
Clob cl = (Clob) record[i];
StringBuffer strOut = new StringBuffer();
String title;
BufferedReader br = new BufferedReader(cl.getCharacterStream());
while ((title = br.readLine())!=null){
strOut.append(title);
rec = strOut.toString();
br.close();
strOut = null;
//....
rec = rec.replaceAll("\r", " ");
rec = rec.replaceAll(System.getProperty("line.separator"), " ");
rec = rec.replaceAll(",", " ");
if( logger.isDebugEnabled() )
logger.debug("Parsing query object record: "+rec);
buf.append("\""+rec+"\"");
if (i != record.length - 1)
buf.append(delimiter);
buf.append("\n");
//System.out.println("The TEXT IS "+ buf.toString());
if (includeColumnNames)
StringBuffer colBuf = new StringBuffer();
String select = sqlString.substring( sqlString.indexOf("select") + 6, sqlString.lastIndexOf("from"));
if (logger.isDebugEnabled() )
logger.debug("Processing column name record: "+select);
StringTokenizer st = new StringTokenizer(select, ",", false);
String column = null;
String processedCol = null;
while (st.hasMoreTokens())
column = st.nextToken();
if (logger.isDebugEnabled() )
logger.debug("Processing column: "+column);
processedCol = column.substring(column.indexOf(".") + 1);
if( processedCol.indexOf("as") != -1 )
processedCol = processedCol.substring(0, processedCol.indexOf("as"));
if ( processedCol.indexOf("from") != -1 )
processedCol = processedCol.substring(0, processedCol.indexOf("from"));
if (logger.isDebugEnabled() )
logger.debug("Processing column parsed: "+processedCol);
colBuf.append(processedCol.trim());
colBuf.append(delimiter);
// Remove trailing delimiter
colBuf.deleteCharAt(colBuf.length() - 1);
colBuf.append("\n");
buf.insert(0, colBuf.toString());
return buf;
/**
 * Builds a Query Object from a client side XML request.
 * 
 * @param queryAsXML
 * @return Query object required by service layer
 */
public static Query createQueryFromXML(final String queryAsXML, final Class klass)
Query query = null;
if (logger.isDebugEnabled())
logger.debug("Attempting to execute HQL query: " + queryAsXML);
try
Document document = DocumentHelper.parseText(queryAsXML);
query = createQuery(document.getRootElement(), klass);
catch (DocumentException e)
throw new RuntimeException("Unable to Parse XML query: " + queryAsXML, e);
query.setQueryAsXML(queryAsXML);
return query;
private static Query createQuery(final Element root, final Class klass) {
Query query = new Query(klass);
List<Element> conditionEls = root.elements();
for (Element conditonEl : conditionEls) {
Condition condition = parseConditionEl(conditonEl);
query.addCondition(condition);
return query;
private static Condition parseConditionEl(final Element conditionEl)
String column = conditionEl.elementTextTrim(COLUMN);
Operator operator = Operator.valueOfOperator(conditionEl.elementTextTrim(OPERATOR));
String operand = conditionEl.elementTextTrim(OPERAND);
if( operand == null || operand.equals("") || operand.length() == 0)
operand = "''";
Operator predicate = Operator.fromString(conditionEl.elementTextTrim(PREDICATE));
assert column != null;
assert operator != null;
assert operand != null;
assert predicate != null;
return new Condition(column, operator, operand, predicate);
/**
 * Retrieve the Hibernate Session object.
 * 
 * @see EXT.DOMAIN.pharmacy.ct.domain.staging.IBaseHibernateDAO#getSession()
 */
private Session getStagingSession()
return stagingHibernateTemplate.getSessionFactory().getCurrentSession();
/**
 * Retrieve the Hibernate Session object.
 * 
 * @see EXT.DOMAIN.pharmacy.ct.domain.staging.IBaseHibernateDAO#getSession()
 */
private Session getFdbSession()
return fdbHibernateTemplate.getSessionFactory().getCurrentSession();
/**
 * Assign the Hibernate SessionFactory object.
 * 
 * @param stagingSessionFactory the session factory to use
 * @see EXT.DOMAIN.pharmacy.ct.domain.staging.IBaseHibernateDAO#setSessionFactory(org.hibernate.SessionFactory)
 */
public void setStagingSessionFactory( final SessionFactory stagingSessionFactory)
this.stagingSessionFactory = stagingSessionFactory;
stagingHibernateTemplate = new HibernateTemplate(stagingSessionFactory);
/**
 * Retrieve the file extension.
 * 
 * @return File extension assigned.
 */
public String getFileExtension()
return fileExtension;
/**
 * Assign the file extension. The file extension MUST include the file
 * separator character "."
 * 
 * @param fileExtension
 *            including the file separator.
 */
public void setFileExtension(final String fileExtension)
if (fileExtension.startsWith("."))
this.fileExtension = fileExtension;
else
this.fileExtension = "." + fileExtension;
/**
 * Retrieve the file delimiter
 * 
 * @return the file delimiter
 */
public String getDelimiter()
return delimiter;
/**
 * Assign the file delimiter
 * 
 * @param delimiter
 */
public void setDelimiter(final String delimiter)
this.delimiter = delimiter;
/**
 * Retrieve the include column flag. This flag indicates whether or not to
 * append delimited column names as the first row in the returned delimited
 * file.
 * 
 * @return includeColumnNames flag
 */
public boolean isIncludeColumnNames()
return includeColumnNames;
/**
 * Assign the include column names flag;
 * 
 * @param includeColumnNames
 */
public void setIncludeColumnNames(final boolean includeColumnNames)
this.includeColumnNames = includeColumnNames;
/**
 * Retrieve the file name.
 * 
 * @return fileName value
 */
public String getFileName()
return fileName;
/**
 * Assign the file name value.
 * 
 * @param fileName
 */
public void setFileName(final String fileName)
this.fileName = fileName;
public SessionFactory getFdbSessionFactory()
return fdbSessionFactory;
public void setFdbSessionFactory(final SessionFactory fdbSessionFactory)
this.fdbSessionFactory = fdbSessionFactory;
fdbHibernateTemplate = new HibernateTemplate(fdbSessionFactory);
public String getFilePath()
return filePath;
public void setFilePath(final String filePath)
this.filePath = filePath;
