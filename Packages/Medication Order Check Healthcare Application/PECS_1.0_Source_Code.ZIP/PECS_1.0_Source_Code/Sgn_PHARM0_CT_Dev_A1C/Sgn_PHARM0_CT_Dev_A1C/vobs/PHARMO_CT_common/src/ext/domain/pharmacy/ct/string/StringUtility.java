package EXT.DOMAIN.pharmacy.ct.string;
public class StringUtility {
/**
 * Cannot instantiate
 */
private StringUtility() {
super();
/**
 * Convert any null string to an empty string
 * 
 * @param string
 *            String to set to empty, if needed
 * @return the original string or an empty string if the original is null
 */
public static String nullToEmptyString(final String string) {
return string == null ? "" : string;
public static boolean isNullOrEmpty(final String string) {
boolean isNullOrEmpty = true;
if (string != null) {
String trimmedString = string.trim();
if (!trimmedString.equals("")) {
isNullOrEmpty = false;
return isNullOrEmpty;
/**
 * Capitalize the first letter of a word.
 * 
 * @param s
 *            java.lang.String
 */
public static String capitalize(final String s) {
char chars[] = s.toCharArray();
chars[0] = Character.toUpperCase(chars[0]);
return new String(chars);
