/**
 * 
 */
package EXT.DOMAIN.pharmacy.ct.exception;
/**
 * @author susarlan
 *
 */
public class CustomizationServiceException extends RuntimeException
/**
 *
 */
public CustomizationServiceException()
// TODO Auto-generated constructor stub
super();
/**
 *
 */
public CustomizationServiceException(String arg0, Throwable arg1)
super(arg0, arg1);
/**
 *
 */
public CustomizationServiceException(String arg0)
super(arg0);
/**
 *
 */
public CustomizationServiceException(Throwable t)
super(t);
