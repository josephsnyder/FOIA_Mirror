package EXT.DOMAIN.pharmacy.ct.query;
/**
 * @author rick.bloyer
 * 
 */
public class Condition implements Comparable
private int index = 0;
private String column = null;
private Operator operator = null;
private Operator predicate = Operator.AND;
private String operand1 = null;
private String operand2 = null;
private boolean lower = true;
private static String ALPHA_REGEX = "^(?![0-9]+)[0-9a-zA-Z\\s_\\(\\)]+$"; //matches nonempty sequence of alphanumeric characters, low lines (underscores) and spaces
private static String DATE_REGEX = "(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\\d\\d"; // matches mm/dd/yyyy
private static String SELECT_REGEX = "select";
public Condition()
public Condition(final String column, final Operator operator, final String operand1)
this(column, operator, operand1, true);
public Condition(final String column, final Operator operator, final String operand1, boolean lower)
this.lower = lower;
this.column = column;
this.operator = operator;
setOperand1(operand1);
public Condition(final String column, final Operator operator, final String operand1, final Operator predicate)
this(column, operator, operand1, true);
this.predicate = predicate;
public Condition(final String column, final Operator operator, final String operand1, final Operator predicate, boolean lower)
this(column, operator, operand1, lower);
this.predicate = predicate;
public Condition(final int index, final String column, final Operator operator, final String operand1)
this(index, column, operator, operand1, null, true);
public Condition(final int index, final String column, final Operator operator, final String operand1, boolean lower)
this(index, column, operator, operand1, null, lower);
public Condition(final String column, final Operator operator, final String operand1, final String operand2)
this(0, column, operator, operand1, operand2, true);
public Condition(final String column, final Operator operator, final String operand1, final String operand2, boolean lower)
this(0, column, operator, operand1, operand2, lower);
public Condition(final int index, final String column, final Operator operator, final String operand1, final String operand2)
this(index, column, operator, operand1, operand2, true);
public Condition(final int index, final String column, final Operator operator, final String operand1, final String operand2, boolean lower)
this.index = index;
this.column = column;
this.operator = operator;
this.lower = lower;
setOperand1(operand1);
setOperand2(operand2);
public String getCondition()
StringBuffer cond = new StringBuffer();
cond.append(column);
if( lower )
cond.append(")");
cond.append(operator.getFormatted(getOperand1(), getOperand2()));
return cond.toString();
public String getColumn() {
return column;
public void setColumn(final String column) {
this.column = column;
public Operator getOperator() {
return operator;
public String getOperatorFormatted() {
return operator.getFormatted(operand1, operand2);
public void setOperator(final Operator operator) {
this.operator = operator;
public Operator getPredicate() {
return predicate;
public void setPredicate(final Operator predicate) {
this.predicate = predicate;
public void setOperand1(final String operand)
operand1 = operand;
if (operand != null && !operand.contains(SELECT_REGEX))
// if alpha (a word), then enclose in ticks
if (operand.matches(ALPHA_REGEX) || operand.matches(DATE_REGEX))
if( lower )
operand1 = operand1.toLowerCase();
operand1 = "'" + operand1 + "'";
public String getOperand2() {
return operand2;
public void setOperand2(final String operand) {
operand2 = operand;
if (operand != null && !operand.contains(SELECT_REGEX)) {
// if alpha (a word), then enclose in ticks
if (operand.matches(ALPHA_REGEX) || operand.matches(DATE_REGEX))
{ 
if( lower )
operand2 = operand2.toLowerCase();
operand2 = "'" + operand2 + "'";
public int getIndex() {
return index;
public void setIndex(final int index) {
this.index = index;
public int compareTo(final Object obj) throws ClassCastException {
if (!(obj instanceof Condition)) {
throw new ClassCastException("A Condition object is expected.");
int otherIndex = ((Condition) obj).getIndex();
return index - otherIndex;
public String getOperand1() {
return operand1;
public boolean isLower()
return lower;
public void setLower(boolean lower)
this.lower = lower;
public Condition getDeepCopy()
Condition copy = new Condition();
copy.setIndex(this.index);
copy.setColumn(this.column);
copy.setOperator(this.operator);
copy.setPredicate(this.predicate);
copy.setOperand1(this.operand1);
copy.setOperand2(this.operand2);
copy.setLower(this.lower);
return copy;
