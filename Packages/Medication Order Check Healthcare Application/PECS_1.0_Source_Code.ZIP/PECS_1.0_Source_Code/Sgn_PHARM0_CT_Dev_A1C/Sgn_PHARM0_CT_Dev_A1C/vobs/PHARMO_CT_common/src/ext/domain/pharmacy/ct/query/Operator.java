package EXT.DOMAIN.pharmacy.ct.query;
/**
 * @author rick.bloyer
 * 
 */
public final class Operator {
private String operator = null;
private Operator(final String operator) {
this.operator = operator;
// Operators
public static final Operator EQ = new Operator("=");
public static final Operator NEQ = new Operator("<>");
public static final Operator LT = new Operator("<");
public static final Operator LTEQ = new Operator("<=");
public static final Operator GT = new Operator(">");
public static final Operator GTEQ = new Operator(">=");
public static final Operator TEXT_BW = new Operator("like_bw");
public static final Operator TEXT_EW = new Operator("like_ew");
public static final Operator TEXT_CONTAINS = new Operator("like_contains");
public static final Operator IS_NULL = new Operator("is_null");
public static final Operator IS_NOT_NULL = new Operator("is_not_null");
// Predicates
public static final Operator AND = new Operator("and");
public static final Operator OR = new Operator("or");
public static final Operator IN = new Operator("in");
public static final Operator BETWEEN = new Operator("between");
public static final Operator NOT_LIKE = new Operator("not like");
public static final Operator ASC = new Operator("asc");
public static final Operator DESC = new Operator("desc");
@Override
public String toString() {
return operator;
public static Operator fromString(final String operator) {
if (operator == null) {
throw new IllegalArgumentException("required parameter is null");
} else if ("=".equals(operator)) {
return EQ;
} else if ("<>".equals(operator)) {
return NEQ;
} else if ("<".equals(operator)) {
return LT;
} else if ("<=".equals(operator)) {
return LTEQ;
} else if (">".equals(operator)) {
return GT;
} else if (">=".equals(operator)) {
return GTEQ;
} else if ("like_bw".equalsIgnoreCase(operator)) {
return TEXT_BW;
} else if ("like_ew".equalsIgnoreCase(operator)) {
return TEXT_EW;
} else if ("like_contains".equalsIgnoreCase(operator)) {
return TEXT_CONTAINS;
} else if ("and".equalsIgnoreCase(operator)) {
return AND;
} else if ("or".equalsIgnoreCase(operator)) {
return OR;
} else if ("in".equalsIgnoreCase(operator)) {
return IN;
} else if ("between".equalsIgnoreCase(operator)) {
return BETWEEN;
} else if ("not like".equalsIgnoreCase(operator)) {
return NOT_LIKE;
} else if ("asc".equalsIgnoreCase(operator)) {
return ASC;
} else if ("desc".equalsIgnoreCase(operator)) {
return DESC;
} else if ("is_null".equalsIgnoreCase(operator)) {
return IS_NULL;
} else if ("is_not_null".equalsIgnoreCase(operator)) {
return IS_NOT_NULL;
} else {
throw new RuntimeException("the operator as entered: " + operator
+ " is not valid");
public static Operator valueOfOperator(final String operator) {
if (operator == null) {
throw new IllegalArgumentException("required parameter is null");
} else if ("eq".equalsIgnoreCase(operator)) {
return EQ;
} else if ("neq".equalsIgnoreCase(operator)) {
return NEQ;
} else if ("lt".equalsIgnoreCase(operator)) {
return LT;
} else if ("lteq".equalsIgnoreCase(operator)) {
return LTEQ;
} else if ("gt".equalsIgnoreCase(operator)) {
return GT;
} else if ("gteq".equalsIgnoreCase(operator)) {
return GTEQ;
} else if ("like_bw".equalsIgnoreCase(operator)) {
return TEXT_BW;
} else if ("like_ew".equalsIgnoreCase(operator)) {
return TEXT_EW;
} else if ("like_contains".equalsIgnoreCase(operator)) {
return TEXT_CONTAINS;
} else if ("and".equalsIgnoreCase(operator)) {
return AND;
} else if ("or".equalsIgnoreCase(operator)) {
return OR;
} else if ("in".equalsIgnoreCase(operator)) {
return IN;
} else if ("between".equalsIgnoreCase(operator)) {
return BETWEEN;
} else if ("not like".equalsIgnoreCase(operator)) {
return NOT_LIKE;
} else if ("asc".equalsIgnoreCase(operator)) {
return ASC;
} else if ("desc".equalsIgnoreCase(operator)) {
return DESC;
} else if ("is_null".equalsIgnoreCase(operator)) {
return IS_NULL;
} else if ("is_not_null".equalsIgnoreCase(operator)) {
return IS_NOT_NULL;
} else {
throw new RuntimeException("the operator as entered: " + operator
+ " is not valid");
public static String valueOf(final Operator operator) {
if (operator == null) {
throw new IllegalArgumentException("required parameter is null");
} else if (EQ.equals(operator)) {
return "eq";
} else if (NEQ.equals(operator)) {
return "neq";
} else if (LT.equals(operator)) {
return "lt";
} else if (LTEQ.equals(operator)) {
return "lteq";
} else if (GT.equals(operator)) {
return "gt";
} else if (GTEQ.equals(operator)) {
return "gteq";
} else if (TEXT_BW.equals(operator)) {
return "like_bw";
} else if (TEXT_EW.equals(operator)) {
return "like_ew";
} else if (TEXT_CONTAINS.equals(operator)) {
return "like_contains";
} else if (AND.equals(operator)) {
return "and";
} else if (OR.equals(operator)) {
return "or";
} else if (IN.equals(operator)) {
return "in";
} else if (BETWEEN.equals(operator)) {
return "between";
} else if (NOT_LIKE.equals(operator)) {
return "not like";
} else if (ASC.equals(operator)) {
return "asc";
} else if (DESC.equals(operator)) {
return "desc";
} else if (IS_NULL.equals(operator)) {
return "is_null";
} else if (IS_NOT_NULL.equals(operator)) {
return "is_not_null";
} else {
throw new RuntimeException("the operator as entered: " + operator
+ " is not valid");
public String getFormatted(final String operand1) {
return getFormatted(operand1, null);
public String getFormatted(final String operand1, final String operand2) {
if (this == Operator.AND || this == Operator.OR) {
return operand1;
} else if (this == Operator.EQ) {
return " = " + operand1;
} else if (this == Operator.NEQ) {
return " <> " + operand1;
} else if (this == Operator.LT) {
return " < " + operand1;
} else if (this == Operator.LTEQ) {
return " <= " + operand1;
} else if (this == Operator.GT) {
return " > " + operand1;
} else if (this == Operator.GTEQ) {
return " >= " + operand1;
} else if (this == Operator.IN) {
return " in (" + operand1 + ")";
} else if (this == Operator.BETWEEN) {
if (operand2 == null || operand2.equals("")) {
return null;
return " between " + operand1 + " and " + operand2;
else if (this == Operator.TEXT_CONTAINS)
StringBuffer buf = new StringBuffer();
if (operand1.startsWith("'"))
buf.append(" like ");
buf.append(operand1);
buf.insert(buf.indexOf("'") + 1, "%");
buf.insert(buf.lastIndexOf("'"), "%");
else
buf.append(" like '%");
buf.append(operand1);
buf.append("%'");
return buf.toString();
else if (this == Operator.TEXT_BW)
StringBuffer buf = new StringBuffer();
buf.append(" like ");
buf.append(operand1);
if (operand1.startsWith("'")) {
buf.insert(buf.lastIndexOf("'"), "%");
} else {
buf.insert(0, "'");
buf.insert(buf.length() - 1, "%'");
return buf.toString();
} else if (this == Operator.TEXT_EW) {
StringBuffer buf = new StringBuffer();
buf.append(" like ");
buf.append(operand1);
if (operand1.startsWith("'")) {
buf.insert(buf.indexOf("'") + 1, "%");
} else {
buf.insert(0, "'%");
buf.insert(buf.length() - 1, "'");
return buf.toString();
} else if (this == Operator.NOT_LIKE)
StringBuffer buf = new StringBuffer();
if (operand1.startsWith("'"))
buf.append(" not like ");
buf.append(operand1);
buf.insert(buf.indexOf("'") + 1, "%");
buf.insert(buf.lastIndexOf("'"), "%");
else
buf.append(" not like '%");
buf.append(operand1);
buf.append("%'");
return buf.toString();
} else if (this == Operator.ASC) {
return " asc";
} else if (this == Operator.DESC) {
return " desc";
} else if (this == Operator.IS_NULL) {
return " is null";
} else if (this == Operator.IS_NOT_NULL) {
return " is not null";
} else {
return operand1;
