package EXT.DOMAIN.pharmacy.ct.exception;
public class CustomizationReportException extends CustomizationException
/**
 *
 */
public CustomizationReportException()
// TODO Auto-generated constructor stub
super();
/**
 *
 */
public CustomizationReportException(String arg0, Throwable arg1)
super(arg0, arg1);
/**
 *
 */
public CustomizationReportException(String arg0)
super(arg0);
/**
 *
 */
public CustomizationReportException(Throwable t)
super(t);
