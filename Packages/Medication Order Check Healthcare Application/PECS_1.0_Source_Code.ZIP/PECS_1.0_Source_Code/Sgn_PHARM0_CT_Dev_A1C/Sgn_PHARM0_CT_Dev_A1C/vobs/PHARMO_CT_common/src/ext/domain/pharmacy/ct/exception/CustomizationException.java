/**
 * 
 */
package EXT.DOMAIN.pharmacy.ct.exception;
/**
 * @author susarlan
 *
 */
public abstract class CustomizationException extends Exception
/**
 *
 */
public CustomizationException()
// TODO Auto-generated constructor stub
super();
/**
 *
 */
public CustomizationException(String arg0, Throwable arg1)
super(arg0, arg1);
/**
 *
 */
public CustomizationException(String arg0)
super(arg0);
/**
 *
 */
public CustomizationException(Throwable t)
super(t);
